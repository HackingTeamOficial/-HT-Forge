"""HT Forge - Interfaz Web (GUI/API server)."""

__version__ = "2.0.0"
