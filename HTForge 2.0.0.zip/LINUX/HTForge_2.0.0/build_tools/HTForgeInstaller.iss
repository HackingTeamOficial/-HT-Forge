#define MyAppName "HT Forge"
#define MyAppVersion "2.0.0"
#define MyAppPublisher "HT Forge"
#define MyAppExeName "HTForge.exe"

[Setup]
AppId={{B8B3D5C4-2A0E-4D8A-9E72-HTFORGE2000}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\HT Forge
DefaultGroupName=HT Forge
OutputDir=..\dist\installer
OutputBaseFilename=HTForgeInstaller
Compression=lzma
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern

[Files]
Source: "..\dist\HTForge\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\VERSION"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\EDITION.json"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autodesktop}\HT Forge 2.0.0"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Comment: "HT Forge 2.0.0 Unified — DEMO / PRO / PREMIUM"
Name: "{group}\HT Forge 2.0.0"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Iniciar HT Forge"; Flags: nowait postinstall skipifsilent
