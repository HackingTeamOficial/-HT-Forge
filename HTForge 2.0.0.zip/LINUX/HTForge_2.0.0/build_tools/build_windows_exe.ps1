$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $Root

Write-Host 'HT Forge 2.0.0 Unified — Windows build' -ForegroundColor Cyan
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Python 3.11+ no encontrado.' }

python -m venv .build-venv
$Py = Join-Path $Root '.build-venv\Scripts\python.exe'
& $Py -m pip install --upgrade pip
& $Py -m pip install -e . pyinstaller

Remove-Item -Recurse -Force -ErrorAction SilentlyContinue build, dist
& $Py -m PyInstaller --clean --noconfirm build_tools\HTForge.spec

$ISCC = @(
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($ISCC) {
  & $ISCC build_tools\HTForgeInstaller.iss
  Write-Host 'Installer PE generado en dist\installer\HTForgeInstaller.exe' -ForegroundColor Green
} else {
  Write-Host 'PyInstaller terminado. Instala Inno Setup 6 y ejecuta build_tools\HTForgeInstaller.iss para producir el EXE instalable.' -ForegroundColor Yellow
}
