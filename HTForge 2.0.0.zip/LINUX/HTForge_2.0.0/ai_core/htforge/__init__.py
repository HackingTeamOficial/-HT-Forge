"""HT Forge AI Detector Package"""

from .detector_ai import (
    AIAnalyzer,
    DetectionTemplate,
    AIError,
    OllamaProvider,
    VLLMProvider,
    HermesIAProvider,
    ClaudeProvider,
    OpenAIProvider,
    OpencodeProvider,
    ProviderManager,
    generate_sqli_templates,
    generate_idor_templates, 
    generate_rce_templates,
    generate_xss_templates,
    generate_path_traversal_templates,
    generate_ssrf_templates,
    generate_open_redirect_templates,
    generate_ssti_templates,
)

from .ollama_manager import (
    OllamaManager,
    get_ollama_manager,
    ManagedScan,
)

from .template_runner import (
    TemplateRunner,
    TemplateValidator,
)

__all__ = [
    "AIAnalyzer",
    "DetectionTemplate",
    "AIError",
    "OllamaProvider",
    "VLLMProvider",
    "HermesIAProvider",
    "ClaudeProvider",
    "OpenAIProvider",
    "OpencodeProvider",
    "ProviderManager",
    "generate_sqli_templates",
    "generate_idor_templates",
    "generate_rce_templates",
    "generate_xss_templates",
    "generate_path_traversal_templates",
    "generate_ssrf_templates",
    "generate_open_redirect_templates",
    "generate_ssti_templates",
    "OllamaManager",
    "get_ollama_manager",
    "ManagedScan",
    "TemplateRunner",
    "TemplateValidator",
]

__version__ = "2.2.0"