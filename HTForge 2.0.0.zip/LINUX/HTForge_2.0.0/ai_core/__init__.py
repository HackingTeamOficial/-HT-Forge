"""HT Forge AI Core - local-first, read-only AI analysis."""
from .htforge.detector_ai import (
    AIAnalyzer, DetectionTemplate, AIError, OllamaProvider, VLLMProvider,
    HermesIAProvider, ClaudeProvider, OpenAIProvider, OpencodeProvider,
    ProviderManager, generate_sqli_templates, generate_idor_templates,
    generate_rce_templates, generate_xss_templates, generate_path_traversal_templates,
    generate_ssrf_templates, generate_open_redirect_templates, generate_ssti_templates,
)
from dataclasses import dataclass
from urllib.parse import urlparse

@dataclass
class AIConfig:
    base_url: str = "http://127.0.0.1:11434"
    model: str = "hermes3:8b"
    timeout: int = 90
    temperature: float = 0.1
    enabled: bool = True
    allow_actions: bool = False
    def validate(self):
        u=urlparse(self.base_url)
        if u.scheme not in ("http","https") or not u.netloc: raise AIError("URL de Ollama no válida")
        if not 5 <= self.timeout <= 600: raise AIError("Timeout fuera de rango")
        if self.allow_actions: raise AIError("AI actions no están habilitadas: HT Forge AI es read-only.")

from .htforge.ollama_manager import OllamaManager, get_ollama_manager, ManagedScan

__version__ = "2.0.0"

def _extract_json_object(raw):
    """Parse strict JSON plus common fenced/prose LLM responses safely."""
    import json, re
    if isinstance(raw, (dict, list)):
        return raw
    text = str(raw or "").strip().lstrip("\ufeff")
    if not text:
        raise AIError("El modelo no devolvió contenido.")
    text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```\s*$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    for opening, closing in (("{", "}"), ("[", "]")):
        start = text.find(opening)
        while start >= 0:
            depth, quote, escaped = 0, False, False
            for i in range(start, len(text)):
                ch = text[i]
                if quote:
                    if escaped: escaped = False
                    elif ch == "\\": escaped = True
                    elif ch == '"': quote = False
                    continue
                if ch == '"': quote = True
                elif ch == opening: depth += 1
                elif ch == closing:
                    depth -= 1
                    if depth == 0:
                        try: return json.loads(text[start:i+1])
                        except json.JSONDecodeError: break
            start = text.find(opening, start + 1)
    raise AIError("El modelo respondió pero no devolvió JSON válido.")


class AICore:
    """HT Forge AI facade. Ollama is kept alive during scans and AI is read-only."""
    PROVIDER_INFO = {
        "ollama": {"name": "Ollama", "description": "Orquestador local para modelos descargados en el equipo. Recomendado para HT Forge por privacidad y funcionamiento offline.", "local": True},
        "vllm": {"name": "vLLM", "description": "Servidor local de inferencia de alto rendimiento. Adecuado para GPU y modelos grandes.", "local": True},
        "hermes_ia": {"name": "Hermes IA", "description": "Proveedor/orquestador compatible con endpoint local. Úsalo si tienes un servicio Hermes IA separado.", "local": True},
        "opencode": {"name": "OpenCode", "description": "Orquestador/CLI externo. Se mantiene como opción avanzada; no es necesario para el núcleo local de HT Forge.", "local": True},
        "claude": {"name": "Claude", "description": "Proveedor remoto/API. Requiere configuración externa y no es el modo local predeterminado.", "local": False},
        "openai": {"name": "OpenAI", "description": "Proveedor remoto/API. Requiere API y configuración externa.", "local": False},
    }

    def __init__(self, base_url="http://127.0.0.1:11434", model=None, **kwargs):
        # Backward-compatible form: AICore(AIConfig(...), knowledge_root)
        if isinstance(base_url, AIConfig):
            cfg = base_url
            self.base_url = cfg.base_url.rstrip('/')
            if isinstance(model, str) and model:
                self.selected_model = model
            else:
                self.selected_model = cfg.model
            self.timeout = int(cfg.timeout)
            self.auto_smallest = False
        else:
            self.base_url = str(base_url).rstrip('/')
            self.timeout = int(kwargs.get('timeout', 120))
            self.selected_model = model or None
            self.auto_smallest = model in (None, "", "auto", "smallest")
        self.analyzer = AIAnalyzer(config={
            "ollama": {"base_url": self.base_url, "timeout": self.timeout, "enabled": True, "model": model or ""},
            "detection": {"max_templates_per_type": kwargs.get('max_templates_per_type', 5), "min_confidence": kwargs.get('min_confidence', 0.7)},
        })
        if not hasattr(self, 'selected_model'):
            self.selected_model = model or None
        if not hasattr(self, 'auto_smallest'):
            self.auto_smallest = model in (None, "", "auto", "smallest")
        self._select_default_model()

    def _ollama(self):
        return self.analyzer.providers.get('ollama')

    def model_details(self):
        p = self._ollama()
        if not p:
            return []
        try:
            import urllib.request, json
            req = urllib.request.Request(self.base_url + '/api/tags', headers={'Accept':'application/json'})
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read().decode('utf-8'))
            out=[]
            for m in data.get('models') or []:
                if not isinstance(m, dict): continue
                out.append({
                    'name': m.get('name',''), 'size': int(m.get('size') or 0),
                    'size_text': self._human_size(m.get('size') or 0),
                    'modified_at': m.get('modified_at',''), 'digest': m.get('digest',''),
                    'family': (m.get('details') or {}).get('family',''),
                    'parameter_size': (m.get('details') or {}).get('parameter_size',''),
                    'quantization': (m.get('details') or {}).get('quantization_level',''),
                })
            return sorted(out, key=lambda x: (x['size'] if x['size'] else 10**30, x['name']))
        except Exception:
            return []

    @staticmethod
    def _human_size(n):
        n=float(n or 0)
        for u in ('B','KB','MB','GB','TB'):
            if n < 1024: return f'{n:.1f} {u}'
            n/=1024
        return f'{n:.1f} PB'

    def _select_default_model(self):
        models=self.model_details()
        if self.auto_smallest and models:
            self.selected_model=models[0]['name']
        elif self.selected_model and models and self.selected_model not in {m['name'] for m in models}:
            self.selected_model=models[0]['name']
        elif not self.selected_model:
            self.selected_model=(models[0]['name'] if models else 'hermes3:8b')
        if self.selected_model in {m['name'] for m in models}:
            try: self.analyzer.set_model(self.selected_model, 'ollama')
            except Exception: pass

    def status(self):
        models=self.model_details()
        names=[m['name'] for m in models]
        selected=self.selected_model if self.selected_model in names else (models[0]['name'] if models else self.selected_model)
        if selected != self.selected_model and selected:
            self.selected_model=selected
        return {
            'enabled': True, 'provider':'ollama', 'base_url':self.base_url,
            'model':selected, 'auto_smallest':self.auto_smallest,
            'model_available': bool(selected and selected in names), 'models':names,
            'model_details':models,
            'ollama': {'ok': bool(models) or self._health_ok(), 'models':models},
            'read_only':True, 'actions_enabled':False,
            'providers': self.PROVIDER_INFO,
        }

    def _health_ok(self):
        try:
            import urllib.request
            with urllib.request.urlopen(self.base_url + '/api/tags', timeout=3): return True
        except Exception: return False

    def set_model(self, model):
        models={m['name'] for m in self.model_details()}
        if model not in models: raise AIError(f'Modelo no instalado: {model}')
        self.selected_model=model; self.auto_smallest=False
        self.analyzer.set_model(model, 'ollama')
        return self.status()

    def auto_select_smallest(self):
        self.auto_smallest=True
        self._select_default_model()
        return self.status()

    def _generate(self, prompt, system=''):
        p=self._ollama()
        models=self.model_details()
        if not models: raise AIError('Ollama no está disponible o no tiene modelos instalados. Abre Ollama y pulsa «Comprobar Ollama».')
        order=models if self.auto_smallest else sorted(models, key=lambda x: 0 if x['name']==self.selected_model else 1)
        last=''
        for m in order:
            try:
                text=p.generate(prompt, m['name'], system)
                if text.strip():
                    self.selected_model=m['name']
                    return text
            except Exception as exc:
                last=str(exc)
                continue
        raise AIError('Ollama respondió con un error. HT Forge probó los modelos instalados sin ejecutar ninguna acción externa. Detalle: '+last[:300])

    def _generate_json(self, prompt, system, required_keys):
        """Structured local inference with one corrective retry per model."""
        p = self._ollama()
        if not p:
            raise AIError("Proveedor Ollama no disponible.")
        models = self.model_details()
        if not models:
            raise AIError("Ollama no está disponible o no tiene modelos instalados.")
        order = models if self.auto_smallest else sorted(
            models, key=lambda x: 0 if x["name"] == self.selected_model else 1)
        last_error = None
        for m in order:
            for attempt in range(2):
                try:
                    if hasattr(p, "generate_structured"):
                        raw = p.generate_structured(prompt, m["name"], system)
                    else:
                        raw = p.generate(prompt, m["name"], system)
                    obj = _extract_json_object(raw)
                    if not isinstance(obj, dict):
                        raise AIError("La IA devolvió JSON que no es un objeto.")
                    missing = [k for k in required_keys if k not in obj]
                    if missing:
                        raise AIError("JSON incompleto; faltan: " + ", ".join(missing))
                    self.selected_model = m["name"]
                    return obj
                except AIError as exc:
                    last_error = exc
                    if attempt == 0:
                        prompt = prompt + (
                            "\n\nREINTENTO OBLIGATORIO: responde ÚNICAMENTE con un objeto JSON "
                            "válido. No uses Markdown, comentarios ni texto fuera del JSON. "
                            "Incluye todas las claves solicitadas."
                        )
        raise AIError(f"La IA no produjo una respuesta estructurada válida. {last_error}")

    def analyze_finding(self, finding):
        import json
        clean = self._clean(finding)
        prompt = """Analiza SOLO el hallazgo proporcionado por HT Forge. No inventes evidencias.
Devuelve un objeto JSON válido con estas claves:
classification, verdict, confidence, severity, cwe, owasp, cves, cve_status,
affected_component, false_positive_risk, rationale, evidence_used, remediation, references.
verdict: CONFIRMED, LIKELY, INCONCLUSIVE o REFUTED.
confidence: número entre 0 y 1.
evidence_used: lista que SOLO puede citar datos presentes en HALLAZGO.
cves: lista vacía salvo que producto/versión/evidencia permitan una relación sustentada.
cve_status: exact, candidate o none.
No conviertas banners, puertos abiertos, reflejos o rutas interesantes en una vulnerabilidad
confirmada por sí solos.

HALLAZGO:
""" + json.dumps(clean, ensure_ascii=False)
        system = """Eres HT Forge AI Analyst. Eres read-only y defensivo.
Forge Core conserva la autoridad técnica. No puedes modificar el hallazgo original,
crear evidencia, ejecutar acciones, ni afirmar una vulnerabilidad sin evidencia suficiente.
La salida debe ser JSON válido."""
        obj = self._generate_json(prompt, system, [
            "classification","verdict","confidence","severity","evidence_used",
            "rationale","remediation"
        ])
        return self._normalize(obj, clean)

    def summarize_session(self, session):
        import json
        clean = self._clean(session, 18000)
        prompt = """Analiza esta sesión de HT Forge. No inventes vulnerabilidades ni CVE.
Devuelve JSON con: executive_summary, priorities, confirmed_count, inconclusive_count,
false_positive_risks, vulnerability_types, cves, recommendations.
priorities debe ser una lista de objetos con title, severity y reason.
cves solo puede contener candidatos sustentados por producto/versión/evidencia.

SESIÓN:
""" + json.dumps(clean, ensure_ascii=False)
        return self._generate_json(
            prompt,
            "Eres HT Forge AI Analyst, read-only. Forge Core tiene la autoridad técnica.",
            ["executive_summary","priorities","confirmed_count",
             "inconclusive_count","recommendations"]
        )

    @staticmethod
    def _clean(v,limit=12000):
        if isinstance(v,dict): return {str(k)[:100]:AICore._clean(x,limit) for k,x in list(v.items())[:100]}
        if isinstance(v,list): return [AICore._clean(x,limit) for x in v[:100]]
        if isinstance(v,str): return v.replace('\x00','')[:limit]
        return v

    @staticmethod
    def _normalize(r, s):
        verdict = str(r.get("verdict", "INCONCLUSIVE")).upper()
        if verdict not in {"CONFIRMED", "LIKELY", "INCONCLUSIVE", "REFUTED"}:
            verdict = "INCONCLUSIVE"
        try:
            conf = max(0.0, min(1.0, float(r.get("confidence", 0))))
        except (TypeError, ValueError):
            conf = 0.0
        cves = r.get("cves") if isinstance(r.get("cves"), list) else []
        # Forge Core remains authoritative: never replace the scanner's severity.
        source_severity = str(s.get("severity") or "info").lower()
        return {
            "classification": str(r.get("classification") or s.get("type") or "unknown")[:200],
            "verdict": verdict,
            "confidence": conf,
            "severity": source_severity,
            "ai_severity": str(r.get("severity") or source_severity).lower()[:32],
            "cwe": r.get("cwe") or "—",
            "owasp": r.get("owasp") or "—",
            "cves": cves[:20],
            "cve_status": str(r.get("cve_status") or ("candidate" if cves else "none")),
            "affected_component": r.get("affected_component") or "—",
            "false_positive_risk": str(r.get("false_positive_risk") or "unknown")[:100],
            "rationale": str(r.get("rationale") or "")[:5000],
            "evidence_used": r.get("evidence_used") if isinstance(r.get("evidence_used"), list) else [],
            "remediation": str(r.get("remediation") or "")[:5000],
            "references": r.get("references") if isinstance(r.get("references"), list) else [],
            "engine_authority": "HT Forge Forge Core",
            "read_only": True,
        }

__all__=['AIAnalyzer','AICore','AIConfig','DetectionTemplate','AIError','OllamaProvider','VLLMProvider','HermesIAProvider','ClaudeProvider','OpenAIProvider','OpencodeProvider','ProviderManager','generate_sqli_templates','generate_idor_templates','generate_rce_templates','generate_xss_templates','generate_path_traversal_templates','generate_ssrf_templates','generate_open_redirect_templates','generate_ssti_templates','OllamaManager','get_ollama_manager','ManagedScan']
