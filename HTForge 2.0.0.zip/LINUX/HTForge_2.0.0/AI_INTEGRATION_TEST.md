# HT Forge AI Core — prueba de integración

## Resultado

**13/13 tests OK**.

La prueba cubre:

- conexión a un endpoint Ollama compatible;
- detección del modelo `hermes3:8b`;
- generación y parsing de salida JSON;
- normalización de veredicto/confianza;
- recuperación de conocimiento local;
- modo read-only;
- bloqueo explícito de acciones de ejecución.

## Arquitectura probada

`Forge Core → AI Core → Ollama → Hermes 3`

La IA no sustituye la verificación técnica. Los findings siguen perteneciendo a Forge Core y la IA solo recibe evidencia ya producida.

## Prueba real de modelo

En el entorno de empaquetado no había un servicio Ollama local activo, por lo que la prueba automatizada utiliza un servidor compatible simulado para verificar el protocolo y la seguridad de la integración.

En Windows/Linux con Ollama instalado se puede ejecutar:

```powershell
ollama pull hermes3:8b
```

Después, HT Forge mostrará en **HT Forge AI** si Ollama está conectado y si el modelo está disponible.
