import unittest
from core.vulnlab_benchmark import run_vulnlab_benchmark
from core.evidence_graph import build_evidence_graph

class VulnLabBenchmarkTests(unittest.TestCase):
    def test_local_fixture_benchmark_metrics(self):
        result = run_vulnlab_benchmark()
        self.assertEqual(result['aggregate']['cases'], 20)
        self.assertEqual(result['aggregate']['FP'], 0)
        self.assertEqual(result['aggregate']['FN'], 0)
        self.assertEqual(result['aggregate']['TP'], 10)
        self.assertEqual(result['aggregate']['TN'], 10)
        self.assertEqual(len(result['metrics']), 5)
        self.assertIn('no external traffic', result['scope'])

    def test_graph_redacts_query_and_raw_secrets(self):
        graph = build_evidence_graph([{
            'type':'test', 'title':'Test finding', 'url':'https://example.invalid/path?token=SECRET',
            'verification_state':'CANDIDATE', 'evidence':{'response_excerpt':'SECRET_RESPONSE', 'matched_signature':'test'}
        }])
        serialized = str(graph)
        self.assertNotIn('token=SECRET', serialized)
        self.assertNotIn('SECRET_RESPONSE', serialized)
        self.assertIn('supported_by', serialized)
        self.assertGreater(graph['node_count'], 1)

    def test_graph_adds_contextual_correlation_edges_without_claiming_exploit_chain(self):
        graph = build_evidence_graph([
            {'type': 'sqli', 'title': 'SQLi', 'url': 'https://example.invalid/search?id=1', 'parameter': 'id', 'technology': 'PHP'},
            {'type': 'xss', 'title': 'XSS', 'url': 'https://example.invalid/search?q=2', 'parameter': 'q', 'technology': 'PHP'},
            {'type': 'idor', 'title': 'IDOR', 'url': 'https://example.invalid/profile', 'parameter': 'id', 'technology': 'PHP'},
        ])
        relations = [e['relation'] for e in graph['edges']]
        self.assertIn('same_endpoint', relations)
        self.assertIn('same_technology', relations)
        self.assertEqual(graph['summary']['correlations']['same_endpoint'], 1)
        self.assertIn('Shared context only', graph['summary']['correlation_semantics'])
        self.assertTrue(all(e.get('correlation') == 'contextual_only' for e in graph['edges'] if e['relation'].startswith('same_')))

    def test_graph_redacts_userinfo_and_keeps_duplicate_findings_distinct(self):
        graph = build_evidence_graph([
            {'type': 'xss', 'title': 'Same', 'url': 'https://user:password@example.invalid/a?token=secret'},
            {'type': 'xss', 'title': 'Same', 'url': 'https://user:password@example.invalid/a?token=secret'},
        ])
        serialized = str(graph)
        self.assertNotIn('user:password', serialized)
        self.assertNotIn('token=secret', serialized)
        self.assertEqual(sum(1 for n in graph['nodes'] if n['kind'] == 'finding'), 2)

    def test_graph_correlates_sqli_xss_parameters_and_states_without_raw_payloads(self):
        graph = build_evidence_graph([
            {'type':'sqli', 'title':'SQL injection candidate', 'module':'sqli', 'url':'https://example.invalid/item?id=7&token=secret', 'parameter':'id', 'severity':'high', 'verification_state':'VERIFIED', 'confidence':0.91, 'evidence':{'technique':'boolean-differential','payload':'SECRET_PAYLOAD','response_excerpt':'SECRET_BODY','matched_signature':'SQLSTATE'}},
            {'type':'xss_reflected', 'title':'Reflected XSS', 'module':'xss', 'url':'https://example.invalid/search?q=secret', 'parameter':'q', 'severity':'medium', 'verification_state':'CANDIDATE', 'confidence':0.62, 'evidence':{'reflection_context':'html_text','marker':'SECRET_MARKER'}},
        ])
        kinds = {n['kind'] for n in graph['nodes']}
        self.assertTrue({'finding','endpoint','parameter','technique','evidence'} <= kinds)
        self.assertIn('tests_parameter', {e['relation'] for e in graph['edges']})
        self.assertEqual(graph['summary']['by_type'], {'sqli':1, 'xss_reflected':1})
        serialized = str(graph)
        for secret in ('SECRET_PAYLOAD','SECRET_BODY','SECRET_MARKER','token=secret','q=secret'):
            self.assertNotIn(secret, serialized)

if __name__ == '__main__': unittest.main()
