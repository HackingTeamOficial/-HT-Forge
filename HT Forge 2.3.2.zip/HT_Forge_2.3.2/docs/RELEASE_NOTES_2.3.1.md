# HT Forge 2.3.1 — Evidence Graph Correlation

## Cambios

- Añade relaciones contextuales entre hallazgos que comparten endpoint, parámetro o tecnología.
- La interfaz muestra los contadores de correlación y permite inspeccionar las relaciones encontradas.
- Cada correlación se etiqueta como contexto compartido; no se presenta como prueba de causalidad ni como cadena de explotación.
- Mejora la protección de datos sensibles: se excluyen credenciales de URL, query strings, fragmentos y valores de evidencia.
- Evita fusionar hallazgos distintos solo porque comparten título, tipo y endpoint.
- Limita el tamaño máximo de entrada del grafo y acota las correlaciones para evitar crecimiento excesivo.
- Añade pruebas automatizadas para correlación, privacidad y preservación de hallazgos duplicados.

## Validación

- `python -m unittest discover -v`: 17 pruebas superadas.
- `python -m compileall -q core ui tests`: completado sin errores.
- Validación de sintaxis JavaScript inline con `node --check`: completada.
- Las pruebas usan fixtures locales; no se realizó tráfico hacia sistemas externos.

## Limitaciones

Las relaciones son contextuales y no prueban que exista una vulnerabilidad ni una cadena de ataque. La validación de detectores reales requiere ampliar el corpus de laboratorios y no puede inferirse únicamente de estas pruebas unitarias.
