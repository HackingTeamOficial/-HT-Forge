# HT Forge 2.3.2 — Grafo de Superficie de Ataque

## Novedad principal

### Grafo de Superficie de Ataque interactivo

Nueva vista «Grafo de Ataque» con las mismas capacidades del grafo de HunterBug:

- **VisualizaciónForce-directed** (Fruchterman-Reingold) de la superficie de ataque.
- **Tipos de nodo**: objetivo, dominio, subdominio, IP, puerto, servicio, tecnología, endpoint, parámetro, CVE y hallazgo.
- **Colores por tipo** y severidad (crítico, alto, medio, bajo, info).
- **Zoom** con rueda del ratón (0.25x – 3.5x).
- **Arrastre/pan** con botón izquierdo.
- **Selección de nodo** con clic: muestra tipo, etiqueta, severidad, estado, módulo, conexiones y detalle.
- **Reorganizar**: recálculo del layout en el navegador.
- **Analizar nodo con IA**: envía el nodo seleccionado al analista de HT Forge AI Core (read-only).
- **Analizar grafo con IA**: envía el resumen textual de la superficie de ataque al analista.
- **Generación por sesión**: selector de sesiones o sesión actual.

## Backend

- `core/attack_graph.py`: constructor de grafo, layout dirigido por fuerzas, resumen para IA y análisis de nodo.
- Endpoints: `POST /api/attack-graph`, `POST /api/graph-node-analyze`, `POST /api/graph-analyze`.
- Privacidad: solo se serializan campos no sensibles; nunca se exponen valores de evidencia crudos.

## Licencia DEMO

- La edición **DEMO queda siempre operativa**: si la ventana de evaluación expira, se renueva automáticamente al iniciar, sin mostrar el aviso de «La DEMO de 24 horas ha expirado».
- El **acceso es completo** en DEMO: HT Brute Force ya no exige PREMIUM, basta una licencia válida.

## Notas

- No se modificó la funcionalidad existente (Evidence Graph textual, IA de hallazgos, escaneo, informes).
- Requiere Ollama activo para las funciones de IA del grafo.
