# PTT — ATT&CK Task Tree
**Target:** HT_Forge_2.3.1 | **Started:** 2026-11-14T22:57:33.368Z | **Updated:** 2026-11-14T22:57:33.368Z
**ATT&CK Catalog:** Enterprise v19.1
**OPSEC Level:** balanced
**Autonomy Level:** medium

> This file contains only ATT&CK-mapped technical tasks. Engagement scope,
> rules of engagement, evidence, reports, and cleanup live in their managed
> records and Skills.

## TA0043 Reconnaissance

## TA0042 Resource Development

## TA0001 Initial Access

## TA0002 Execution

## TA0003 Persistence

## TA0004 Privilege Escalation

## TA0005 Stealth

## TA0112 Defense Impairment

## TA0006 Credential Access

## TA0007 Discovery

## TA0008 Lateral Movement

## TA0009 Collection

## TA0011 Command and Control

## TA0010 Exfiltration

## TA0040 Impact
