"""HT Forge - Grafo de superficie de ataque.

Construye un grafo visual de nodos/aristas a partir de los hallazgos y datos
de la sesion, inspirado en el modelo de HunterBug: objetivo, dominio,
subdominio, IP, puerto, servicio, tecnologia, endpoint, parametro, CVE y
hallazgo. Incluye layout dirigido por fuerzas (Fruchterman-Reingold) para
dibujarlo en el lienzo del navegador y un resumen textual para la IA.

Solo usa campos no sensibles (nunca serializa valores de evidencia crudos).
"""
from __future__ import annotations

import math
import random
from typing import Any
from urllib.parse import urlsplit

TIPOS_NODO = {
    "objetivo":   {"color": "#00ff41", "radius": 26, "label": "Objetivo"},
    "dominio":    {"color": "#00d4ff", "radius": 20, "label": "Dominio"},
    "subdominio": {"color": "#3399ff", "radius": 17, "label": "Subdominio"},
    "ip":         {"color": "#a78bfa", "radius": 18, "label": "IP"},
    "puerto":     {"color": "#fbbf24", "radius": 15, "label": "Puerto"},
    "servicio":   {"color": "#fb923c", "radius": 15, "label": "Servicio"},
    "tecnologia": {"color": "#38bdf8", "radius": 15, "label": "Tecnologia"},
    "endpoint":   {"color": "#94a3b8", "radius": 13, "label": "Endpoint"},
    "parametro":  {"color": "#cbd5e1", "radius": 11, "label": "Parametro"},
    "cve":        {"color": "#ff3333", "radius": 17, "label": "CVE"},
    "hallazgo":   {"color": "#ff9900", "radius": 15, "label": "Hallazgo"},
}

SEVERIDAD_COLOR = {
    "critico": "#ff2222", "critical": "#ff2222",
    "alto": "#ff6600", "high": "#ff6600",
    "medio": "#ffcc00", "medium": "#ffcc00",
    "bajo": "#66cc66", "low": "#66cc66",
    "info": "#8899aa",
}


class AttackGraph:
    """Grafo dirigido ligero con identificadores estables."""

    def __init__(self):
        self.nodes: dict[str, dict] = {}
        self.edges: list[dict] = []
        self._edge_keys: set[tuple] = set()

    def node(self, nid: str, kind: str, label: str, **data) -> str:
        if nid not in self.nodes:
            self.nodes[nid] = {"id": nid, "kind": kind, "label": str(label)[:180],
                               "data": dict(data), "degree": 0}
        else:
            self.nodes[nid]["data"].update(data)
            if label and not self.nodes[nid]["label"]:
                self.nodes[nid]["label"] = str(label)[:180]
        return nid

    def edge(self, source: str, target: str, relation: str = "relacion", label: str = "") -> None:
        if source not in self.nodes or target not in self.nodes:
            return
        key = (source, target, relation)
        if key in self._edge_keys:
            return
        self._edge_keys.add(key)
        self.edges.append({"source": source, "target": target,
                           "relation": relation, "label": label})
        self.nodes[source]["degree"] += 1
        self.nodes[target]["degree"] += 1

    @staticmethod
    def nid(kind: str, value: Any) -> str:
        return "%s:%s" % (kind, str(value).strip().lower())

    def clear(self) -> None:
        self.nodes.clear()
        self.edges.clear()
        self._edge_keys.clear()

    # ---- consultas ----

    def by_kind(self, kind: str) -> list[dict]:
        return [n for n in self.nodes.values() if n["kind"] == kind]

    def count_by_kind(self) -> dict:
        counts: dict[str, int] = {}
        for n in self.nodes.values():
            counts[n["kind"]] = counts.get(n["kind"], 0) + 1
        return counts

    def findings(self) -> list[dict]:
        return self.by_kind("hallazgo")

    def summary(self) -> dict:
        c = self.count_by_kind()
        return {"nodes": len(self.nodes), "edges": len(self.edges), "by_kind": c}

    # ---- layout ----

    def force_layout(self, width: float = 1200.0, height: float = 700.0,
                     iterations: int = 280, seed: int = 7) -> dict[str, tuple[float, float]]:
        """Fruchterman-Reingold simplificado. Devuelve {id: (x, y)}."""
        rnd = random.Random(seed)
        ids = list(self.nodes.keys())
        if not ids:
            return {}
        n = len(ids)
        pos = {i: [rnd.uniform(0, width), rnd.uniform(0, height)] for i in ids}

        area = width * height
        k = math.sqrt(area / max(1, n)) * 0.75
        temp = width * 0.10

        adj: dict[str, list[str]] = {i: [] for i in ids}
        for e in self.edges:
            if e["source"] in adj and e["target"] in adj:
                adj[e["source"]].append(e["target"])
                adj[e["target"]].append(e["source"])

        for _ in range(iterations):
            disp = {i: [0.0, 0.0] for i in ids}

            for idx_a in range(n):
                ia = ids[idx_a]
                for idx_b in range(idx_a + 1, n):
                    ib = ids[idx_b]
                    dx = pos[ia][0] - pos[ib][0]
                    dy = pos[ia][1] - pos[ib][1]
                    d2 = dx * dx + dy * dy
                    if d2 < 0.01:
                        dx, dy, d2 = rnd.uniform(-1, 1), rnd.uniform(-1, 1), 0.01
                    d = math.sqrt(d2)
                    f = (k * k) / d
                    ux, uy = dx / d, dy / d
                    disp[ia][0] += ux * f
                    disp[ia][1] += uy * f
                    disp[ib][0] -= ux * f
                    disp[ib][1] -= uy * f

            for e in self.edges:
                ia, ib = e["source"], e["target"]
                if ia not in pos or ib not in pos:
                    continue
                dx = pos[ia][0] - pos[ib][0]
                dy = pos[ia][1] - pos[ib][1]
                d = math.sqrt(dx * dx + dy * dy) or 0.01
                f = (d * d) / k
                ux, uy = dx / d, dy / d
                disp[ia][0] -= ux * f
                disp[ia][1] -= uy * f
                disp[ib][0] += ux * f
                disp[ib][1] += uy * f

            for i in ids:
                disp[i][0] += (width / 2 - pos[i][0]) * 0.008
                disp[i][1] += (height / 2 - pos[i][1]) * 0.008

            for i in ids:
                dx, dy = disp[i]
                d = math.sqrt(dx * dx + dy * dy) or 0.01
                lim = min(d, temp)
                pos[i][0] += (dx / d) * lim
                pos[i][1] += (dy / d) * lim
                pos[i][0] = max(30, min(width - 30, pos[i][0]))
                pos[i][1] = max(30, min(height - 30, pos[i][1]))
            temp *= 0.985

        return {i: (pos[i][0], pos[i][1]) for i in ids}

    # ---- resumen para la IA ----

    def ai_summary(self, max_findings: int = 40) -> str:
        lines = ["SUPERFICIE DE ATAQUE OBSERVADA"]
        c = self.count_by_kind()
        lines.append("Nodos: %d | Aristas: %d | Detalle: %s"
                     % (len(self.nodes), len(self.edges),
                        ", ".join("%s=%d" % (k, v) for k, v in sorted(c.items()))))

        for kind in ("dominio", "subdominio", "ip", "puerto", "servicio", "tecnologia"):
            items = self.by_kind(kind)
            if items:
                vals = ", ".join(sorted({n["label"] for n in items})[:25])
                lines.append("- %s (%d): %s" % (kind, len(items), vals))

        findings = self.findings()
        if findings:
            order = {"critico": 0, "critical": 0, "alto": 1, "high": 1,
                     "medio": 2, "medium": 2, "bajo": 3, "low": 3, "info": 4}
            findings = sorted(findings,
                              key=lambda h: order.get(str(h["data"].get("severidad", "info")).lower(), 5))
            lines.append("HALLAZGOS (%d), ordenados por severidad:" % len(findings))
            for h in findings[:max_findings]:
                d = h["data"]
                lines.append("  [%s] %s | %s"
                             % (str(d.get("severidad", "")).upper(),
                                d.get("titulo", h["label"]),
                                str(d.get("detalle", ""))[:180]))
        else:
            lines.append("HALLAZGOS: ninguno todavia")
        return "\n".join(lines)


def _safe_host(url: str) -> str:
    """Devuelve host[:puerto] sin credenciales ni ruta; vacio si no es valido."""
    try:
        p = urlsplit(str(url))
        if p.scheme.lower() not in ("http", "https") or not p.hostname:
            return ""
        host = p.hostname.encode("idna").decode("ascii").lower().rstrip(".")
        try:
            port = p.port
        except ValueError:
            return ""
        if port and not ((p.scheme.lower() == "http" and port == 80) or
                         (p.scheme.lower() == "https" and port == 443)):
            host += ":%d" % port
        return host
    except Exception:
        return ""


def build_attack_graph(session: dict, max_findings: int = 400) -> dict:
    """Construye el grafo de superficie de ataque desde una sesion de HT Forge."""
    g = AttackGraph()
    findings_raw = session.get("findings") if isinstance(session.get("findings"), list) else []
    target = str(session.get("target") or "").strip()
    if not target and findings_raw:
        for f in findings_raw[:50]:
            if isinstance(f, dict):
                target = str(f.get("url") or "").strip()
                if target:
                    break
    target = _safe_host(target) or target[:80]

    nid_obj = g.node(g.nid("objetivo", target or "objetivo"), "objetivo", target or "Objetivo")

    if target:
        nid_dom = g.node(g.nid("dominio", target), "dominio", target)
        g.edge(nid_obj, nid_dom, "resuelve")

    used = 0
    for f in findings_raw[:max(1, min(2000, int(max_findings)))]:
        if not isinstance(f, dict):
            continue
        used += 1
        title = str(f.get("title") or f.get("type") or "Hallazgo")[:180]
        sev = str(f.get("severity") or "info").lower()[:30]
        state = str(f.get("verification_state") or "CANDIDATE").upper()[:40]
        module = str(f.get("module") or f.get("type") or "unknown")[:100]
        raw_url = f.get("url") or f.get("endpoint") or ""
        ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
        param = str(f.get("parameter") or f.get("param")
                    or ev.get("parameter") or ev.get("param") or "").strip()[:100]
        technology = str(f.get("technology") or ev.get("technology") or "").strip()[:100]

        fid = g.node(g.nid("hallazgo", "%d|%s|%s" % (used, title, raw_url)), "hallazgo", title,
                     severidad=sev, estado=state, modulo=module,
                     detalle=str(f.get("detail") or "")[:400],
                     url=str(raw_url)[:300])
        g.edge(nid_obj, fid, "hallazgo")

        if raw_url:
            host = _safe_host(raw_url)
            if host:
                nid_ep = g.node(g.nid("endpoint", raw_url), "endpoint", str(raw_url)[:120])
                g.edge(fid, nid_ep, "observed_at")
                if host != target:
                    nid_h = g.node(g.nid("dominio", host), "dominio", host)
                    g.edge(nid_obj, nid_h, "resuelve")
            if ":" in raw_url and raw_url.split(":")[-1].isdigit():
                port = raw_url.split(":")[-1]
                nid_p = g.node(g.nid("puerto", "%s:%s" % (host or target, port)),
                               "puerto", "tcp/%s" % port)
                g.edge(nid_obj, nid_p, "expone")

        if param:
            nid_par = g.node(g.nid("parametro", ("%s|%s" % (raw_url, param)).lower()),
                             "parametro", param)
            g.edge(fid, nid_par, "tests_parameter")

        if technology:
            nid_t = g.node(g.nid("tecnologia", technology.lower()), "tecnologia", technology)
            g.edge(fid, nid_t, "associated_with")

        cve = ev.get("cve") or f.get("cve")
        if cve:
            nid_c = g.node(g.nid("cve", cve), "cve", str(cve))
            g.edge(fid, nid_c, "cve")

    positions = g.force_layout()
    return {
        "ok": True,
        "graph_type": "attack_surface_graph",
        "target": target,
        "finding_count": used,
        "node_count": len(g.nodes),
        "edge_count": len(g.edges),
        "nodes": [
            {
                "id": n["id"],
                "kind": n["kind"],
                "label": n["label"],
                "degree": n["degree"],
                "color": SEVERIDAD_COLOR.get(str(n["data"].get("severidad", "")).lower(),
                                             TIPOS_NODO.get(n["kind"], {}).get("color", "#888")),
                "data": {k: v for k, v in n["data"].items()
                         if k in ("severidad", "estado", "modulo", "detalle", "url")},
                "position": list(positions.get(n["id"], (0.0, 0.0))),
            }
            for n in g.nodes.values()
        ],
        "edges": g.edges,
        "summary": g.summary(),
        "ai_summary": g.ai_summary(),
        "privacy": "Solo se incluyen campos no sensibles; nunca se serializan valores de evidencia crudos.",
    }


def analyze_node_with_ai(node: dict) -> dict:
    """Prepara un hallazgo sintetico a partir de un nodo para el analisis de IA."""
    if not isinstance(node, dict):
        return {"error": "nodo invalido"}
    data = node.get("data") if isinstance(node.get("data"), dict) else {}
    kind = str(node.get("kind") or "")
    title = str(node.get("label") or "Nodo")
    pseudo_finding = {
        "type": str(data.get("modulo") or kind or "graph_node"),
        "severity": str(data.get("severidad") or "info"),
        "title": title,
        "detail": str(data.get("detalle") or "Nodo del grafo de superficie de ataque."),
        "url": str(data.get("url") or ""),
        "parameter": "",
        "verification_state": str(data.get("estado") or "CANDIDATE"),
        "evidence": {
            "technique": "graph_analysis",
            "node_kind": kind,
            "node_degree": node.get("degree", 0),
        },
    }
    return pseudo_finding
