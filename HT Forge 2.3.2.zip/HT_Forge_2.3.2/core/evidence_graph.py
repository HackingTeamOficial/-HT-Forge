"""Build a deterministic, privacy-preserving graph of findings and evidence.

Correlation edges describe shared observations only; they are not proof of an
exploit chain and never alter a finding's verification state or severity.
"""
from __future__ import annotations

from hashlib import sha256
from typing import Any
from urllib.parse import urlsplit

SENSITIVE_KEYS = {
    "request", "response", "request_body", "response_body", "cookie",
    "authorization", "token", "password", "secret", "payload", "snippet",
    "raw_reflection", "response_excerpt", "mutated_excerpt", "headers",
    "api_key", "access_token", "session", "sessionid", "credential",
}


def _id(kind: str, value: str) -> str:
    return kind + "_" + sha256((kind + "\0" + value).encode("utf-8", "replace")).hexdigest()[:12]


def _safe_endpoint(url: str) -> str:
    """Return scheme/host/path only; discard credentials, query and fragment."""
    try:
        p = urlsplit(str(url))
        if p.scheme.lower() not in ("http", "https") or not p.hostname:
            return ""
        host = p.hostname.encode("idna").decode("ascii").lower().rstrip(".")
        # Avoid leaking malformed ports and reject control characters.
        try:
            port = p.port
        except ValueError:
            return ""
        if port and not ((p.scheme.lower() == "http" and port == 80) or
                         (p.scheme.lower() == "https" and port == 443)):
            host += f":{port}"
        path = p.path or "/"
        path = path[:160]
        if any(ord(c) < 32 for c in host + path):
            return ""
        return (p.scheme.lower() + "://" + host + path)[:220]
    except Exception:
        return ""


def _counts(findings, key, limit, default="unknown"):
    counts = {}
    for finding in (findings or [])[:max(0, int(limit))]:
        if not isinstance(finding, dict):
            continue
        value = str(finding.get(key) or default).lower()[:80]
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items()))


def build_evidence_graph(findings: list[dict[str, Any]], max_findings: int = 300) -> dict[str, Any]:
    """Build graph nodes, direct evidence links and conservative correlations.

    `same_endpoint`, `same_parameter` and `same_technology` are contextual
    relationships only. They do not imply exploitability or causal linkage.
    """
    try:
        limit = max(0, min(2000, int(max_findings)))
    except (TypeError, ValueError):
        limit = 300
    source = findings if isinstance(findings, list) else []
    selected = source[:limit]
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[tuple[str, str, str], dict[str, Any]] = {}
    finding_meta: list[dict[str, Any]] = []

    def node(kind: str, value: str, label: str, **extra) -> str:
        key = _id(kind, str(value))
        if key not in nodes:
            nodes[key] = {"id": key, "kind": kind, "label": str(label)[:180], **extra}
        return key

    def edge(src: str, dst: str, relation: str, **extra) -> None:
        if src == dst:
            return
        key = (src, dst, relation)
        edges.setdefault(key, {"source": src, "target": dst, "relation": relation, **extra})

    used = 0
    for index, f in enumerate(selected):
        if not isinstance(f, dict):
            continue
        used += 1
        ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
        title = str(f.get("title") or f.get("type") or "Finding")[:180]
        typ = str(f.get("type") or f.get("module") or "unknown").strip().lower()[:100]
        raw_url = f.get("url") or f.get("endpoint") or ev.get("url") or ""
        safe_url = _safe_endpoint(str(raw_url))
        param = str(f.get("parameter") or f.get("param") or ev.get("parameter") or ev.get("param") or "").strip()[:100]
        technique = str(ev.get("technique") or f.get("technique") or typ).strip()[:100]
        state = str(f.get("verification_state") or "CANDIDATE").upper()[:40]
        severity = str(f.get("severity") or "info").lower()[:30]
        confidence = f.get("confidence")
        try:
            confidence = round(max(0.0, min(1.0, float(confidence))), 3) if confidence is not None else None
        except (TypeError, ValueError):
            confidence = None

        # Include stable per-record discriminator to avoid merging separate findings
        # that happen to share a title, endpoint, parameter and type.
        fid = node("finding", f"{index}|{title}|{safe_url}|{param}|{typ}", title,
                   state=state, severity=severity, module=str(f.get("module") or typ)[:100],
                   finding_type=typ, confidence=confidence)
        tech_node = ""
        if safe_url:
            uid = node("endpoint", safe_url, safe_url)
            edge(fid, uid, "observed_at")
        else:
            uid = ""
        if param:
            pid = node("parameter", (safe_url + "|" + param).lower(), param)
            edge(fid, pid, "tests_parameter")
            if uid:
                edge(pid, uid, "belongs_to")
        if technique:
            tid = node("technique", technique.lower(), technique)
            edge(fid, tid, "detected_by")
        technology = str(f.get("technology") or ev.get("technology") or "").strip()[:100]
        if technology:
            tech_node = node("technology", technology.lower(), technology)
            edge(fid, tech_node, "associated_with")

        # Graph only evidence field names/types; never serialize evidence values.
        evkeys = [k for k, v in ev.items()
                  if v not in (None, "", [], {}) and str(k).lower() not in SENSITIVE_KEYS
                  and not any(secret in str(k).lower() for secret in ("password", "token", "secret", "cookie", "credential", "payload"))]
        for key in sorted(evkeys)[:16]:
            value_type = type(ev[key]).__name__
            eid = node("evidence", str(key) + ":" + value_type,
                       str(key).replace("_", " ").title(), field=str(key)[:80], value_type=value_type)
            edge(fid, eid, "supported_by")
        finding_meta.append({"id": fid, "endpoint": safe_url, "parameter": param.casefold(),
                             "technology": technology.casefold(), "type": typ,
                             "state": state, "severity": severity})

    # Conservative correlation edges: shared context only, with explicit labels.
    # Indexing keeps the work bounded rather than comparing every pair blindly.
    by_endpoint: dict[str, list[dict[str, Any]]] = {}
    by_parameter: dict[tuple[str, str], list[dict[str, Any]]] = {}
    by_technology: dict[str, list[dict[str, Any]]] = {}
    for item in finding_meta:
        if item["endpoint"]:
            by_endpoint.setdefault(item["endpoint"], []).append(item)
            if item["parameter"]:
                by_parameter.setdefault((item["endpoint"], item["parameter"]), []).append(item)
        if item["technology"]:
            by_technology.setdefault(item["technology"], []).append(item)

    correlation_counts = {"same_endpoint": 0, "same_parameter": 0, "same_technology": 0}
    def connect_group(group, relation, cap=5000):
        pairs = 0
        for group_items in group.values():
            # Same node is excluded. Cap avoids pathological quadratic graphs.
            for i, left in enumerate(group_items):
                for right in group_items[i + 1:]:
                    if left["id"] == right["id"]:
                        continue
                    if pairs >= cap:
                        return pairs
                    edge(left["id"], right["id"], relation,
                         correlation="contextual_only", evidence_basis=relation)
                    pairs += 1
        return pairs

    correlation_counts["same_endpoint"] = connect_group(by_endpoint, "same_endpoint")
    correlation_counts["same_parameter"] = connect_group(by_parameter, "same_parameter")
    correlation_counts["same_technology"] = connect_group(by_technology, "same_technology")

    valid_findings = [f for f in selected if isinstance(f, dict)]
    with_parameter = sum(1 for f in valid_findings if (f.get("parameter") or f.get("param") or
                         (isinstance(f.get("evidence"), dict) and
                          (f["evidence"].get("parameter") or f["evidence"].get("param")))))
    return {
        "ok": True,
        "graph_type": "sanitized_evidence_graph",
        "finding_count": used,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "nodes": list(nodes.values()),
        "edges": list(edges.values()),
        "summary": {
            "by_type": _counts(selected, "type", limit),
            "by_state": _counts(selected, "verification_state", limit, default="CANDIDATE"),
            "by_severity": _counts(selected, "severity", limit, default="info"),
            "with_parameter": with_parameter,
            "correlations": correlation_counts,
            "correlation_semantics": "Shared context only; edges do not prove causality or exploitability.",
        },
        "privacy": "Query strings, user-info, raw payloads, response excerpts and credential-like values are omitted.",
    }
