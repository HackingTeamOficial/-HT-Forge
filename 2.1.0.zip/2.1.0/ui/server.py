#!/usr/bin/env python3
"""HT Forge GUI server."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import sys
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.engine import get_engine
from core.profiles import PROFILES
from core.exporters import export_report, generate_infographic
from core.db import Database
from core.session_store import save as save_auth_session, get as get_auth_session, masked as masked_auth_session
from core.workbench import get_workbench
from core.license import install_license, license_status, LicenseError
from core import telegram as tg
from ai_core import AICore, AIConfig, AIError
from core.ht_bruteforce import PROTOCOLS as BF_PROTOCOLS, get_job as bf_get_job, start_hash_detect as bf_hash_detect, start_hash_crack as bf_hash_crack, start_port_scan as bf_port_scan, start_service as bf_service

def _default_runtime() -> Path:
    if os.name == "nt":
        base = Path(os.getenv("LOCALAPPDATA") or Path.home())
        return base / "HT Forge" / "runtime"
    return Path.home() / ".htforge"

RUNTIME = Path(os.getenv("HTFORGE_RUNTIME", str(_default_runtime())))
RUNTIME.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("HTFORGE_RUNTIME", str(RUNTIME))
os.environ.setdefault("HTFORGE_DB", str(RUNTIME / "htforge.db"))
CONFIG_FILE = RUNTIME / "config.json"
INDEX = ROOT / "ui" / "index.html"


def _reports_base() -> Path:
    try:
        from core.exporters import default_reports_dir
        p = Path(default_reports_dir())
    except Exception:
        p = ROOT / "reports"
    p.mkdir(parents=True, exist_ok=True)
    return p


REPORTS_DIR = _reports_base()
STATIC = ROOT / "ui" / "static"
AI_MODEL = os.getenv("HTFORGE_AI_MODEL", "").strip()
AI_BASE_URL = os.getenv("HTFORGE_OLLAMA_URL", "http://127.0.0.1:11434")

# Local-first AI: when no model is explicitly forced, AICore selects the
# smallest installed Ollama model automatically.
def _load_ai_persisted():
    try:
        obj = json.loads(CONFIG_FILE.read_text())
        if isinstance(obj, dict) and isinstance(obj.get("ai"), dict):
            return obj["ai"]
    except Exception:
        pass
    return {}


def _save_ai_persisted(ai_cfg):
    try:
        obj = {}
        try:
            obj = json.loads(CONFIG_FILE.read_text())
            if not isinstance(obj, dict):
                obj = {}
        except Exception:
            obj = {}
        obj["ai"] = ai_cfg
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(obj, ensure_ascii=False, indent=2))
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
    except Exception:
        pass


try:
    AI_CORE = AICore(base_url=AI_BASE_URL, model=(AI_MODEL or None), timeout=120,
                     max_templates_per_type=5, min_confidence=0.7)
    _AI_SAVED = _load_ai_persisted()
    if _AI_SAVED:
        try:
            _AI_PROV = str(_AI_SAVED.get("provider") or "ollama")
            _AI_CFG = _AI_SAVED.get("providers") or {}
            if isinstance(_AI_CFG, dict) and _AI_CFG:
                AI_CORE.provider_cfg.update(_AI_CFG)
                AI_CORE._ensure_providers()
            if _AI_PROV != "ollama" and _AI_PROV in AI_CORE.analyzer.providers:
                AI_CORE.active_provider = _AI_PROV
                AI_CORE._select_default_model()
        except Exception:
            pass
except Exception:
    AI_CORE = None


def json_safe(v):
    if v is None or isinstance(v, (str, int, float, bool)): return v
    if isinstance(v, dict): return {str(k): json_safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple, set)): return [json_safe(x) for x in v]
    if hasattr(v, "isoformat"): return v.isoformat()
    return str(v)


def session_dict(s):
    if isinstance(s, dict): return json_safe(s)
    return json_safe({"id": s.id, "target": s.target, "profile": s.profile, "started_at": s.started_at, "status": s.status, "findings": s.findings, "modules_run": s.modules_run, "errors": s.errors, "metadata": s.metadata})


def _lic_safe():
    """Estado de licencia que nunca rompe la respuesta (el corte se comunica en JSON)."""
    try:
        return license_status()
    except LicenseError as exc:
        return {"valid": False, "reason": str(exc), "license_required": True}
    except Exception as exc:
        return {"valid": False, "reason": str(exc), "license_required": True}


def _delete_session_files(sid: str) -> int:
    """Borra los ficheros de reporte de una sesión. Devuelve nº borrados."""
    n = 0
    try:
        for pat in (f"htforge_report_{sid}.*", f"htforge_infographic_{sid}.svg"):
            for f in REPORTS_DIR.glob(pat):
                try:
                    if f.is_file():
                        f.unlink()
                        n += 1
                except OSError:
                    pass
    except OSError:
        pass
    return n


def _collect_referenced_reports(server) -> set:
    """Rutas de reporte aún referenciadas por alguna sesión (memoria + DB)."""
    refs = set()
    try:
        for s in (getattr(server, "sessions", {}) or {}).values():
            meta = getattr(s, "metadata", None)
            if isinstance(meta, dict):
                for v in (meta.get("reports") or {}).values():
                    if v and isinstance(v, str):
                        refs.add(str(Path(v).resolve()) if Path(v).is_absolute() else v)
    except Exception:
        pass
    try:
        db = getattr(server, "session_db", None)
        if db is not None:
            for row in db.list_sessions(1000):
                try:
                    meta = json.loads(row.get("metadata") or "{}")
                except Exception:
                    meta = {}
                for v in (meta.get("reports") or {}).values():
                    if v and isinstance(v, str):
                        refs.add(str(Path(v).resolve()) if Path(v).is_absolute() else v)
    except Exception:
        pass
    return refs


class GUIHandler(BaseHTTPRequestHandler):
    server_version = "HTForge/2.1.0"

    def log_message(self, fmt, *args):
        return

    def _send(self, status, data, content_type="application/json"):
        body = data if isinstance(data, bytes) else (json.dumps(json_safe(data), ensure_ascii=False).encode("utf-8") if content_type == "application/json" else str(data).encode("utf-8"))
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS"); self.send_header("Access-Control-Allow-Headers", "Content-Type"); self.end_headers(); self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0")); raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8")) if raw else {}


    def _active_edition(self):
        try:
            lic = _lic_safe() or {}
            ed = str(lic.get("edition") or "").upper()
            if ed in ("DEMO", "PRO", "PREMIUM"):
                return ed
        except Exception:
            pass
        return os.getenv("HTFORGE_EDITION", "DEMO")

    # --- Estado de sincronización (sigiloso: jamás expone destino ni secreto) ---
    def _sync_state(self):
        try:
            rt = Path(os.getenv("HTFORGE_RUNTIME", str(ROOT / "runtime")))
            cache = {}
            for name in ("state_sync.json",):
                try:
                    obj = json.loads((rt / name).read_text())
                    if isinstance(obj, dict) and obj:
                        cache = obj
                        break
                except Exception:
                    continue
            last = {}
            lids = list(cache.keys())
            if lids:
                last = {"checked_at": cache[lids[0]].get("checked_at"),
                        "verdict": cache[lids[0]].get("verdict")}
        except Exception:
            last = {}
        try:
            from core.sync_link import find_blob
            linked = find_blob() is not None
        except Exception:
            linked = False
        return {"linked": linked, "last_check": last}

    def do_OPTIONS(self):
        self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization"); self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS"); self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"): return self._file(INDEX, "text/html; charset=utf-8")
        if p.startswith("/static/"): return self._file(STATIC / Path(p[len("/static/"):]).name)
        if p == "/api/status": return self._send(200, {"ok": True, "version": "2.1.1", "edition": self._active_edition(), "workbench": True, "license": license_status()})
        if p == "/api/workbench/history": return self._send(200, get_workbench().list_history())
        if p.startswith("/api/workbench/history/"): return self._history_item(p.rsplit("/",1)[-1])
        if p == "/api/workbench/extensions": return self._send(200, get_workbench().list_extensions())
        if p == "/api/workbench/workspace": return self._send(200, get_workbench().get_workspace())
        if p.startswith("/api/workbench/fuzz/"): return self._fuzz_status(p.rsplit("/",1)[-1])
        if p == "/api/sessions": return self._send(200, self._sessions())
        if p == "/api/telegram/config": return self._send(200, tg.status())
        if p == "/api/module-health":
            from core.module_health import summary as module_health_summary
            return self._send(200, module_health_summary())
        if p.startswith("/api/bruteforce/status/"): return self._bf_get(p.rsplit("/",1)[-1])
        if p == "/api/bruteforce/wordlist":
            try:
                self._require_premium_bf()
                path=ROOT/"ht_brute_force"/"dictionaries_htbf_default.txt"
                return self._send(200, {"ok":True,"path":str(path.name),"words":path.read_text(encoding="utf-8",errors="replace").splitlines()})
            except Exception as exc: return self._send(500, {"ok":False,"error":str(exc)})
        if p == "/api/ai/status": return self._ai_status()
        if p == "/api/ai/check": return self._ai_check()
        if p == "/api/ai/models": return self._ai_models()
        if p == "/api/sync/state": return self._send(200, self._sync_state())
        if p.startswith("/api/sessions/") and p.endswith("/infographic.svg"):
            sid=p.split("/")[3]
            return self._infographic(sid)
        if p.startswith("/api/sessions/") and "/reports/" in p:
            parts=p.strip("/").split("/")
            # /api/sessions/<sid>/reports/<fmt> -> parts[4] es el formato
            if len(parts) >= 5:
                return self._report_file(parts[2], parts[4])
            if len(parts) >= 4:
                return self._report_file(parts[2], parts[3])
        if p.startswith("/api/sessions/"):
            return self._session(p.rsplit("/",1)[-1])
        self._send(404, {"error":"Ruta no encontrada"})

    def do_DELETE(self):
        p = urlparse(self.path).path
        try:
            if p == "/api/sessions":
                count = self.server.session_db.delete_all_sessions()
                self.server.sessions.clear()
                self.server.engines.clear()
                files = _delete_session_files("*")
                return self._send(200, {"ok": True, "deleted": count, "files_deleted": files})
            if p.startswith("/api/sessions/"):
                sid = p.rsplit("/", 1)[-1]
                if sid in self.server.engines:
                    self.server.engines[sid].stop()
                    self.server.engines.pop(sid, None)
                self.server.sessions.pop(sid, None)
                deleted = self.server.session_db.delete_session(sid)
                files = _delete_session_files(sid)
                return self._send(200, {"ok": True, "deleted": bool(deleted), "files_deleted": files})
            return self._send(404, {"error": "Ruta no encontrada"})
        except Exception as e:
            return self._send(400, {"error": str(e)})

    def do_POST(self):
        p = urlparse(self.path).path; data = self._body()
        try:

            if p == "/api/license":
                if data.get("key"):
                    return self._send(200, install_license(data["key"]))
                return self._send(200, license_status())
            if p == "/api/telegram/config":
                return self._send(200, tg.save_config(data or {}))
            if p == "/api/telegram/test":
                try:
                    return self._send(200, tg.test_message())
                except Exception as e:
                    return self._send(400, {"ok": False, "error": str(e)})
            if p == "/api/bruteforce/start": return self._bf_start(data)
            if p == "/api/bruteforce/stop": return self._bf_stop(data)
            if p == "/api/scan": return self._start_scan(data)
            if p == "/api/scan/stop": return self._stop_scan(data)
            if p == "/api/export": return self._export(data)
            if p == "/api/reports/cleanup": return self._cleanup_reports()
            if p == "/api/workbench/repeater": return self._repeater(data)
            if p == "/api/workbench/retest": return self._repeater({**data, "source": "retest"})
            if p == "/api/workbench/intruder": return self._intruder(data)
            if p == "/api/workbench/diff": return self._send(200, get_workbench().diff(data.get("left") or {}, data.get("right") or {}))
            if p == "/api/workbench/workspace": return self._send(200, get_workbench().update_workspace(data))
            if p == "/api/workbench/workspace/target": return self._send(200, get_workbench().add_target(data.get("target", "")))
            if p == "/api/workbench/openapi": return self._send(200, get_workbench().import_openapi(data.get("document", "")))
            if p == "/api/workbench/websocket": return self._send(200, get_workbench().websocket_send(data.get("url", ""), data.get("message", ""), data.get("timeout", 10), data.get("verify_ssl", False)))
            if p == "/api/workbench/history/clear": get_workbench().clear_history(); return self._send(200,{"ok":True})
            if p == "/api/ai/analyze": return self._ai_analyze(data)
            if p == "/api/ai/model": return self._ai_model(data)
            if p == "/api/ai/test": return self._ai_test(data)
            if p == "/api/ai/session": return self._ai_session(data)
            if p == "/api/auth/session":
                save_auth_session(data.get("target",""),data.get("session_id",""),data.get("token",""),data.get("session_cookie_name","sessionid")); return self._send(200,{"ok":True,"session":masked_auth_session(data.get("target",""))})
            self._send(404,{"error":"Ruta no encontrada"})
        except Exception as e:
            self._send(400,{"error":str(e)})

    def _require_premium_bf(self):
        lic = license_status()
        if not lic.get("valid"):
            raise LicenseError("HT Brute Force requiere una licencia PREMIUM activa.")
        if str(lic.get("edition","")).upper() != "PREMIUM":
            raise LicenseError("HT Brute Force está disponible únicamente en la edición PREMIUM.")
        return lic

    def _bf_get(self, jid):
        try:
            self._require_premium_bf()
        except LicenseError as exc:
            return self._send(403, {"ok": False, "error": str(exc), "edition": self._active_edition()})
        job=bf_get_job(jid)
        if not job:
            return self._send(404, {"ok": False, "error": "Trabajo Brute Force no encontrado"})
        return self._send(200, job.public())

    def _bf_start(self, data):
        try:
            self._require_premium_bf()
        except LicenseError as exc:
            return self._send(403, {"ok": False, "error": str(exc), "edition": self._active_edition()})
        from core.ht_bruteforce import PORT_PROTOCOL
        kind=str(data.get("kind") or "").lower()
        if kind=="hash-detect":
            lines=[str(x).strip() for x in (data.get("hashes") or []) if str(x).strip()]
            if not lines: return self._send(400, {"ok":False,"error":"Introduce al menos un hash."})
            return self._send(202, {"ok":True,"job":bf_hash_detect(lines).id})
        if kind=="hash-crack":
            targets=[str(x).strip() for x in (data.get("hashes") or []) if str(x).strip()]
            words=[str(x).strip() for x in (data.get("words") or []) if str(x).strip()]
            if not targets or not words: return self._send(400, {"ok":False,"error":"Hashes y diccionario son obligatorios."})
            try: max_time=max(5,min(300,float(data.get("max_time",30))))
            except Exception: max_time=30
            return self._send(202, {"ok":True,"job":bf_hash_crack(targets,words,str(data.get("hash_type") or "auto"),bool(data.get("rules",True)),max_time).id})
        if kind=="port-scan":
            host=str(data.get("host") or "").strip()
            if not host: return self._send(400, {"ok":False,"error":"Host obligatorio."})
            try:
                ports=[int(x.strip()) for x in str(data.get("ports") or "").split(",") if x.strip().isdigit() and 1<=int(x.strip())<=65535]
                timeout=max(.5,min(30,float(data.get("scan_timeout",3))))
                threads=max(1,min(100,int(data.get("threads",50))))
            except Exception: return self._send(400, {"ok":False,"error":"Parámetros de port scan no válidos."})
            if not ports: return self._send(400, {"ok":False,"error":"Lista de puertos vacía."})
            return self._send(202, {"ok":True,"job":bf_port_scan(host,ports,timeout,threads).id})
        if kind=="service":
            host=str(data.get("host") or "").strip()
            proto=str(data.get("protocol") or "").lower()
            try: port=int(data.get("port"))
            except Exception: port=0
            users=[str(x) for x in (data.get("users") or []) if str(x).strip()]
            passwords=[str(x) for x in (data.get("passwords") or []) if str(x).strip()]
            if not host or port<1 or port>65535 or not proto:
                return self._send(400, {"ok":False,"error":"Host, protocolo y puerto son obligatorios."})
            if not passwords or (proto not in ("redis","vnc") and not users):
                return self._send(400, {"ok":False,"error":"Usuarios/contraseñas son obligatorios para este protocolo."})
            try: threads=max(1,min(50,int(data.get("threads",10)))); timeout=max(.5,min(120,float(data.get("timeout",5))))
            except Exception: threads,timeout=10,5
            extra=data.get("extra") if isinstance(data.get("extra"),dict) else {}
            return self._send(202, {"ok":True,"job":bf_service(proto,host,port,users,passwords,threads,timeout,extra).id})
        return self._send(400, {"ok":False,"error":"Tipo Brute Force no soportado."})

    def _bf_stop(self, data):
        try: self._require_premium_bf()
        except LicenseError as exc: return self._send(403, {"ok":False,"error":str(exc)})
        job=bf_get_job(str(data.get("job") or ""))
        if not job: return self._send(404, {"ok":False,"error":"Trabajo no encontrado"})
        job.stop_event.set()
        return self._send(200, {"ok":True})

    def _ai_status(self):
        if AI_CORE is None:
            return self._send(200, {"enabled": False, "error": "AI Core no pudo inicializarse", "read_only": True, "actions_enabled": False})
        return self._send(200, AI_CORE.status())

    def _ai_check(self):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible", "read_only": True})
        try:
            return self._send(200, {"ok": True, **AI_CORE.self_test()})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc), "read_only": True})

    def _ai_models(self):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        prov = ""
        try:
            from urllib.parse import urlparse as _up, parse_qs as _pqs
            prov = (_pqs(_up(self.path).query).get("provider") or [""])[0].strip()
        except Exception:
            prov = ""
        try:
            if prov and prov != AI_CORE.active_provider:
                names = AI_CORE.provider_models(prov)
                details = [{"name": m} for m in names]
                return self._send(200, {"ok": True, "provider": prov, "models": details,
                                        "selected": AI_CORE.selected_model if prov == AI_CORE.active_provider else (names[0] if names else ""),
                                        "auto_smallest": AI_CORE.auto_smallest, "providers": AI_CORE.PROVIDER_INFO,
                                        "providers_state": AI_CORE.providers_state()})
            return self._send(200, {"ok": True, "provider": AI_CORE.active_provider,
                                    "models": AI_CORE.model_details() if AI_CORE.active_provider == "ollama" else [{"name": m} for m in AI_CORE.provider_models()],
                                    "selected": AI_CORE.selected_model, "auto_smallest": AI_CORE.auto_smallest,
                                    "providers": AI_CORE.PROVIDER_INFO, "providers_state": AI_CORE.providers_state()})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc)})

    def _ai_model(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        try:
            prov = str(data.get("provider") or "").strip()
            if prov:
                base_url = data.get("base_url")
                api_key = data.get("api_key")
                timeout = data.get("timeout")
                model = data.get("model")
                st = AI_CORE.configure_provider(prov, base_url=base_url, api_key=api_key,
                                                timeout=timeout, model=model)
                _save_ai_persisted({"provider": AI_CORE.active_provider,
                                    "providers": {k: {"base_url": (v.get("base_url") or ""),
                                                       "api_key": (v.get("api_key") or ""),
                                                       "timeout": (v.get("timeout") or ""),
                                                       "model": (v.get("model") or "")}
                                                  for k, v in (AI_CORE.provider_cfg or {}).items()}})
                if data.get("model"):
                    st = AI_CORE.set_model(str(data["model"]))
                    _save_ai_persisted({"provider": AI_CORE.active_provider,
                                        "providers": {k: {"base_url": (v.get("base_url") or ""),
                                                           "api_key": (v.get("api_key") or ""),
                                                           "timeout": (v.get("timeout") or ""),
                                                           "model": (v.get("model") or "")}
                                                      for k, v in (AI_CORE.provider_cfg or {}).items()}})
                return self._send(200, {"ok": True, **st})
            if data.get("auto_smallest"):
                st = AI_CORE.auto_select_smallest()
                _save_ai_persisted({"provider": AI_CORE.active_provider,
                                    "providers": {k: {"base_url": (v.get("base_url") or ""),
                                                       "api_key": (v.get("api_key") or ""),
                                                       "timeout": (v.get("timeout") or ""),
                                                       "model": (v.get("model") or "")}
                                                  for k, v in (AI_CORE.provider_cfg or {}).items()}})
                return self._send(200, {"ok": True, **st})
            model = str(data.get("model") or "")
            if not model:
                return self._send(400, {"ok": False, "error": "Modelo requerido"})
            st = AI_CORE.set_model(model)
            _save_ai_persisted({"provider": AI_CORE.active_provider,
                                "providers": {k: {"base_url": (v.get("base_url") or ""),
                                                   "api_key": (v.get("api_key") or ""),
                                                   "timeout": (v.get("timeout") or ""),
                                                   "model": (v.get("model") or "")}
                                              for k, v in (AI_CORE.provider_cfg or {}).items()}})
            return self._send(200, {"ok": True, **st})
        except AIError as exc:
            return self._send(400, {"ok": False, "error": str(exc)})

    def _ai_test(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        try:
            res = AI_CORE.test_provider(
                str(data.get("provider") or "ollama"),
                base_url=data.get("base_url"), api_key=data.get("api_key"),
                timeout=data.get("timeout"))
            return self._send(200, res)
        except Exception as exc:
            return self._send(500, {"ok": False, "error": str(exc)[:300]})

    def _ai_analyze(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        finding = data.get("finding") or {}
        if not isinstance(finding, dict) or not finding:
            return self._send(400, {"ok": False, "error": "finding requerido"})
        try:
            return self._send(200, {"ok": True, "analysis": AI_CORE.analyze_finding(finding)})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc)})

    def _ai_session(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        sid = str(data.get("session_id") or "")
        if not sid:
            return self._send(400, {"ok": False, "error": "session_id requerido"})
        try:
            session = self.server.sessions.get(sid)
            if session:
                obj = session_dict(session)
            else:
                row = self.server.session_db.get_session(sid)
                if not row:
                    return self._send(404, {"ok": False, "error": "Sesión no encontrada"})
                obj = dict(row)
                obj["findings"] = self.server.session_db.get_findings(sid)
                obj["metadata"] = json.loads(obj.get("metadata") or "{}")
            return self._send(200, {"ok": True, "summary": AI_CORE.summarize_session(obj)})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc)})

    def _repeater(self,data):
        try:return self._send(200,get_workbench().send(data,"repeater"))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _intruder(self,data):
        try:return self._send(202,get_workbench().start_fuzz(data.get("request") or {},data.get("position","url"),data.get("payloads") or [],data.get("workers",4)))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _history_item(self,eid):
        x=get_workbench().get_history(eid); return self._send(200,x) if x else self._send(404,{"error":"Intercambio no encontrado"})

    def _fuzz_status(self,jid):
        x=get_workbench().get_fuzz(jid); return self._send(200,x) if x else self._send(404,{"error":"Trabajo no encontrado"})

    def _file(self, path, content_type=None, download=False):
        try:
            body=path.read_bytes(); ct=content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            if download:
                self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body))); self.send_header("Content-Disposition", f"attachment; filename=\"{path.name}\""); self.send_header("Cache-Control", "no-store"); self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers(); self.wfile.write(body); return
            return self._send(200,body,ct)
        except FileNotFoundError: return self._send(404,{"error":"Archivo no encontrado"})

    def _sessions(self):
        out=[]
        for r in self.server.session_db.list_sessions(100):
            s=dict(r); s["findings"]=s.get("findings_count",0); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); out.append(s)
        for sid,s in self.server.sessions.items(): out.append(session_dict(s))
        seen={}; [seen.__setitem__(x["id"],x) for x in out]; return list(seen.values())

    def _session(self,sid):
        if sid in self.server.sessions: return self._send(200,session_dict(self.server.sessions[sid]))
        r=self.server.session_db.get_session(sid)
        if not r:return self._send(404,{"error":"Sesión no encontrada"})
        s=dict(r); s["findings"]=self.server.session_db.get_findings(sid); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); return self._send(200,s)

    def _infographic(self, sid):
        s=self.server.sessions.get(sid)
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            # Stored sessions are reconstructed in the same shape used by _session.
            from core.models import ScanSession
            started=r.get("started_at") if isinstance(r,dict) else None
            try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
            except Exception: started=datetime.now()
            s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
        try:
            svg=generate_infographic(s, str(REPORTS_DIR))
            return self._file(Path(svg), "image/svg+xml; charset=utf-8")
        except Exception as exc:
            return self._send(500,{"error":str(exc)})

    def _start_scan(self,data):
        try: from core.license import require_license; require_license()
        except LicenseError as e: return self._send(403,{"error":str(e),"license_required":True,"license":license_status()})
        target=data.get("target","").strip(); profile=data.get("profile","full")
        if not target:return self._send(400,{"error":"Target requerido"})
        sid=str(uuid.uuid4())[:8]; config=data.get("config") or {}; config["session_id"]=sid; config.setdefault("reports_dir", str(REPORTS_DIR)); config["modules"]=data.get("modules") or []
        engine=get_engine(config=config); self.server.engines[sid]=engine
        try:
            from core import telegram as _tg
            engine.on_finding = lambda f, _t=target: _tg.notify_finding(f if isinstance(f, dict) else {}, _t)
        except Exception:
            pass
        def worker():
            s=engine.scan(target,profile,options=config); self.server.sessions[sid]=s
            try:
                from core import telegram as _tg2
                _tg2.notify_summary(s)
            except Exception:
                pass
        t=threading.Thread(target=worker,daemon=True); self.server.threads[sid]=t; t.start()
        # session object is created immediately by Engine; expose it once available
        for _ in range(50):
            if engine.session: self.server.sessions[sid]=engine.session; break
            time.sleep(.01)
        return self._send(202,{"session_id":sid})

    def _stop_scan(self,data):
        sid=data.get("session_id"); e=self.server.engines.get(sid)
        if not e:return self._send(404,{"error":"Escaneo no encontrado"})
        e.stop(); return self._send(200,{"ok":True})


    def _report_file(self, sid, fmt):
        if fmt not in {"svg", "html", "pdf", "json", "csv", "md", "xml", "txt", "evidence"}:
            return self._send(400, {"error": "Formato no soportado"})
        if fmt == "evidence":
            return self._evidence_zip(sid)
        s=self.server.sessions.get(sid)
        report_path=None
        if s and isinstance(s.metadata, dict):
            report_path=(s.metadata.get("reports") or {}).get(fmt)
        if not report_path or not Path(str(report_path)).is_file():
            r=self.server.session_db.get_session(sid)
            if r:
                try:
                    meta=json.loads(r.get("metadata") or "{}")
                    report_path=(meta.get("reports") or {}).get(fmt)
                except Exception:
                    report_path=None
        # El SVG se puede regenerar bajo demanda. Esto evita vistas vacías
        # si el escaneo terminó antes de persistir el mapa de reportes.
        if fmt == "svg" and (not report_path or not Path(str(report_path)).is_file()):
            try:
                if s is None:
                    r=self.server.session_db.get_session(sid)
                    if r:
                        from core.models import ScanSession
                        started=r.get("started_at")
                        try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
                        except Exception: started=datetime.now()
                        s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
                if s is not None:
                    report_path=generate_infographic(s, str(REPORTS_DIR))
                    if isinstance(s.metadata, dict):
                        s.metadata.setdefault("reports", {})["svg"]=report_path
                        try: self.server.session_db.update_session(s)
                        except Exception: pass
            except Exception as exc:
                return self._send(500, {"error": f"No se pudo generar el SVG: {exc}"})
        if not report_path or not Path(str(report_path)).is_file():
            return self._send(404, {"error": f"Reporte {fmt.upper()} no generado todavía"})
        path=Path(str(report_path)).resolve()
        try:
            path.relative_to(REPORTS_DIR.resolve())
        except ValueError:
            return self._send(403, {"error": "Ruta de reporte no permitida"})
        cts={"svg":"image/svg+xml; charset=utf-8","html":"text/html; charset=utf-8","pdf":"application/pdf","json":"application/json; charset=utf-8","csv":"text/csv; charset=utf-8","md":"text/markdown; charset=utf-8","xml":"application/xml; charset=utf-8","txt":"text/plain; charset=utf-8"}
        return self._file(path, cts[fmt], download=(fmt != "svg"))

    def _cleanup_reports(self):
        """Borra huérfanos: ficheros htforge_* sin sesión que los referencie."""
        try:
            refs = _collect_referenced_reports(self.server)
            deleted, kept, freed = 0, 0, 0
            if REPORTS_DIR.is_dir():
                for f in REPORTS_DIR.iterdir():
                    if not f.is_file():
                        continue
                    if not (f.name.startswith("htforge_report_") or f.name.startswith("htforge_infographic_")):
                        continue
                    if str(f.resolve()) in refs or f.name in refs:
                        kept += 1
                        continue
                    try:
                        freed += f.stat().st_size
                        f.unlink()
                        deleted += 1
                    except OSError:
                        kept += 1
            return self._send(200, {"ok": True, "deleted": deleted, "kept": kept, "freed_bytes": freed})
        except Exception as exc:
            return self._send(500, {"ok": False, "error": str(exc)})

    def _evidence_zip(self, sid):
        """Sirve evidence/ como zip, generándolo bajo demanda si falta."""
        from core.exporters import export_evidence
        from core.models import ScanSession
        s = self.server.sessions.get(sid)
        if s is None:
            r = self.server.session_db.get_session(sid)
            if not r:
                return self._send(404, {"error": "Sesión no encontrada"})
            try:
                started = datetime.fromisoformat(str(r.get("started_at")).replace("Z", "+00:00"))
            except Exception:
                started = datetime.now()
            s = ScanSession(id=sid, target=r.get("target", ""), profile=r.get("profile", "full"),
                            started_at=started, status=r.get("status", "completed"),
                            findings=self.server.session_db.get_findings(sid),
                            modules_run=json.loads(r.get("modules_run") or "[]"),
                            errors=json.loads(r.get("errors") or "[]"),
                            metadata=json.loads(r.get("metadata") or "{}"))
        try:
            ev_dir = Path(export_evidence(s, str(REPORTS_DIR)))
        except Exception as exc:
            return self._send(500, {"error": f"No se pudo generar evidence: {exc}"})
        try:
            import zipfile, io
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for f in sorted(ev_dir.glob("finding-*.json")):
                    z.write(f, f"evidence/{f.name}")
            data = buf.getvalue()
        except Exception as exc:
            return self._send(500, {"error": f"No se pudo empaquetar evidence: {exc}"})
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Disposition", f"attachment; filename=\"htforge_evidence_{sid}.zip\"")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _export(self,data):
        sid=data.get("session_id"); fmt=data.get("format","json"); e=self.server.engines.get(sid); s=e.session if e and e.session else self.server.sessions.get(sid)
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            # Regenerar el reporte desde la sesión persistida (no exige sesión en memoria).
            try:
                from core.models import ScanSession
                started=r.get("started_at")
                try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
                except Exception: started=datetime.now(timezone.utc)
                s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
            except Exception as exc:
                return self._send(500,{"error":f"No se pudo reconstruir la sesión: {exc}"})
        try:
            out=export_report(s,fmt,str(REPORTS_DIR))
        except Exception as exc:
            return self._send(500,{"error":f"No se pudo generar el reporte {fmt}: {exc}"})
        # Descarga real: devolver URL + forzar persistencia en metadata.
        try:
            if isinstance(getattr(s,"metadata",None),dict):
                s.metadata.setdefault("reports",{})[fmt]=out
        except Exception:
            pass
        return self._send(200,{"output":out,"download":f"/api/sessions/{sid}/reports/{fmt}"})

def run_server(host="127.0.0.1",port=9090,open_browser=True):
    
    try:
        server=ThreadingHTTPServer((host,port),GUIHandler)
    except OSError as exc:
        if getattr(exc,"errno",None)==98:
            raise RuntimeError(f"El puerto {port} ya está en uso. Cierra la instancia anterior de HT Forge o usa --port <puerto>." ) from exc
        raise
    
    def _db_path():
        import os as _os, pathlib as _pl
        primary = _os.getenv("HTFORGE_DB", str(ROOT/"runtime"/"htforge.db"))
        try:
            _pl.Path(primary).parent.mkdir(parents=True, exist_ok=True)
            probe = _pl.Path(primary).parent / ".write_test"
            probe.write_text("ok")
            probe.unlink(missing_ok=True)
            return primary
        except Exception:
            fb_base = _os.getenv("LOCALAPPDATA") or _os.getenv("APPDATA") or str(_pl.Path.home())
            fb = _pl.Path(fb_base) / "HT Forge" / "runtime" / "htforge.db"
            fb.parent.mkdir(parents=True, exist_ok=True)
            return str(fb)
    import pathlib as _pl
    server.sessions={}; server.engines={}; server.threads={}; server._lock=threading.RLock(); server.session_db=Database(_db_path())
    url=f"http://{host}:{port}"; print(f"🌐 HT Forge GUI corriendo en {url}")
    if open_browser: threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: server.shutdown()


if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--host",default="127.0.0.1"); ap.add_argument("--port",type=int,default=9090); ap.add_argument("--no-browser",action="store_true"); a=ap.parse_args(); run_server(a.host,a.port,not a.no_browser)
