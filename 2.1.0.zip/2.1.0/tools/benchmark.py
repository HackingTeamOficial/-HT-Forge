#!/usr/bin/env python3
"""HT Forge Benchmark — harness reproducible de medición.

Mide sobre un objetivo dado (por defecto el VulnLab local):
  detection, severidades, estados de verificación, calidad de
  evidencia, cobertura (módulos), peticiones si se exponen,
  duración, errores y deduplicación básica.

Uso:
  python3 tools/benchmark.py --target http://127.0.0.1:8080 --profile full
  python3 tools/benchmark.py --target http://127.0.0.1:8080 --modules sqli xss

El resultado se guarda en tools/benchmark_results/bench_<ts>.json
y se imprime una tabla resumen. Determinista: mismo target +
mismos módulos => métricas comparables entre runs y entre
herramientas (ZAP, Nuclei, HT Forge).
"""
import argparse
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _evidence_quality(findings):
    total = len(findings)
    if not total:
        return {"with_response_pair": 0, "with_retest": 0, "with_cwe": 0,
                "rate_pair": 0.0, "rate_retest": 0.0, "rate_cwe": 0.0}
    pair = sum(1 for f in findings
               if isinstance(f.get("evidence"), dict) and f["evidence"].get("response_pair"))
    retest = sum(1 for f in findings
                 if isinstance(f.get("evidence"), dict)
                 and (f["evidence"].get("retest") or f["evidence"].get("reproduced")))
    cwe = sum(1 for f in findings if f.get("cwe"))
    return {"with_response_pair": pair, "with_retest": retest, "with_cwe": cwe,
            "rate_pair": round(pair / total, 3),
            "rate_retest": round(retest / total, 3),
            "rate_cwe": round(cwe / total, 3)}


def _dedup_rate(findings):
    keys = [(str(f.get("type")), str(f.get("url")), str(f.get("parameter") or "")) for f in findings]
    seen = set(keys)
    return {"total": len(keys), "unique": len(seen),
            "duplicate_rate": round(1 - len(seen) / len(keys), 3) if keys else 0.0}


def main() -> int:
    ap = argparse.ArgumentParser(description="HT Forge Benchmark")
    ap.add_argument("--target", default="http://127.0.0.1:8080")
    ap.add_argument("--profile", default="full")
    ap.add_argument("--modules", nargs="*", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    from core.engine import Engine

    out_dir = ROOT / "tools" / "benchmark_results"
    out_dir.mkdir(parents=True, exist_ok=True)

    options = {}
    if args.modules is not None:
        options["modules"] = args.modules
    engine = Engine(config={"reports_dir": str(ROOT / "reports")})

    t0 = time.monotonic()
    session = engine.scan(args.target, args.profile, options=options or None)
    duration = round(time.monotonic() - t0, 1)

    findings = session.findings or []
    result = {
        "tool": "HT Forge",
        "version": (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "unknown",
        "target": args.target,
        "profile": args.profile,
        "modules_requested": args.modules,
        "modules_run": session.modules_run,
        "started_at": session.started_at.isoformat() if hasattr(session.started_at, "isoformat") else str(session.started_at),
        "duration_s": duration,
        "findings_total": len(findings),
        "by_severity": dict(Counter(str(f.get("severity", "info")) for f in findings)),
        "by_state": dict(Counter(str(f.get("verification_state", "UNKNOWN")) for f in findings)),
        "actionable": sum(1 for f in findings
                          if str(f.get("verification_state", "")).upper() in ("CONFIRMED", "VERIFIED", "LIKELY")),
        "evidence_quality": _evidence_quality(findings),
        "dedup": _dedup_rate(findings),
        "errors": session.errors or [],
        "error_count": len(session.errors or []),
    }

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest = Path(args.out) if args.out else out_dir / f"bench_{ts}.json"
    dest.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"target={args.target} profile={args.profile} "
          f"hallazgos={result['findings_total']} accionables={result['actionable']} "
          f"tiempo={duration}s errores={result['error_count']}")
    print(f"severidades={result['by_severity']}")
    print(f"estados={result['by_state']}")
    print(f"evidencia={result['evidence_quality']}")
    print(f"guardado en {dest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
