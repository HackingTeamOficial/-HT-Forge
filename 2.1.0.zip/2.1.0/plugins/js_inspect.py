#!/usr/bin/env python3
"""plugins/js_inspect.py - HT Forge Web Runtime estático (idea GramFuzz #6).

Inspección de JavaScript sin navegador (stdlib, sin Playwright):
detecta fetch/XHR/axios, endpoints dinámicos, parámetros generados
por JS, formularios dinámicos, rutas SPA, respuestas JSON y APIs
descubiertas tras analizar scripts. Eleva al crawler clásico.
"""

import re
from typing import Dict, List
from urllib.parse import parse_qsl, urljoin, urlsplit

from core.context import Context

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])

SCRIPT_SRC_RE = re.compile(
    r'<script[^>]+src\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
INLINE_SCRIPT_RE = re.compile(
    r"<script(?![^>]*src=)[^>]*>(.*?)</script>", re.IGNORECASE | re.DOTALL)
DYNAMIC_ENDPOINT_RE = re.compile(
    r"(?:fetch|axios\.(?:get|post|put|patch|delete)|XMLHttpRequest|"
    r"\.ajax|loadJSON|getJSON|\$http|ws:|wss:|EventSource|"
    r"new\s+WebSocket)\s*\(?\s*['\"`]([^'\"`\s]+)['\"`]",
    re.IGNORECASE)
TEMPLATE_URL_RE = re.compile(
    r"[`\"']((?:/|\./|https?://)[^`\"'\s]*\$\{[^}]+\}[^`\"'\s]*)[`\"']")
DYNAMIC_FORM_RE = re.compile(
    r"(?:createElement\s*\(\s*['\"]form['\"]|formData|FormData|"
    r"\.submit\s*\(|addEventListener\s*\(\s*['\"]submit['\"])",
    re.IGNORECASE)
JSON_KEY_RE = re.compile(r'"([A-Za-z_][A-Za-z0-9_]{1,40})"\s*:')
WS_RE = re.compile(r"wss?://[^\s'\"`]+", re.IGNORECASE)


def _same_origin(base, url):
    try:
        return urlsplit(urljoin(base, url)).netloc == urlsplit(base).netloc
    except Exception:
        return False


def run(ctx: Context) -> Dict:
    """Analiza scripts del objetivo y extrae superficie dinámica."""
    budget = get_budget(ctx, "js_inspect", {"max_requests": 20, "max_seconds": 90.0,
                                            "max_payloads": 0, "max_targets": 12}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "Web Runtime: inspección estática de JavaScript")

    seeds = [ctx.target] + [u for u in (ctx.get("discovered_urls", []) or [])
                            if isinstance(u, str)]
    seeds = need(ctx, "js_inspect",
                 list(dict.fromkeys(seeds))[: (budget.max_targets if budget else 12)])

    known_urls = set(ctx.get("discovered_urls", []) or [])
    known_params = {(str(p.get("url", "")), str(p.get("param", "")))
                    for p in (ctx.get("discovered_params", []) or [])
                    if isinstance(p, dict)}
    dyn_endpoints, dyn_params, ws_urls, dyn_forms = [], [], [], []

    for page in seeds:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        try:
            if budget and not budget.consume_request():
                break
            resp = ctx.req("GET", page, timeout=10, headers={"Connection": "close"})
            html = getattr(resp, "text", "") or ""
        except Exception:
            continue
        scripts = [page]
        for src in SCRIPT_SRC_RE.findall(html):
            abs_src = urljoin(page, src)
            if _same_origin(ctx.target, abs_src) and abs_src not in scripts:
                scripts.append(abs_src)
        bodies = [html]
        for src in scripts[1:]:
            if budget and not budget.consume_request():
                break
            try:
                r = ctx.req("GET", src.split("#")[0], timeout=10,
                            headers={"Connection": "close"})
                bodies.append(getattr(r, "text", "") or "")
            except Exception:
                continue
        for body in bodies:
            for m in DYNAMIC_ENDPOINT_RE.finditer(body):
                ep = urljoin(page, m.group(1))
                if _same_origin(ctx.target, ep) and ep not in known_urls:
                    known_urls.add(ep)
                    dyn_endpoints.append(ep)
            for m in TEMPLATE_URL_RE.finditer(body):
                dyn_endpoints.append(f"{urljoin(page, m.group(1))} [templated]")
            for m in WS_RE.finditer(body):
                if m.group(0) not in ws_urls:
                    ws_urls.append(m.group(0))
            if DYNAMIC_FORM_RE.search(body):
                dyn_forms.append(page)
            for m in JSON_KEY_RE.finditer(body[:60000]):
                key = m.group(1).lower()
                if key in ("endpoint", "apiurl", "baseurl", "route", "path"):
                    continue
                entry_key = (page.split("?")[0], m.group(1))
                if entry_key not in known_params and len(m.group(1)) <= 32:
                    known_params.add(entry_key)

    for ep in dyn_endpoints:
        if "[templated]" in ep:
            continue
        parts = urlsplit(ep)
        for pname, pval in parse_qsl(parts.query, keep_blank_values=True):
            key = (ep.split("?")[0], pname)
            if key not in known_params:
                known_params.add(key)
                dyn_params.append({"url": ep.split("?")[0], "param": pname,
                                   "method": "GET", "baseline_value": pval,
                                   "source": "js_inspect"})

    if dyn_endpoints or dyn_params or ws_urls:
        ctx.set("discovered_urls",
                list(dict.fromkeys(list(ctx.get("discovered_urls", []) or [])
                                     + [e for e in dyn_endpoints
                                        if "[templated]" not in e])))
        ctx.set("discovered_params",
                list(ctx.get("discovered_params", []) or []) + dyn_params)
        sev = "low"
        if ws_urls:
            sev = "medium"
        finding = {
            "type": "js_dynamic_surface",
            "severity": sev,
            "confidence": 80,
            "verification_state": "CONFIRMED",
            "title": f"Superficie dinámica JS: {len(dyn_endpoints)} endpoint(s), "
                     f"{len(dyn_params)} param(s), {len(ws_urls)} websocket(s)",
            "detail": "Endpoints y parámetros generados por JavaScript que el "
                      "crawler HTTP clásico no ve. Alimentan verificación.",
            "url": ctx.target,
            "evidence": {"dynamic_endpoints": dyn_endpoints[:50],
                         "dynamic_params": [p["param"] for p in dyn_params[:50]],
                         "websockets": ws_urls[:10],
                         "dynamic_forms": sorted(set(dyn_forms))[:10],
                         "baseline": {"scripts_analyzed": len(seeds)}},
        }
        findings.append(finding)
        ctx.finding(finding)
        ctx.log("ok", f"Web Runtime: +{len(dyn_endpoints)} endpoints dinámicos, "
                      f"+{len(dyn_params)} params, {len(ws_urls)} WS")
    else:
        ctx.log("info", "Web Runtime: sin superficie dinámica nueva")
    return {"findings": findings, "dynamic_endpoints": dyn_endpoints,
            "dynamic_params": dyn_params, "websockets": ws_urls,
            "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
