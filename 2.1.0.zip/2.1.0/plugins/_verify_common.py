"""Helpers compartidos de verificación diferencial (motores nativos GramFuzz-style).

Todos los motores de verificación comparan baseline contra mutación y
exigen evidencia diferencial: nunca se confirma un hallazgo por el mero
hecho de recibir HTTP 200.
"""
import hashlib
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

ID_PARAM_RE = re.compile(
    r"^(id|user_?id|account_?id|uid|oid|customer_?id|order_?id|invoice_?id|"
    r"doc_?id|file_?id|report_?id|ticket_?id|profile_?id|member_?id|client_?id|"
    r"object_?id|resource_?id|item_?id|record_?id|ref_?id|key_?id|num|number)$",
    re.IGNORECASE,
)

NUM_VALUE_RE = re.compile(r"^\d{1,12}$")
UUID_VALUE_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)


def sig_of(resp):
    """Firma comparable de una respuesta: (status, bytes, hash normalizado)."""
    try:
        body = getattr(resp, "text", "") or ""
    except Exception:
        body = ""
    norm = re.sub(r"\s+", " ", body).strip()
    digest = hashlib.sha256(norm.encode("utf-8", "replace")).hexdigest()[:16]
    try:
        status = int(getattr(resp, "status_code", 0) or 0)
    except (TypeError, ValueError):
        status = 0
    return (status, len(norm), digest)


def safe_fetch(ctx, budget, method, url, **kwargs):
    """Petición con presupuesto. Devuelve None si se agota o falla."""
    try:
        if budget is not None and not budget.consume_request():
            return None
        kwargs.setdefault("timeout", 10)
        headers = dict(kwargs.pop("headers", {}) or {})
        headers.setdefault("Connection", "close")
        return ctx.req(method, url, headers=headers, **kwargs)
    except Exception:
        return None


def set_param(url, param, value):
    """Sustituye (o añade) un query param preservando el resto."""
    p = urlsplit(str(url))
    pairs = parse_qsl(p.query, keep_blank_values=True)
    out, replaced = [], False
    for key, old in pairs:
        if key == param and not replaced:
            out.append((key, value))
            replaced = True
        elif key != param:
            out.append((key, old))
    if not replaced:
        out.append((param, value))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out, doseq=True), p.fragment))


def is_id_param(name, value):
    """True si el parámetro parece un identificador de objeto/usuario."""
    name = str(name or "")
    value = str(value or "")
    if ID_PARAM_RE.match(name):
        return True
    return bool(NUM_VALUE_RE.match(value) or UUID_VALUE_RE.match(value))


def mutate_id(value):
    """Genera IDs alternos para pruebas de autorización (no destructivos)."""
    value = str(value)
    cands = []
    if NUM_VALUE_RE.match(value):
        try:
            n = int(value)
            for alt in (n + 1, n - 1, 1, 0):
                if alt != n and alt >= 0:
                    cands.append(str(alt))
        except ValueError:
            pass
    elif UUID_VALUE_RE.match(value):
        last = value[-1]
        cands.append(value[:-1] + ("0" if last != "0" else "1"))
    if value:
        cands.append(value + "0")
    seen = []
    for c in cands:
        if c not in seen:
            seen.append(c)
    return seen[:4]


def bodies_differ(sig_a, sig_b, min_bytes_delta=0):
    """Diferencia material entre dos respuestas (no solo status).

    El hash normalizado manda: si el contenido difiere, difiere.
    El filtro de falsos positivos por contenido dinámico trivial
    (timestamps, tokens) lo aplican los motores con señales propias
    (cross_owner_signal, firmas de error, reflexión de marcador).
    """
    if sig_a is None or sig_b is None:
        return False
    if sig_a[2] == sig_b[2]:
        return False
    if min_bytes_delta and abs(sig_a[1] - sig_b[1]) < min_bytes_delta \
            and sig_a[0] == sig_b[0]:
        return False
    return True


def cross_owner_signal(base_body, mutated_body, base_id, mutated_id):
    """Señal fuerte de BOLA: cada respuesta contiene SU propio ID con datos.

    Devuelve True solo si la respuesta mutada expone el ID alterno con
    contenido (no un error genérico) y difiere materialmente del baseline.
    """
    base_body = str(base_body or "")
    mutated_body = str(mutated_body or "")
    base_id = str(base_id or "")
    mutated_id = str(mutated_id or "")
    if not mutated_body or len(mutated_body) < 24:
        return False
    lowered = mutated_body.lower()
    if any(t in lowered for t in ("not found", "no existe", "forbidden",
                                   "access denied", "unauthorized", "error 4")):
        if mutated_id not in mutated_body:
            return False
    if mutated_id and mutated_id not in mutated_body:
        return False
    if base_id and base_id != mutated_id and base_id in mutated_body \
            and mutated_id not in mutated_body:
        return False
    return True


def trim(text, limit=4000):
    """Recorta texto de evidencia sin romper (recorte determinista)."""
    text = str(text or "")
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n…[recortado {len(text) - limit} bytes]"
