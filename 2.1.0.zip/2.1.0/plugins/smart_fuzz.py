#!/usr/bin/env python3
"""plugins/smart_fuzz.py - Fuzzing inteligente por tipo (idea GramFuzz #3).

No es fuzzing bruto: identifica el tipo de cada parámetro y aplica
payloads específicos con comparación contra baseline:

  id       -> IDOR (delegado a bola_verify; aquí solo señal débil)
  q/search -> XSS / SQLi (marcadores reflejados, sin exploit)
  url/next -> SSRF / Open Redirect (diferencial, sin callback externo)
  template -> SSTI (marcador aritmético, sin ejecución remota)
  file     -> LFI (marcadores de ficheros del propio objetivo)
  redirect -> Open Redirect (diferencial de Location)

Solo emite CONFIRMED/LIKELY con evidencia diferencial.
"""

import re
from typing import Dict, List

from core.context import Context

try:
    from plugins._verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )
except ImportError:  # pragma: no cover
    from _verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])

MARKER = "htforge7x"

PAYLOAD_SETS = {
    # nombre-tipo: [(payload, clase, severidad_si_confirma)]
    "xss_sqli": [
        (MARKER + "<'\">", "reflection", "medium"),
        ("' OR '1'='1", "sqli_marker", "high"),
    ],
    "ssrf": [
        ("http://127.0.0.1:9/htforge", "ssrf_loopback", "high"),
        ("http://169.254.169.254/latest/meta-data/", "ssrf_metadata", "critical"),
    ],
    "redirect": [
        ("https://example.test/htforge", "open_redirect", "medium"),
        ("//example.test/htforge", "open_redirect_proto", "medium"),
    ],
    "ssti": [
        ("{{7*7}}", "ssti_marker", "high"),
        ("${7*7}", "ssti_marker", "high"),
    ],
    "lfi": [
        ("../../../../etc/passwd", "lfi_unix", "high"),
    ],
}

METADATA_SIGNS = [
    re.compile(r"ami-id|instance-id|customer-|hostname|public-keys", re.I),
    re.compile(r"root:x:0:0:", re.I),
    re.compile(r"49", re.I),  # {{7*7}} / ${7*7} evaluado
]


def classify_param(name):
    """Tipo de fuzzing según el nombre del parámetro."""
    n = str(name or "").lower()
    if n in ("id", "uid") or n.endswith(("_id", "id")):
        return None  # Lo cubre bola_verify con contexto de autorización.
    if any(k in n for k in ("url", "uri", "link", "src", "image", "img",
                            "webhook", "callback", "import", "preview", "feed")):
        return "ssrf"
    if any(k in n for k in ("redirect", "next", "return", "dest", "continue",
                            "target", "ref", "rurl")):
        return "redirect"
    if any(k in n for k in ("template", "tpl", "view", "theme", "layout")):
        return "ssti"
    if any(k in n for k in ("file", "path", "dir", "page", "include",
                            "document", "download")):
        return "lfi"
    if any(k in n for k in ("q", "query", "search", "keyword", "s", "term")):
        return "xss_sqli"
    return None


def _replay(ctx, budget, info, value):
    if budget is not None and not budget.consume_payload():
        return None
    method = str(info.get("method", "GET")).upper()
    if method == "POST":
        data = dict(info.get("form_data") or {})
        data[info["param"]] = value
        return safe_fetch(ctx, budget, "POST", info["url"], data=data)
    return safe_fetch(ctx, budget, "GET",
                      set_param(info["url"], info["param"], value))


def run(ctx: Context) -> Dict:
    """Fuzzing tipado con baseline y confirmación diferencial."""
    budget = get_budget(ctx, "smart_fuzz", {"max_requests": 80, "max_seconds": 150.0,
                                            "max_payloads": 40, "max_targets": 15}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "Smart fuzz: tipo de parámetro -> payloads específicos")

    params = [p for p in (ctx.get("discovered_params", []) or [])
              if isinstance(p, dict) and classify_param(p.get("param"))]
    params = need(ctx, "smart_fuzz", params)[: (budget.max_targets if budget else 15)]

    for info in params:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        if budget and not budget.consume_target():
            break
        kind = classify_param(info.get("param"))
        base_resp = _replay(ctx, budget, info,
                            str(info.get("baseline_value", "")))
        if base_resp is None:
            continue
        base_sig = sig_of(base_resp)
        if base_sig[0] >= 400:
            continue
        for payload, pclass, sev in PAYLOAD_SETS[kind]:
            if ctx.stopped or (budget and budget.exhausted()):
                break
            resp = _replay(ctx, budget, info, payload)
            if resp is None:
                continue
            sig = sig_of(resp)
            body = getattr(resp, "text", "") or ""
            state, conf, note = None, 0, ""
            if kind == "xss_sqli" and pclass == "reflection":
                if MARKER in body and bodies_differ(base_sig, sig):
                    state, conf = "LIKELY", 70
                    note = "valor reflejado con diferencia material"
            elif kind == "xss_sqli" and pclass == "sqli_marker":
                if bodies_differ(base_sig, sig) and re.search(
                        r"sql|syntax|mysql|odbc|ora-|sqlite|psql", body, re.I):
                    state, conf = "LIKELY", 75
                    note = "error SQL diferencial ante marcador"
            elif kind == "ssrf":
                if any(rx.search(body) for rx in METADATA_SIGNS[:2]):
                    state, conf = "CONFIRMED", 90
                    note = "metadatos cloud internos expuestos"
                elif bodies_differ(base_sig, sig) and re.search(
                        r"connection|refused|timeout|dns|resolve|private|internal|"
                        r"169\.254|127\.0\.0\.1|localhost", body, re.I):
                    state, conf = "LIKELY", 70
                    note = "diferencial interno ante URL controlada"
            elif kind == "redirect":
                try:
                    loc = str(resp.headers.get("Location", "")) if hasattr(
                        resp, "headers") else ""
                except Exception:
                    loc = ""
                hist = getattr(resp, "history", []) or []
                if "example.test" in loc or any(
                        "example.test" in str(getattr(h, "headers", {}).get(
                            "Location", "")) for h in hist):
                    state, conf = "CONFIRMED", 85
                    note = f"redirección externa a {loc or 'historial'}"
            elif kind == "ssti":
                # Confirmación matemática (idea #6): 7*7->49, 8*8->64,
                # 9*9->81. La relación debe mantenerse en las tres.
                ladder = [("{{7*7}}", "49"), ("{{8*8}}", "64"), ("{{9*9}}", "81")]
                hits = []
                if re.search(r"\b49\b", body) and bodies_differ(base_sig, sig):
                    hits.append(("{{7*7}}", "49", body, sig))
                    for expr, want in ladder[1:]:
                        if budget and not budget.consume_payload():
                            break
                        rr = _replay(ctx, budget, info, expr)
                        if rr is None:
                            break
                        rb = getattr(rr, "text", "") or ""
                        rs = sig_of(rr)
                        if re.search(r"\b%s\b" % want, rb) and bodies_differ(base_sig, rs):
                            hits.append((expr, want, rb, rs))
                        else:
                            break
                if len(hits) >= 3:
                    state, conf = "CONFIRMED", 95
                    note = "evaluación matemática 7*7=49, 8*8=64, 9*9=81"
                    body, sig = hits[0][2], hits[0][3]
                    payload = " · ".join(h[0] for h in hits)
                elif hits:
                    state, conf = "LIKELY", 70
                    note = "expresión 7*7 evaluada (49), escalera incompleta"
            elif kind == "lfi":
                if re.search(r"root:x:0:0:", body):
                    state, conf = "CONFIRMED", 90
                    note = "/etc/passwd expuesto"
            if state:
                # Retest de la sonda ganadora (reproducibilidad +20).
                retest_ok = False
                rr = _replay(ctx, budget, info, payload.split(" · ")[0])
                if rr is not None:
                    rb = getattr(rr, "text", "") or ""
                    rs = sig_of(rr)
                    if kind == "ssti":
                        retest_ok = bool(re.search(r"\b49\b", rb))
                    elif kind == "lfi":
                        retest_ok = bool(re.search(r"root:x:0:0:", rb))
                    elif kind == "redirect":
                        try:
                            lloc = str(rr.headers.get("Location", "")) if hasattr(rr, "headers") else ""
                        except Exception:
                            lloc = ""
                        retest_ok = "example.test" in lloc
                    else:
                        retest_ok = bodies_differ(base_sig, rs)
                # La reflexión sola no es firma de exploit: sin matched_signature
                # el score queda en diferencial+retest+contexto (LIKELY).
                sig_keys = {"ssti": "evaluated_expression",
                            "lfi": "file_signature",
                            "ssrf": "metadata_response",
                            "redirect": "external_redirect"}
                ev_extra = {}
                if sig_keys.get(kind):
                    ev_extra["matched_signature"] = sig_keys[kind]
                finding = {
                    "type": f"smart_{kind}",
                    "severity": sev,
                    "confidence": conf,
                    "verification_state": state,
                    "title": f"Smart fuzz [{kind}]: {note} en '{info['param']}'",
                    "detail": f"Baseline {base_sig[0]}/{base_sig[1]} bytes -> "
                              f"payload {sig[0]}/{sig[1]} bytes. {note}.",
                    "url": info["url"],
                    "parameter": info["param"],
                    "payload": payload,
                    "evidence": {
                        "url": info["url"], "parameter": info["param"],
                        "method": info.get("method", "GET"),
                        "baseline": {"status": base_sig[0], "bytes": base_sig[1]},
                        "comparison": {"status": sig[0], "bytes": sig[1]},
                        "response_pair": True,
                        "retest": retest_ok,
                        "retest_count": 2 if retest_ok else 1,
                        "response_excerpt": trim(body, 800),
                        **ev_extra,
                    },
                }
                findings.append(finding)
                ctx.finding(finding)
                ctx.log("ok", f"Smart fuzz [{kind}]: {info['param']} ({state})")
                break  # Un confirmado por parámetro basta; evita ruido.
    ctx.log("info", f"Smart fuzz: {len(findings)} hallazgo(s) verificado(s)")
    return {"findings": findings, "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["discovered_params"]
