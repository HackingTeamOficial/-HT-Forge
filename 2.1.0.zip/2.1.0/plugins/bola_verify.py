#!/usr/bin/env python3
"""plugins/bola_verify.py - HT Forge Authorization Engine (idea GramFuzz #1).

Verificación real de BOLA/IDOR con contexto de autorización:

  detectar identificadores -> crear baseline -> modificar ID ->
  comparar respuesta -> comprobar identidad/propietario ->
  repetir con contexto -> confirmar / refutar

Nunca confirma por un mero HTTP 200: exige evidencia diferencial de
que los datos pertenecen a otro contexto de autorización. Las
hipótesis refutadas no generan hallazgo (solo log).
"""

from typing import Dict, List
from urllib.parse import parse_qsl, urlsplit

from core.context import Context

try:
    from plugins._verify_common import (
        bodies_differ, cross_owner_signal, is_id_param, mutate_id,
        safe_fetch, set_param, sig_of, trim,
    )
except ImportError:  # pragma: no cover - fallback ejecución directa
    from _verify_common import (
        bodies_differ, cross_owner_signal, is_id_param, mutate_id,
        safe_fetch, set_param, sig_of, trim,
    )

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])


def _collect_id_targets(ctx) -> List[Dict]:
    """IDs desde parámetros descubiertos + query del target + crawler."""
    targets: List[Dict] = []
    seen = set()
    params = list(ctx.get("discovered_params", []) or [])
    for info in params:
        if not isinstance(info, dict):
            continue
        name = str(info.get("param", ""))
        value = str(info.get("baseline_value", info.get("value", "")))
        if not value:
            # Sin valor conocido no hay baseline: se omite (no adivinar).
            continue
        if is_id_param(name, value):
            key = (str(info.get("url", ctx.target)), name)
            if key not in seen:
                seen.add(key)
                targets.append({
                    "url": str(info.get("url", ctx.target)),
                    "param": name,
                    "method": str(info.get("method", "GET")).upper(),
                    "value": value,
                })
    # Query string del propio target.
    try:
        q = parse_qsl(urlsplit(ctx.target).query, keep_blank_values=True)
        for name, value in q:
            if value and is_id_param(name, value):
                key = (ctx.target, name)
                if key not in seen:
                    seen.add(key)
                    targets.append({"url": ctx.target, "param": name,
                                    "method": "GET", "value": value})
    except Exception:
        pass
    return targets


def _replay(ctx, budget, info, value, extra=None):
    method = info["method"]
    kw = dict(extra or {})
    if method == "POST":
        data = dict(kw.pop("form_data", None) or {})
        data[info["param"]] = value
        return safe_fetch(ctx, budget, "POST", info["url"], data=data, **kw)
    return safe_fetch(ctx, budget, "GET", set_param(info["url"], info["param"], value), **kw)


def _auth_contexts(ctx):
    """Contextos de autorización extra (idea #3): [{name, headers, cookies}].

    Sin segundo contexto no se puede probar cambio de usuario: se deja
    verification_needed en la evidencia en vez de inventarlo.
    """
    raw = (getattr(ctx, "config", None) or {}).get("auth_contexts") or []
    out = []
    for entry in raw[:2]:
        if isinstance(entry, dict):
            out.append({"name": str(entry.get("name") or f"ctx{len(out) + 1}"),
                        "headers": dict(entry.get("headers") or {}),
                        "cookies": dict(entry.get("cookies") or {})})
    return out


def run(ctx: Context) -> Dict:
    """Motor de autorización: confirma o refuta BOLA/IDOR."""
    budget = get_budget(ctx, "bola_verify", {"max_requests": 60, "max_seconds": 120.0,
                                             "max_payloads": 20, "max_targets": 12}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "Authorization Engine: baseline -> mutación -> comparación")

    targets = need(ctx, "bola_verify", _collect_id_targets(ctx))
    refuted = 0
    for info in targets:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        if budget and not budget.consume_target():
            break
        base_resp = _replay(ctx, budget, info, info["value"])
        if base_resp is None:
            continue
        base_sig = sig_of(base_resp)
        base_body = getattr(base_resp, "text", "") or ""
        if base_sig[0] >= 400:
            continue  # Sin baseline válido no se puede verificar.

        for alt in mutate_id(info["value"]):
            if ctx.stopped or (budget and budget.exhausted()):
                break
            if budget and not budget.consume_payload():
                break
            mut_resp = _replay(ctx, budget, info, alt)
            if mut_resp is None:
                continue
            mut_sig = sig_of(mut_resp)
            mut_body = getattr(mut_resp, "text", "") or ""
            if not bodies_differ(base_sig, mut_sig):
                refuted += 1  # Misma respuesta: hipótesis refutada.
                continue
            if mut_sig[0] in (401, 403):
                refuted += 1  # Control de acceso activo: refutado.
                continue
            if cross_owner_signal(base_body, mut_body, info["value"], alt):
                # Retest: repetir la mutación ganadora (reproducibilidad).
                retest_ok = False
                re_resp = _replay(ctx, budget, info, alt)
                if re_resp is not None:
                    re_body = getattr(re_resp, "text", "") or ""
                    retest_ok = cross_owner_signal(base_body, re_body,
                                                   info["value"], alt)
                # Segundo contexto de autorización (idea #3): A->propio OK,
                # B->objeto de A ¿DENIED o 200+datos?
                contexts = _auth_contexts(ctx)
                cross = None
                if len(contexts) >= 1:
                    second = contexts[0]
                    kw = {}
                    if second["headers"]:
                        kw["headers"] = second["headers"]
                    if second["cookies"]:
                        kw["cookies"] = second["cookies"]
                    b_base = _replay(ctx, budget, info, info["value"], extra=kw)
                    b_mut = _replay(ctx, budget, info, alt, extra=kw)
                    if b_base is not None and b_mut is not None:
                        bs, ms = sig_of(b_base), sig_of(b_mut)
                        mb = getattr(b_mut, "text", "") or ""
                        if ms[0] in (401, 403):
                            cross = {"context_b": second["name"],
                                     "result": "DENIED",
                                     "note": "B no accede al objeto de A"}
                        elif cross_owner_signal(
                                getattr(b_base, "text", "") or "", mb,
                                info["value"], alt):
                            cross = {"context_b": second["name"],
                                     "result": "200+datos",
                                     "note": "B también ve datos de A: "
                                             "control ausente"}
                finding = {
                    "type": "bola_idor",
                    "severity": "high",
                    "confidence": 92 if (retest_ok and cross) else 85,
                    "verification_state": "CONFIRMED",
                    "title": f"BOLA/IDOR confirmado en parámetro '{info['param']}'",
                    "detail": (
                        f"El objeto '{alt}' devuelve datos de otro contexto de "
                        f"autorización (baseline '{info['value']}': "
                        f"{base_sig[0]}/{base_sig[1]} bytes -> mutación: "
                        f"{mut_sig[0]}/{mut_sig[1]} bytes)."
                    ),
                    "url": info["url"],
                    "parameter": info["param"],
                    "payload": alt,
                    "evidence": {
                        "url": info["url"],
                        "parameter": info["param"],
                        "method": info["method"],
                        "baseline": {"id": info["value"], "status": base_sig[0],
                                     "bytes": base_sig[1]},
                        "comparison": {"id": alt, "status": mut_sig[0],
                                       "bytes": mut_sig[1]},
                        "response_pair": True,
                        "matched_signature": "cross_owner_data",
                        "retest": retest_ok,
                        "retest_count": 2 if retest_ok else 1,
                        "authorization_matrix": {
                            "context_a": "propio",
                            "a_own_object": f"{base_sig[0]}+datos",
                            "cross_context": cross,
                        },
                        "verification_needed": (
                            None if cross else
                            "Confirmar con segundo contexto de autorización "
                            "(auth_contexts en config)"),
                        "mutated_excerpt": trim(mut_body, 800),
                    },
                }
                findings.append(finding)
                ctx.finding(finding)
                ctx.log("ok", f"BOLA confirmado: {info['param']}={alt}")
                break
            refuted += 1
    ctx.log("info", f"Authorization Engine: {len(findings)} confirmado(s), "
                    f"{refuted} hipótesis refutada(s)")
    return {"findings": findings,
            "refuted": refuted,
            "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["discovered_params"]
