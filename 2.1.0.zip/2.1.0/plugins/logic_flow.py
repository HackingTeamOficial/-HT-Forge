#!/usr/bin/env python3
"""plugins/logic_flow.py - HT Forge Business Logic Engine (idea GramFuzz #7).

Analiza secuencias A -> B -> C y prueba violaciones de flujo:

  B -> B  (replay: repetir una acción de cambio de estado)
  A -> C  (step-skip: saltarse un paso intermedio)
  A -> A' (tamper: cambiar un parámetro tras la validación)

No destructivo: usa replays idénticos y accesos directos de lectura.
Solo emite CONFIRMED/LIKELY con diferencial; el resto es log.
"""

import re
from typing import Dict, List

from core.context import Context

try:
    from plugins._verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )
except ImportError:  # pragma: no cover
    from _verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])

STATE_HINT_RE = re.compile(
    r"(order|checkout|payment|pay|cart|transfer|withdraw|coupon|voucher|"
    r"redeem|loyalty|register|confirm|approve|publish|delete|update|"
    r"action|do|step|stage|phase|wizard)", re.IGNORECASE)
COUNT_RE = re.compile(
    r"(total|count|balance|quantity|qty|amount|uses?|remaining|left)\s*"
    r"[:=]\s*['\"]?(\d+)", re.IGNORECASE)


def _flows(ctx) -> List[Dict]:
    """Candidatos de flujo: POSTs descubiertos + URLs con pasos."""
    flows = []
    for p in (ctx.get("discovered_params", []) or []):
        if not isinstance(p, dict):
            continue
        url = str(p.get("url", ""))
        if str(p.get("method", "GET")).upper() == "POST" and STATE_HINT_RE.search(url):
            flows.append({"url": url, "param": str(p.get("param", "")),
                          "form_data": dict(p.get("form_data") or {}),
                          "kind": "state_change"})
    for u in (ctx.get("discovered_urls", []) or []):
        u = u if isinstance(u, str) else str(u)
        m = re.search(r"(step|stage|phase|page)=(\d+)", u)
        if m:
            flows.append({"url": u, "param": m.group(1),
                          "step": int(m.group(2)), "kind": "step"})
    return flows


def _counts(body):
    return dict(COUNT_RE.findall(str(body or "")))


def run(ctx: Context) -> Dict:
    """Pruebas de secuencia con evidencia diferencial."""
    budget = get_budget(ctx, "logic_flow", {"max_requests": 50, "max_seconds": 120.0,
                                            "max_payloads": 20, "max_targets": 10}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "Business Logic Engine: replay, step-skip, tamper")

    flows = need(ctx, "logic_flow", _flows(ctx))[: (budget.max_targets if budget else 10)]
    for flow in flows:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        if budget and not budget.consume_target():
            break
        if flow["kind"] == "state_change":
            # B -> B: repetir la misma acción y comparar contadores/estado.
            data = dict(flow["form_data"])
            if flow["param"] and flow["param"] not in data:
                data[flow["param"]] = "1"
            r1 = safe_fetch(ctx, budget, "POST", flow["url"], data=data)
            if r1 is None:
                continue
            s1, b1 = sig_of(r1), getattr(r1, "text", "") or ""
            if s1[0] >= 400:
                continue
            r2 = safe_fetch(ctx, budget, "POST", flow["url"], data=data)
            if r2 is None:
                continue
            s2, b2 = sig_of(r2), getattr(r2, "text", "") or ""
            c1, c2 = _counts(b1), _counts(b2)
            moved = {k: (c1.get(k), c2.get(k)) for k in set(c1) | set(c2)
                     if c1.get(k) != c2.get(k)}
            if moved and bodies_differ(s1, s2, min_bytes_delta=0):
                finding = {
                    "type": "logic_replay",
                    "severity": "medium",
                    "confidence": 75,
                    "verification_state": "LIKELY",
                    "title": f"Replay de acción de estado en {flow['url'][:80]}",
                    "detail": f"Repetir B->B cambia el estado observable: {moved}. "
                              f"Posible falta de idempotencia / doble efecto.",
                    "url": flow["url"],
                    "parameter": flow["param"],
                    "evidence": {
                        "url": flow["url"], "parameter": flow["param"],
                        "baseline": {"status": s1[0], "bytes": s1[1]},
                        "comparison": {"status": s2[0], "bytes": s2[1]},
                        "counters_moved": moved,
                        "response_pair": True,
                    },
                }
                findings.append(finding)
                ctx.finding(finding)
                ctx.log("ok", f"Logic replay LIKELY: {flow['url'][:80]}")
        elif flow["kind"] == "step":
            # A -> C: pedir el paso N+1 sin completar el paso N.
            nxt = re.sub(r"(step|stage|phase|page)=\d+",
                         lambda m: f"{m.group(1)}={flow['step'] + 1}", flow["url"])
            base = safe_fetch(ctx, budget, "GET", flow["url"])
            if base is None:
                continue
            sb = sig_of(base)
            rj = safe_fetch(ctx, budget, "GET", nxt)
            if rj is None:
                continue
            sj, bj = sig_of(rj), getattr(rj, "text", "") or ""
            if sj[0] < 400 and bodies_differ(sb, sj) and not re.search(
                    r"login|signin|auth|denied|forbidden|not found|no existe",
                    bj, re.I):
                finding = {
                    "type": "logic_step_skip",
                    "severity": "medium",
                    "confidence": 70,
                    "verification_state": "LIKELY",
                    "title": f"Posible salto de paso: {nxt[:100]} accesible",
                    "detail": f"El paso {flow['step'] + 1} responde {sj[0]} sin "
                              f"completar el paso {flow['step']}. Requiere "
                              f"validación humana del flujo real.",
                    "url": nxt,
                    "parameter": flow["param"],
                    "evidence": {
                        "url": nxt, "parameter": flow["param"],
                        "baseline": {"status": sb[0], "bytes": sb[1]},
                        "comparison": {"status": sj[0], "bytes": sj[1]},
                        "response_pair": True,
                        "response_excerpt": trim(bj, 600),
                    },
                }
                findings.append(finding)
                ctx.finding(finding)
                ctx.log("ok", f"Logic step-skip LIKELY: paso {flow['step'] + 1}")
    ctx.log("info", f"Business Logic Engine: {len(findings)} hallazgo(s)")
    return {"findings": findings, "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["discovered_params", "discovered_urls"]
