#!/usr/bin/env python3
"""plugins/api_discovery.py - Descubrimiento de APIs desde tráfico (idea #2).

Extrae endpoints de las respuestas ya observadas (HTML/JS/JSON):
fetch/XHR, rutas API, parámetros y contexto de autorización, sin
disparar peticiones indiscriminadas. Alimenta discovered_urls y
discovered_params para los motores de verificación.
"""

import re
from typing import Dict, List
from urllib.parse import parse_qsl, urljoin, urlsplit

from core.context import Context

try:
    from core.budgets import get_budget, need
except ImportError:  # pragma: no cover
    get_budget = None
    need = lambda ctx, label, items: list(items or [])

# fetch("/api/x"), axios.post('...'), $.get("..."), open('GET', ...)
FETCH_RE = re.compile(
    r"(?:fetch|axios\.(?:get|post|put|patch|delete)|"
    r"\$\.(?:get|post|ajax)|xhr\.open|\.open)\s*\(\s*"
    r"(?:['\"](GET|POST|PUT|PATCH|DELETE)['\"]\s*,\s*)?['\"`]([^'\"`]+)['\"`]",
    re.IGNORECASE,
)
# "/api/v1/users", "api/auth/login"
PATH_RE = re.compile(r"['\"`](/?(?:api|v\d|graphql|rest|ajax|json|auth|oauth)[^'\"`\s<>]*)['\"`]", re.IGNORECASE)
# SPA routes: path: '/dashboard/:id', route("/admin")
ROUTE_RE = re.compile(
    r"(?:path|route|to)\s*[:=]\s*['\"`](/(?!/)[^'\"`]*?)['\"`]", re.IGNORECASE)
AUTH_HINT_RE = re.compile(
    r"(authorization|bearer|session|csrf|xsrf|token|api[_-]?key|auth)", re.IGNORECASE)


def _candidate_urls(text):
    found = []
    for rx in (FETCH_RE, PATH_RE, ROUTE_RE):
        for m in rx.finditer(text or ""):
            groups = [g for g in m.groups() if g]
            if not groups:
                continue
            url = groups[-1].strip()
            if not url or url.startswith(("data:", "javascript:", "#", "mailto:")):
                continue
            if " " in url:
                continue
            found.append(url)
    # Deduplicar preservando orden.
    return list(dict.fromkeys(found))


def run(ctx: Context) -> Dict:
    """Mapea endpoints desde el tráfico observado."""
    budget = get_budget(ctx, "api_discovery", {"max_requests": 10, "max_seconds": 60.0,
                                               "max_payloads": 0, "max_targets": 10}) \
        if get_budget else None
    findings: List[Dict] = []
    ctx.log("info", "API discovery: endpoints desde tráfico observado")

    pages = []
    for u in (ctx.get("discovered_urls", []) or [])[: (budget.max_targets if budget else 10)]:
        pages.append(u if isinstance(u, str) else str(u))
    if ctx.target not in pages:
        pages.insert(0, ctx.target)
    pages = need(ctx, "api_discovery", pages)

    known_urls = set(pages)
    known_params = {(str(p.get("url", "")), str(p.get("param", "")))
                    for p in (ctx.get("discovered_params", []) or [])
                    if isinstance(p, dict)}
    new_endpoints, new_params = [], []

    for page in pages:
        if ctx.stopped or (budget and budget.exhausted()):
            break
        try:
            if budget and not budget.consume_request():
                break
            resp = ctx.req("GET", page, timeout=10,
                           headers={"Connection": "close"})
            body = getattr(resp, "text", "") or ""
            ctype = ""
            try:
                ctype = str(resp.headers.get("Content-Type", ""))
            except Exception:
                pass
        except Exception:
            continue
        for cand in _candidate_urls(body):
            abs_url = urljoin(page, cand)
            parts = urlsplit(abs_url)
            if parts.netloc and parts.netloc != urlsplit(ctx.target).netloc:
                continue  # Solo mismo origen.
            clean = abs_url.split("#")[0]
            if clean not in known_urls:
                known_urls.add(clean)
                new_endpoints.append(clean)
            for pname, pval in parse_qsl(parts.query, keep_blank_values=True):
                key = (clean.split("?")[0], pname)
                if key not in known_params:
                    known_params.add(key)
                    entry = {"url": clean.split("?")[0], "param": pname,
                             "method": "GET", "baseline_value": pval,
                             "source": "api_discovery",
                             "auth_context": bool(AUTH_HINT_RE.search(body[:20000]))}
                    new_params.append(entry)
        # JSON con rutas: {"endpoint": "/api/..."} o listas de paths.
        if "json" in ctype.lower() or body.lstrip().startswith(("{", "[")):
            for m in re.finditer(r"['\"](/[A-Za-z0-9_\-./]{2,120})['\"]", body):
                abs_url = urljoin(page, m.group(1))
                if urlsplit(abs_url).netloc == urlsplit(ctx.target).netloc \
                        and abs_url not in known_urls:
                    known_urls.add(abs_url)
                    new_endpoints.append(abs_url)

    if new_endpoints or new_params:
        urls = list(ctx.get("discovered_urls", []) or []) + new_endpoints
        ctx.set("discovered_urls", list(dict.fromkeys(urls)))
        params = list(ctx.get("discovered_params", []) or []) + new_params
        ctx.set("discovered_params", params)
        finding = {
            "type": "api_discovery",
            "severity": "info",
            "confidence": 90,
            "verification_state": "CONFIRMED",
            "title": f"API discovery: {len(new_endpoints)} endpoint(s), "
                     f"{len(new_params)} parámetro(s) desde tráfico",
            "detail": f"Endpoints mapeados sin fuzzing bruto: {len(new_endpoints)} "
                      f"nuevos. Alimentan a los motores de verificación.",
            "url": ctx.target,
            "evidence": {"endpoints": new_endpoints[:50],
                         "parameters": [p["param"] for p in new_params[:50]],
                         "baseline": {"pages_analyzed": len(pages)}},
        }
        findings.append(finding)
        ctx.finding(finding)
        ctx.log("ok", f"API discovery: +{len(new_endpoints)} endpoints, "
                      f"+{len(new_params)} params")
    else:
        ctx.log("info", "API discovery: sin endpoints nuevos")
    return {"findings": findings, "endpoints": new_endpoints,
            "parameters": new_params,
            "budget": budget.summary() if budget else {}}


__version__ = "2.1.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
