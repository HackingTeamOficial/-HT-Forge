"""HT Brute Force — Hash cracker.
Supports dictionary, rules, mask attacks for common hash types.
Uses bcrypt (pip) and hashlib (stdlib). Falls back to john/hashcat if installed.
"""
import hashlib, hmac, os, subprocess, sys, time
from typing import Optional

try:
    import bcrypt
    HAS_BCRYPT = True
except ImportError:
    HAS_BCRYPT = False

class CrackResult:
    def __init__(self, hash_type, raw, cracked, password=None, time_s=0, method="", attempts=None):
        self.hash_type = hash_type
        self.raw = raw
        self.cracked = cracked
        self.password = password
        self.time_s = time_s
        self.method = method
        self.attempts = attempts

    def to_dict(self):
        return {"type": self.hash_type, "hash": self.raw[:24], "cracked": self.cracked,
                "password": self.password, "time_s": round(self.time_s, 3), "method": self.method}

def _md5(s): return hashlib.md5(s.encode() if isinstance(s, str) else s).hexdigest()
def _sha1(s): return hashlib.sha1(s.encode() if isinstance(s, str) else s).hexdigest()
def _sha256(s): return hashlib.sha256(s.encode() if isinstance(s, str) else s).hexdigest()
def _sha512(s): return hashlib.sha512(s.encode() if isinstance(s, str) else s).hexdigest()
def _ntlm(s): return hashlib.new('md4', s.encode('utf-16le')).hexdigest()

def _try_hash(hasher, target, word, salt=None):
    """Compare hasher(word) against target. Returns password on match."""
    try:
        h = hasher(word)
        if h.lower() == target.lower():
            return word
    except Exception:
        pass
    return None

def crack_hash(target: str, words: list, hash_type: str = "auto",
               rules: bool = False, mask: str = "", max_time: float = 30) -> CrackResult:
    """Crack a single hash against a wordlist with optional rules/mask."""
    info = {"ntlm": ("ntlm", _ntlm), "md5": ("md5", _md5), "sha1": ("sha1", _sha1),
            "sha256": ("sha256", _sha256), "sha512": ("sha512", _sha512),
            "md4": ("md4", lambda s: hashlib.new('md4', s.encode('utf-16le')).hexdigest())}

    if hash_type == "auto":
        from ht_brute_force.core.hash_detect import detect
        dt = detect(target)
        hash_type = dt["type"]

    t0 = time.time()

    # bcrypt / scrypt / argon2 — slow, limited attempts
    if hash_type in ("bcrypt", "scrypt", "argon2"):
        if not HAS_BCRYPT:
            return CrackResult(hash_type, target, False, method="no-bcrypt")
        for i, w in enumerate(words):
            if time.time() - t0 > max_time:
                return CrackResult(hash_type, target, False, method="timeout", attempts=i)
            try:
                if bcrypt.checkpw(w.encode(), target.encode()):
                    return CrackResult(hash_type, target, True, password=w,
                                       time_s=time.time()-t0, method="bcrypt")
            except Exception:
                continue
        return CrackResult(hash_type, target, False, method="bcrypt", attempts=len(words))

    # md5crypt / sha256crypt / sha512crypt — use john if available
    if hash_type in ("md5crypt", "sha256crypt", "sha512crypt"):
        return _crack_crypt(target, words, hash_type, t0, max_time)

    # Standard hashes
    if hash_type in info:
        name, hasher = info[hash_type]
        for w in words:
            if time.time() - t0 > max_time:
                return CrackResult(name, target, False, method="dict-timeout", attempts=len(words))
            r = _try_hash(hasher, target, w)
            if r:
                return CrackResult(name, target, True, password=r,
                                   time_s=time.time()-t0, method="dictionary")
            if rules:
                for mut in _rules(w):
                    r = _try_hash(hasher, target, mut)
                    if r:
                        return CrackResult(name, target, True, password=mut,
                                           time_s=time.time()-t0, method="rules")
        return CrackResult(name, target, False, method="dictionary", attempts=len(words))

    return CrackResult(hash_type, target, False, method="unsupported")

def _crack_crypt(target, words, hash_type, t0, max_time):
    """Fallback: write hash to file, call john --wordlist, parse output."""
    import tempfile, subprocess
    prefix = {"md5crypt": "$1$", "sha256crypt": "$5$", "sha512crypt": "$6$"}[hash_type]
    # Extract salt from target
    parts = target.split("$")
    if len(parts) < 3:
        return CrackResult(hash_type, target, False, method="john-fail")
    salt = parts[2]
    fake_hash = f"{prefix}${salt}$placeholder"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".hash", delete=False) as f:
        f.write(fake_hash + "\n")
        hfile = f.name
    with tempfile.NamedTemporaryFile(mode="w", suffix=".lst", delete=False) as f:
        for w in words:
            f.write(w + "\n")
        wfile = f.name
    try:
        subprocess.run(["john", "--wordlist=" + wfile, hfile, "--format=" + hash_type,
                        "--stdout", "--session=htbf"], capture_output=True, timeout=max_time+5)
        # Try john --show
        r = subprocess.run(["john", "--show", hfile], capture_output=True, text=True,
                           timeout=10)
        for line in r.stdout.splitlines():
            if ":" in line:
                pw = line.split(":")[-1].strip()
                if pw and pw != "placeholder":
                    return CrackResult(hash_type, target, True, password=pw,
                                       time_s=time.time()-t0, method="john")
        return CrackResult(hash_type, target, False, method="john", attempts=len(words))
    except Exception as e:
        return CrackResult(hash_type, target, False, method=f"john-error:{e}")
    finally:
        os.unlink(hfile)
        os.unlink(wfile)

# --- Rules engine ---
RULES = [
    lambda w: w,
    lambda w: w.capitalize(),
    lambda w: w.upper(),
    lambda w: w.lower(),
    lambda w: w + "1",
    lambda w: w + "12",
    lambda w: w + "123",
    lambda w: w + "!",
    lambda w: w + "1!",
    lambda w: w + "2024",
    lambda w: w + "2025",
    lambda w: w + "2026",
    lambda w: "P" + w,
    lambda w: w + "p",
    lambda w: w + "_",
    lambda w: "_" + w,
    lambda w: w[::-1],
    lambda w: w + "1234",
    lambda w: w + "12345",
    lambda w: w + "123456",
]

def _rules(word):
    for r in RULES:
        try:
            yield r(word)
        except Exception:
            continue

def crack_batch(targets: list, words: list, hash_type="auto", rules=False, max_time=30) -> list:
    return [crack_hash(t, words, hash_type, rules, max_time=max_time) for t in targets]