"""HT Brute Force — Generic TCP brute force.
Works against any service that sends a banner or accepts login via plain socket.
"""
import socket, time, threading, queue

class TCPBruter:
    def __init__(self, timeout=10, max_threads=10, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []
        self.banner = ""

    def _grab_banner(self, host, port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.settimeout(3)
            try:
                self.banner = s.recv(1024).decode('utf-8', errors='replace').strip()
            except Exception:
                pass
            s.close()
        except Exception:
            pass

    def _try_auth(self, host, port, user, passwd):
        """Override in protocol-specific subclass. Base returns None."""
        return None

    def run(self, host, port, users, passwords):
        self._grab_banner(host, port)
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_auth(host, port, u, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results