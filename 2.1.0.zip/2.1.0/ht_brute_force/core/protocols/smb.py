"""HT Brute Force — SMB/NFS/FTP brute force.
Uses raw socket for SMB-like services.
"""
import socket, struct, time, threading, queue

class SMBBruter:
    def __init__(self, timeout=10, max_threads=3, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _negotiate(self, s):
        """SMBv1 negotiate protocol request."""
        negotiate = b"\x00\x00\x00\x85\xffSMBr\x00\x00\x00\x00\x18\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xfe\x00\x00\x00\x00\x00\x62\x00\x02\x50\x43\x20\x4e\x45\x54\x57\x4f\x52\x4b\x20\x50\x52\x4f\x47\x52\x41\x4d\x20\x31\x2e\x30\x00\x02\x4c\x41\x4e\x4d\x41\x4e\x31\x2e\x30\x00\x02\x57\x69\x6e\x64\x6f\x77\x73\x20\x66\x6f\x72\x20\x57\x6f\x72\x6b\x67\x72\x6f\x75\x70\x73\x20\x33\x2e\x31\x61\x00\x02\x4c\x4d\x31\x2e\x32\x58\x30\x30\x32\x00\x02\x4c\x41\x4e\x4d\x41\x4e\x32\x2e\x31\x00\x02\x4e\x54\x20\x4c\x4d\x20\x30\x2e\x31\x32\x00"
        s.send(negotiate)
        return s.recv(1024)

    def _try_session(self, host, port, user, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            resp = self._negotiate(s)
            if not resp or b"SMB" not in resp[:4]:
                s.close()
                return None
            # Session setup andx - simplified check
            s.close()
            # Fallback: try using existing tools
            return self._try_ncrack(host, port, user, passwd, t0)
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def _try_ncrack(self, host, port, user, passwd, t0):
        """Use ncrack if available."""
        try:
            r = subprocess.run(
                ["ncrack", "-p", str(port), "--user", user, "-P", "-", host],
                input=passwd.encode(), capture_output=True, timeout=self.timeout+5)
            if b"Success" in r.stderr or b"success" in r.stderr.lower():
                return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
            return None
        except FileNotFoundError:
            return None

    def run(self, host, port, users, passwords):
        import subprocess
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_session(host, port, u, p)
                if r and r.get("password"):
                    self.results.append(r)
                    self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results