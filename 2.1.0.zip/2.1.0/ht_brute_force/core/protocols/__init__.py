"""HT Brute Force protocol adapters."""
