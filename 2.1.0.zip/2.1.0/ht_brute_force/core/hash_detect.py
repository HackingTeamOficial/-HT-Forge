"""HT Brute Force -- Hash type detector.
Identifies hash type by pattern. Returns dict with type, name, example, cracker.
No external deps -- pure stdlib regex.
"""
import re

HASH_PATTERNS = [
    # (name, regex, cracker_hint, example)
    # Order matters - check from most specific to most general
    # bcrypt family
    ("bcrypt", re.compile(r'^\$2[aby]\$\d+\$[A-Za-z0-9./]+$'), "bcrypt"),
    ("scrypt", re.compile(r'^\$scrypt\$\d+:\d+:\d+:[A-Za-z0-9+/=]+$'), "scrypt"),
    ("argon2", re.compile(r'^\$argon2[di]\$v=\d+,m=\d+,t=\d+(,p=\d+)?\$[A-Za-z0-9+/=]+$'), "hashcat"),
    # Unix crypt variants
    ("sha512crypt", re.compile(r'^\$6\$[A-Za-z0-9./]+\$[A-Za-z0-9./]+$'), "hashcat"),
    ("sha256crypt", re.compile(r'^\$5\$[A-Za-z0-9./]+\$[A-Za-z0-9./]+$'), "hashcat"),
    ("md5crypt", re.compile(r'^\$1\$[A-Za-z0-9./]+\$[A-Za-z0-9./]+$'), "hashcat"),
    # Prefixed hashes (sha1$, md5$, etc.)
    ("django", re.compile(r'^argon2\$|\$argon2|sha1\$|md5\$|^pbkdf2_sha256|^pbkdf2_sha1', re.I)),
    # Salted hashes
    ("joomla", re.compile(r'^[A-Fa-f0-9]{32}:[A-Fa-f0-9]{32}$'), "hashcat"),
    ("mscash2", re.compile(r'^[A-Fa-f0-9]{32}:[A-Fa-f0-9]{32}$')),
    ("netntlmv2", re.compile(r'^[A-Fa-f0-9]{32}::[A-Fa-f0-9]{16}:[A-Fa-f0-9]+$')),
    ("netntlm", re.compile(r'^[A-Fa-f0-9]{32}:[A-Fa-f0-9]{32}$')),
    ("wordpress", re.compile(r'^\$P\$[A-Za-z0-9./]{31}$'), "hashcat"),
    ("phpass", re.compile(r'^\$H\$[A-Za-z0-9./]{31}$'), "hashcat"),
    # Hex-only hashes by length
    ("sha512", re.compile(r'^[A-Fa-f0-9]{128}$')),
    ("sha384", re.compile(r'^[A-Fa-f0-9]{96}$')),
    ("sha256", re.compile(r'^[A-Fa-f0-9]{64}$')),
    ("sha224", re.compile(r'^[A-Fa-f0-9]{56}$')),
    ("sha1", re.compile(r'^[A-Fa-f0-9]{40}$')),
    ("mysql_sha1", re.compile(r'^\*[A-Fa-f0-9]{40}$')),
    ("md5", re.compile(r'^[A-Fa-f0-9]{32}$')),
    ("ntlm", re.compile(r'^[A-Fa-f0-9]{32}$')),
    ("lanman", re.compile(r'^[A-Fa-f0-9]{32}$')),
    ("wpa", re.compile(r'^[A-Fa-f0-9]{64}$')),
    ("mysql_old", re.compile(r'^[A-Fa-f0-9]{16}$')),
    ("oracle", re.compile(r'^[A-Fa-f0-9]{16}:[A-Fa-f0-9]{16}$')),
    ("ssh_ed25519", re.compile(r'^ssh-ed25519\s+AAAAC3')),
    ("ssh_rsa", re.compile(r'^ssh-rsa\s+AAAAB3')),
]

def detect(hash_str: str, prefer_type: str = None) -> dict:
    """Detect hash type. If prefer_type is provided, prioritize it when ambiguity exists."""
    h = hash_str.strip()
    
    # First, check if preferred type matches
    if prefer_type:
        prefer_lower = prefer_type.lower().replace("-", "").replace(" ", "")
        for name, pattern, *rest in HASH_PATTERNS:
            if name.lower().replace("-", "").replace(" ", "") == prefer_lower and pattern.match(h):
                cracker = rest[0] if rest else "hashcat"
                return {"type": name, "cracker": cracker, "example": h[:24], "raw": h}
    
    # Normal detection
    for name, pattern, *rest in HASH_PATTERNS:
        if pattern.match(h):
            cracker = rest[0] if rest else "hashcat"
            return {"type": name, "cracker": cracker, "example": h[:24], "raw": h}
    
    return {"type": "unknown", "cracker": "hashcat", "example": h[:24], "raw": h}

def detect_batch(lines: list) -> list:
    return [{"line": i+1, **detect(l)} for i, l in enumerate(lines) if l.strip()]

def detect_with_label(label: str, hash_str: str) -> dict:
    """Detect hash type using user-provided label as hint for ambiguous cases."""
    label_clean = label.lower().replace("-", "").replace(" ", "")
    return detect(hash_str, prefer_type=label_clean)

if __name__ == "__main__":
    tests = [
        ["MD5", "aba13ce07c5f2c9727ae02642f7d7d6d"],
        ["SHA-1", "d27a8500de00fe3f8e2b5b3ced1c1972fd6eab4d"],
        ["SHA-224", "5c4a21911a79bf55ab15da6c50894be82dae6f1524cd478aab3b894e"],
        ["SHA-256", "34b9ba63c1e3a872eb0f97fdee16556dea24219ff6d3538c75daf4284ff92015"],
        ["SHA-384", "085ef812cf1fd1b13997f1bcc6671985860285bf74624b5417bd41903bb3b8a09b725ed0341e695533c21bd6148d3fef"],
        ["SHA-512", "505f1ba5b91dc46289b9bec6aa55e2d9f95aa5b6f480366757f4aff83fc59c5ff5417a271dd39a0b875e2b53f44af036866e223bc6326355db43bb7745188f54"],
    ]
    print("=== Detección de hashes con etiquetas ===")
    for expected, h in tests:
        result = detect_with_label(expected, h)
        detected = result["type"]
        match = "✓" if detected == expected else "✗"
        print(f"{match} {expected:12} -> {detected}")