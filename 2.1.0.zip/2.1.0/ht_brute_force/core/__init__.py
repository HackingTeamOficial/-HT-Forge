"""Native HT Brute Force core integrated into HT Forge."""
