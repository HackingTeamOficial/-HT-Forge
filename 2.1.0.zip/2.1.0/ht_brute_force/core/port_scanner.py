"""HT Brute Force — Port scanner with service version detection."""
import socket, time, threading, queue, struct
from concurrent.futures import ThreadPoolExecutor, as_completed

# Common ports with service names
COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 111: "RPC", 135: "MS-RPC", 139: "NetBIOS",
    143: "IMAP", 1433: "MSSQL", 1521: "Oracle", 3306: "MySQL",
    3389: "RDP", 443: "HTTPS", 445: "SMB", 5432: "PostgreSQL",
    6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB"
}

class PortScanner:
    """Scanner that detects open/closed/filtered ports with optional service detection."""
    
    def __init__(self, timeout=3, max_threads=100, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.results = []
        self.banners = {}
    
    def _scan_port(self, host, port):
        """Scan a single port, return (port, state, service, version, banner)."""
        if self.stop_event.is_set():
            return (port, "STOPPED", "", "", "")
        
        state = "CLOSED"
        service = COMMON_PORTS.get(port, "unknown")
        version = ""
        banner = ""
        
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            s.connect((host, port))
            
            # Try to grab banner
            try:
                s.settimeout(2)
                raw = s.recv(1024)
                banner = raw.decode('utf-8', errors='replace').strip()
            except:
                pass
            
            s.close()
            state = "OPEN"
            
            # Simple service/version detection from banner
            b = banner.lower()
            if b:
                if 'ssh' in b:
                    version = self._extract_version(b, 'ssh')
                    service = "SSH"
                elif 'ftp' in b:
                    version = self._extract_version(b, 'ftp')
                    service = "FTP"
                elif 'smtp' in b:
                    version = self._extract_version(b, 'smtp')
                    service = "SMTP"
                elif 'telnet' in b:
                    service = "Telnet"
                elif 'http' in b or 'apache' in b or 'nginx' in b:
                    if 'nginx' in b:
                        service = "Nginx"
                        version = self._extract_version(b, 'nginx')
                    elif 'apache' in b:
                        service = "Apache"
                        version = self._extract_version(b, 'apache')
                    elif 'httpd' in b:
                        service = "Apache"
                        version = self._extract_version(b, 'httpd')
                elif 'microsoft' in b or 'microsoft-iis' in b:
                    service = "IIS"
                    version = self._extract_version(b, 'iis')
                elif 'mysql' in b:
                    service = "MySQL"
                elif 'redis' in b:
                    service = "Redis"
                elif 'smtp' in b:
                    service = "SMTP"
                elif 'smb' in b or 'microsoft' in b:
                    service = "SMB"
                    
        except socket.timeout:
            state = "FILTERED"
        except ConnectionRefusedError:
            state = "CLOSED"
        except OSError:
            state = "FILTERED"
        except Exception:
            state = "CLOSED"
        
        return (port, state, service, version, banner)
    
    def _extract_version(self, banner, service):
        """Extract version string from banner."""
        # Common patterns: /1.0, -1.0, version 1.0, etc.
        import re
        patterns = [
            rf'{service}[/\s-]([\d.]+)',
            rf'version[/\s-]*([\d.]+)',
            r'[\d]+\.[\d]+\.[\d]+',
            r'v[\d]+\.[\d]+',
        ]
        for p in patterns:
            m = re.search(p, banner, re.I)
            if m:
                return m.group(1)
        return ""
    
    def scan_host(self, host, ports=None, service_scan=False):
        """Scan a single host for open ports."""
        if ports is None:
            ports = list(COMMON_PORTS.keys())
        
        self.results = []
        self.banners = {}
        
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = {
                executor.submit(self._scan_port, host, p): p 
                for p in ports
            }
            
            for future in as_completed(futures):
                if self.stop_event.is_set():
                    break
                try:
                    result = future.result()
                    port, state, service, version, banner = result
                    if state in ("OPEN", "CLOSED", "FILTERED"):
                        entry = {
                            "port": port,
                            "state": state,
                            "service": service,
                            "version": version,
                            "banner": banner,
                            "host": host
                        }
                        self.results.append(entry)
                        if banner:
                            self.banners[port] = banner
                except Exception:
                    pass
        
        return self.results


class PortScanAndBrute:
    """Combines port scanning with brute force for discovered services."""
    
    def __init__(self, timeout=10, max_threads=50, stop_event=None):
        self.timeout = timeout
        self.max_threads = max_threads
        self.stop_event = stop_event or threading.Event()
        self.scan_results = []
        self.brute_results = []
        self._scanner = None
    
    def _get_protocols_for_ports(self, ports):
        """Map ports to protocol keys."""
        port_map = {
            22: "ssh", 23: "telnet", 21: "ftp", 25: "smtp",
            110: "mail", 143: "mail", 3306: "mysql", 5432: "mysql",
            6379: "redis", 27017: "redis", 3389: "rdp", 445: "smb",
            139: "smb", 443: "http", 80: "http", 8080: "http",
            8443: "http"
        }
        return [port_map.get(p, "ssh") for p in ports]
    
    def run(self, host, ports=None, users=None, passwords=None, 
            scan_timeout=3, brute_timeout=10):
        """Run port scan then brute force on discovered services."""
        from ht_brute_force.core.protocols.ssh import SSHBruter
        from ht_brute_force.core.protocols.ftp import FTPBruter
        from ht_brute_force.core.protocols.http_basic import HTTPBasicBruter
        from ht_brute_force.core.protocols.mysql import MySQLBruter
        from ht_brute_force.core.protocols.smtp import SMTPBruter
        from ht_brute_force.core.protocols.redis import RedisBruter
        from ht_brute_force.core.protocols.vnc import VNCBruter
        from ht_brute_force.core.protocols.telnet import TelnetBruter
        from ht_brute_force.core.protocols.rdp import RDPBruter
        from ht_brute_force.core.protocols.smb import SMBBruter
        from ht_brute_force.core.protocols.ldap import LDAPBruter
        from ht_brute_force.core.protocols.mail import POP3Bruter, IMAPBruter
        
        users = users or ["admin", "root", "user", "test", "administrator"]
        passwords = passwords or ["admin", "password", "123456", "root", "test"]
        
        # Phase 1: Port Scan
        self._scanner = PortScanner(timeout=scan_timeout, max_threads=50, 
                                       stop_event=self.stop_event)
        self.scan_results = self._scanner.scan_host(host, ports, service_scan=True)
        
        # Get open ports
        open_ports = [r for r in self.scan_results if r["state"] == "OPEN"]
        
        # Map ports to protocols
        proto_map = {
            "ssh": (SSHBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "ftp": (FTPBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "telnet": (TelnetBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "http": (HTTPBasicBruter, lambda h, p, u, pw: (f"http://{h}:{p}", u, pw, "GET")),
            "smtp": (SMTPBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "mysql": (MySQLBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "redis": (RedisBruter, lambda h, p, u, pw: (h, p, pw)),
            "vnc": (VNCBruter, lambda h, p, u, pw: (h, p, pw)),
            "rdp": (RDPBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "smb": (SMBBruter, lambda h, p, u, pw: (h, p, u, pw)),
            "mail": (POP3Bruter, lambda h, p, u, pw: (h, p, u, pw, False)),
        }
        
        # Phase 2: Brute Force on open ports
        for result in open_ports:
            if self.stop_event.is_set():
                break
            
            port = result["port"]
            service_name = result["service"].lower()
            
            # Determine protocol based on port
            port_to_proto = {
                22: "ssh", 23: "telnet", 21: "ftp", 25: "smtp",
                110: "mail", 143: "mail", 3306: "mysql", 6379: "redis",
                3389: "rdp", 445: "smb", 139: "smb", 443: "http",
                80: "http", 8080: "http", 8443: "http"
            }
            
            proto_key = port_to_proto.get(port, "ssh")
            
            if proto_key in proto_map:
                cls, args_fn = proto_map[proto_key]
                try:
                    b = cls(timeout=brute_timeout, max_threads=self.max_threads, 
                            stop_event=self.stop_event)
                    args = args_fn(host, port, users, passwords)
                    r = b.run(*args)
                    for item in r:
                        item["port"] = port
                        item["state"] = "OPEN"
                        item["service"] = result["service"]
                        item["version"] = result["version"]
                        item["banner"] = result["banner"]
                        item["host"] = host
                        self.brute_results.append(item)
                except Exception:
                    pass
        
        # Combine results
        combined = []
        for r in self.scan_results:
            combined.append({
                "port": r["port"],
                "state": r["state"],
                "service": r["service"],
                "version": r["version"],
                "banner": r["banner"],
                "host": r["host"],
                "matches": 0
            })
        
        for r in self.brute_results:
            for c in combined:
                if c["port"] == r["port"] and "password" in r:
                    c["matches"] += 1
                    c["password"] = r.get("password")
                    c["user"] = r.get("user")
                    c["brute_time"] = r.get("time_s")
        
        return {
            "scan_results": self.scan_results,
            "brute_results": self.brute_results,
            "combined": combined,
            "host": host
        }