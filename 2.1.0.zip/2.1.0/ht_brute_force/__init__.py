"""HT Brute Force integration for HT Forge Premium."""
