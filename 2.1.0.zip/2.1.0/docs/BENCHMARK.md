# HT Forge Benchmark — metodología

Comparación objetiva HT Forge vs ZAP / Burp / Nuclei. Sin promesas:
demostrar o no, con resultados reproducibles.

## Métricas

- **Detection**: hallazgos totales y accionables (CONFIRMED/VERIFIED/LIKELY).
- **True/false positives**: estados de verificación + retest como proxy;
  etiquetado manual para TP/FP/FN en la hoja de resultados.
- **Confirmation**: tasa con par baseline→sonda (`response_pair`) y con retest.
- **Evidence quality**: tasas de `response_pair`, `retest`, `cwe`.
- **Coverage**: módulos ejecutados (`modules_run`) vs solicitados.
- **Tiempo**: `duration_s` de pared.
- **Deduplicación**: `duplicate_rate` sobre (tipo, url, parámetro).
- **Errores**: `error_count` + lista.

## Separación de entornos

- **Benchmark público externo**: labs públicos (p. ej. Acuforum de Acunetix)
  y objetivos autorizados. Solo detección, sin volcado de datos.
- **Laboratorio propio** (HT Forge VulnLab local): desarrollo y regresión.
  Aquí sí se permite explotación completa contra datos sintéticos.

Nunca se mezcla: el lab propio no sirve para afirmar superioridad
frente a terceros.

## Reproducir

```bash
python3 tools/benchmark.py --target http://127.0.0.1:8080 --profile full
python3 tools/benchmark.py --target http://127.0.0.1:8080 --modules sqli xss
```

Resultados en `tools/benchmark_results/bench_<ts>.json`.

## Ediciones

DEMO = experiencia completa con límite de capacidad (trial de 24 h a
acceso total, sin recortes de funciones). PRO (~199–299 €/año, hipótesis)
y PREMIUM (~799–1.499 €/año, hipótesis) amplían vigencia y uso
empresarial. Precios pendientes de validación comercial.
