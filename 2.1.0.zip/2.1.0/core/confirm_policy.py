#!/usr/bin/env python3
"""core/confirm_policy.py - Política de confirmación por tipo (9.x, ideas #4/#7/#8).

Endurece los detectores sin tocarlos: limita el estado máximo que cada
tipo puede autodeclarar y exige las claves de evidencia que lo
justifican. Solo degrada; la única subida permitida es la escalera
SQLi (dos técnicas independientes) a nivel de sesión.

Reglas:
- RFI/SSI/marcadores: LIKELY salvo consecuencia demostrada.
- XSS sin contexto ejecutable: LIKELY (tres niveles del doc #4).
- XXE entidad interna: "Unsafe XML entity processing", máx VERIFIED.
- SSRF: matriz por nivel de evidencia (idea #1).
- Score: CONFIRMED>=70 (+repro o independiente), VERIFIED>=40, LIKELY>=35.
"""

from __future__ import annotations

from typing import Any, Dict, List

try:
    from .evidence import (
        ACTIONABLE_STATES, EXECUTABLE_XSS_CONTEXTS, RANK_STATE, STATE_MIN_SCORE,
        STATE_RANK, evidence_score,
    )
except ImportError:  # pragma: no cover
    from core.evidence import (
        ACTIONABLE_STATES, EXECUTABLE_XSS_CONTEXTS, RANK_STATE, STATE_MIN_SCORE,
        STATE_RANK, evidence_score,
    )

# Tipos que jamás se autoconfirman con reflexión/diferencial solos.
MARKER_ONLY_TYPES = {
    "rfi", "ssi", "ssti_possible", "possible_ssti", "rfi_candidate",
    "ssi_candidate", "traversal_candidate",
}

EXECUTABLE_XSS_TYPES = {"xss", "xss_reflected", "xss_stored", "smart_xss_sqli"}


def _is_executable_xss(ev: Dict[str, Any]) -> bool:
    if ev.get("executable") is True:
        return True
    ctx = str(ev.get("reflection_context") or "")
    return (ctx in EXECUTABLE_XSS_CONTEXTS
            and bool(ev.get("raw_reflection"))
            and not ev.get("escaped", True))


def _ssrf_level(ev: Dict[str, Any]) -> tuple:
    """Matriz SSRF (idea #1): nivel + razones del salto.

    respuesta del destino -> CONFIRMED+ · conexión demostrada -> CONFIRMED
    timeout/diferencial -> LIKELY · solo acepta URL -> CANDIDATE.
    """
    if ev.get("metadata_response") or ev.get("destination_response"):
        return ("CONFIRMED", ["respuesta del destino obtenida"])
    body_markers = ("instance_response", "file_content", "service_banner")
    if any(ev.get(k) for k in body_markers):
        return ("CONFIRMED", ["contenido interno del destino en respuesta"])
    conn = str(ev.get("connection_evidence") or "")
    comp = ev.get("comparison") if isinstance(ev.get("comparison"), dict) else {}
    excerpt = str(ev.get("response_excerpt") or "")
    import re as _re
    conn_mark = ("ConnectTimeout" in conn or "ConnectionPool" in conn
                 or "Connection refused" in conn or "NameResolution" in conn
                 or bool(_re.search(r"ConnectTimeout|HTTPConnectionPool|"
                                    r"Failed to establish|Name or service",
                                    excerpt)))
    if conn_mark or ev.get("connection_demonstrated"):
        return ("CONFIRMED", ["conexión al destino demostrada"])
    if ev.get("response_pair") or ev.get("timing_differential"):
        return ("LIKELY", ["timeout/diferencial de red ante URL controlada"])
    return ("CANDIDATE", ["el parámetro acepta URL sin diferencial"])


def apply_policy(finding: Dict[str, Any]) -> Dict[str, Any]:
    """Aplica score + reglas de tipo. Devuelve el finding (mutado)."""
    f = finding
    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    f["evidence"] = ev
    scored = evidence_score(ev)
    ev["evidence_score"] = scored["score"]
    ev["score_breakdown"] = scored["breakdown"]
    reasons: List[str] = list(ev.get("policy_reasons") or [])
    ftype = str(f.get("type") or "").lower()
    module = str(f.get("module") or "").lower()
    state = str(f.get("verification_state") or "CANDIDATE").upper()

    def cap(to_state: str, reason: str):
        nonlocal state
        if STATE_RANK.get(state, 1) > STATE_RANK.get(to_state, 1):
            state = to_state
            reasons.append(reason)

    # --- Reglas por tipo ---
    if ftype in MARKER_ONLY_TYPES or module in MARKER_ONLY_TYPES:
        if not ev.get("consequence"):
            cap("LIKELY", f"{ftype or module}: marcador sin consecuencia "
                          "demostrada (máx LIKELY)")
    if ftype in EXECUTABLE_XSS_TYPES or module in ("xss",):
        if state in ("VERIFIED", "CONFIRMED") and not _is_executable_xss(ev):
            cap("LIKELY", "xss: reflexión no ejecutable (máx LIKELY)")
    if ftype == "xxe" or module == "xxe":
        if str(ev.get("technique") or "") == "internal-entity":
            if "Unsafe XML entity" not in str(f.get("title") or ""):
                f["title"] = ("Unsafe XML entity processing — "
                              + str(f.get("title") or "entidad interna expandida"))
            cap("VERIFIED", "xxe: solo entidad interna (máx VERIFIED; "
                            "XXE confirmed exige resolución externa)")
    if ftype in ("ssrf", "ssrf_verified", "smart_ssrf") or module in ("ssrf", "ssrf_verify"):
        level, level_reasons = _ssrf_level(ev)
        ev["ssrf_level"] = level
        ev["level_reasons"] = level_reasons
        cap(level, f"ssrf: {'; '.join(level_reasons)}")
        if level == "CANDIDATE" and str(f.get("severity") or "").lower() not in ("info",):
            f["severity"] = "info"
            reasons.append("ssrf: candidato degradado a info")

    # --- Umbrales de score (solo degradan) ---
    for target_state in ("CONFIRMED", "VERIFIED", "LIKELY"):
        need = STATE_MIN_SCORE[target_state]
        if state == target_state and scored["score"] < need:
            if target_state == "CONFIRMED":
                # CONFIRMED exige además reproducibilidad o confirmación
                # independiente: sin ellas no es defendible.
                state = "VERIFIED" if scored["score"] >= STATE_MIN_SCORE["VERIFIED"] else (
                    "LIKELY" if scored["score"] >= STATE_MIN_SCORE["LIKELY"] else "CANDIDATE")
                reasons.append(f"score {scored['score']} < {need} para CONFIRMED")
            else:
                lower = "LIKELY" if target_state == "VERIFIED" else "CANDIDATE"
                if scored["score"] < STATE_MIN_SCORE[lower] and target_state == "LIKELY":
                    lower = "CANDIDATE"
                state = lower
                reasons.append(f"score {scored['score']} < {need} para {target_state}")
    if state == "CONFIRMED" and not (
            scored["breakdown"]["reproducibility"] or scored["breakdown"]["independent"]):
        state = "VERIFIED"
        reasons.append("CONFIRMED exige reproducibilidad o confirmación independiente")

    f["verification_state"] = state
    if reasons:
        ev["policy_reasons"] = reasons
    f["requires_human_review"] = state not in ("VERIFIED", "CONFIRMED", "REFUTED")
    return f


def correlate_session(session) -> Dict[str, Any]:
    """Escalera SQLi (idea #5): error-based + boolean-based.

    Dos técnicas independientes sobre el mismo (url, parámetro) suben el
    VERIFIED booleano a CONFIRMED. Única subida permitida.
    """
    findings = getattr(session, "findings", None) or []
    by_target: Dict[tuple, List[Dict]] = {}
    for f in findings:
        if not isinstance(f, dict) or str(f.get("type") or "").lower() != "sqli":
            continue
        ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
        key = (str(f.get("url") or ev.get("url") or ""),
               str(f.get("parameter") or ev.get("parameter") or ""))
        by_target.setdefault(key, []).append(f)
    upgraded = 0
    for key, group in by_target.items():
        has_error = any("error" in str(f.get("title") or "").lower()
                        or str((f.get("evidence") or {}).get("technique") or "")
                        .startswith("error")
                        for f in group)
        for f in group:
            ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
            boolean_ok = bool(ev.get("replayed_confirmation") or ev.get("positive_pairs"))
            if (has_error and boolean_ok
                    and str(f.get("verification_state") or "").upper() == "VERIFIED"):
                f["verification_state"] = "CONFIRMED"
                techs = list(ev.get("techniques") or [])
                for t in ("error-based", "boolean-based"):
                    if t not in techs:
                        techs.append(t)
                ev["techniques"] = techs
                rescored = evidence_score(ev)
                ev["evidence_score"] = rescored["score"]
                ev["score_breakdown"] = rescored["breakdown"]
                reasons = list(ev.get("policy_reasons") or [])
                reasons.append("escalera SQLi: error-based + boolean-based "
                               "(dos técnicas independientes)")
                ev["policy_reasons"] = reasons
                upgraded += 1
    return {"sqli_ladder_upgraded": upgraded}
