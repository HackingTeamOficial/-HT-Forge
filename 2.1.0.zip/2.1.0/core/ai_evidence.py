#!/usr/bin/env python3
"""core/ai_evidence.py - Analizador IA basado en evidencias (idea GramFuzz #9).

Flujo: Scanner -> Evidence -> Finding -> AI -> classification /
explanation / CWE mapping. La IA NO decide si existe la
vulnerabilidad: la autoridad sigue siendo HT Forge Core y el resultado
se fusiona con evidence.correlate() (Core siempre prevalece).

Respeta el requisito READ-ONLY del AI Core: solo lee evidencia ya
almacenada, nunca ejecuta acciones.
"""

from __future__ import annotations

from typing import Any, Dict, List


def _get_ai_core():
    """AI Core perezoso: None si no está disponible (modo degradado)."""
    try:
        from ai_core import AICore
        return AICore()
    except Exception:
        pass
    try:
        from ai_core.core import AICore as AICore2
        return AICore2()
    except Exception:
        return None


def review_finding(finding: Dict[str, Any], ai_core=None) -> Dict[str, Any]:
    """Revisión IA de UN hallazgo. Devuelve registro de correlación.

    Nunca modifica el hallazgo: el llamador decide si adjunta el
    registro bajo evidence['ai_review'].
    """
    try:
        from .evidence import correlate
    except ImportError:  # pragma: no cover
        from core.evidence import correlate
    core = ai_core if ai_core is not None else _get_ai_core()
    if core is None:
        return {"core_verdict": str((finding or {}).get("verification_state", "CANDIDATE")),
                "ai_verdict": "INCONCLUSIVE", "final_verdict": "INCONCLUSIVE",
                "ai_confidence": 0.0, "authority": "HT Forge Core",
                "read_only": True, "skipped": "ai_unavailable"}
    try:
        # Solo evidencia: recorte determinista, sin campos de control.
        ev = finding.get("evidence") if isinstance(finding.get("evidence"), dict) else {}
        view = {
            "type": finding.get("type"), "title": finding.get("title"),
            "severity": finding.get("severity"),
            "confidence": finding.get("confidence"),
            "verification_state": finding.get("verification_state"),
            "url": finding.get("url"), "parameter": finding.get("parameter"),
            "payload": finding.get("payload"),
            "evidence": {k: (str(v)[:2000] if isinstance(v, str) else v)
                         for k, v in list(ev.items())[:12]},
        }
        ai_result = core.analyze_finding(view)
        record = correlate(finding, ai_result if isinstance(ai_result, dict) else {})
        record["read_only"] = True
        return record
    except Exception as exc:
        return {"core_verdict": str((finding or {}).get("verification_state", "CANDIDATE")),
                "ai_verdict": "INCONCLUSIVE", "final_verdict": "INCONCLUSIVE",
                "ai_confidence": 0.0, "authority": "HT Forge Core",
                "read_only": True, "skipped": f"ai_error: {exc}"}


def review_session(session, limit: int = 25) -> Dict[str, Any]:
    """Revisa los hallazgos principales de una sesión (solo lectura).

    Adjunta el registro bajo finding['evidence']['ai_review'] sin tocar
    verdict/severity/confidence del Core. Devuelve resumen.
    """
    findings: List[Dict] = list(getattr(session, "findings", []) or [])
    # Priorizar accionables y de mayor score.
    try:
        from .evidence import ACTIONABLE_STATES
    except ImportError:  # pragma: no cover
        from core.evidence import ACTIONABLE_STATES
    ordered = sorted(
        findings,
        key=lambda f: (str(f.get("verification_state", "")).upper() in ACTIONABLE_STATES,
                       float(f.get("scored", 0) or 0)),
        reverse=True,
    )[: max(0, int(limit))]
    core = _get_ai_core()
    reviewed, skipped = 0, 0
    for f in ordered:
        try:
            ev = f.setdefault("evidence", {})
            if not isinstance(ev, dict):
                continue
            if "ai_review" in ev:
                continue
            ev["ai_review"] = review_finding(f, ai_core=core)
            reviewed += 1
        except Exception:
            skipped += 1
    return {"reviewed": reviewed, "skipped": skipped, "limit": int(limit),
            "authority": "HT Forge Core", "read_only": True}
