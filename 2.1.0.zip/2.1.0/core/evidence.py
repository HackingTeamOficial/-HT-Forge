"""Evidence and verification primitives shared by HT Forge modules.

The verifier is deliberately conservative: it never upgrades a finding merely
because a payload was reflected.  It records what was actually observed so the
Core and optional AI analyst can correlate evidence without inventing it.
"""
from typing import Any, Dict, List

VERDICTS = {"DISCOVERED", "CANDIDATE", "PROBED", "CORRELATED", "VERIFIED", "CONFIRMED", "LIKELY", "INCONCLUSIVE", "MANUAL", "REFUTED"}

# Idea GramFuzz #4: solo estos estados entran en el resumen principal
# (rating accionable). El resto se documenta pero no infla el riesgo.
ACTIONABLE_STATES = {"CONFIRMED", "VERIFIED", "LIKELY"}

# Estados que requieren revisión humana antes de decisiones de impacto.
MANUAL_REVIEW_STATES = {"CANDIDATE", "INCONCLUSIVE", "PROBED", "CORRELATED", "DISCOVERED"}


def is_actionable(finding: Dict[str, Any]) -> bool:
    """True si el hallazgo cuenta para el rating accionable."""
    try:
        state = str(finding.get("verification_state", "")).upper()
    except Exception:
        return False
    return state in ACTIONABLE_STATES


def actionable_summary(findings) -> Dict[str, int]:
    """Conteo accionable por severidad (solo CONFIRMED/VERIFIED/LIKELY)."""
    out = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings or []:
        if not isinstance(f, dict) or not is_actionable(f):
            continue
        sev = str(f.get("severity", "info")).lower()
        out[sev if sev in out else "info"] += 1
    return out


def mark_refuted(finding: Dict[str, Any], reason: str, method: str = "") -> Dict[str, Any]:
    """Marca un hallazgo como REFUTADO con motivo auditable.

    El hallazgo se conserva (no se borra): sale del rating accionable
    pero queda documentado con quién lo refutó y por qué.
    """
    f = dict(finding or {})
    f["verification_state"] = "REFUTED"
    f["refuted_reason"] = str(reason or "sin motivo registrado")[:500]
    if method:
        f["refuted_by"] = str(method)[:120]
    f["requires_human_review"] = False
    return f


def refuted_summary(findings) -> List[Dict[str, Any]]:
    """Lista compacta de refutados: título, URL, motivo."""
    out = []
    for f in findings or []:
        if not isinstance(f, dict):
            continue
        if str(f.get("verification_state", "")).upper() != "REFUTED":
            continue
        out.append({
            "title": f.get("title") or f.get("type") or "Hallazgo",
            "url": f.get("url") or (f.get("evidence") or {}).get("url") if isinstance(f.get("evidence"), dict) else f.get("url"),
            "reason": f.get("refuted_reason") or "sin motivo registrado",
            "by": f.get("refuted_by") or "motor",
        })
    return out


# Idea #9 (9.x): evidencia ponderada. Filosofía: cada CONFIRMED debe
# ser defendible por la suma de su evidencia, no por una sola señal.
EVIDENCE_WEIGHTS = {
    "differential": 30,    # baseline vs mutación con par de respuestas
    "signature": 25,       # firma específica del exploit
    "reproducibility": 20,  # retest / repetición con éxito
    "independent": 15,     # segunda técnica independiente
    "contextual": 10,      # contexto (owner, auth, snippet, CSP…)
}

# Contextos de reflexión XSS considerados ejecutables.
EXECUTABLE_XSS_CONTEXTS = {
    "html_text", "attribute_quoted", "attribute_unquoted",
    "js_string", "url_context", "css_context",
    "script", "event_handler", "javascript",
}


def evidence_score(evidence: Dict[str, Any]) -> Dict[str, Any]:
    """Pondera la evidencia: devuelve {score, breakdown}.

    +30 diferencial baseline · +25 firma específica · +20 reproducibilidad
    +15 confirmación independiente · +10 evidencia contextual = 100.
    """
    ev = evidence if isinstance(evidence, dict) else {}
    breakdown = {}

    has_baseline = any(ev.get(k) for k in (
        "baseline", "baseline_status", "comparison", "response_pair",
        "boolean_pair", "true_payload", "response_status"))
    has_marker_diff = bool(ev.get("marker") and ev.get("raw_reflection"))
    breakdown["differential"] = EVIDENCE_WEIGHTS["differential"] \
        if (has_baseline or has_marker_diff) else 0

    sig_keys = ("matched_signature", "matched", "signature", "error_signature",
                "file_signature", "metadata_response", "evaluated_expression")
    has_sig = any(ev.get(k) for k in sig_keys)
    technique = str(ev.get("technique") or "")
    has_tech_sig = technique.startswith(("error-", "boolean-", "time-based",
                                         "union-", "auth-bypass"))
    rctx = str(ev.get("reflection_context") or "")
    has_exec_ctx = rctx in EXECUTABLE_XSS_CONTEXTS and not ev.get("escaped", True)
    has_entity_sig = str(ev.get("technique") or "") in (
        "internal-entity", "entity-expansion", "external-entity")
    breakdown["signature"] = EVIDENCE_WEIGHTS["signature"] \
        if (has_sig or has_exec_ctx or has_entity_sig or has_tech_sig) else 0

    try:
        retests = int(ev.get("retest_count") or 0)
    except (TypeError, ValueError):
        retests = 0
    has_repro = bool(ev.get("reproduced") or ev.get("replayed_confirmation")
                     or ev.get("retest") is True or retests >= 2
                     or ev.get("positive_pairs"))
    breakdown["reproducibility"] = EVIDENCE_WEIGHTS["reproducibility"] \
        if has_repro else 0

    techs = ev.get("techniques")
    has_indep = bool(ev.get("confirmation") or ev.get("second_technique")
                     or ev.get("second_file")
                     or (isinstance(techs, list) and len(techs) >= 2)
                     or (isinstance(ev.get("positive_pairs"), int)
                         and ev.get("positive_pairs") >= 2))
    breakdown["independent"] = EVIDENCE_WEIGHTS["independent"] \
        if has_indep else 0

    ctx_keys = ("authorization_matrix", "owner", "auth_context", "cross_context",
                "reflection_context", "snippet", "csp_blocks_inline",
                "counters_moved", "response_excerpt", "mutated_excerpt")
    breakdown["contextual"] = EVIDENCE_WEIGHTS["contextual"] \
        if any(ev.get(k) for k in ctx_keys) else 0

    return {"score": sum(breakdown.values()), "breakdown": breakdown}


# Umbrales mínimos de score por estado declarado (idea #9).
# La política solo degrada, nunca inventa certeza.
STATE_MIN_SCORE = {
    "CONFIRMED": 70,
    "VERIFIED": 40,
    "LIKELY": 35,
}

STATE_RANK = {
    "REFUTED": 0, "CANDIDATE": 1, "INCONCLUSIVE": 1, "MANUAL": 1,
    "DISCOVERED": 2, "PROBED": 2, "CORRELATED": 3,
    "LIKELY": 4, "VERIFIED": 5, "CONFIRMED": 6,
}

RANK_STATE = {v: k for k, v in STATE_RANK.items()}

def normalize_finding(finding: Dict[str, Any]) -> Dict[str, Any]:
    f = dict(finding or {})
    evidence = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    state = str(f.get("verification_state") or evidence.get("verification_state") or "CANDIDATE").upper()
    if state not in VERDICTS:
        state = "CANDIDATE"
    f["verification_state"] = state
    f.setdefault("requires_human_review", state not in {"VERIFIED", "CONFIRMED", "REFUTED"})
    f["evidence"] = evidence
    f["evidence_quality"] = evidence_quality(evidence)
    return f

def evidence_quality(evidence: Dict[str, Any]) -> str:
    if not evidence:
        return "none"
    keys = set(evidence)
    strong = {"baseline", "comparison", "retest", "authorization_matrix", "matched_signature", "response_pair"}
    if len(keys & strong) >= 2:
        return "strong"
    if keys & strong or len(keys) >= 2:
        return "moderate"
    return "weak"

def correlate(core_finding: Dict[str, Any], ai_result: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return a read-only correlation record; Core remains authoritative."""
    f = normalize_finding(core_finding)
    ai = ai_result or {}
    core_state = f["verification_state"]
    ai_state = str(ai.get("verdict", "INCONCLUSIVE")).upper()
    if ai_state not in {"CONFIRMED", "LIKELY", "INCONCLUSIVE", "REFUTED"}:
        ai_state = "INCONCLUSIVE"
    final = core_state
    if core_state in {"CONFIRMED", "REFUTED"}:
        final = core_state
    elif core_state == "VERIFIED" and ai_state == "REFUTED":
        final = "VERIFIED"  # AI cannot override Core verification.
    return {"core_verdict": core_state, "ai_verdict": ai_state, "final_verdict": final,
            "ai_confidence": max(0.0, min(1.0, float(ai.get("confidence", 0) or 0))),
            "authority": "HT Forge Core", "read_only": True}


def human_verification(finding: Dict[str, Any]) -> Dict[str, Any]:
    """Human Verification Mode: auditable card derived only from stored evidence."""
    f = normalize_finding(finding)
    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    state = f["verification_state"]
    try:
        conf = float(f.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        conf = 0.0
    return {
        "state": state,
        "evidences": len([k for k in ev.keys() if k]),
        "reproducible": bool(ev.get("reproduced") or ev.get("retest") or f.get("verified") is True),
        "differential": bool(ev.get("comparison") or ev.get("baseline") or ev.get("response_pair")),
        "secondary_check": bool(ev.get("retest") or ev.get("confirmation") or f.get("verified") is True),
        "confidence": round(conf if conf <= 1.0 else conf / 100.0, 2),
        "engine": "HT Forge Core",
        "requires_human_review": bool(f.get("requires_human_review", state not in ("VERIFIED", "CONFIRMED", "REFUTED"))),
    }
