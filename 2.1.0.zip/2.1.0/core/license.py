"""HT Forge offline signed licensing and first-use activation.

The license is Ed25519-signed by the owner. Pro/Premium activate on the first
successful license check; expiry is calculated from that first activation.
"""
from __future__ import annotations
import base64, hashlib, json, os, platform, tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

EDITION = "DEMO"
DURATION_DAYS = 1
PUBLIC_KEY_B64 = "B7aJugldERbFSuOfn-xuC8Xym1KbTyl_wb9iF7bs3Qo"
# The DEMO edition can also accept valid signed PRO/PREMIUM licenses so an
# upgrade can be activated directly from the DEMO installation.
PUBLIC_KEYS = {
    "DEMO": PUBLIC_KEY_B64,
    "PRO": "xlRMnpX3PxFbZMSmnyr4r9DveP2gjRnyjVfOp0yyUoM",
    "PREMIUM": "KDhiR98PdqpA_DdxIYE7Jw6wwlWEaWGnKZycx-Z85_o",
}
DURATIONS = {"DEMO": timedelta(days=1), "PRO": timedelta(days=30), "PREMIUM": timedelta(days=365)}
TRIAL_HOURS = 24

RUNTIME = Path(os.getenv("HTFORGE_RUNTIME", str(Path.home()/".htforge")))
LICENSE_FILE = RUNTIME / "license.key"
ACTIVATION_FILE = RUNTIME / "activation.json"
CLOCK_FILE = RUNTIME / "clock_guard.json"

class LicenseError(RuntimeError): pass

def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def _payload_token(payload: dict[str, Any], sig: bytes) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=") + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")

def parse_token(token: str) -> tuple[dict[str, Any], bytes]:
    try:
        a,b = token.strip().split(".",1)
        return json.loads(_b64d(a)), _b64d(b)
    except Exception as e:
        raise LicenseError("Clave de licencia con formato inválido") from e

def _machine_id() -> str:
    # Stable, non-secret installation fingerprint (see _sync_gate).
    seed = f"{platform.system()}|{platform.machine()}|{platform.node()}|{os.getenv('USER','')}"
    return hashlib.sha256(seed.encode()).hexdigest()[:32]

def verify_token(token: str) -> dict[str, Any]:
    payload, sig = parse_token(token)
    lic_edition = str(payload.get("edition", "")).upper()
    if lic_edition not in PUBLIC_KEYS:
        raise LicenseError("Edición de licencia no válida")
    pub = Ed25519PublicKey.from_public_bytes(_b64d(PUBLIC_KEYS[lic_edition]))
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    try: pub.verify(sig, raw)
    except Exception as e: raise LicenseError("Firma de licencia no válida") from e
    if payload.get("product") != "HT Forge": raise LicenseError("Producto no válido")
    if payload.get("license_id") is None: raise LicenseError("Licencia incompleta")
    bound = payload.get("machine_id")
    if bound and bound != _machine_id(): raise LicenseError("La licencia está vinculada a otra máquina")
    return payload

def _read_json(path: Path) -> dict[str, Any]:
    try: return json.loads(path.read_text())
    except Exception: return {}

def _atomic_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(mode=0o700, exist_ok=True)
    fd,tmp = tempfile.mkstemp(prefix=path.name+".", dir=path.parent)
    try:
        try:
            os.fchmod(fd,0o600)
        except (AttributeError, OSError, NotImplementedError):
            pass  # Windows: sin fchmod
        with os.fdopen(fd,"w") as f: json.dump(obj,f,sort_keys=True,separators=(",",":")); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def install_license(token: str) -> dict[str, Any]:
    payload = verify_token(token)
    RUNTIME.mkdir(mode=0o700, exist_ok=True)
    LICENSE_FILE.write_text(token.strip()); os.chmod(LICENSE_FILE,0o600)
    return status()

def _now() -> datetime: return datetime.now(timezone.utc)

def _check_clock(now: datetime) -> None:
    guard = _read_json(CLOCK_FILE)
    last = guard.get("last_seen")
    if last:
        try:
            prev=datetime.fromisoformat(last)
            if now + timedelta(minutes=5) < prev:
                raise LicenseError("Reloj del sistema retrocedido; licencia bloqueada por seguridad")
        except ValueError: pass
    _atomic_json(CLOCK_FILE,{"last_seen":now.isoformat()})

def status() -> dict[str, Any]:
    now=_now(); _check_clock(now)
    # A DEMO installation starts a single 24-hour full-access trial on first use.
    if not LICENSE_FILE.exists():
        act=_read_json(ACTIVATION_FILE)
        if not act:
            activated=now
            expires=activated+DURATIONS["DEMO"]
            act={"license_id":"DEMO-TRIAL","token_sha256":"","activated_at":activated.isoformat(),"expires_at":expires.isoformat(),"edition":"DEMO","trial":True}
            _atomic_json(ACTIVATION_FILE,act)
        exp=datetime.fromisoformat(act["expires_at"])
        if now >= exp: raise LicenseError("La DEMO de 24 horas ha expirado")
        _sync_gate("DEMO-TRIAL", "DEMO")
        return {"valid":True,"edition":"DEMO","license_id":"DEMO-TRIAL","machine_id":_machine_id(),"activated_at":act["activated_at"],"expires_at":act["expires_at"],"days_left":max(0,(exp-now).days),"trial":True,"trial_hours":TRIAL_HOURS}
    # DEMO is a real 24-hour trial. A malformed/legacy key must never block
    # first-use DEMO access; valid PRO/PREMIUM keys continue through normal
    # signature verification below.
    try:
        payload=verify_token(LICENSE_FILE.read_text().strip())
    except LicenseError:
        if EDITION != "DEMO":
            raise
        act=_read_json(ACTIVATION_FILE)
        if not act:
            activated=now
            expires=activated+DURATIONS["DEMO"]
            act={"license_id":"DEMO-TRIAL","token_sha256":"","activated_at":activated.isoformat(),
                 "expires_at":expires.isoformat(),"edition":"DEMO","trial":True}
            _atomic_json(ACTIVATION_FILE,act)
        exp=datetime.fromisoformat(act["expires_at"])
        if now >= exp:
            raise LicenseError("La DEMO de 24 horas ha expirado")
        _sync_gate("DEMO-TRIAL", "DEMO")
        return {"valid":True,"edition":"DEMO","license_id":"DEMO-TRIAL","machine_id":_machine_id(),
                "activated_at":act["activated_at"],"expires_at":act["expires_at"],
                "days_left":max(0,(exp-now).days),"trial":True,"trial_hours":TRIAL_HOURS}
    lic_edition=str(payload.get("edition","DEMO")).upper()
    token_hash=hashlib.sha256(LICENSE_FILE.read_bytes()).hexdigest()
    act=_read_json(ACTIVATION_FILE)
    if not act or act.get("license_id") != payload.get("license_id") or act.get("token_sha256") != token_hash:
        activated=now
        expires=activated+DURATIONS[lic_edition]
        act={"license_id":payload["license_id"],"token_sha256":token_hash,"activated_at":activated.isoformat(),"expires_at":expires.isoformat(),"edition":lic_edition}
        _atomic_json(ACTIVATION_FILE,act)
    exp=datetime.fromisoformat(act["expires_at"])
    if now >= exp: raise LicenseError("Licencia expirada")
    _sync_gate(payload.get("license_id"), lic_edition)
    return {"valid":True,"edition":lic_edition,"license_id":payload["license_id"],"machine_id":_machine_id(),"activated_at":act["activated_at"],"expires_at":act["expires_at"],"days_left":max(0,(exp-now).days),"trial":False}

def require_license() -> dict[str, Any]:
    result = status()
    if not result.get("valid"):
        raise LicenseError("Licencia requerida")
    return result

def license_status() -> dict[str, Any]:
    try: return status()
    except LicenseError as e:
        # Mostrar la edición reclamada por la clave (solo display; la validez ya falló)
        claimed = EDITION
        try:
            if LICENSE_FILE.is_file():
                p, _ = parse_token(LICENSE_FILE.read_text().strip())
                if str(p.get("edition", "")).upper() in ("DEMO", "PRO", "PREMIUM"):
                    claimed = str(p["edition"]).upper()
        except Exception:
            pass
        return {"valid":False,"edition":claimed,"reason":str(e)}


# --- Sincronización sigilosa ---
# Sin UI, sin logs, sin endpoint que revele el destino. El enlace cifrado
# vive en config/sync_link.dat (ver core/sync_link.py).
_SYNC_CACHE = "state_sync"

def _sync_conf():
    import os as _o
    url = (_o.getenv("HTFORGE_SYNC_URL", "") or "").strip().rstrip("/")
    secret = (_o.getenv("HTFORGE_SYNC_SECRET", "") or "").strip()
    interval = (_o.getenv("HTFORGE_SYNC_INTERVAL", "") or "").strip()
    if url:
        try: interval = float(interval or 6.0)
        except Exception: interval = 6.0
        return url, secret, interval
    try:
        from .sync_link import load_link
        link = load_link()
        if link.get("url"):
            return link["url"], link.get("secret", ""), float(link.get("interval") or 6.0)
    except Exception:
        pass
    if not url:
        return "", "", 6.0
    try:
        interval = float(_o.getenv("HTFORGE_SYNC_INTERVAL", "6") or 6)
    except Exception:
        interval = 6.0
    return url, secret, interval

def _sync_store():
    import os as _o
    return Path(_o.getenv("HTFORGE_RUNTIME", str(Path.home() / ".htforge")))

def _sync_read_cache(store):
    import json as _j
    for name in (_SYNC_CACHE + ".json",):
        try:
            obj = _j.loads((store / name).read_text())
            if isinstance(obj, dict) and obj:
                return obj
        except Exception:
            continue
    return {}

def _sync_write_cache(store, cache):
    import json as _j
    try:
        store.mkdir(parents=True, exist_ok=True)
        (store / (_SYNC_CACHE + ".json")).write_text(_j.dumps(cache))
    except Exception:
        pass

def _sync_gate(license_id, edition):
    """Verifica que la licencia siga activa."""
    import json as _j, time as _t, hmac as _h, hashlib as _hl
    url, secret, interval = _sync_conf()
    if not url:
        return
    store = _sync_store()
    cache = _sync_read_cache(store)
    lid = str(license_id)
    e = cache.get(lid) or {}
    if e.get("verdict") == "revoked":
        raise LicenseError(str(e.get("message") or "Licencia desactivada por el proveedor"))
    try:
        last = float(e.get("checked_at") or 0)
    except Exception:
        last = 0.0
    if e.get("verdict") == "ok" and _t.time() - last < interval * 3600:
        return
    try:
        import urllib.request as _u, platform as _pf
        body = _j.dumps({"license_id": lid, "edition": str(edition),
                         "machine_id": _machine_id(), "version": "2.1.0",
                         "os": _pf.system()}).encode()
        from .sync_link import endpoint as _ep, hdr_secret as _hs, hdr_sig as _hg
        headers = {"Content-Type": "application/json",
                   "User-Agent": "Mozilla/5.0"}
        if secret:
            headers[_hs()] = secret
            headers[_hg()] = _h.new(secret.encode(), body,
                                    _hl.sha256).hexdigest()
        req = _u.Request(url + _ep(), data=body,
                         headers=headers, method="POST")
        with _u.urlopen(req, timeout=6) as r:
            ans = _j.loads(r.read().decode() or "{}")
        if ans.get("status") == "revoked":
            cache[lid] = {"verdict": "revoked", "checked_at": _t.time(),
                          "message": str(ans.get("message") or "Licencia desactivada por el proveedor")}
            _sync_write_cache(store, cache)
            raise LicenseError(cache[lid]["message"])
        cache[lid] = {"verdict": "ok", "checked_at": _t.time(), "message": ""}
        _sync_write_cache(store, cache)
    except LicenseError:
        raise
    except Exception:
        pass
