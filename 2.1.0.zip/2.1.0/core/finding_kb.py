#!/usr/bin/env python3
"""core/finding_kb.py — base de conocimiento por tipo de vulnerabilidad.

Cada finding sale del motor con ficha completa: impacto, remediación,
OWASP, CWE y referencias. El motor solo usa setdefault: nunca pisa
lo que un módulo ya aportó con evidencia propia.
"""
from typing import Any, Dict, List

DEFAULT = {
    "impact": "Exposición o debilidad pendiente de caracterizar con el contexto del activo.",
    "remediation": "Revisar el hallazgo, reproducirlo con la evidencia adjunta y aplicar el control correspondiente.",
    "owasp": "A04:2021 – Insecure Design",
    "cwe": "",
    "references": ["https://owasp.org/Top10/"],
}

KB: Dict[str, Dict[str, Any]] = {
    "sqli": {
        "impact": "Lectura, modificación o borrado de datos; posible escalado a ejecución en el servidor.",
        "remediation": "Consultas parametrizadas / ORM, mínimo privilegio en la cuenta SQL, validación de tipos y WAF solo como capa extra.",
        "owasp": "A03:2021 – Injection", "cwe": "CWE-89",
        "references": ["https://owasp.org/www-community/attacks/SQL_Injection", "https://cwe.mitre.org/data/definitions/89.html"],
    },
    "xss": {
        "impact": "Ejecución de JavaScript en el navegador de la víctima: robo de sesión, phishing y acciones en su nombre.",
        "remediation": "Codificación de salida según contexto, CSP estricta, validación de entrada y cookies HttpOnly/Secure.",
        "owasp": "A03:2021 – Injection", "cwe": "CWE-79",
        "references": ["https://owasp.org/www-community/attacks/xss/", "https://cwe.mitre.org/data/definitions/79.html"],
    },
    "idor": {
        "impact": "Acceso a objetos de otros usuarios: lectura o manipulación de datos ajenos.",
        "remediation": "Control de autorización por objeto en servidor, referencias indirectas y tests A-vs-B.",
        "owasp": "A01:2021 – Broken Access Control", "cwe": "CWE-639",
        "references": ["https://owasp.org/API-Security/editions/2023/en/0x11-t10/", "https://cwe.mitre.org/data/definitions/639.html"],
    },
    "bola": {
        "impact": "Acceso a objetos de otros usuarios: lectura o manipulación de datos ajenos.",
        "remediation": "Control de autorización por objeto en servidor, referencias indirectas y tests A-vs-B.",
        "owasp": "API1:2023 – Broken Object Level Authorization", "cwe": "CWE-639",
        "references": ["https://owasp.org/API-Security/editions/2023/en/0x11-t10/", "https://cwe.mitre.org/data/definitions/639.html"],
    },
    "ssrf": {
        "impact": "El servidor realiza peticiones internas: lectura de metadatos cloud, pivote a red interna.",
        "remediation": "Lista blanca de destinos, bloqueo de rangos internos/link-local, validación de URL y sin redirects a ciegas.",
        "owasp": "A10:2021 – SSRF", "cwe": "CWE-918",
        "references": ["https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/", "https://cwe.mitre.org/data/definitions/918.html"],
    },
    "lfi": {
        "impact": "Lectura de ficheros del servidor (configuración, credenciales, código).",
        "remediation": "Evitar incluir rutas de usuario, mapa de recursos permitidos, chroot/jail y validación estricta.",
        "owasp": "A01:2021 – Broken Access Control", "cwe": "CWE-22",
        "references": ["https://owasp.org/www-project-web-security-testing-guide/", "https://cwe.mitre.org/data/definitions/22.html"],
    },
    "rfi": {
        "impact": "Inclusión de código remoto: posible ejecución remota de código.",
        "remediation": "Desactivar inclusión remota (allow_url_include off), lista cerrada de recursos.",
        "owasp": "A03:2021 – Injection", "cwe": "CWE-98",
        "references": ["https://cwe.mitre.org/data/definitions/98.html"],
    },
    "ssti": {
        "impact": "Evaluación de plantillas con datos de usuario: de fuga de datos a RCE.",
        "remediation": "No interpolar entrada de usuario en plantillas, sandbox y motores logic-less donde aplique.",
        "owasp": "A03:2021 – Injection", "cwe": "CWE-1336",
        "references": ["https://owasp.org/www-project-web-security-testing-guide/", "https://cwe.mitre.org/data/definitions/1336.html"],
    },
    "xxe": {
        "impact": "Lectura de ficheros, SSRF y DoS vía entidades XML externas.",
        "remediation": "Desactivar DTD/entidades externas, parser endurecido o JSON.",
        "owasp": "A05:2021 – Security Misconfiguration", "cwe": "CWE-611",
        "references": ["https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing", "https://cwe.mitre.org/data/definitions/611.html"],
    },
    "open_redirect": {
        "impact": "Phishing creíble con la marca del dominio legítimo.",
        "remediation": "Lista blanca de destinos, referencias relativas y aviso al salir.",
        "owasp": "A01:2021 – Broken Access Control", "cwe": "CWE-601",
        "references": ["https://cwe.mitre.org/data/definitions/601.html"],
    },
    "csrf": {
        "impact": "Acciones no deseadas en nombre de un usuario autenticado.",
        "remediation": "Tokens anti-CSRF por sesión, SameSite=Lax/Strict y verificación de Origin.",
        "owasp": "A01:2021 – Broken Access Control", "cwe": "CWE-352",
        "references": ["https://owasp.org/www-community/attacks/csrf", "https://cwe.mitre.org/data/definitions/352.html"],
    },
    "file_upload": {
        "impact": "Subida maliciosa: de webshell a RCE o defacement.",
        "remediation": "Validar tipo real (magic bytes), renombrar, servir fuera del webroot y sin ejecución.",
        "owasp": "A04:2021 – Insecure Design", "cwe": "CWE-434",
        "references": ["https://owasp.org/www-community/vulnerabilities/Unrestricted_File_Upload", "https://cwe.mitre.org/data/definitions/434.html"],
    },
    "auth_bypass": {
        "impact": "Acceso sin credenciales válidas a funciones o datos protegidos.",
        "remediation": "Verificación de sesión en cada endpoint, sin controles solo-cliente.",
        "owasp": "A07:2021 – Identification and Authentication Failures", "cwe": "CWE-287",
        "references": ["https://cwe.mitre.org/data/definitions/287.html"],
    },
    "sensitive_exposure": {
        "impact": "Fuga de datos sensibles (claves, PII, tokens) legibles por terceros.",
        "remediation": "Minimizar exposición, cifrado, rotación de secretos y revisión de respuestas/logs.",
        "owasp": "A02:2021 – Cryptographic Failures", "cwe": "CWE-200",
        "references": ["https://cwe.mitre.org/data/definitions/200.html"],
    },
    "security_headers": {
        "impact": "Endurecimiento ausente: facilita XSS, clickjacking e interceptación.",
        "remediation": "CSP, HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy.",
        "owasp": "A05:2021 – Security Misconfiguration", "cwe": "CWE-693",
        "references": ["https://owasp.org/www-project-secure-headers/"],
    },
    "cors": {
        "impact": "Origen cruzado permisivo: lectura de respuestas autenticadas desde webs atacantes.",
        "remediation": "Orígenes explícitos, sin reflejar Origin con credenciales, Vary: Origin.",
        "owasp": "A01:2021 – Broken Access Control", "cwe": "CWE-942",
        "references": ["https://cwe.mitre.org/data/definitions/942.html"],
    },
    "jwt": {
        "impact": "Tokens falsificables o débiles: suplantación de identidad.",
        "remediation": "Algoritmo fijo (RS256/ES256), validar exp/iss/aud, claves robustas y rotación.",
        "owasp": "A07:2021 – Identification and Authentication Failures", "cwe": "CWE-347",
        "references": ["https://cwe.mitre.org/data/definitions/347.html"],
    },
}


def _key(finding: Dict[str, Any]) -> str:
    t = str(finding.get("type") or finding.get("module") or "").lower()
    for k in KB:
        if k in t:
            return k
    return ""


def enrich(finding: Dict[str, Any]) -> Dict[str, Any]:
    """Completa impacto/remediación/OWASP/CWE/referencias sin pisar evidencia propia."""
    entry = KB.get(_key(finding), DEFAULT)
    for field in ("impact", "remediation", "owasp"):
        finding.setdefault(field, entry[field])
    if not finding.get("cwe"):
        finding["cwe"] = finding.get("cwe") or entry.get("cwe", "")
    refs = finding.get("references")
    if not refs:
        finding["references"] = list(entry.get("references", []))
    return finding


def conclusion_chain(finding: Dict[str, Any]) -> str:
    """Cadena auditable: cómo HT Forge llegó a la conclusión."""
    ev = finding.get("evidence") if isinstance(finding.get("evidence"), dict) else {}
    steps: List[str] = []
    if ev.get("baseline") or ev.get("baseline_status"):
        steps.append("1) baseline capturado")
    sig = ev.get("matched_signature") or ev.get("signature") or ev.get("technique") or ev.get("file_signature")
    if sig:
        steps.append(f"2) señal observada: {sig}")
    if ev.get("response_pair") or ev.get("comparison") or ev.get("boolean_pair"):
        steps.append("3) diferencial baseline→sonda verificado")
    if ev.get("second_file") or ev.get("second_technique") or ev.get("confirmation"):
        steps.append("4) segunda evidencia independiente")
    if ev.get("retest") is True or ev.get("reproduced") or (ev.get("retest_count") or 0) >= 2:
        steps.append("5) retest reproducible")
    lvl = ev.get("ssrf_level")
    if lvl:
        steps.append(f"nivel SSRF: {lvl}")
    rctx = ev.get("reflection_context")
    if rctx:
        steps.append(f"contexto de reflexión: {rctx}")
    score = None
    try:
        from .evidence import evidence_score as _es
        score = _es(ev).get("score")
    except Exception:
        score = ev.get("evidence_score")
    state = str(finding.get("verification_state") or "CANDIDATE")
    tail = f"→ estado {state}"
    if score is not None:
        tail += f" (score {score}/100)"
    if not steps:
        return f"Sin cadena diferencial registrada {tail}."
    return " · ".join(steps) + f" {tail}."
