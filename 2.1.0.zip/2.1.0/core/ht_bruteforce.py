"""HT Forge Premium — native web adapter for HT Brute Force.

The adapter reuses the supplied HT Brute Force engines without changing their
protocol implementations. All network actions are user initiated and intended
for explicitly authorized audit targets.
"""
from __future__ import annotations
import threading, time, uuid, os
from pathlib import Path
from typing import Any

from ht_brute_force.core.hash_detect import detect_batch
from ht_brute_force.core.hash_crack import crack_batch
from ht_brute_force.core.port_scanner import PortScanner

PROTOCOLS = [
    ("SSH", "ssh", 22, True), ("FTP", "ftp", 21, True), ("HTTP Basic", "http", 80, True),
    ("MySQL", "mysql", 3306, True), ("SMTP", "smtp", 25, True), ("Redis", "redis", 6379, False),
    ("VNC", "vnc", 5900, False), ("Telnet", "telnet", 23, True), ("LDAP", "ldap", 389, True),
    ("POP3 / IMAP", "mail", 110, True), ("RDP", "rdp", 3389, True), ("SMB", "smb", 445, True),
]
PROTOCOL_CLASSES = {
    "ssh": ("ht_brute_force.core.protocols.ssh", "SSHBruter"),
    "ftp": ("ht_brute_force.core.protocols.ftp", "FTPBruter"),
    "http": ("ht_brute_force.core.protocols.http_basic", "HTTPBasicBruter"),
    "mysql": ("ht_brute_force.core.protocols.mysql", "MySQLBruter"),
    "smtp": ("ht_brute_force.core.protocols.smtp", "SMTPBruter"),
    "redis": ("ht_brute_force.core.protocols.redis", "RedisBruter"),
    "vnc": ("ht_brute_force.core.protocols.vnc", "VNCBruter"),
    "telnet": ("ht_brute_force.core.protocols.telnet", "TelnetBruter"),
    "ldap": ("ht_brute_force.core.protocols.ldap", "LDAPBruter"),
    "mail_pop3": ("ht_brute_force.core.protocols.mail", "POP3Bruter"),
    "mail_imap": ("ht_brute_force.core.protocols.mail", "IMAPBruter"),
    "rdp": ("ht_brute_force.core.protocols.rdp", "RDPBruter"),
    "smb": ("ht_brute_force.core.protocols.smb", "SMBBruter"),
}
PORT_PROTOCOL = {22:"ssh",23:"telnet",21:"ftp",25:"smtp",110:"mail_pop3",143:"mail_imap",
                 3306:"mysql",5432:"mysql",6379:"redis",5900:"vnc",3389:"rdp",445:"smb",
                 80:"http",443:"http",8080:"http",8443:"http"}

class BFJob:
    def __init__(self):
        self.id=uuid.uuid4().hex[:10]
        self.status="queued"; self.kind=""; self.started_at=None; self.ended_at=None
        self.result=None; self.error=""; self.stop_event=threading.Event()
        self._lock=threading.Lock()
    def set(self, **kw):
        with self._lock: [setattr(self,k,v) for k,v in kw.items()]
    def public(self):
        return {"id":self.id,"status":self.status,"kind":self.kind,
                "started_at":self.started_at,"ended_at":self.ended_at,
                "result":self.result,"error":self.error}

JOBS: dict[str,BFJob] = {}
JOBS_LOCK=threading.Lock()

def get_job(jid): return JOBS.get(jid)

def _put(job):
    with JOBS_LOCK: JOBS[job.id]=job

def _run(job, kind, fn):
    job.set(kind=kind,status="running",started_at=time.time())
    try:
        result=fn(job.stop_event)
        job.set(result=result,status="stopped" if job.stop_event.is_set() else "completed")
    except Exception as exc:
        job.set(error=str(exc)[:1000],status="error")
    finally:
        job.set(ended_at=time.time())

def start_hash_detect(lines):
    job=BFJob(); _put(job)
    def work(stop):
        return {"rows":detect_batch(lines or [])}
    threading.Thread(target=_run,args=(job,"hash-detect",work),daemon=True).start()
    return job

def start_hash_crack(targets, words, hash_type="auto", rules=True, max_time=30):
    job=BFJob(); _put(job)
    def work(stop):
        # Existing cracker has its own per-hash timeout; stop is checked between
        # jobs so a user can cancel a batch cleanly.
        rows=[]
        for target in targets or []:
            if stop.is_set(): break
            rows.append(crack_batch([target], words or [], hash_type, bool(rules), max_time=float(max_time or 30))[0].to_dict())
        return {"rows":rows}
    threading.Thread(target=_run,args=(job,"hash-crack",work),daemon=True).start()
    return job

def start_port_scan(host, ports, timeout=3, threads=50):
    job=BFJob(); _put(job)
    def work(stop):
        scanner=PortScanner(timeout=float(timeout or 3),max_threads=max(1,min(int(threads or 50),100)),stop_event=stop)
        rows=scanner.scan_host(host,ports,service_scan=True)
        return {"host":host,"ports":rows,"open_ports":[x for x in rows if x.get("state")=="OPEN"]}
    threading.Thread(target=_run,args=(job,"port-scan",work),daemon=True).start()
    return job

def start_service(proto_key, host, port, users, passwords, threads=10, timeout=5, extra=None):
    job=BFJob(); _put(job)
    options=dict(extra or {})
    def work(stop):
        import importlib
        key=proto_key
        if key=="mail":
            key = "mail_imap" if str(options.get("mail_mode") or "auto").lower()=="imap" else "mail_pop3"
        modname, clsname=PROTOCOL_CLASSES[key]
        cls=getattr(importlib.import_module(modname),clsname)
        kwargs={"timeout":float(timeout or 5),"max_threads":max(1,min(int(threads or 10),50)),"stop_event":stop}
        # Protocol constructors in the supplied tool differ slightly. Try the
        # canonical signature first, then fall back to the base-compatible one.
        try: bruter=cls(**kwargs)
        except TypeError:
            try: bruter=cls(timeout=float(timeout or 5),threads=max(1,min(int(threads or 10),50)),stop_event=stop)
            except TypeError: bruter=cls(timeout=float(timeout or 5),stop_event=stop)
        if key=="http":
            url=options.get("url") or f"http://{host}:{port}"
            method=options.get("method") or "GET"
            rows=bruter.run(url,users,passwords,method=method)
        elif key=="ldap":
            rows=bruter.run(host,port,users,passwords,options.get("base_dn") or "dc=example,dc=com")
        elif key in ("mail_pop3","mail_imap"):
            rows=bruter.run(host,port,users,passwords)
        elif key in ("redis","vnc"):
            rows=bruter.run(host,port,passwords)
        else:
            rows=bruter.run(host,port,users,passwords)
        return {"protocol":proto_key,"host":host,"port":port,"results":rows or []}
    threading.Thread(target=_run,args=(job,"service",work),daemon=True).start()
    return job
