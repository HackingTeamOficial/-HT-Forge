#!/usr/bin/env python3
"""core/budgets.py - Presupuestos de ejecución y finalización garantizada.

Idea GramFuzz #5 (nativo HT Forge): cada motor declara límites
(max_requests, max_seconds, max_payloads, max_targets) y el pipeline
hace short-circuit cuando una fase no tiene entrada, más un watchdog
global para que el escaneo SIEMPRE termine en SCAN FINISHED.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List


@dataclass
class Budget:
    """Contador de consumo con límites duros por módulo."""

    max_requests: int = 60
    max_seconds: float = 120.0
    max_payloads: int = 40
    max_targets: int = 25
    _requests: int = field(default=0, init=False, repr=False)
    _payloads: int = field(default=0, init=False, repr=False)
    _targets: int = field(default=0, init=False, repr=False)
    _start: float = field(default_factory=time.monotonic, init=False, repr=False)

    def consume_request(self) -> bool:
        self._requests += 1
        if self.max_requests <= 0:
            return not self.expired()
        return self._requests <= self.max_requests and not self.expired()

    def consume_payload(self) -> bool:
        self._payloads += 1
        if self.max_payloads <= 0:
            return not self.expired()
        return self._payloads <= self.max_payloads and not self.expired()

    def consume_target(self) -> bool:
        self._targets += 1
        if self.max_targets <= 0:
            return not self.expired()
        return self._targets <= self.max_targets and not self.expired()

    def expired(self) -> bool:
        return (time.monotonic() - self._start) >= self.max_seconds

    def exhausted(self) -> bool:
        # Un límite <= 0 significa "sin límite" para ese contador.
        return ((self.max_requests > 0 and self._requests >= self.max_requests)
                or (self.max_payloads > 0 and self._payloads >= self.max_payloads)
                or (self.max_targets > 0 and self._targets >= self.max_targets)
                or self.expired())

    def summary(self) -> Dict[str, Any]:
        return {
            "requests": self._requests,
            "payloads": self._payloads,
            "targets": self._targets,
            "elapsed_seconds": round(time.monotonic() - self._start, 2),
        }


def get_budget(ctx, name: str, defaults: Dict[str, Any] | None = None) -> Budget:
    """Crea un Budget leyendo overrides de ctx.config: <name>_max_*."""
    defaults = defaults or {}
    cfg = getattr(ctx, "config", None) or {}

    def _int(key: str, default: int) -> int:
        try:
            return int(cfg.get(f"{name}_{key}", default))
        except (TypeError, ValueError):
            return default

    def _float(key: str, default: float) -> float:
        try:
            return float(cfg.get(f"{name}_{key}", default))
        except (TypeError, ValueError):
            return default

    return Budget(
        max_requests=_int("max_requests", int(defaults.get("max_requests", 60))),
        max_seconds=_float("max_seconds", float(defaults.get("max_seconds", 120.0))),
        max_payloads=_int("max_payloads", int(defaults.get("max_payloads", 40))),
        max_targets=_int("max_targets", int(defaults.get("max_targets", 25))),
    )


def need(ctx, label: str, items: Iterable | None) -> List:
    """Short-circuit: si no hay entrada, lo registra y devuelve [].

    Evita que un motor consuma presupuesto sin datos de partida.
    """
    items = list(items or [])
    if not items:
        try:
            ctx.log("info", f"{label}: sin entrada, fase omitida (short-circuit)")
        except Exception:
            pass
    return items


def scan_deadline_exceeded(ctx, engine) -> bool:
    """Watchdog global: True si el escaneo superó su presupuesto temporal."""
    try:
        deadline = getattr(engine, "_scan_deadline", None)
        if deadline is None:
            return False
        return time.monotonic() >= deadline
    except Exception:
        return False
