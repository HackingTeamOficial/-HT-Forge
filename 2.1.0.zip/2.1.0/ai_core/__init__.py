"""HT Forge AI Core - local-first, read-only AI analysis."""
from .htforge.detector_ai import (
    AIAnalyzer, DetectionTemplate, AIError, OllamaProvider, VLLMProvider,
    HermesIAProvider, ClaudeProvider, OpenAIProvider, OpencodeProvider,
    ProviderManager, generate_sqli_templates, generate_idor_templates,
    generate_rce_templates, generate_xss_templates, generate_path_traversal_templates,
    generate_ssrf_templates, generate_open_redirect_templates, generate_ssti_templates,
)
from dataclasses import dataclass
from urllib.parse import urlparse

@dataclass
class AIConfig:
    base_url: str = "http://127.0.0.1:11434"
    model: str = "hermes3:8b"
    timeout: int = 90
    temperature: float = 0.1
    enabled: bool = True
    allow_actions: bool = False
    def validate(self):
        u=urlparse(self.base_url)
        if u.scheme not in ("http","https") or not u.netloc: raise AIError("URL de Ollama no válida")
        if not 5 <= self.timeout <= 600: raise AIError("Timeout fuera de rango")
        if self.allow_actions: raise AIError("AI actions no están habilitadas: HT Forge AI es read-only.")

from .htforge.ollama_manager import OllamaManager, get_ollama_manager, ManagedScan

__version__ = "2.1.0"

def _extract_json_object(raw):
    """Parse strict JSON plus common fenced/prose LLM responses safely.

    Nunca levanta por JSON inválido: si no hay objeto parseable devuelve
    un fallback con el texto, para que el llamador lo registre como
    INCONCLUSIVE con el hallazgo intacto (el Core manda).
    """
    import json, re
    if isinstance(raw, (dict, list)):
        return raw
    text = str(raw or "").strip().lstrip("\ufeff")
    if not text:
        return {"_text_fallback": "", "_parse_error": True}
    text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```\s*$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    text = re.sub(r",\s*([}\]])", r"\1", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    for opening, closing in (("{", "}"), ("[", "]")):
        start = text.find(opening)
        while start >= 0:
            depth, quote, escaped = 0, False, False
            for i in range(start, len(text)):
                ch = text[i]
                if quote:
                    if escaped: escaped = False
                    elif ch == "\\": escaped = True
                    elif ch == '"': quote = False
                    continue
                if ch == '"': quote = True
                elif ch == opening: depth += 1
                elif ch == closing:
                    depth -= 1
                    if depth == 0:
                        try: return json.loads(text[start:i+1])
                        except json.JSONDecodeError: break
            start = text.find(opening, start + 1)
    return {"_text_fallback": str(raw or "")[:2000], "_parse_error": True}


class AICore:
    """HT Forge AI facade. Ollama is kept alive during scans and AI is read-only."""
    PROVIDER_INFO = {
        "ollama": {"name": "Ollama", "description": "Orquestador local para modelos descargados en el equipo. Recomendado para HT Forge por privacidad y funcionamiento offline.", "local": True},
        "vllm": {"name": "vLLM", "description": "Servidor local de inferencia de alto rendimiento. Adecuado para GPU y modelos grandes.", "local": True},
        "hermes_ia": {"name": "Hermes IA", "description": "Proveedor/orquestador compatible con endpoint local. Úsalo si tienes un servicio Hermes IA separado.", "local": True},
        "opencode": {"name": "OpenCode", "description": "Orquestador/CLI externo. Se mantiene como opción avanzada; no es necesario para el núcleo local de HT Forge.", "local": True},
        "claude": {"name": "Claude", "description": "Proveedor remoto/API. Requiere configuración externa y no es el modo local predeterminado.", "local": False},
        "openai": {"name": "OpenAI", "description": "Proveedor remoto/API. Requiere API y configuración externa.", "local": False},
    }

    def __init__(self, base_url="http://127.0.0.1:11434", model=None, **kwargs):
        # Backward-compatible form: AICore(AIConfig(...), knowledge_root)
        if isinstance(base_url, AIConfig):
            cfg = base_url
            self.base_url = cfg.base_url.rstrip('/')
            if isinstance(model, str) and model:
                self.selected_model = model
            else:
                self.selected_model = cfg.model
            self.timeout = int(cfg.timeout)
            self.auto_smallest = False
        else:
            self.base_url = str(base_url).rstrip('/')
            self.timeout = int(kwargs.get('timeout', 120))
            self.selected_model = model or None
            self.auto_smallest = model in (None, "", "auto", "smallest")
        self.analyzer = AIAnalyzer(config={
            "ollama": {"base_url": self.base_url, "timeout": self.timeout, "enabled": True, "model": model or ""},
            "detection": {"max_templates_per_type": kwargs.get('max_templates_per_type', 5), "min_confidence": kwargs.get('min_confidence', 0.7)},
        })
        if not hasattr(self, 'selected_model'):
            self.selected_model = model or None
        if not hasattr(self, 'auto_smallest'):
            self.auto_smallest = model in (None, "", "auto", "smallest")
        self.active_provider = str(kwargs.get('provider', 'ollama') or 'ollama')
        self.provider_cfg = dict(kwargs.get('provider_cfg') or {})
        self._ensure_providers()
        self._select_default_model()

    def _prov_timeout(self, name):
        try:
            return max(5, min(600, int((self.provider_cfg.get(name) or {}).get("timeout") or self.timeout)))
        except (TypeError, ValueError):
            return self.timeout

    def _ensure_providers(self):
        """Crea instancias de proveedores configurados (vLLM/Hermes/OpenAI/Claude)."""
        from .htforge.detector_ai import VLLMProvider, HermesIAProvider, OpenAIProvider, ClaudeProvider
        cfg = self.provider_cfg
        try:
            if 'vllm' not in self.analyzer.providers and (cfg.get('vllm', {}).get('base_url') or '').strip():
                self.analyzer.providers['vllm'] = VLLMProvider(
                    base_url=cfg['vllm']['base_url'].rstrip('/'), timeout=self._prov_timeout('vllm'))
        except Exception:
            pass
        try:
            import os as _os
            hcfg = dict(cfg.get('hermes_ia', {}) or {})
            hurl = (hcfg.get('base_url') or _os.getenv('HERMES_IA_URL', '') or '').strip()
            if 'hermes_ia' not in self.analyzer.providers and hurl:
                self.analyzer.providers['hermes_ia'] = HermesIAProvider(
                    base_url=hurl.rstrip('/'), timeout=self._prov_timeout('hermes_ia'))
        except Exception:
            pass
        try:
            ocfg = dict(cfg.get('openai', {}) or {})
            if 'openai' not in self.analyzer.providers and (ocfg.get('api_key') or '').strip():
                self.analyzer.providers['openai'] = OpenAIProvider(
                    api_key=ocfg['api_key'], base_url=(ocfg.get('base_url') or 'https://api.openai.com/v1').rstrip('/'),
                    timeout=self._prov_timeout('openai'))
        except Exception:
            pass
        try:
            ccfg = dict(cfg.get('claude', {}) or {})
            if 'claude' not in self.analyzer.providers and (ccfg.get('api_key') or '').strip():
                self.analyzer.providers['claude'] = ClaudeProvider(
                    api_key=ccfg['api_key'], timeout=self._prov_timeout('claude'))
        except Exception:
            pass

    def configure_provider(self, name, base_url=None, api_key=None, timeout=None, model=None):
        """Activa un proveedor con su URL/clave/timeout/modelo. Devuelve el estado actualizado."""
        name = str(name or 'ollama').strip() or 'ollama'
        if name not in ('ollama', 'vllm', 'hermes_ia', 'openai', 'claude', 'opencode'):
            from .htforge.detector_ai import AIError as _AIError
            raise _AIError(f'Proveedor desconocido: {name}')
        cfg = self.provider_cfg.setdefault(name, {})
        if base_url is not None:
            cfg['base_url'] = str(base_url).strip()
        if api_key is not None:
            cfg['api_key'] = str(api_key)
        if timeout is not None:
            try:
                cfg['timeout'] = max(5, min(600, int(timeout)))
            except (TypeError, ValueError):
                pass
        if model is not None and str(model).strip():
            cfg['model'] = str(model).strip()
        if name in self.analyzer.providers and (base_url is not None or api_key is not None or timeout is not None):
            del self.analyzer.providers[name]
        self._ensure_providers()
        if name == 'ollama' and 'ollama' not in self.analyzer.providers:
            from .htforge.detector_ai import OllamaProvider
            self.analyzer.providers['ollama'] = OllamaProvider(
                base_url=self.base_url, timeout=self.timeout)
        if name not in self.analyzer.providers:
            from .htforge.detector_ai import AIError as _AIError
            raise _AIError(f'Proveedor {name} no disponible: revisa URL/clave.')
        self.active_provider = name
        self.auto_smallest = False
        self._select_default_model()
        return self.status()

    def test_provider(self, name, base_url=None, api_key=None, timeout=None):
        """Prueba un proveedor SIN activarlo: lista modelos y verifica respuesta.

        Usa la config guardada + overrides puntuales. No cambia active_provider.
        """
        from .htforge.detector_ai import (
            VLLMProvider, HermesIAProvider, OpenAIProvider, ClaudeProvider, OllamaProvider)
        name = str(name or "ollama").strip() or "ollama"
        saved = dict(self.provider_cfg.get(name) or {})
        url = str(base_url if base_url is not None else saved.get("base_url") or "").strip()
        key = str(api_key if api_key is not None else saved.get("api_key") or "")
        try:
            to = max(5, min(120, int(timeout if timeout is not None else saved.get("timeout") or 30)))
        except (TypeError, ValueError):
            to = 30
        try:
            if name == "ollama":
                p = self.analyzer.providers.get("ollama") or OllamaProvider(
                    base_url=(url or self.base_url), timeout=to)
            elif name == "vllm":
                if not url:
                    return {"ok": False, "provider": name, "error": "Falta base_url"}
                p = VLLMProvider(base_url=url.rstrip("/"), timeout=to)
            elif name == "hermes_ia":
                import os as _os
                url = url or _os.getenv("HERMES_IA_URL", "").strip()
                if not url:
                    return {"ok": False, "provider": name, "error": "Falta base_url (o HERMES_IA_URL)"}
                p = HermesIAProvider(base_url=url.rstrip("/"), timeout=to)
            elif name == "openai":
                if not key:
                    return {"ok": False, "provider": name, "error": "Falta api_key"}
                p = OpenAIProvider(api_key=key, base_url=(url or "https://api.openai.com/v1").rstrip("/"), timeout=to)
            elif name == "claude":
                if not key:
                    return {"ok": False, "provider": name, "error": "Falta api_key"}
                p = ClaudeProvider(api_key=key, timeout=to)
            elif name == "opencode":
                return {"ok": True, "provider": name, "available": False,
                        "models": 0, "note": "Orquestador externo: gestión manual fuera de HT Forge."}
            else:
                return {"ok": False, "provider": name, "error": f"Proveedor desconocido: {name}"}
            try:
                raw = p.list_models() or []
            except Exception as exc:
                return {"ok": False, "provider": name, "error": f"Sin respuesta: {exc}"[:300]}
            names = [m.get("name") if isinstance(m, dict) else str(m) for m in raw]
            names = sorted({n for n in names if n})
            avail = bool(names)
            if avail and hasattr(p, "is_available"):
                try:
                    avail = bool(p.is_available())
                except Exception:
                    pass
            return {"ok": True, "provider": name, "available": avail,
                    "models": len(names), "sample": names[:5], "timeout": to}
        except Exception as exc:
            return {"ok": False, "provider": name, "error": str(exc)[:300]}

    def _active(self):
        p = self.analyzer.providers.get(self.active_provider)
        if p is None:
            p = self._ollama()
            self.active_provider = 'ollama'
        return p

    def provider_models(self, name=None):
        """Nombres de modelos del proveedor indicado (o el activo)."""
        name = str(name or self.active_provider or 'ollama')
        if name == 'ollama':
            return [m['name'] for m in self.model_details()]
        p = self.analyzer.providers.get(name)
        if not p:
            self._ensure_providers()
            p = self.analyzer.providers.get(name)
        if not p:
            return []
        try:
            raw = p.list_models() or []
        except Exception:
            return []
        out = []
        for m in raw:
            if isinstance(m, dict) and m.get('name'):
                out.append(m['name'])
            elif isinstance(m, str) and m:
                out.append(m)
        return sorted(set(out))

    def providers_state(self):
        st = {}
        for name in ('ollama', 'hermes_ia', 'vllm', 'openai', 'claude', 'opencode'):
            p = self.analyzer.providers.get(name)
            ok = False
            n = 0
            if p is not None:
                try:
                    n = len(self.provider_models(name)) if name != 'ollama' else len(self.model_details())
                    ok = bool(getattr(p, 'is_available', lambda: n > 0)())
                    if name in ('ollama', 'hermes_ia', 'vllm') and n:
                        ok = True
                except Exception:
                    ok, n = False, 0
            cfg = self.provider_cfg.get(name, {}) or {}
            st[name] = {'available': bool(ok), 'models': int(n),
                        'base_url': (cfg.get('base_url') or ''),
                        'has_key': bool(cfg.get('api_key')),
                        'timeout': cfg.get('timeout') or '',
                        'model': cfg.get('model') or ''}
        return st

    def _ollama(self):
        return self.analyzer.providers.get('ollama')

    def model_details(self):
        p = self._ollama()
        if not p:
            return []
        try:
            import urllib.request, json
            req = urllib.request.Request(self.base_url + '/api/tags', headers={'Accept':'application/json'})
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read().decode('utf-8'))
            out=[]
            for m in data.get('models') or []:
                if not isinstance(m, dict): continue
                out.append({
                    'name': m.get('name',''), 'size': int(m.get('size') or 0),
                    'size_text': self._human_size(m.get('size') or 0),
                    'modified_at': m.get('modified_at',''), 'digest': m.get('digest',''),
                    'family': (m.get('details') or {}).get('family',''),
                    'parameter_size': (m.get('details') or {}).get('parameter_size',''),
                    'quantization': (m.get('details') or {}).get('quantization_level',''),
                })
            return sorted(out, key=lambda x: (x['size'] if x['size'] else 10**30, x['name']))
        except Exception:
            return []

    @staticmethod
    def _human_size(n):
        n=float(n or 0)
        for u in ('B','KB','MB','GB','TB'):
            if n < 1024: return f'{n:.1f} {u}'
            n/=1024
        return f'{n:.1f} PB'

    def _select_default_model(self):
        models = self.provider_models(self.active_provider)
        prefer = str((self.provider_cfg.get(self.active_provider) or {}).get("model") or "").strip()
        if prefer and prefer in set(models or []):
            self.selected_model = prefer
        elif self.auto_smallest and models:
            self.selected_model = models[0]
        elif self.selected_model and models and self.selected_model not in set(models):
            self.selected_model = models[0]
        elif not self.selected_model:
            self.selected_model = (models[0] if models else 'llama3.1:8b')
        if self.active_provider == 'ollama' and self.selected_model in set(models):
            try:
                self.analyzer.set_model(self.selected_model, 'ollama')
            except Exception:
                pass

    def status(self):
        if self.active_provider == 'ollama':
            details = self.model_details()
            names = [m['name'] for m in details]
        else:
            names = self.provider_models(self.active_provider)
            details = [{'name': m} for m in names]
        selected = self.selected_model if self.selected_model in names else (names[0] if names else self.selected_model)
        if selected != self.selected_model and selected:
            self.selected_model = selected
        return {
            'enabled': True, 'provider': self.active_provider, 'base_url': self.base_url,
            'model': selected, 'auto_smallest': self.auto_smallest,
            'model_available': bool(selected and selected in names), 'models': names,
            'model_details': details,
            'ollama': {'ok': True, 'models': self.model_details()},
            'providers_state': self.providers_state(),
            'read_only': True, 'actions_enabled': False,
            'providers': self.PROVIDER_INFO,
        }

    def _health_ok(self):
        try:
            import urllib.request
            with urllib.request.urlopen(self.base_url + '/api/tags', timeout=3): return True
        except Exception: return False

    def self_test(self):
        """Verify real local inference, not only the /api/tags health endpoint."""
        prompt = '{"status":"ok"}'
        obj = self._generate_json(
            prompt,
            "Eres una prueba interna de HT Forge. Devuelve exactamente {\"status\":\"ok\"}. No ejecutes nada.",
            ["status"]
        )
        if str(obj.get("status", "")).lower() != "ok":
            raise AIError("El modelo respondió, pero la prueba estructurada no fue válida.")
        return {"generation_ready": True, "model": self.selected_model, "mode": "READ-ONLY"}

    def set_model(self, model):
        models = set(self.provider_models(self.active_provider))
        if model not in models:
            raise AIError(f'Modelo no instalado en {self.active_provider}: {model}')
        self.selected_model = model
        self.auto_smallest = False
        if self.active_provider == 'ollama':
            try:
                self.analyzer.set_model(model, 'ollama')
            except Exception:
                pass
        return self.status()

    def auto_select_smallest(self):
        self.auto_smallest=True
        self._select_default_model()
        return self.status()

    def _generate(self, prompt, system=''):
        p = self._active()
        models = self.provider_models(self.active_provider)
        if not models:
            raise AIError('El proveedor activo no tiene modelos disponibles. Revisa URL/clave en Ajustes → Modelos y orquestadores.')
        order = models if self.auto_smallest else sorted(models, key=lambda x: 0 if x == self.selected_model else 1)
        last = ''
        for m in order:
            try:
                text = p.generate(prompt, m, system)
                if text.strip():
                    self.selected_model = m
                    return text
            except Exception as exc:
                last = str(exc)
                continue
        raise AIError('El proveedor respondió con un error. HT Forge probó los modelos disponibles sin ejecutar ninguna acción externa. Detalle: ' + last[:300])

    def _generate_json(self, prompt, system, required_keys):
        """Structured local inference with one corrective retry per model."""
        p = self._active()
        if not p:
            raise AIError("Proveedor de IA no disponible.")
        models = self.provider_models(self.active_provider)
        if not models:
            raise AIError("El proveedor activo no tiene modelos disponibles.")
        order = models if self.auto_smallest else sorted(
            models, key=lambda x: 0 if x == self.selected_model else 1)
        last_error = None
        last_raw = ""
        for m in order:
            for attempt in range(2):
                try:
                    if hasattr(p, "generate_structured"):
                        raw = p.generate_structured(prompt, m, system)
                    else:
                        raw = p.generate(prompt, m, system)
                    last_raw = str(raw or "")
                    obj = _extract_json_object(raw)
                    if not isinstance(obj, dict):
                        raise AIError("La IA devolvió JSON que no es un objeto.")
                    missing = [k for k in required_keys if k not in obj]
                    if missing:
                        raise AIError("JSON incompleto; faltan: " + ", ".join(missing))
                    self.selected_model = m
                    return obj
                except AIError as exc:
                    last_error = exc
                    if attempt == 0:
                        prompt = prompt + (
                            "\n\nREINTENTO OBLIGATORIO: responde ÚNICAMENTE con un objeto JSON "
                            "válido. No uses Markdown, comentarios ni texto fuera del JSON. "
                            "Incluye todas las claves solicitadas."
                        )
        # Fallback a Ollama local antes de rendirse (el Core sigue intacto).
        if self.active_provider != "ollama":
            try:
                fb = self._fallback_generate_json(prompt, system, required_keys)
                if fb is not None:
                    return fb
            except Exception:
                pass
        return {"verdict": "INCONCLUSIVE", "confidence": 0.0,
                "_parse_error": True, "_text_fallback": last_raw[:2000],
                "_detail": str(last_error)[:300] if last_error else ""}

    def _fallback_generate_json(self, prompt, system, required_keys):
        """Un intento contra Ollama local cuando el proveedor activo falla."""
        try:
            p = self.analyzer.providers.get("ollama")
            models = self.provider_models("ollama") if p else []
            if not p or not models:
                return None
            m = self.selected_model if self.selected_model in models else models[0]
            raw = p.generate(prompt, m, system)
            obj = _extract_json_object(raw)
            if not isinstance(obj, dict):
                return None
            if any(k not in obj for k in required_keys):
                return None
            obj["fallback_used"] = f"ollama:{m}"
            return obj
        except Exception:
            return None

    def analyze_finding(self, finding):
        import json
        clean = self._clean(finding)
        prompt = """Analiza SOLO el hallazgo proporcionado por HT Forge. No inventes evidencias.
Devuelve un objeto JSON válido con estas claves:
classification, verdict, confidence, severity, cwe, owasp, cves, cve_status,
affected_component, false_positive_risk, rationale, evidence_used, remediation, references.
verdict: CONFIRMED, LIKELY, INCONCLUSIVE o REFUTED.
confidence: número entre 0 y 1.
evidence_used: lista que SOLO puede citar datos presentes en HALLAZGO.
cves: lista vacía salvo que producto/versión/evidencia permitan una relación sustentada.
cve_status: exact, candidate o none.
No conviertas banners, puertos abiertos, reflejos o rutas interesantes en una vulnerabilidad
confirmada por sí solos.

HALLAZGO:
""" + json.dumps(clean, ensure_ascii=False)
        system = """Eres HT Forge AI Analyst. Eres read-only y defensivo.
Forge Core conserva la autoridad técnica. No puedes modificar el hallazgo original,
crear evidencia, ejecutar acciones, ni afirmar una vulnerabilidad sin evidencia suficiente.
La salida debe ser JSON válido."""
        obj = self._generate_json(prompt, system, [
            "classification","verdict","confidence","severity","evidence_used",
            "rationale","remediation"
        ])
        return self._normalize(obj, clean)

    def summarize_session(self, session):
        import json
        compact = self._compact_session(session)
        prompt = """Resume esta sesión de HT Forge en JSON con: executive_summary (2-3 líneas),
priorities (máx 5, cada una {title, severity, reason}), confirmed_count,
inconclusive_count, recommendations (máx 5, accionables y breves).
No inventes vulnerabilidades ni CVE. Sé conciso: el resumen debe caber en ~1200 palabras.

SESIÓN:
""" + json.dumps(compact, ensure_ascii=False)
        return self._generate_json(
            prompt,
            "Eres HT Forge AI Analyst, read-only. Forge Core tiene la autoridad técnica. Responde solo JSON, breve.",
            ["executive_summary", "priorities", "confirmed_count",
             "inconclusive_count", "recommendations"]
        )

    @staticmethod
    def _compact_session(session):
        """Sesión resumida para inferencia rápida: conteos + top hallazgos sin evidencias."""
        s = session if isinstance(session, dict) else {}
        findings = s.get("findings") if isinstance(s.get("findings"), list) else []
        sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        top = sorted(
            [f for f in findings if isinstance(f, dict) and f.get("type") not in ("fp_stats", "crawl_results")],
            key=lambda f: (sev_rank.get(str(f.get("severity", "info")).lower(), 5), str(f.get("title", ""))),
        )[:12]
        counts = {}
        for f in findings:
            if isinstance(f, dict):
                k = str(f.get("severity", "info")).lower()
                counts[k] = counts.get(k, 0) + 1
        return {
            "target": str(s.get("target", ""))[:200],
            "profile": str(s.get("profile", ""))[:60],
            "status": str(s.get("status", ""))[:30],
            "counts": counts,
            "findings_total": len(findings),
            "top": [
                {
                    "title": str(f.get("title", ""))[:160],
                    "type": str(f.get("type", ""))[:40],
                    "severity": str(f.get("severity", ""))[:12],
                    "confidence": f.get("confidence"),
                    "url": str(f.get("url", ""))[:200],
                    "parameter": str(f.get("parameter", f.get("param", "")))[:60],
                    "state": str(f.get("verification_state", ""))[:16],
                }
                for f in top
            ],
        }

    @staticmethod
    def _clean(v,limit=12000):
        if isinstance(v,dict): return {str(k)[:100]:AICore._clean(x,limit) for k,x in list(v.items())[:100]}
        if isinstance(v,list): return [AICore._clean(x,limit) for x in v[:100]]
        if isinstance(v,str): return v.replace('\x00','')[:limit]
        return v

    @staticmethod
    def _normalize(r, s):
        verdict = str(r.get("verdict", "INCONCLUSIVE")).upper()
        if verdict not in {"CONFIRMED", "LIKELY", "INCONCLUSIVE", "REFUTED"}:
            verdict = "INCONCLUSIVE"
        try:
            conf = max(0.0, min(1.0, float(r.get("confidence", 0))))
        except (TypeError, ValueError):
            conf = 0.0
        cves = r.get("cves") if isinstance(r.get("cves"), list) else []
        cves = [str(x)[:80] for x in cves[:20] if isinstance(x, (str, int, float))]
        evidence = r.get("evidence_used") if isinstance(r.get("evidence_used"), list) else []
        source_keys = {str(k) for k in s.keys()}
        evidence = [str(x)[:160] for x in evidence[:30] if str(x) in source_keys]
        cve_status = str(r.get("cve_status") or ("candidate" if cves else "none")).lower()
        if cve_status not in {"exact", "candidate", "none"}: cve_status = "none"
        # Forge Core remains authoritative: never replace the scanner's severity.
        source_severity = str(s.get("severity") or "info").lower()
        return {
            "classification": str(r.get("classification") or s.get("type") or "unknown")[:200],
            "verdict": verdict,
            "confidence": conf,
            "severity": source_severity,
            "ai_severity": str(r.get("severity") or source_severity).lower()[:32],
            "cwe": r.get("cwe") or "—",
            "owasp": r.get("owasp") or "—",
            "cves": cves[:20],
            "cve_status": cve_status,
            "affected_component": r.get("affected_component") or "—",
            "false_positive_risk": str(r.get("false_positive_risk") or "unknown")[:100],
            "rationale": ((("[IA: respuesta no-JSON, solo texto; veredicto del Core intacto] "
                            + (("[fallback: %s] " % r.get("fallback_used")) if r.get("fallback_used") else ""))
                           if r.get("_parse_error") else "")
                          + str(r.get("rationale") or ""))[:5000],
            "evidence_used": evidence,
            "remediation": str(r.get("remediation") or "")[:5000],
            "references": r.get("references") if isinstance(r.get("references"), list) else [],
            "engine_authority": "HT Forge Forge Core",
            "read_only": True,
        }

__all__=['AIAnalyzer','AICore','AIConfig','DetectionTemplate','AIError','OllamaProvider','VLLMProvider','HermesIAProvider','ClaudeProvider','OpenAIProvider','OpencodeProvider','ProviderManager','generate_sqli_templates','generate_idor_templates','generate_rce_templates','generate_xss_templates','generate_path_traversal_templates','generate_ssrf_templates','generate_open_redirect_templates','generate_ssti_templates','OllamaManager','get_ollama_manager','ManagedScan']
