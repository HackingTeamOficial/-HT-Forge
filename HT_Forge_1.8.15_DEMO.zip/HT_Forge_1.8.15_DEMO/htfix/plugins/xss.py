#!/usr/bin/env python3
"""Reflected XSS detector for authorized assessments."""
import html
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode
from core.context import Context
from core.payloads import PayloadCollection
from core.payloads_1_8 import XSS_CONTEXT

XSS_PAYLOADS=tuple(dict.fromkeys(PayloadCollection.XSS + XSS_CONTEXT))

def _set_query_param(url,param,value):
    p=urlsplit(str(url)); pairs=parse_qsl(p.query,keep_blank_values=True); out=[]; replaced=False
    for k,v in pairs:
        if k==param and not replaced: out.append((k,value)); replaced=True
        elif k!=param: out.append((k,v))
    if not replaced: out.append((param,value))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))

def _post(ctx,info,param,payload):
    data=dict(info.get('form_data') or {}); data[param]=payload
    return ctx.req('POST',str(info.get('url',ctx.target)),data=data,
                   headers={'Content-Type':'application/x-www-form-urlencoded'},timeout=float(ctx.config.get('xss_request_timeout',8)))

def _classify_reflection(payload: str, text: str, content_type: str, status: int | None):
    """Classify reflection conservatively to reduce false positives."""
    raw = payload in text
    ct = (content_type or '').lower()
    is_html = 'text/html' in ct or 'application/xhtml+xml' in ct
    executable = False
    if raw and is_html:
        # The payload must survive in an HTML response and contain a script-capable
        # construct. A raw reflection inside JSON/plain text is not executable XSS.
        executable = '<script' in payload.lower() and '<script' in text.lower()
    # Server errors are useful evidence of unsafe handling, but are not enough to
    # claim executable XSS when the response is an error page.
    if status is not None and int(status) >= 500:
        executable = False
    if executable:
        return raw, True, 'high'
    if raw and is_html:
        return raw, False, 'medium'
    if raw:
        return raw, False, 'low'
    return False, False, None

def run(ctx:Context):
    target=ctx.target; findings=[]
    params=(ctx.get('discovered_params',[]) or [
        {'url':target,'param':'q','method':'GET'},
        {'url':target,'param':'search','method':'GET'}])[:int(ctx.config.get('xss_max_params',50))]
    ctx.log('info',f'Iniciando detección XSS en {target}')
    for info in params:
        if ctx.stopped: break
        param=str(info.get('param') or ''); method=str(info.get('method','GET')).upper()
        if not param: continue
        for payload in XSS_PAYLOADS[:int(ctx.config.get('xss_max_payloads', len(XSS_PAYLOADS)) )]:
            if ctx.stopped: break
            try:
                if method=='POST':
                    resp=_post(ctx,info,param,payload); test_url=str(info.get('url',target))
                else:
                    test_url=_set_query_param(info.get('url',target),param,payload)
                    resp=ctx.req('GET',test_url,timeout=float(ctx.config.get('xss_request_timeout',8)))
                text=getattr(resp,'text','') or ''
                status=getattr(resp,'status_code',None)
                ct=getattr(resp,'headers',{}).get('Content-Type','') if getattr(resp,'headers',None) else ''
                raw, executable, severity = _classify_reflection(payload, text, ct, status)
                if raw and severity:
                    title='XSS Reflejado' if executable else 'Posible XSS Reflejado'
                    detail=(f'Payload reflejado sin escapar en el parámetro {param}; '
                            f'contexto HTML compatible con ejecución.' if executable else
                            f'Payload reflejado en el parámetro {param}, pero la respuesta no demuestra ejecución XSS; requiere revisión.')
                    findings.append({'type':'xss_reflected','severity':severity,'title':title,
                       'detail':detail,'confidence':0.92 if executable else (0.65 if 'text/html' in str(ct).lower() else 0.45),
                       'evidence':{'url':test_url,'parameter':param,'payload':payload,
                                   'method':method,'response_status':status,'content_type':ct,
                                   'raw_reflection':True,'html_context':('text/html' in str(ct).lower()),
                                   'executable_context':executable},
                       'url':test_url,'parameter':param,'payload':payload})
                    ctx.log('ok' if executable else 'info',f'{title} en {param}'); break
            except (TimeoutError,ConnectionError,RuntimeError) as exc:
                ctx.log('warn',f'XSS {param}: {exc}')
            except Exception as exc:
                ctx.log('warn',f'XSS {param}: {exc}')
    return {'findings':findings}

__version__='1.8'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
