#!/usr/bin/env python3
"""HT Forge report exporters.

The PDF/HTML report follows the information architecture of the supplied
HTScanner reference report: professional cover, executive summary, exposure
dashboard, risk matrix, scope/assets, prioritized findings and technical
finding detail. Data always comes from the current ScanSession.
"""
import json
import html
import subprocess
import shutil
from datetime import datetime
from pathlib import Path
from collections import Counter
from typing import Dict, List, Any

try:
    from weasyprint import HTML
    WEASYPRINT_AVAILABLE = True
except ImportError:
    WEASYPRINT_AVAILABLE = False

try:
    from fpdf import FPDF
    FPDF_AVAILABLE = True
except ImportError:
    FPDF_AVAILABLE = False

from .models import ScanSession

SEV_ORDER = ["critical", "high", "medium", "low", "info"]
SEV_LABEL = {"critical":"Crítica", "high":"Alta", "medium":"Media", "low":"Baja", "info":"Informativa"}
SEV_COLOR = {"critical":"#8b1e2d", "high":"#c2410c", "medium":"#b45309", "low":"#15803d", "info":"#2563eb"}


def _count_severities(findings: List[Dict]) -> Dict[str, int]:
    counts = {k: 0 for k in SEV_ORDER}
    for f in findings or []:
        sev = str(f.get("severity", "info")).lower()
        counts[sev if sev in counts else "info"] += 1
    return counts


def _score(f: Dict) -> float:
    try:
        return float(f.get("scored", f.get("cvss", 0)) or 0)
    except Exception:
        return 0.0


def _risk_global(counts: Dict[str, int]) -> str:
    if counts["critical"]: return "CRÍTICO"
    if counts["high"]: return "ALTO"
    if counts["medium"]: return "MEDIO"
    if counts["low"]: return "BAJO"
    return "INFORMATIVO"


def _risk_indicator(counts: Dict[str, int]) -> int:
    # 0 = peor, 100 = mejor; transparent, deterministic executive indicator.
    total = sum(counts.values())
    if not total: return 100
    weighted = counts["critical"]*10 + counts["high"]*7.5 + counts["medium"]*5 + counts["low"]*2.5
    return max(0, min(100, round(100 - min(100, (weighted / total) * 10))))


def _technologies(session: ScanSession) -> List[str]:
    vals = session.metadata.get("technologies", []) if isinstance(session.metadata, dict) else []
    if vals: return sorted({str(x) for x in vals})
    for f in session.findings or []:
        if f.get("type") == "tech_fingerprint":
            ev = f.get("evidence") or {}
            vals = ev.get("technologies", []) if isinstance(ev, dict) else []
            if vals: return sorted({str(x) for x in vals})
    return []


def _urls(session: ScanSession) -> List[str]:
    meta = session.metadata or {}
    for key in ("discovered_urls", "crawler_urls", "urls"):
        vals = meta.get(key)
        if isinstance(vals, list) and vals:
            return list(dict.fromkeys(str(x) for x in vals if x))
    for f in session.findings or []:
        if f.get("type") == "crawl_results":
            ev = f.get("evidence") or {}
            vals = ev.get("urls", []) if isinstance(ev, dict) else []
            if vals: return list(dict.fromkeys(str(x) for x in vals if x))
    return list(dict.fromkeys(str(f.get("url")) for f in session.findings if f.get("url")))


def _assets(session: ScanSession) -> List[str]:
    vals = session.metadata.get("assets", []) if isinstance(session.metadata, dict) else []
    if isinstance(vals, list): return list(dict.fromkeys(str(x) for x in vals if x))
    return []


def _module_counts(findings: List[Dict]) -> Dict[str, int]:
    c = Counter(str(f.get("module", "unknown")) for f in findings or [])
    return dict(c.most_common(8))


def _esc(v: Any) -> str:
    if v is None: return "N/A"
    if isinstance(v, (dict, list)):
        return html.escape(json.dumps(v, ensure_ascii=False, indent=2, default=str))
    return html.escape(str(v))


def _finding_description(f: Dict) -> str:
    return str(f.get("detail") or f.get("description") or f.get("title") or "Sin descripción disponible.")


def _finding_evidence(f: Dict) -> str:
    ev = f.get("evidence")
    if not ev: return ""
    return json.dumps(ev, ensure_ascii=False, indent=2, default=str)


def _bar_chart(counts: Dict[str,int]) -> str:
    mx = max([counts[k] for k in SEV_ORDER] + [1])
    rows=[]
    for k in SEV_ORDER:
        pct = (counts[k]/mx)*100
        rows.append(f'<div class="barrow"><span>{SEV_LABEL[k]}</span><div class="bar"><i style="width:{pct:.1f}%;background:{SEV_COLOR[k]}"></i></div><b>{counts[k]}</b></div>')
    return ''.join(rows)


def _module_chart(findings: List[Dict]) -> str:
    mc = _module_counts(findings)
    mx = max(list(mc.values()) + [1])
    return ''.join(f'<div class="barrow"><span>{_esc(m)}</span><div class="bar"><i style="width:{(n/mx)*100:.1f}%"></i></div><b>{n}</b></div>' for m,n in mc.items()) or '<div class="muted">Sin hallazgos por módulo.</div>'


def _risk_matrix(counts: Dict[str,int]) -> str:
    # qualitative 5x5 matrix, with markers scaled by severity counts.
    labels = ["Muy baja","Baja","Media","Alta","Muy alta"]
    cells=[]
    high = counts["critical"] + counts["high"]
    med = counts["medium"]
    for impact in range(5,0,-1):
        for prob in range(1,6):
            level = impact * prob
            cls = "r1" if level <= 4 else "r2" if level <= 9 else "r3" if level <= 14 else "r4" if level <= 19 else "r5"
            marker = "●" if (level >= 16 and high) or (10 <= level < 16 and med) else ""
            cells.append(f'<div class="matrixcell {cls}"><small>{level}</small>{marker}</div>')
    return f'<div class="matrix"><div class="matrixgrid">{"".join(cells)}</div><div class="matrixaxis">PROBABILIDAD →</div><div class="matrixy">IMPACTO ↑</div></div>'


def _infographic_payload(session: ScanSession) -> Dict[str, Any]:
    findings = session.findings or []
    counts = _count_severities(findings)
    return {"target": session.target, "counts": counts, "risk": _risk_global(counts), "indicator": _risk_indicator(counts)}


def _local_infographic_svg(session: ScanSession) -> str:
    """HT Forge Cyber Grid infographic."""
    findings = session.findings or []
    counts = _count_severities(findings)
    risk = _risk_global(counts)
    indicator = _risk_indicator(counts)
    esc = lambda v: html.escape(str(v if v is not None else ""), quote=True)
    urls = _urls(session)
    tech = _technologies(session)
    meta = session.metadata or {}
    duration = (meta.get("metrics") or {}).get("elapsed_seconds")
    duration_txt = f"{duration}s" if duration is not None else "N/A"
    colors = {"critical":"#ff3b5c","high":"#ff7a18","medium":"#ffc857","low":"#35e58a","info":"#58a6ff"}
    labels = {"critical":"CRÍTICA","high":"ALTA","medium":"MEDIA","low":"BAJA","info":"INFO"}
    ordered = sorted(findings, key=lambda f: (SEV_ORDER.index(str(f.get("severity","info")).lower()) if str(f.get("severity","info")).lower() in SEV_ORDER else 99, -_score(f)))[:6]
    rows=[]
    for f in ordered:
        sev=str(f.get("severity","info")).lower()
        if sev not in colors: sev="info"
        y=474+len(rows)*48
        title=esc(f.get("title","Sin título"))[:72]
        module=esc(f.get("module","unknown"))[:28]
        url=esc(f.get("url") or f.get("endpoint") or (f.get("evidence") or {}).get("url") or "N/A")[:86]
        rows.append(f'<g><rect x="70" y="{y}" width="1160" height="38" rx="8" fill="#0d1524" stroke="#20344d"/><rect x="70" y="{y}" width="6" height="38" rx="3" fill="{colors[sev]}"/><text x="92" y="{y+16}" class="finding">{title}</text><text x="92" y="{y+30}" class="muted">{module} · {url}</text><rect x="1038" y="{y+7}" width="92" height="23" rx="11" fill="{colors[sev]}" opacity=".18" stroke="{colors[sev]}"/><text x="1084" y="{y+22}" text-anchor="middle" class="badge" fill="{colors[sev]}">{labels[sev]}</text><text x="1178" y="{y+22}" text-anchor="end" class="score">{_score(f):.1f}</text></g>')
    if not rows: rows=['<text x="92" y="496" class="muted">No se registraron hallazgos.</text>']
    metric_data=[("CRÍTICAS",counts["critical"],colors["critical"]),("ALTAS",counts["high"],colors["high"]),("MEDIAS",counts["medium"],colors["medium"]),("BAJAS",counts["low"],colors["low"]),("INFO",counts["info"],colors["info"])]
    metrics=[]
    for i,(label,val,col) in enumerate(metric_data):
        x=70+i*232
        metrics.append(f'<g><rect x="{x}" y="194" width="210" height="82" rx="10" fill="#0d1524" stroke="#20344d"/><text x="{x+18}" y="218" class="muted">{label}</text><text x="{x+18}" y="254" class="metric" fill="{col}">{val}</text><rect x="{x+18}" y="263" width="174" height="3" rx="2" fill="#152238"/><rect x="{x+18}" y="263" width="{max(4,min(174,val*18))}" height="3" rx="2" fill="{col}"/></g>')
    tech_txt=esc(", ".join(tech[:6]) if tech else "No identificadas")[:90]
    modules_txt=esc(", ".join(session.modules_run[:7]) if session.modules_run else "N/A")[:110]
    return f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1280\" height=\"820\" viewBox=\"0 0 1280 820\" role=\"img\" aria-label=\"HT Forge Cyber Grid Security Assessment\">
<defs><pattern id=\"grid\" width=\"32\" height=\"32\" patternUnits=\"userSpaceOnUse\"><path d=\"M32 0H0V32\" fill=\"none\" stroke=\"#1b2a3f\" stroke-width=\"1\"/></pattern><linearGradient id=\"glow\" x1=\"0\" x2=\"1\"><stop offset=\"0\" stop-color=\"#22d3ee\"/><stop offset=\"1\" stop-color=\"#58a6ff\"/></linearGradient><style>.title{{font:800 30px Arial,sans-serif;letter-spacing:3px;fill:#f4f8ff}}.sub{{font:500 13px Arial,sans-serif;fill:#7f94ad}}.muted{{font:500 12px Arial,sans-serif;fill:#7f94ad}}.metric{{font:800 29px Arial,sans-serif}}.finding{{font:700 13px Arial,sans-serif;fill:#edf5ff}}.badge{{font:800 10px Arial,sans-serif;letter-spacing:1px}}.score{{font:800 12px Arial,sans-serif;fill:#b8c9dd}}.label{{font:800 11px Arial,sans-serif;letter-spacing:1.4px;fill:#91a7c0}}.value{{font:700 13px Arial,sans-serif;fill:#dce9f7}}</style></defs>
<rect width=\"1280\" height=\"820\" fill=\"#070b12\"/><rect width=\"1280\" height=\"820\" fill=\"url(#grid)\" opacity=\".65\"/><rect x=\"28\" y=\"28\" width=\"1224\" height=\"764\" rx=\"18\" fill=\"#09101a\" stroke=\"#20344d\" stroke-width=\"2\"/><rect x=\"28\" y=\"28\" width=\"1224\" height=\"5\" rx=\"2\" fill=\"url(#glow)\"/>
<circle cx=\"68\" cy=\"69\" r=\"7\" fill=\"#22d3ee\"/><circle cx=\"88\" cy=\"69\" r=\"7\" fill=\"#58a6ff\"/><circle cx=\"108\" cy=\"69\" r=\"7\" fill=\"#35e58a\"/><text x=\"132\" y=\"78\" class=\"title\">HT FORGE</text><text x=\"132\" y=\"98\" class=\"sub\">CYBER GRID · SECURITY ASSESSMENT</text>
<text x=\"70\" y=\"137\" class=\"label\">TARGET</text><text x=\"70\" y=\"160\" class=\"value\">{esc(session.target)[:110]}</text><text x=\"900\" y=\"137\" class=\"label\">SCAN STATUS</text><text x=\"900\" y=\"160\" class=\"value\">{esc(session.status).upper()} · {duration_txt}</text><rect x=\"1080\" y=\"116\" width=\"120\" height=\"56\" rx=\"10\" fill=\"#0d1524\" stroke=\"#2a425e\"/><text x=\"1140\" y=\"137\" text-anchor=\"middle\" class=\"label\">RISK</text><text x=\"1140\" y=\"158\" text-anchor=\"middle\" class=\"metric\" fill=\"#ff7a18\" font-size=\"18\">{esc(risk)}</text>
{''.join(metrics)}
<rect x=\"70\" y=\"300\" width=\"560\" height=\"142\" rx=\"12\" fill=\"#0d1524\" stroke=\"#20344d\"/><text x=\"92\" y=\"327\" class=\"label\">ATTACK SURFACE</text><text x=\"92\" y=\"354\" class=\"value\">URLs observadas: {len(urls)}</text><text x=\"92\" y=\"379\" class=\"value\">Tecnologías: {tech_txt}</text><text x=\"92\" y=\"404\" class=\"value\">Módulos: {modules_txt}</text><rect x=\"650\" y=\"300\" width=\"550\" height=\"142\" rx=\"12\" fill=\"#0d1524\" stroke=\"#20344d\"/><text x=\"672\" y=\"327\" class=\"label\">EXECUTIVE SCORE</text><text x=\"672\" y=\"381\" class=\"metric\" fill=\"url(#glow)\">{indicator}<tspan font-size=\"16\" fill=\"#7f94ad\"> / 100</tspan></text><text x=\"672\" y=\"410\" class=\"muted\">Indicador orientativo basado en la distribución de severidades.</text>
<text x=\"70\" y=\"463\" class=\"label\">TOP FINDINGS</text><text x=\"1180\" y=\"463\" text-anchor=\"end\" class=\"label\">CVSS EST.</text>{''.join(rows)}<line x1=\"70\" y1=\"765\" x2=\"1210\" y2=\"765\" stroke=\"#20344d\"/><text x=\"70\" y=\"784\" class=\"muted\">HT Forge · Hacking Team · Uso autorizado únicamente</text><text x=\"1210\" y=\"784\" text-anchor=\"end\" class=\"muted\">Cyber Grid Renderer · {len(findings)} hallazgo(s)</text></svg>"""


def generate_infographic(session: ScanSession, output_dir: str) -> str:
    """Generate the bundled HT Forge Cyber Grid SVG."""
    out=Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    path=out/f"htforge_infographic_{session.id}.svg"
    path.write_text(_local_infographic_svg(session), encoding="utf-8")
    return str(path)


def _html_template(session: ScanSession, output_dir: str = "reports") -> str:
    findings = sorted(session.findings or [], key=lambda f: (SEV_ORDER.index(str(f.get("severity","info")).lower()) if str(f.get("severity","info")).lower() in SEV_ORDER else 99, -_score(f)))
    counts = _count_severities(findings)
    risk = _risk_global(counts)
    indicator = _risk_indicator(counts)
    urls = _urls(session)
    tech = _technologies(session)
    assets = _assets(session)
    meta = session.metadata or {}
    generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    org = meta.get("organization", "Organización evaluada")
    mode = meta.get("mode", session.profile)
    ended = meta.get("ended_at", "N/A")
    duration = (meta.get("metrics") or {}).get("elapsed_seconds")
    duration_txt = f"{duration}s" if duration is not None else "N/A"

    summary_cards = ''.join(f'<div class="metric"><strong>{counts[k]}</strong><span>{SEV_LABEL[k]}</span></div>' for k in SEV_ORDER)
    finding_rows=[]
    detail_sections=[]
    for i,f in enumerate(findings,1):
        sev=str(f.get("severity","info")).lower(); sev=sev if sev in SEV_ORDER else "info"
        cvss=_score(f)
        confidence=f.get("confidence") or (f.get("evidence") or {}).get("confidence") or "observed"
        url=f.get("url") or f.get("endpoint") or (f.get("evidence") or {}).get("url") or "N/A"
        finding_rows.append(f'<tr><td>{i}</td><td><span class="badge {sev}">{SEV_LABEL[sev]}</span></td><td>{_esc(f.get("module","unknown"))}</td><td>{cvss:.1f}</td><td>{_esc(confidence)}</td><td>{_esc(f.get("title","Sin título"))}</td></tr>')
        ev=_finding_evidence(f)
        evidence_html=f'<pre class="evidence">{_esc(ev)}</pre>' if ev else ''
        detail_sections.append(f'''<section class="finding-detail"><div class="fd-head"><span>#{i} · {_esc(f.get("title","Sin título"))}</span><span class="badge {sev}">{SEV_LABEL[sev]}</span></div>
        <div class="fd-grid"><div><b>Severidad</b><span>{SEV_LABEL[sev]}</span></div><div><b>Confianza</b><span>{_esc(confidence)}</span></div><div><b>CVSS</b><span>{cvss:.1f} / 10 (estimado)</span></div><div><b>Activo / URL</b><span>{_esc(url)}</span></div><div><b>Módulo</b><span>{_esc(f.get("module","unknown"))}</span></div><div><b>Fase</b><span>{_esc(f.get("phase","N/A"))}</span></div></div>
        <h4>Descripción / evidencia</h4><p>{_esc(_finding_description(f))}</p>{evidence_html}</section>''')

    url_items=''.join(f'<li>{_esc(u)}</li>' for u in urls) or '<li>No se registraron URLs descubiertas.</li>'
    tech_items=''.join(f'<span class="tech">{_esc(t)}</span>' for t in tech) or '<span class="muted">No identificadas</span>'
    asset_items=''.join(f'<li>{_esc(a)}</li>' for a in assets) or '<li>Host/objetivo principal: ' + _esc(session.target) + '</li>'
    modules=', '.join(session.modules_run or []) or 'N/A'
    infographic_path = generate_infographic(session, output_dir)
    infographic_name = Path(infographic_path).name

    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><title>HT Forge — Informe de evaluación</title>
<style>
@page{{size:A4;margin:15mm 14mm 17mm;@bottom-right{{content:"Página " counter(page) " / " counter(pages);font-size:8pt;color:#64748b}}}}
*{{box-sizing:border-box}}body{{font-family:Arial,Helvetica,sans-serif;color:#172033;background:white;font-size:9.5pt;line-height:1.45;margin:0}}h1,h2,h3,h4{{margin:0 0 9px}}h2{{font-size:18pt;color:#14213d;border-bottom:2px solid #14213d;padding-bottom:6px}}h3{{font-size:12pt;color:#334155}}p{{margin:5px 0 9px}}.cover{{height:245mm;display:flex;flex-direction:column;justify-content:center;text-align:center;border-bottom:8px solid #14213d}}.logo{{font-size:33pt;font-weight:800;letter-spacing:2px;color:#14213d}}.cover-title{{font-size:19pt;letter-spacing:1px;margin-top:7px}}.cover-sub{{color:#64748b;margin-top:18px}}.cover-meta{{margin:30px auto 0;width:78%;border-collapse:collapse;text-align:left}}.cover-meta td{{padding:9px 12px;border-bottom:1px solid #e2e8f0}}.cover-meta td:first-child{{font-weight:bold;width:34%;color:#64748b}}.page{{page-break-before:always}}.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}.card{{border:1px solid #dbe3ee;border-radius:7px;padding:13px;background:#fff}}.risk{{background:#f8fafc;text-align:center;border-top:5px solid #c2410c}}.risk strong{{display:block;font-size:25pt;color:#c2410c}}.indicator{{font-size:18pt;font-weight:bold;color:#14213d}}.metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;margin:13px 0}}.metric{{padding:10px 4px;text-align:center;border:1px solid #e2e8f0;border-radius:6px}}.metric strong{{display:block;font-size:18pt}}.metric span{{font-size:8pt;color:#64748b;text-transform:uppercase}}.dashboard{{page-break-inside:avoid}}.barrow{{display:grid;grid-template-columns:85px 1fr 28px;gap:7px;align-items:center;margin:7px 0;font-size:8.5pt}}.bar{{height:9px;background:#e8eef5;border-radius:9px;overflow:hidden}}.bar i{{display:block;height:100%;border-radius:9px}}.barrow b{{text-align:right}}.matrix{{position:relative;margin:12px 35px 28px 35px}}.matrixgrid{{display:grid;grid-template-columns:repeat(5,1fr);border:1px solid #94a3b8}}.matrixcell{{height:33px;border:1px solid white;display:flex;align-items:center;justify-content:center;font-size:12px;position:relative}}.matrixcell small{{position:absolute;top:2px;left:3px;font-size:6pt;opacity:.65}}.r1{{background:#dcfce7}}.r2{{background:#d9f99d}}.r3{{background:#fef08a}}.r4{{background:#fed7aa}}.r5{{background:#fecaca}}.matrixaxis{{text-align:center;font-size:7pt;margin-top:4px;color:#64748b}}.matrixy{{position:absolute;left:-31px;top:50%;transform:rotate(-90deg);font-size:7pt;color:#64748b}}table{{width:100%;border-collapse:collapse;margin:10px 0 16px;font-size:8pt}}th{{background:#14213d;color:#fff;text-align:left;padding:7px}}td{{border-bottom:1px solid #dbe3ee;padding:6px;vertical-align:top}}tr{{page-break-inside:avoid}}.badge{{display:inline-block;padding:3px 7px;border-radius:12px;color:white;font-weight:bold;font-size:7pt;text-transform:uppercase;white-space:nowrap}}.badge.critical{{background:#8b1e2d}}.badge.high{{background:#c2410c}}.badge.medium{{background:#b45309}}.badge.low{{background:#15803d}}.badge.info{{background:#2563eb}}.scope td:first-child{{font-weight:bold;color:#64748b;width:28%}}ul{{margin:5px 0 12px;padding-left:18px}}li{{margin:2px 0;word-break:break-all}}.tech{{display:inline-block;padding:5px 8px;border:1px solid #94a3b8;border-radius:14px;margin:3px;font-size:8pt;background:#f8fafc}}.finding-detail{{page-break-inside:avoid;border:1px solid #dbe3ee;border-radius:7px;margin:0 0 15px;overflow:hidden}}.fd-head{{background:#f1f5f9;padding:9px 11px;font-weight:bold;display:flex;justify-content:space-between;gap:10px}}.fd-grid{{display:grid;grid-template-columns:1fr 1fr;gap:7px;padding:11px 11px 4px}}.fd-grid div{{display:grid;grid-template-columns:95px 1fr;gap:5px}}.fd-grid b{{color:#64748b}}.finding-detail h4,.finding-detail p,.finding-detail pre{{margin-left:11px;margin-right:11px}}.evidence{{background:#0f172a;color:#e2e8f0;padding:9px;border-radius:5px;white-space:pre-wrap;word-break:break-word;font-size:7pt;max-height:90mm;overflow:hidden}}.muted{{color:#64748b}}.note{{background:#f8fafc;border-left:4px solid #64748b;padding:9px;margin:10px 0}}.footerline{{margin-top:25px;padding-top:8px;border-top:1px solid #cbd5e1;color:#64748b;font-size:7.5pt;text-align:center}}
</style></head><body>
<section class="cover"><div class="logo">HT FORGE</div><div class="cover-title">INFORME PROFESIONAL DE EVALUACIÓN DE SEGURIDAD</div><div class="cover-sub">Documento técnico para uso autorizado</div><table class="cover-meta"><tr><td>Organización</td><td>{_esc(org)}</td></tr><tr><td>Objetivo</td><td>{_esc(session.target)}</td></tr><tr><td>Fecha</td><td>{_esc(session.started_at)}</td></tr><tr><td>Modo</td><td>{_esc(mode)}</td></tr><tr><td>ID DE EVALUACIÓN</td><td>{_esc(session.id)}</td></tr></table></section>

<section class="page"><h2>1. Resumen ejecutivo</h2><p>Vista de alto nivel para dirección y responsables de seguridad.</p><div class="grid2"><div class="card risk"><span>RIESGO GLOBAL</span><strong>{risk}</strong><div>Clasificación basada en la severidad máxima observada.</div></div><div class="card"><span>INDICADOR EJECUTIVO</span><div class="indicator">{indicator}/100</div><p>Indicador orientativo calculado a partir de la distribución de severidades.</p></div></div><div class="metrics">{summary_cards}</div><p>La evaluación sobre <b>{_esc(session.target)}</b> registró <b>{len(findings)}</b> hallazgo(s) y <b>{len(urls)}</b> URL(s) observadas/descubiertas. La priorización debe considerar conjuntamente severidad, evidencia, confianza y exposición del activo.</p><div class="note"><b>Interpretación:</b> los hallazgos informativos no representan por sí mismos una vulnerabilidad; se incluyen para documentar superficie, tecnología o condiciones relevantes. Los hallazgos con confianza no confirmada deben validarse antes de decisiones de alto impacto.</div></section>

<section class="page dashboard"><h2>2. Dashboard de exposición</h2><p>Indicadores visuales para identificar rápidamente dónde concentrar la remediación.</p><div class="grid2"><div class="card"><h3>Distribución por severidad</h3>{_bar_chart(counts)}</div><div class="card"><h3>Hallazgos por módulo (top 8)</h3>{_module_chart(findings)}</div></div><div class="card" style="margin-top:14px"><h3>Tecnologías identificadas</h3><div>{tech_items}</div></div></section>

<section class="page"><h2>3. Distribución y matriz de riesgo</h2><div class="grid2"><div class="card"><h3>Composición del riesgo detectado</h3>{_bar_chart(counts)}</div><div class="card"><h3>Interpretación</h3><p>La matriz representa una clasificación cualitativa de probabilidad e impacto. No sustituye un cálculo formal de riesgo corporativo cuando la organización requiera parámetros propios.</p></div></div>{_risk_matrix(counts)}</section>

<section class="page"><h2>4. Alcance y activos observados</h2><table class="scope"><tr><td>Objetivo</td><td>{_esc(session.target)}</td></tr><tr><td>Host / IP / activos</td><td><ul>{asset_items}</ul></td></tr><tr><td>Tecnología</td><td>{tech_items}</td></tr><tr><td>Módulos ejecutados</td><td>{_esc(modules)}</td></tr><tr><td>Modo</td><td>{_esc(mode)}</td></tr><tr><td>Hallazgos</td><td>{len(findings)}</td></tr><tr><td>URLs observadas</td><td>{len(urls)}</td></tr><tr><td>Duración</td><td>{_esc(duration_txt)}</td></tr><tr><td>Estado</td><td>{_esc(session.status)}</td></tr></table><div class="note">El informe refleja únicamente los activos, rutas, servicios y respuestas que el scanner pudo observar durante la ejecución. Una ausencia de hallazgo no equivale a ausencia de vulnerabilidad.</div><h3>URLs detectadas por crawler</h3><ul>{url_items}</ul></section>

<section class="page"><h2>5. Hallazgos priorizados</h2><p>Ordenados por severidad y, cuando está disponible, por CVSS estimado.</p><table><thead><tr><th>#</th><th>Severidad</th><th>Módulo</th><th>CVSS</th><th>Confianza</th><th>Descripción</th></tr></thead><tbody>{''.join(finding_rows) or '<tr><td colspan="6">No se detectaron hallazgos.</td></tr>'}</tbody></table></section>

<section class="page"><h2>6. Detalle técnico de vulnerabilidades</h2><p>Evidencia y contexto disponibles para reproducibilidad y remediación.</p>{''.join(detail_sections) or '<div class="note">No se registraron vulnerabilidades con detalle técnico.</div>'}</section>

<section class="page"><h2>7. Infografía de seguridad — AntV Infographic</h2><p>Representación visual generada a partir de los datos reales de esta evaluación. Si el runtime AntV SSR no está disponible, HT Forge usa un renderer SVG local compatible para garantizar que el informe siempre incluya una infografía válida.</p><div class="card" style="text-align:center"><img src="{infographic_name}" alt="HT Forge Security Infographic" style="width:100%;max-width:180mm;height:auto"></div></section>

<section class="page"><h2>8. Metodología y notas</h2><table class="scope"><tr><td>Perfil</td><td>{_esc(session.profile)}</td></tr><tr><td>Inicio</td><td>{_esc(session.started_at)}</td></tr><tr><td>Fin</td><td>{_esc(ended)}</td></tr><tr><td>Errores de módulos</td><td>{len(session.errors or [])}</td></tr></table><div class="note">Reporte generado automáticamente por HT Forge. Las puntuaciones CVSS indicadas como estimadas son una ayuda de priorización y deben validarse según el contexto real del activo.</div><div class="footerline">HT Forge · Hacking Team · Uso autorizado únicamente · Reporte confidencial · Generado {generated}</div></section>
</body></html>'''


def export_report(session: ScanSession, format: str = "json", output_dir: str = "reports") -> str:
    fmt = format.lower(); out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    if fmt == "json":
        path=out/f"htforge_report_{session.id}.json"; path.write_text(_export_json(session),encoding="utf-8"); return str(path)
    if fmt == "html":
        path=out/f"htforge_report_{session.id}.html"; path.write_text(_html_template(session, str(out)),encoding="utf-8"); return str(path)
    if fmt == "pdf": return _export_pdf(session, str(out))
    raise ValueError(f"Formato no soportado: {format}")


def _export_json(session: ScanSession) -> str:
    return json.dumps({
        "report": {"product":"HT Forge","type":"Professional Security Assessment"},
        "session": {"id":session.id,"target":session.target,"profile":session.profile,"started_at":session.started_at.isoformat(),"ended_at":session.metadata.get("ended_at"),"status":session.status,"modules_run":session.modules_run,"errors":session.errors,"metadata":session.metadata},
        "summary": _count_severities(session.findings),
        "findings": session.findings,
        "generated_at": datetime.now().isoformat()
    }, indent=2, ensure_ascii=False, default=str)


def _export_pdf(session: ScanSession, output_dir: str) -> str:
    path = str(Path(output_dir)/f"htforge_report_{session.id}.pdf")
    html_content = _html_template(session, output_dir)
    if WEASYPRINT_AVAILABLE:
        HTML(string=html_content, base_url=str(Path(output_dir).resolve())).write_pdf(path)
        return path
    if FPDF_AVAILABLE:
        return _export_pdf_fpdf(session, output_dir)
    fallback = str(Path(output_dir)/f"htforge_report_{session.id}.html")
    Path(fallback).write_text(html_content,encoding="utf-8")
    return fallback


def _export_pdf_fpdf(session: ScanSession, output_dir: str) -> str:
    # Conservative fallback when WeasyPrint is unavailable.
    pdf=FPDF(); pdf.set_auto_page_break(True,15); pdf.add_page(); pdf.set_font("Helvetica","B",20); pdf.cell(0,12,"HT FORGE",ln=True,align="C"); pdf.set_font("Helvetica","B",12); pdf.cell(0,8,"INFORME PROFESIONAL DE EVALUACION DE SEGURIDAD",ln=True,align="C"); pdf.ln(8)
    pdf.set_font("Helvetica","",10); pdf.multi_cell(0,6,f"Objetivo: {session.target}\nID: {session.id}\nPerfil: {session.profile}\nEstado: {session.status}"); pdf.ln(5)
    counts=_count_severities(session.findings); pdf.set_font("Helvetica","B",13); pdf.cell(0,8,"1. Resumen ejecutivo",ln=True); pdf.set_font("Helvetica","",10)
    pdf.multi_cell(0,6,f"Riesgo global: {_risk_global(counts)} | Indicador: {_risk_indicator(counts)}/100 | Hallazgos: {len(session.findings)}")
    for k in SEV_ORDER: pdf.cell(0,6,f"{SEV_LABEL[k]}: {counts[k]}",ln=True)
    pdf.add_page(); pdf.set_font("Helvetica","B",13); pdf.cell(0,8,"5. Hallazgos priorizados",ln=True)
    for i,f in enumerate(session.findings,1):
        if pdf.get_y()>255: pdf.add_page()
        pdf.set_font("Helvetica","B",10); pdf.multi_cell(0,6,f"#{i} {f.get('title','Sin titulo')} [{f.get('severity','info').upper()}]")
        pdf.set_font("Helvetica","",9); pdf.multi_cell(0,5,f"Modulo: {f.get('module','unknown')} | CVSS: {_score(f):.1f}\nURL: {f.get('url','N/A')}\n{_finding_description(f)}")
    path=str(Path(output_dir)/f"htforge_report_{session.id}.pdf"); pdf.output(path); return path


def export_all_reports(session: ScanSession, output_dir: str = "reports") -> Dict[str,str]:
    results={}
    for fmt in ("json","html","pdf"):
        try: results[fmt]=export_report(session,fmt,output_dir)
        except Exception as exc: results[fmt]=f"ERROR: {exc}"
    return results
