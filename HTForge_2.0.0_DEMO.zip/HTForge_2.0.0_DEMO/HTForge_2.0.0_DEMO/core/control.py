#!/usr/bin/env python3
"""core/control.py - Control de ejecución y estado"""

import threading
import time
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum


class ControlState(Enum):
    IDLE = "idle"
    STARTING = "starting"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class ControlConfig:
    max_concurrent_modules: int = 3
    module_timeout: int = 300
    global_timeout: int = 3600
    auto_stop_on_critical: bool = False
    pause_on_finding: bool = False


class EngineControl:
    """Control centralizado del motor"""
    
    def __init__(self, config: ControlConfig = None):
        self.config = config or ControlConfig()
        self.state = ControlState.IDLE
        self._lock = threading.RLock()
        self._callbacks: Dict[str, list] = {
            'state_change': [],
            'module_start': [],
            'module_end': [],
            'finding': [],
            'error': []
        }
        self._current_module: Optional[str] = None
        self._modules_completed = 0
        self._modules_total = 0
        self._start_time: Optional[float] = None
        self._pause_event = threading.Event()
        self._pause_event.set()  # No pausado al inicio
        self._stop_event = threading.Event()
    
    def register_callback(self, event: str, callback: Callable):
        if event in self._callbacks:
            self._callbacks[event].append(callback)
    
    def _emit(self, event: str, data: Any):
        for cb in self._callbacks.get(event, []):
            try:
                cb(data)
            except Exception:
                pass
    
    def start(self, total_modules: int):
        with self._lock:
            self.state = ControlState.STARTING
            self._modules_total = total_modules
            self._modules_completed = 0
            self._start_time = time.time()
            self._stop_event.clear()
            self._pause_event.set()
            self._emit('state_change', self.state)
    
    def running(self):
        with self._lock:
            self.state = ControlState.RUNNING
            self._emit('state_change', self.state)
    
    def pause(self):
        with self._lock:
            if self.state == ControlState.RUNNING:
                self.state = ControlState.PAUSED
                self._pause_event.clear()
                self._emit('state_change', self.state)
    
    def resume(self):
        with self._lock:
            if self.state == ControlState.PAUSED:
                self.state = ControlState.RUNNING
                self._pause_event.set()
                self._emit('state_change', self.state)
    
    def stop(self):
        with self._lock:
            self.state = ControlState.STOPPING
            self._stop_event.set()
            self._pause_event.set()  # Desbloquear si está pausado
            self._emit('state_change', self.state)
    
    def stopped(self):
        with self._lock:
            self.state = ControlState.STOPPED
            self._emit('state_change', self.state)
    
    def error(self, err: str):
        with self._lock:
            self.state = ControlState.ERROR
            self._emit('error', err)
            self._emit('state_change', self.state)
    
    def module_start(self, module: str):
        with self._lock:
            self._current_module = module
            self._emit('module_start', module)
    
    def module_end(self, module: str, status: str = 'ok'):
        with self._lock:
            self._modules_completed += 1
            self._emit('module_end', {'module': module, 'status': status})
    
    def finding(self, finding: Dict):
        self._emit('finding', finding)
        if self.config.auto_stop_on_critical and finding.get('severity') == 'critical':
            self.stop()
    
    def wait_if_paused(self):
        """Bloquea si está pausado"""
        self._pause_event.wait()
    
    def should_stop(self) -> bool:
        return self._stop_event.is_set()
    
    def get_progress(self) -> Dict:
        elapsed = time.time() - self._start_time if self._start_time else 0
        return {
            'state': self.state.value,
            'current_module': self._current_module,
            'completed': self._modules_completed,
            'total': self._modules_total,
            'percent': (self._modules_completed / self._modules_total * 100) if self._modules_total > 0 else 0,
            'elapsed': round(elapsed, 1)
        }
    
    def is_running(self) -> bool:
        return self.state in (ControlState.RUNNING, ControlState.STARTING)
    
    def is_paused(self) -> bool:
        return self.state == ControlState.PAUSED
    
    def reset(self):
        with self._lock:
            self.state = ControlState.IDLE
            self._current_module = None
            self._modules_completed = 0
            self._modules_total = 0
            self._start_time = None
            self._stop_event.clear()
            self._pause_event.set()


# Instancia global
control = EngineControl()