"""Persistencia local de credenciales de sesión para HT Forge.

Los tokens se guardan únicamente en runtime/auth_sessions.json con permisos 0600
y nunca se incluyen en logs ni en reportes. Úsalo solo para objetivos autorizados.
"""
import json, os
from pathlib import Path
from urllib.parse import urlparse

STORE = Path("runtime/auth_sessions.json")

def _key(target: str) -> str:
    p = urlparse(target if target.startswith(("http://","https://")) else "https://"+target)
    return f"{p.scheme}://{p.netloc}".lower()

def load_all():
    try:
        if STORE.exists():
            return json.loads(STORE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def save(target: str, session_id: str = "", token: str = "", session_cookie_name: str = "sessionid"):
    data=load_all(); data[_key(target)]={
        "session_id": session_id.strip(),
        "token": token.strip(),
        "session_cookie_name": (session_cookie_name or "sessionid").strip()
    }
    STORE.parent.mkdir(parents=True, exist_ok=True)
    tmp=STORE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.chmod(tmp, 0o600)
    tmp.replace(STORE)
    try: os.chmod(STORE, 0o600)
    except OSError: pass

def get(target: str):
    return load_all().get(_key(target), {})

def masked(target: str):
    a=get(target); tok=a.get("token",""); sid=a.get("session_id","")
    return {"configured": bool(tok or sid), "session_id": sid,
            "token_masked": (tok[:4]+"…"+tok[-4:]) if len(tok)>8 else ("configured" if tok else ""),
            "session_cookie_name": a.get("session_cookie_name","sessionid")}
