#!/usr/bin/env python3
"""core/findings.py - Sistema de Findings mejorado para HT Forge

Finding estructurado con evidencia, deduplicación, estados y correlación.
"""

from typing import Dict, Any, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from collections import defaultdict
import hashlib
import json


class FindingStatus(Enum):
    """Estados del ciclo de vida de un finding"""
    NEW = "new"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    FIXED = "fixed"
    REOPENED = "reopened"
    IGNORED = "ignored"


class FindingSeverity(Enum):
    """Severidad estándar"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class Evidence:
    """Evidencia que respalda un finding"""
    id: str
    type: str  # request_response, screenshot, header, body_diff, log, artifact
    title: str
    description: str
    data: Dict[str, Any]  # Contenido específico según tipo
    plugin_source: str
    timestamp: datetime = field(default_factory=datetime.now)
    hash: str = ""
    
    def __post_init__(self):
        if not self.hash:
            content = json.dumps(self.data, sort_keys=True, default=str)
            self.hash = hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'type': self.type,
            'title': self.title,
            'description': self.description,
            'data': self.data,
            'plugin_source': self.plugin_source,
            'timestamp': self.timestamp.isoformat(),
            'hash': self.hash
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Evidence':
        data = data.copy()
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        return cls(**data)


@dataclass
class Reference:
    """Referencia externa (CVE, CWE, advisory, etc.)"""
    type: str  # cve, cwe, cwg, url, advisory
    value: str
    title: str = ""
    url: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.type,
            'value': self.value,
            'title': self.title,
            'url': self.url
        }


@dataclass
class Finding:
    """Finding completo con toda la metadata"""
    id: str
    title: str
    type: str  # sqli, xss, rce, lfi, info_disclosure, etc.
    category: str  # injection, xss, auth, config, info, crypto, etc.
    severity: FindingSeverity
    confidence: float  # 0.0 - 1.0
    status: FindingStatus = FindingStatus.NEW
    
    # Ubicación
    asset_id: Optional[str] = None  # ID del asset en AssetGraph
    target: str = ""
    endpoint: str = ""
    parameter: str = ""
    method: str = ""
    
    # Evidencia y origen
    evidence: List[Evidence] = field(default_factory=list)
    plugin_sources: List[str] = field(default_factory=list)  # Plugins que lo detectaron
    references: List[Reference] = field(default_factory=list)
    
    # Detalles técnicos
    detail: str = ""
    payload: str = ""
    impact: str = ""
    remediation: str = ""
    
    # Scoring
    cvss_score: Optional[float] = None
    cvss_vector: Optional[str] = None
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    discovered_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    confirmed_at: Optional[datetime] = None
    fixed_at: Optional[datetime] = None
    
    # Correlación
    related_finding_ids: List[str] = field(default_factory=list)
    duplicate_of: Optional[str] = None
    deduplication_key: str = ""
    
    def __post_init__(self):
        if not self.deduplication_key:
            self.deduplication_key = self._compute_dedup_key()
    
    def _compute_dedup_key(self) -> str:
        """Clave para detectar duplicados"""
        parts = [
            self.type,
            self.endpoint or self.target,
            self.parameter or '',
            self.method or ''
        ]
        return hashlib.sha256('|'.join(parts).encode()).hexdigest()[:32]
    
    def add_evidence(self, evidence: Evidence):
        """Añade evidencia y actualiza plugin_sources"""
        self.evidence.append(evidence)
        if evidence.plugin_source not in self.plugin_sources:
            self.plugin_sources.append(evidence.plugin_source)
        self.updated_at = datetime.now()
    
    def add_plugin_source(self, plugin_name: str):
        """Registra un plugin que detectó este finding"""
        if plugin_name not in self.plugin_sources:
            self.plugin_sources.append(plugin_name)
            self.updated_at = datetime.now()
    
    def update_confidence(self):
        """Recalcula confidence basado en evidencia y fuentes"""
        base = 0.5
        # Más evidencia = más confianza
        base += min(len(self.evidence) * 0.1, 0.3)
        # Múltiples fuentes = más confianza
        base += min(len(self.plugin_sources) * 0.15, 0.3)
        # Severidad alta suele tener más evidencia
        if self.severity in (FindingSeverity.CRITICAL, FindingSeverity.HIGH):
            base += 0.1
        self.confidence = min(base, 1.0)
        self.updated_at = datetime.now()
    
    def confirm(self):
        """Marca como confirmado"""
        self.status = FindingStatus.CONFIRMED
        self.confirmed_at = datetime.now()
        self.updated_at = datetime.now()
    
    def mark_false_positive(self):
        """Marca como falso positivo"""
        self.status = FindingStatus.FALSE_POSITIVE
        self.updated_at = datetime.now()
    
    def mark_fixed(self):
        """Marca como corregido"""
        self.status = FindingStatus.FIXED
        self.fixed_at = datetime.now()
        self.updated_at = datetime.now()
    
    def reopen(self):
        """Reabre un finding"""
        self.status = FindingStatus.REOPENED
        self.updated_at = datetime.now()
    
    def merge_with(self, other: 'Finding') -> 'Finding':
        """Fusiona otro finding en este (para deduplicación)"""
        # Añadir evidencia
        for ev in other.evidence:
            if ev.hash not in [e.hash for e in self.evidence]:
                self.add_evidence(ev)
        
        # Añadir fuentes
        for src in other.plugin_sources:
            self.add_plugin_source(src)
        
        # Tomar la severidad más alta
        severity_order = [FindingSeverity.INFO, FindingSeverity.LOW, FindingSeverity.MEDIUM, 
                         FindingSeverity.HIGH, FindingSeverity.CRITICAL]
        if severity_order.index(other.severity) > severity_order.index(self.severity):
            self.severity = other.severity
        
        # Actualizar metadata
        self.updated_at = datetime.now()
        self.tags = list(set(self.tags + other.tags))
        
        return self
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'title': self.title,
            'type': self.type,
            'category': self.category,
            'severity': self.severity.value,
            'confidence': self.confidence,
            'status': self.status.value,
            'asset_id': self.asset_id,
            'target': self.target,
            'endpoint': self.endpoint,
            'parameter': self.parameter,
            'method': self.method,
            'evidence': [e.to_dict() for e in self.evidence],
            'plugin_sources': self.plugin_sources,
            'references': [r.to_dict() for r in self.references],
            'detail': self.detail,
            'payload': self.payload,
            'impact': self.impact,
            'remediation': self.remediation,
            'cvss_score': self.cvss_score,
            'cvss_vector': self.cvss_vector,
            'tags': self.tags,
            'discovered_at': self.discovered_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'confirmed_at': self.confirmed_at.isoformat() if self.confirmed_at else None,
            'fixed_at': self.fixed_at.isoformat() if self.fixed_at else None,
            'related_finding_ids': self.related_finding_ids,
            'duplicate_of': self.duplicate_of,
            'deduplication_key': self.deduplication_key
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Finding':
        data = data.copy()
        data['severity'] = FindingSeverity(data['severity'])
        data['status'] = FindingStatus(data['status'])
        data['evidence'] = [Evidence.from_dict(e) for e in data.get('evidence', [])]
        data['references'] = [Reference(**r) for r in data.get('references', [])]
        for dt_field in ['discovered_at', 'updated_at', 'confirmed_at', 'fixed_at']:
            if data.get(dt_field):
                data[dt_field] = datetime.fromisoformat(data[dt_field])
        return cls(**data)


class FindingsManager:
    """Gestiona la colección de findings con deduplicación automática"""
    
    def __init__(self):
        self.findings: Dict[str, Finding] = {}
        self.by_dedup_key: Dict[str, str] = {}  # dedup_key -> finding_id
        self.by_status: Dict[FindingStatus, Set[str]] = defaultdict(set)
        self.by_severity: Dict[FindingSeverity, Set[str]] = defaultdict(set)
        self.by_plugin: Dict[str, Set[str]] = defaultdict(set)
        self.by_asset: Dict[str, Set[str]] = defaultdict(set)
    
    def add(self, finding: Finding) -> Finding:
        """Añade finding con deduplicación automática"""
        # Verificar duplicado
        if finding.deduplication_key in self.by_dedup_key:
            existing_id = self.by_dedup_key[finding.deduplication_key]
            existing = self.findings[existing_id]
            existing.merge_with(finding)
            existing.duplicate_of = None  # El original no es duplicado
            finding.duplicate_of = existing_id
            return existing
        
        # Nuevo finding
        self.findings[finding.id] = finding
        self.by_dedup_key[finding.deduplication_key] = finding.id
        self.by_status[finding.status].add(finding.id)
        self.by_severity[finding.severity].add(finding.id)
        
        for src in finding.plugin_sources:
            self.by_plugin[src].add(finding.id)
        
        if finding.asset_id:
            self.by_asset[finding.asset_id].add(finding.id)
        
        return finding
    
    def get(self, finding_id: str) -> Optional[Finding]:
        return self.findings.get(finding_id)
    
    def get_all(self) -> List[Finding]:
        return list(self.findings.values())
    
    def get_by_status(self, status: FindingStatus) -> List[Finding]:
        return [self.findings[fid] for fid in self.by_status.get(status, set())]
    
    def get_by_severity(self, severity: FindingSeverity) -> List[Finding]:
        return [self.findings[fid] for fid in self.by_severity.get(severity, set())]
    
    def get_by_plugin(self, plugin: str) -> List[Finding]:
        return [self.findings[fid] for fid in self.by_plugin.get(plugin, set())]
    
    def get_by_asset(self, asset_id: str) -> List[Finding]:
        return [self.findings[fid] for fid in self.by_asset.get(asset_id, set())]
    
    def get_confirmed(self) -> List[Finding]:
        return self.get_by_status(FindingStatus.CONFIRMED)
    
    def get_new(self) -> List[Finding]:
        return self.get_by_status(FindingStatus.NEW)
    
    def get_critical_high(self) -> List[Finding]:
        return self.get_by_severity(FindingSeverity.CRITICAL) + self.get_by_severity(FindingSeverity.HIGH)
    
    def get_summary(self) -> Dict[str, Any]:
        return {
            'total': len(self.findings),
            'by_status': {s.value: len(ids) for s, ids in self.by_status.items()},
            'by_severity': {s.value: len(ids) for s, ids in self.by_severity.items()},
            'by_plugin': {p: len(ids) for p, ids in self.by_plugin.items()},
            'confirmed': len(self.get_confirmed()),
            'new': len(self.get_new()),
            'critical_high': len(self.get_critical_high())
        }
    
    def export_json(self) -> str:
        return json.dumps([f.to_dict() for f in self.findings.values()], indent=2, default=str)
    
    def import_json(self, json_str: str):
        data = json.loads(json_str)
        for item in data:
            finding = Finding.from_dict(item)
            self.add(finding)
    
    def update_status(self, finding_id: str, status: FindingStatus):
        finding = self.findings.get(finding_id)
        if not finding:
            return
        
        # Remover de índice anterior
        self.by_status[finding.status].discard(finding_id)
        
        # Actualizar
        if status == FindingStatus.CONFIRMED:
            finding.confirm()
        elif status == FindingStatus.FALSE_POSITIVE:
            finding.mark_false_positive()
        elif status == FindingStatus.FIXED:
            finding.mark_fixed()
        elif status == FindingStatus.REOPENED:
            finding.reopen()
        else:
            finding.status = status
            finding.updated_at = datetime.now()
        
        # Añadir a nuevo índice
        self.by_status[finding.status].add(finding_id)


# Helpers para crear findings comunes
def create_finding_from_plugin(
    plugin_name: str,
    finding_type: str,
    target: str,
    endpoint: str = "",
    parameter: str = "",
    severity: FindingSeverity = FindingSeverity.MEDIUM,
    confidence: float = 0.7,
    detail: str = "",
    payload: str = "",
    evidence_data: Optional[Dict] = None
) -> Finding:
    """Crea un finding estándar desde un plugin"""
    finding_id = hashlib.sha256(f"{plugin_name}:{finding_type}:{target}:{endpoint}:{parameter}".encode()).hexdigest()[:16]
    
    finding = Finding(
        id=finding_id,
        title=f"{finding_type.upper()} en {parameter or endpoint or target}",
        type=finding_type,
        category=_type_to_category(finding_type),
        severity=severity,
        confidence=confidence,
        target=target,
        endpoint=endpoint,
        parameter=parameter,
        detail=detail,
        payload=payload,
        plugin_sources=[plugin_name]
    )
    
    if evidence_data:
        evidence = Evidence(
            id=hashlib.sha256(str(evidence_data).encode()).hexdigest()[:12],
            type='request_response',
            title=f"Evidencia {finding_type}",
            description=f"Prueba de {finding_type} detectada por {plugin_name}",
            data=evidence_data,
            plugin_source=plugin_name
        )
        finding.add_evidence(evidence)
    
    finding.update_confidence()
    return finding


def _type_to_category(finding_type: str) -> str:
    categories = {
        'sqli': 'injection', 'nosql': 'injection', 'ldap': 'injection', 'xpath': 'injection',
        'xss': 'xss', 'dom_xss': 'xss', 'reflected_xss': 'xss', 'stored_xss': 'xss',
        'rce': 'rce', 'rfi': 'rce', 'lfi': 'lfi', 'traversal': 'lfi',
        'idor': 'auth', 'auth_bypass': 'auth', 'jwt': 'auth', 'session': 'auth',
        'cors': 'config', 'csp': 'config', 'hsts': 'config', 'headers': 'config',
        'info_disclosure': 'info', 'debug': 'info', 'version': 'info',
        'csrf': 'csrf', 'xxe': 'injection', 'ssrf': 'ssrf',
        'graphql': 'injection', 'jwt': 'auth'
    }
    return categories.get(finding_type, 'other')