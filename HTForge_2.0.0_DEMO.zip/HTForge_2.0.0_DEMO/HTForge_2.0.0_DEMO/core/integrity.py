"""Signed package integrity verification. Detects modified application files."""
from __future__ import annotations
import base64, hashlib, json, os
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ROOT=Path(__file__).resolve().parent.parent
MANIFEST=ROOT/"security"/"manifest.json"
PUB=ROOT/"security"/"code_signing_public.pem"

class IntegrityError(RuntimeError): pass

def _digest_manifest(files: dict[str,str]) -> bytes:
    return json.dumps(files,sort_keys=True,separators=(",",":")).encode()

def verify_integrity() -> None:
    if os.getenv("HTFORGE_DEV_MODE")=="1": return
    try:
        obj=json.loads(MANIFEST.read_text())
        pub=serialization_public(PUB.read_bytes())
        sig=base64.b64decode(obj["signature"])
        files=obj["files"]
        pub.verify(sig,_digest_manifest(files))
        for rel,expected in files.items():
            p=ROOT/rel
            if not p.is_file(): raise IntegrityError(f"Archivo protegido ausente: {rel}")
            got=hashlib.sha256(p.read_bytes()).hexdigest()
            if got!=expected: raise IntegrityError(f"Integridad comprometida: {rel}")
    except IntegrityError: raise
    except Exception as e: raise IntegrityError("No se pudo verificar la integridad del paquete") from e

def serialization_public(data: bytes):
    from cryptography.hazmat.primitives import serialization
    return serialization.load_pem_public_key(data)
