"""HT Forge offline signed licensing and first-use activation.

The license is Ed25519-signed by the owner. Pro/Premium activate on the first
successful license check; expiry is calculated from that first activation.
"""
from __future__ import annotations
import base64, hashlib, json, os, platform, tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

EDITION = "DEMO"
DURATION_DAYS = 7
PUBLIC_KEY_B64 = "B7aJugldERbFSuOfn-xuC8Xym1KbTyl_wb9iF7bs3Qo"

RUNTIME = Path(os.getenv("HTFORGE_RUNTIME", str(Path.home()/".htforge")))
LICENSE_FILE = RUNTIME / "license.key"
ACTIVATION_FILE = RUNTIME / "activation.json"
CLOCK_FILE = RUNTIME / "clock_guard.json"

class LicenseError(RuntimeError): pass

def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def _payload_token(payload: dict[str, Any], sig: bytes) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=") + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")

def parse_token(token: str) -> tuple[dict[str, Any], bytes]:
    try:
        a,b = token.strip().split(".",1)
        return json.loads(_b64d(a)), _b64d(b)
    except Exception as e:
        raise LicenseError("Clave de licencia con formato inválido") from e

def _machine_id() -> str:
    # Stable, non-secret installation fingerprint; never sent anywhere.
    seed = f"{platform.system()}|{platform.machine()}|{platform.node()}|{os.getenv('USER','')}"
    return hashlib.sha256(seed.encode()).hexdigest()[:32]

def verify_token(token: str) -> dict[str, Any]:
    if not PUBLIC_KEY_B64:
        raise LicenseError("Clave pública de licencia no configurada")
    payload, sig = parse_token(token)
    pub = Ed25519PublicKey.from_public_bytes(_b64d(PUBLIC_KEY_B64))
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    try: pub.verify(sig, raw)
    except Exception as e: raise LicenseError("Firma de licencia no válida") from e
    if str(payload.get("edition","")).upper() != EDITION:
        raise LicenseError(f"La licencia no corresponde a HT Forge {EDITION}")
    if payload.get("product") != "HT Forge": raise LicenseError("Producto no válido")
    if payload.get("license_id") is None: raise LicenseError("Licencia incompleta")
    bound = payload.get("machine_id")
    if bound and bound != _machine_id(): raise LicenseError("La licencia está vinculada a otra máquina")
    return payload

def _read_json(path: Path) -> dict[str, Any]:
    try: return json.loads(path.read_text())
    except Exception: return {}

def _atomic_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(mode=0o700, exist_ok=True)
    fd,tmp = tempfile.mkstemp(prefix=path.name+".", dir=path.parent)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,"w") as f: json.dump(obj,f,sort_keys=True,separators=(",",":")); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def install_license(token: str) -> dict[str, Any]:
    payload = verify_token(token)
    RUNTIME.mkdir(mode=0o700, exist_ok=True)
    LICENSE_FILE.write_text(token.strip()); os.chmod(LICENSE_FILE,0o600)
    return status()

def _now() -> datetime: return datetime.now(timezone.utc)

def _check_clock(now: datetime) -> None:
    guard = _read_json(CLOCK_FILE)
    last = guard.get("last_seen")
    if last:
        try:
            prev=datetime.fromisoformat(last)
            if now + timedelta(minutes=5) < prev:
                raise LicenseError("Reloj del sistema retrocedido; licencia bloqueada por seguridad")
        except ValueError: pass
    _atomic_json(CLOCK_FILE,{"last_seen":now.isoformat()})

def status() -> dict[str, Any]:
    if not LICENSE_FILE.exists(): return {"valid":False,"reason":"license_required","edition":EDITION}
    payload=verify_token(LICENSE_FILE.read_text().strip())
    now=_now(); _check_clock(now)
    token_hash=hashlib.sha256(LICENSE_FILE.read_bytes()).hexdigest()
    act=_read_json(ACTIVATION_FILE)
    if not act:
        activated=now
        expires=activated+timedelta(days=DURATION_DAYS)
        act={"license_id":payload["license_id"],"token_sha256":token_hash,"activated_at":activated.isoformat(),"expires_at":expires.isoformat()}
        _atomic_json(ACTIVATION_FILE,act)
    else:
        if act.get("license_id") != payload.get("license_id") or act.get("token_sha256") != token_hash:
            raise LicenseError("La licencia local ha sido alterada")
    exp=datetime.fromisoformat(act["expires_at"])
    if now >= exp: raise LicenseError("Licencia expirada")
    return {"valid":True,"edition":EDITION,"license_id":payload["license_id"],"activated_at":act["activated_at"],"expires_at":act["expires_at"],"days_left":max(0,(exp-now).days)}

def require_license() -> dict[str, Any]:
    result = status()
    if not result.get("valid"):
        raise LicenseError("Licencia requerida")
    return result

def license_status() -> dict[str, Any]:
    try: return status()
    except LicenseError as e: return {"valid":False,"edition":EDITION,"reason":str(e)}
