"""Small local forward-proxy bridge for authorized HTTP workbench sessions.

HTTP requests are forwarded and recorded. HTTPS CONNECT is supported as a
transparent tunnel; TLS interception/decryption is intentionally not enabled.
"""
from __future__ import annotations

import http.client
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


class ProxyRecorder:
    def __init__(self, max_items: int = 500):
        self.max_items = max_items
        self._lock = threading.RLock()
        self.items = []

    def add(self, item):
        with self._lock:
            self.items.insert(0, item)
            del self.items[self.max_items:]

    def list(self):
        with self._lock:
            return list(self.items)


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        return

    def _forward(self):
        started = time.monotonic()
        target = self.path
        parsed = urlsplit(target)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            self.send_error(400, "Proxy requiere URL absoluta HTTP/HTTPS")
            return
        if parsed.scheme == "https":
            self.send_error(400, "Use CONNECT para HTTPS")
            return
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        headers = {k: v for k, v in self.headers.items() if k.lower() not in {"proxy-connection", "connection"}}
        length = int(self.headers.get("Content-Length", "0") or 0)
        body = self.rfile.read(length) if length else None
        try:
            conn = http.client.HTTPConnection(parsed.netloc, timeout=20)
            conn.request(self.command, path, body=body, headers=headers)
            resp = conn.getresponse()
            data = resp.read(1_000_000)
            self.send_response(resp.status, resp.reason)
            for k, v in resp.getheaders():
                if k.lower() not in {"connection", "transfer-encoding", "content-length"}:
                    self.send_header(k, v)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            self.server.recorder.add({"method": self.command, "url": target, "status": resp.status,
                                      "duration_ms": int((time.monotonic()-started)*1000),
                                      "request_bytes": len(body or b""), "response_bytes": len(data)})
            conn.close()
        except Exception as exc:
            self.server.recorder.add({"method": self.command, "url": target, "error": str(exc),
                                      "duration_ms": int((time.monotonic()-started)*1000)})
            self.send_error(502, str(exc))

    def do_CONNECT(self):
        host, sep, port = self.path.partition(":")
        try:
            port = int(port or 443)
            upstream = __import__("socket").create_connection((host, port), timeout=20)
            self.send_response(200, "Connection Established")
            self.end_headers()
            self.connection.setblocking(False)
            upstream.setblocking(False)
            import select
            sockets = [self.connection, upstream]
            started = time.monotonic()
            while True:
                readable, _, _ = select.select(sockets, [], [], 30)
                if not readable:
                    break
                closed = False
                for sock in readable:
                    try:
                        data = sock.recv(65536)
                    except BlockingIOError:
                        continue
                    if not data:
                        closed = True
                        break
                    (upstream if sock is self.connection else self.connection).sendall(data)
                if closed:
                    break
            upstream.close()
            self.server.recorder.add({"method": "CONNECT", "url": self.path,
                                      "status": 200, "duration_ms": int((time.monotonic()-started)*1000),
                                      "mode": "tunnel"})
        except Exception as exc:
            self.server.recorder.add({"method": "CONNECT", "url": self.path, "error": str(exc)})
            try:
                self.send_error(502, str(exc))
            except Exception:
                pass

    do_GET = _forward
    do_POST = _forward
    do_PUT = _forward
    do_PATCH = _forward
    do_DELETE = _forward
    do_OPTIONS = _forward


class LocalProxy:
    """Start/stop a local HTTP forward proxy with a request recorder."""
    def __init__(self, host="127.0.0.1", port=0):
        self.host, self.port = host, int(port)
        self.recorder = ProxyRecorder()
        self.server = ThreadingHTTPServer((host, self.port), _Handler)
        self.server.recorder = self.recorder
        self.thread = None

    @property
    def address(self):
        return self.server.server_address

    def start(self):
        if self.thread and self.thread.is_alive():
            return self.address
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self.address

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
