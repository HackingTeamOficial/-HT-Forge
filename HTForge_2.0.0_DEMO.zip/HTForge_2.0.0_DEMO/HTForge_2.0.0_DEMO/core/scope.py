#!/usr/bin/env python3
"""core/scope.py - Scope Guard para HT Forge

Valida que todas las operaciones se mantengan dentro del alcance autorizado.
"""

from typing import Dict, Any, List, Optional, Set, Pattern
from dataclasses import dataclass, field
from urllib.parse import urlparse
import re
import ipaddress


@dataclass
class ScopeRule:
    """Regla de alcance individual"""
    type: str  # domain, ip, cidr, regex, path
    value: str
    allow: bool = True  # True = allow, False = deny
    description: str = ""
    
    def matches(self, target: str) -> bool:
        """Verifica si el target coincide con esta regla"""
        if self.type == 'domain':
            return self._match_domain(target)
        elif self.type == 'ip':
            return self._match_ip(target)
        elif self.type == 'cidr':
            return self._match_cidr(target)
        elif self.type == 'regex':
            return self._match_regex(target)
        elif self.type == 'path':
            return self._match_path(target)
        return False
    
    def _match_domain(self, target: str) -> bool:
        """Coincidencia de dominio (incluye subdominios)"""
        parsed = urlparse(target if '://' in target else 'http://' + target)
        host = parsed.netloc.lower()
        rule_domain = self.value.lower()
        
        # Exact match or subdomain
        return host == rule_domain or host.endswith('.' + rule_domain)
    
    def _match_ip(self, target: str) -> bool:
        """Coincidencia de IP exacta"""
        parsed = urlparse(target if '://' in target else 'http://' + target)
        host = parsed.netloc.split(':')[0]
        return host == self.value
    
    def _match_cidr(self, target: str) -> bool:
        """Coincidencia de rango CIDR"""
        try:
            parsed = urlparse(target if '://' in target else 'http://' + target)
            host = parsed.netloc.split(':')[0]
            ip = ipaddress.ip_address(host)
            network = ipaddress.ip_network(self.value, strict=False)
            return ip in network
        except ValueError:
            return False
    
    def _match_regex(self, target: str) -> bool:
        """Coincidencia por regex"""
        try:
            pattern = re.compile(self.value)
            return bool(pattern.search(target))
        except re.error:
            return False
    
    def _match_path(self, target: str) -> bool:
        """Coincidencia de path"""
        parsed = urlparse(target if '://' in target else 'http://' + target)
        return parsed.path.startswith(self.value)


@dataclass
class Scope:
    """Definición completa de alcance"""
    name: str
    description: str = ""
    rules: List[ScopeRule] = field(default_factory=list)
    default_deny: bool = True  # Denegar por defecto lo no explícito
    
    def __post_init__(self):
        # Ordenar: deny rules first, then allow rules
        self.rules.sort(key=lambda r: (r.allow, 0))  # False (deny) first
    
    def check(self, target: str) -> Dict[str, Any]:
        """
        Verifica si un target está dentro del alcance.
        Returns: {'allowed': bool, 'matched_rules': [], 'reason': str}
        """
        matched = []
        
        for rule in self.rules:
            if rule.matches(target):
                matched.append({
                    'rule': rule,
                    'allow': rule.allow
                })
        
        if not matched:
            return {
                'allowed': not self.default_deny,
                'matched_rules': [],
                'reason': 'No matching rules' + (' - default allow' if not self.default_deny else ' - default deny')
            }
        
        # SEGURIDAD: si alguna regla deny coincide, se deniega (deny gana sobre allow)
        denies = [m for m in matched if not m['allow']]
        if denies:
            last_deny = denies[-1]
            return {
                'allowed': False,
                'matched_rules': matched,
                'reason': f"DENY por regla {last_deny['rule'].type}={last_deny['rule'].value}"
            }
        
        # Solo quedan allows
        last_match = matched[-1]
        return {
            'allowed': True,
            'matched_rules': matched,
            'reason': f"ALLOW por regla {last_match['rule'].type}={last_match['rule'].value}"
        }
    
    def add_allow(self, rule_type: str, value: str, description: str = ""):
        self.rules.append(ScopeRule(type=rule_type, value=value, allow=True, description=description))
        self.__post_init__()
    
    def add_deny(self, rule_type: str, value: str, description: str = ""):
        self.rules.append(ScopeRule(type=rule_type, value=value, allow=False, description=description))
        self.__post_init__()


class ScopeGuard:
    """Guardián de alcance - valida todas las operaciones"""
    
    def __init__(self, scope: Scope):
        self.scope = scope
        self.violations: List[Dict[str, Any]] = []
        self.checks: List[Dict[str, Any]] = []
    
    def check_target(self, target: str, context: str = "") -> bool:
        """Verifica un target y registra el resultado"""
        result = self.scope.check(target)
        
        check_record = {
            'target': target,
            'context': context,
            'allowed': result['allowed'],
            'reason': result['reason'],
            'matched_rules': len(result['matched_rules'])
        }
        self.checks.append(check_record)
        
        if not result['allowed']:
            violation = {
                'target': target,
                'context': context,
                'reason': result['reason'],
                'matched_rules': [str(r['rule'].value) for r in result['matched_rules']]
            }
            self.violations.append(violation)
            return False
        
        return True
    
    def check_url(self, url: str, context: str = "") -> bool:
        """Verifica una URL completa"""
        return self.check_target(url, context)
    
    def check_domain(self, domain: str, context: str = "") -> bool:
        """Verifica un dominio"""
        return self.check_target(domain, context)
    
    def check_ip(self, ip: str, context: str = "") -> bool:
        """Verifica una IP"""
        return self.check_target(ip, context)
    
    def get_violations(self) -> List[Dict[str, Any]]:
        return self.violations
    
    def get_checks(self) -> List[Dict[str, Any]]:
        return self.checks
    
    def get_summary(self) -> Dict[str, Any]:
        total = len(self.checks)
        allowed = sum(1 for c in self.checks if c['allowed'])
        denied = total - allowed
        return {
            'total_checks': total,
            'allowed': allowed,
            'denied': denied,
            'violations': len(self.violations),
            'violation_details': self.violations
        }
    
    def reset(self):
        self.violations.clear()
        self.checks.clear()


# Scopes predefinidos comunes
def create_bugbounty_scope(program_name: str, domains: List[str], 
                          wildcards: bool = True, 
                          extra_deny: List[str] = None) -> Scope:
    """Crea scope típico para bug bounty"""
    scope = Scope(
        name=f"BugBounty: {program_name}",
        description=f"Scope autorizado para {program_name}"
    )
    
    for domain in domains:
        scope.add_allow('domain', domain, f"Dominio principal: {domain}")
        if wildcards:
            scope.add_allow('domain', '*.' + domain, f"Subdominios de {domain}")
    
    # Denegar comúnmente fuera de scope
    deny_list = extra_deny or []
    deny_list.extend([
        'api.github.com',
        'accounts.google.com',
        'login.microsoftonline.com',
        '*.cloudflare.com',
        '*.akamai.net',
        '*.fastly.net'
    ])
    
    for d in deny_list:
        scope.add_deny('domain', d, "Servicio tercero conocido")
    
    return scope


def create_web_audit_scope(target_url: str, 
                          include_subdomains: bool = True,
                          allowed_paths: List[str] = None,
                          denied_paths: List[str] = None) -> Scope:
    """Crea scope para auditoría web"""
    parsed = urlparse(target_url)
    domain = parsed.netloc
    
    scope = Scope(
        name=f"WebAudit: {domain}",
        description=f"Auditoría web autorizada para {target_url}"
    )
    
    scope.add_allow('domain', domain, "Dominio objetivo")
    if include_subdomains:
        scope.add_allow('domain', '*.' + domain, "Subdominios")
    
    # Paths permitidos
    for path in (allowed_paths or ['/']):
        scope.add_allow('path', path, f"Path permitido: {path}")
    
    # Paths denegados (logout, delete, admin actions, etc.)
    default_deny = ['/logout', '/delete', '/remove', '/destroy', '/admin/delete', 
                   '/api/delete', '/account/delete', '/user/delete']
    for path in denied_paths or default_deny:
        scope.add_deny('path', path, f"Path destructivo: {path}")
    
    return scope


def create_network_scope(cidrs: List[str], description: str = "") -> Scope:
    """Crea scope para auditoría de red"""
    scope = Scope(
        name="NetworkAudit",
        description=description or "Auditoría de red autorizada"
    )
    
    for cidr in cidrs:
        scope.add_allow('cidr', cidr, f"Rango: {cidr}")
    
    return scope