"""HT Forge PREMIUM Workbench.

Manual, authorized HTTP testing primitives: repeater, response diff, intruder/fuzzer,
OpenAPI inventory, WebSocket client, workspace state and extension registry.
"""
from __future__ import annotations

import copy
import json
import threading
import time
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .http_client import HTTPClient

MAX_HISTORY = 500
MAX_FUZZ_CASES = 200
MAX_BODY = 1_000_000
RUNTIME = Path(__file__).resolve().parent.parent / "runtime"
WORKSPACE_FILE = RUNTIME / "workbench.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_url(url: str) -> str:
    p = urlsplit(url)
    return urlunsplit((p.scheme, p.netloc, p.path, p.query, ""))


def _headers(value: Any) -> Dict[str, str]:
    return {str(k): str(v) for k, v in (value or {}).items()}


@dataclass
class HTTPExchange:
    id: str
    created_at: str
    method: str
    url: str
    request_headers: Dict[str, str]
    request_body: str
    status: Optional[int] = None
    response_headers: Dict[str, str] = None
    response_body: str = ""
    duration_ms: int = 0
    error: Optional[str] = None
    source: str = "manual"
    request_size: int = 0
    response_size: int = 0

    def __post_init__(self):
        self.response_headers = self.response_headers or {}


class Workbench:
    def __init__(self, workspace_file: Optional[str] = None):
        self._lock = threading.RLock()
        self.history: List[HTTPExchange] = []
        self.fuzz_jobs: Dict[str, Dict[str, Any]] = {}
        self.extensions: Dict[str, Dict[str, Any]] = {}
        self.workspace_file = Path(workspace_file) if workspace_file else WORKSPACE_FILE
        self.workspace: Dict[str, Any] = {"name": "HT Forge PREMIUM Workspace", "targets": [], "notes": ""}
        self._load_workspace()
        self._register_builtin_extensions()

    def _load_workspace(self):
        try:
            if self.workspace_file.exists():
                data = json.loads(self.workspace_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self.workspace.update(data)
        except Exception:
            pass

    def _save_workspace(self):
        self.workspace_file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.workspace_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.workspace, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.workspace_file)

    def _register_builtin_extensions(self):
        builtins = [
            ("repeater", "Manual HTTP request/response testing", "core"),
            ("intruder", "Controlled parameter fuzzing", "core"),
            ("api_openapi", "OpenAPI/Swagger endpoint inventory", "api"),
            ("websocket", "WebSocket request/response client", "protocol"),
            ("response_diff", "Baseline/differential response comparison", "analysis"),
            ("workspace", "Persistent target and testing workspace", "core"),
        ]
        for name, desc, category in builtins:
            self.extensions[name] = {"version": "2.0.0", "description": desc, "category": category, "status": "builtin"}

    # ---- history / repeater -------------------------------------------------
    def _add_history(self, exchange: HTTPExchange):
        with self._lock:
            self.history.insert(0, exchange)
            del self.history[MAX_HISTORY:]
        return exchange

    def list_history(self, limit=100):
        with self._lock:
            return [asdict(x) for x in self.history[:max(1, min(int(limit), MAX_HISTORY))]]

    def get_history(self, exchange_id):
        with self._lock:
            for x in self.history:
                if x.id == exchange_id:
                    return asdict(x)
        return None

    def clear_history(self):
        with self._lock:
            self.history.clear()

    def send(self, request: Dict[str, Any], source="repeater"):
        method = str(request.get("method", "GET")).upper().strip()
        url = str(request.get("url", "")).strip()
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
            raise ValueError("Método HTTP no permitido en Workbench")
        if not url or urlsplit(url).scheme not in {"http", "https"}:
            raise ValueError("URL HTTP/HTTPS requerida")
        headers = _headers(request.get("headers"))
        body = request.get("body", "")
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        body = str(body or "")
        timeout = request.get("timeout", 30)
        verify = bool(request.get("verify_ssl", False))
        redirects = bool(request.get("allow_redirects", False))
        started = time.monotonic()
        client = HTTPClient({"timeout": timeout, "verify_ssl": verify, "allow_redirects": redirects})
        exchange = HTTPExchange(
            str(uuid.uuid4())[:12], _now(), method, _safe_url(url), headers, body,
            request_size=len(body.encode("utf-8", "ignore"))
        )
        try:
            resp = client.request(method, url, headers=headers, data=body if body else None,
                                  timeout=timeout, verify=verify, allow_redirects=redirects)
            text = resp.text[:MAX_BODY]
            exchange.status = getattr(resp, "status_code", None)
            exchange.response_headers = _headers(getattr(resp, "headers", {}))
            exchange.response_body = text
            exchange.response_size = len(text.encode("utf-8", "ignore"))
        except Exception as exc:
            exchange.error = str(exc)
        finally:
            exchange.duration_ms = int((time.monotonic() - started) * 1000)
            try:
                client.close()
            except Exception:
                pass
        return asdict(self._add_history(exchange))

    def diff(self, left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
        """Return a deterministic, privacy-preserving response comparison."""
        a = str(left.get("response_body", ""))
        b = str(right.get("response_body", ""))
        ah, bh = _headers(left.get("response_headers")), _headers(right.get("response_headers"))
        changed_headers = sorted(set(ah) | set(bh))
        changed_headers = [k for k in changed_headers if ah.get(k) != bh.get(k)]
        prefix = 0
        for ca, cb in zip(a, b):
            if ca != cb:
                break
            prefix += 1
        return {
            "same_status": left.get("status") == right.get("status"),
            "status_left": left.get("status"), "status_right": right.get("status"),
            "body_length_left": len(a), "body_length_right": len(b),
            "body_length_delta": len(b) - len(a),
            "changed_headers": changed_headers,
            "first_body_difference": prefix if a != b else None,
            "body_changed": a != b,
        }

    # ---- intruder / fuzzer --------------------------------------------------
    def start_fuzz(self, request, position, payloads, workers=4):
        """Start a bounded Intruder job. Validate the base request before spawning threads.

        A malformed/empty URL used to surface as an uncaught exception inside a
        worker thread. That made the GUI look like the scanner itself had crashed.
        Validation is now synchronous and every individual fuzz case is also
        guarded so one bad case cannot kill the worker thread.
        """
        request = copy.deepcopy(request or {})
        method = str(request.get("method", "GET")).upper().strip()
        url = str(request.get("url", "")).strip()
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
            raise ValueError("Método HTTP no permitido en Intruder")
        if not url or urlsplit(url).scheme not in {"http", "https"} or not urlsplit(url).netloc:
            raise ValueError("Intruder requiere una URL HTTP/HTTPS válida en Request Builder")
        payloads = [str(x) for x in payloads][:MAX_FUZZ_CASES]
        if not payloads:
            raise ValueError("Payloads requeridos")
        if position not in {"url", "query", "body", "header"}:
            raise ValueError("position debe ser url, query, body o header")
        workers = max(1, min(int(workers), 8))
        jid = str(uuid.uuid4())[:12]
        job = {"id": jid, "status": "running", "total": len(payloads), "completed": 0,
               "results": [], "started_at": _now(), "error": None}
        with self._lock:
            self.fuzz_jobs[jid] = job

        def worker():
            results: List[Dict[str, Any]] = []
            sem = threading.Semaphore(workers)

            def one(payload):
                with sem:
                    req = copy.deepcopy(request)
                    marker = "FUZZ"
                    if position == "url":
                        req["url"] = str(req.get("url", "")).replace(marker, payload)
                    elif position == "query":
                        p = urlsplit(str(req.get("url", "")))
                        q = [(k, payload if v == marker else v) for k, v in parse_qsl(p.query, keep_blank_values=True)]
                        req["url"] = urlunsplit((p.scheme, p.netloc, p.path, urlencode(q), p.fragment))
                    elif position == "body":
                        req["body"] = str(req.get("body", "")).replace(marker, payload)
                    else:
                        req["headers"] = {k: str(v).replace(marker, payload) for k, v in _headers(req.get("headers")).items()}
                    try:
                        result = self.send(req, "intruder")
                    except Exception as exc:
                        # Keep the fuzz job alive and expose a structured error
                        # instead of leaking an exception from a background thread.
                        result = {
                            "id": str(uuid.uuid4())[:12],
                            "created_at": _now(),
                            "method": method,
                            "url": _safe_url(str(req.get("url", ""))),
                            "status": None,
                            "response_headers": {},
                            "response_body": "",
                            "duration_ms": 0,
                            "error": str(exc),
                            "source": "intruder",
                            "request_size": 0,
                            "response_size": 0,
                        }
                    result["payload"] = payload
                    results.append(result)
                    with self._lock:
                        job["completed"] += 1
                        job["results"] = list(results)[-MAX_FUZZ_CASES:]

            threads = [threading.Thread(target=one, args=(payload,), daemon=True) for payload in payloads]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            with self._lock:
                job["status"] = "completed"
                job["ended_at"] = _now()
                job["errors"] = sum(1 for r in job.get("results", []) if r.get("error"))

        threading.Thread(target=worker, daemon=True).start()
        return {"id": jid, "status": "running", "total": len(payloads)}

    def get_fuzz(self, jid):
        with self._lock:
            return copy.deepcopy(self.fuzz_jobs.get(jid))

    # ---- workspace ----------------------------------------------------------
    def get_workspace(self):
        with self._lock:
            return copy.deepcopy(self.workspace)

    def update_workspace(self, data: Dict[str, Any]):
        with self._lock:
            if "name" in data:
                self.workspace["name"] = str(data["name"])[:120]
            if "notes" in data:
                self.workspace["notes"] = str(data["notes"])[:20000]
            if "targets" in data and isinstance(data["targets"], list):
                self.workspace["targets"] = [str(x)[:2048] for x in data["targets"][:500]]
            self._save_workspace()
            return copy.deepcopy(self.workspace)

    def add_target(self, target: str):
        target = str(target).strip()
        if not target or urlsplit(target).scheme not in {"http", "https"}:
            raise ValueError("Target HTTP/HTTPS requerido")
        with self._lock:
            targets = self.workspace.setdefault("targets", [])
            if target not in targets:
                targets.insert(0, target)
                del targets[500:]
            self._save_workspace()
            return copy.deepcopy(self.workspace)

    # ---- OpenAPI ------------------------------------------------------------
    def import_openapi(self, document: Any) -> Dict[str, Any]:
        if isinstance(document, str):
            text = document.strip()
            try:
                spec = json.loads(text)
            except json.JSONDecodeError:
                try:
                    import yaml
                    spec = yaml.safe_load(text)
                except Exception as exc:
                    raise ValueError(f"OpenAPI JSON/YAML inválido: {exc}")
        elif isinstance(document, dict):
            spec = document
        else:
            raise ValueError("Documento OpenAPI inválido")
        if not isinstance(spec, dict) or not (spec.get("openapi") or spec.get("swagger")):
            raise ValueError("No parece un documento OpenAPI/Swagger")
        base = ""
        servers = spec.get("servers") or []
        if servers and isinstance(servers[0], dict):
            base = str(servers[0].get("url", ""))
        paths = []
        for path, item in (spec.get("paths") or {}).items():
            if not isinstance(item, dict):
                continue
            for method, operation in item.items():
                if method.lower() not in {"get", "post", "put", "patch", "delete", "head", "options"}:
                    continue
                operation = operation if isinstance(operation, dict) else {}
                paths.append({"method": method.upper(), "path": str(path),
                              "operation_id": operation.get("operationId", ""),
                              "summary": operation.get("summary", "")})
        result = {"version": spec.get("openapi") or spec.get("swagger"), "base_url": base,
                  "title": ((spec.get("info") or {}).get("title", "")), "endpoints": paths}
        with self._lock:
            self.workspace["openapi"] = result
            self._save_workspace()
        return result

    # ---- WebSocket ----------------------------------------------------------
    def websocket_send(self, url: str, message: str, timeout: float = 10, verify_ssl: bool = False) -> Dict[str, Any]:
        if not url.startswith(("ws://", "wss://")):
            raise ValueError("URL ws:// o wss:// requerida")
        try:
            import websocket
        except ImportError as exc:
            raise RuntimeError("WebSocket requiere la dependencia opcional websocket-client") from exc
        started = time.monotonic()
        try:
            ws = websocket.create_connection(url, timeout=float(timeout), sslopt={"cert_reqs": 0} if not verify_ssl else {})
            ws.send(str(message))
            response = ws.recv()
            ws.close()
            return {"ok": True, "url": url, "message": str(message), "response": str(response)[:MAX_BODY],
                    "duration_ms": int((time.monotonic() - started) * 1000)}
        except Exception as exc:
            return {"ok": False, "url": url, "message": str(message), "error": str(exc),
                    "duration_ms": int((time.monotonic() - started) * 1000)}

    def list_extensions(self):
        with self._lock:
            return [{"name": n, **m} for n, m in sorted(self.extensions.items())]


_workbench = None

def get_workbench():
    global _workbench
    if _workbench is None:
        _workbench = Workbench()
    return _workbench
