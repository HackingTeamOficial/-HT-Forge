#!/usr/bin/env python3
"""core/scoring.py - Motor de scoring de riesgo para hallazgos"""

from typing import Dict, Any, List
import re


class RiskScorer:
    """Calcula score de riesgo (0-10) para cada hallazgo"""
    
    # Pesos base por severidad
    SEVERITY_WEIGHTS = {
        'critical': 9.0,
        'high': 7.0,
        'medium': 5.0,
        'low': 3.0,
        'info': 1.0,
    }
    
    # Multiplicadores por tipo de vulnerabilidad
    VULN_MULTIPLIERS = {
        'sqli': 1.3,
        'rce': 1.4,
        'lfi': 1.1,
        'rfi': 1.2,
        'xxe': 1.2,
        'xss': 1.0,
        'idor': 0.9,
        'csrf': 0.8,
        'cors': 0.7,
        'jwt': 1.1,
        'ssrf': 1.2,
        'ssti': 1.2,
        'deserialization': 1.3,
    }
    
    # Factores contextuales
    CONTEXT_FACTORS = {
        'authenticated': 1.2,
        'admin_panel': 1.3,
        'api_endpoint': 1.1,
        'public_exploit': 1.4,
        'waf_bypass': 1.2,
        'chained': 1.3,
    }
    
    def score(self, finding: Dict) -> float:
        """Calcula score final 0-10"""
        # Severidad base
        severity = finding.get('severity', 'info').lower()
        base = self.SEVERITY_WEIGHTS.get(severity, 1.0)
        
        # Tipo de vulnerabilidad
        vuln_type = finding.get('type', '').lower()
        for vtype, mult in self.VULN_MULTIPLIERS.items():
            if vtype in vuln_type or vtype in finding.get('module', '').lower():
                base *= mult
                break
        
        # Confianza (0-100) - reduce score si confianza es baja
        confidence = finding.get('confidence', 100)
        try:
            conf = float(confidence)
            # Factor de confianza: 0.5 a 1.0 (50% = 0.5, 100% = 1.0)
            conf_factor = max(0.5, conf / 100.0)
            base *= conf_factor
        except (ValueError, TypeError):
            pass
        
        # Factores contextuales
        detail = str(finding.get('detail', '')).lower()
        evidence = str(finding.get('evidence', '')).lower()
        combined = detail + ' ' + evidence
        
        for factor, mult in self.CONTEXT_FACTORS.items():
            if factor in combined:
                base *= mult
        
        # CVSS si está disponible
        cvss = finding.get('cvss')
        if cvss:
            try:
                cvss_val = float(cvss)
                base = max(base, cvss_val)
            except (ValueError, TypeError):
                pass
        
        # Clampear 0-10
        return round(min(max(base, 0.0), 10.0), 1)
    
    def score_batch(self, findings: List[Dict]) -> List[Dict]:
        """Scorea lista de hallazgos y los ordena por riesgo"""
        for f in findings:
            f['scored'] = self.score(f)
        return sorted(findings, key=lambda x: x.get('scored', 0), reverse=True)
    
    def get_risk_level(self, score: float) -> str:
        """Convierte score a nivel de riesgo"""
        if score >= 9.0:
            return 'CRITICAL'
        elif score >= 7.0:
            return 'HIGH'
        elif score >= 5.0:
            return 'MEDIUM'
        elif score >= 3.0:
            return 'LOW'
        return 'INFO'