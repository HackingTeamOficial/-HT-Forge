#!/usr/bin/env python3
"""core/assets.py - Asset Intelligence para HT Forge

Construye automáticamente un inventario de activos y los relaciona.
"""

from typing import Dict, Any, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict
import json


@dataclass
class Asset:
    """Representa un activo en el inventario"""
    id: str
    type: str  # domain, subdomain, ip, port, service, technology, endpoint, finding
    value: str
    parent_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    discovered_at: datetime = field(default_factory=datetime.now)
    discovered_by: str = ""
    confidence: float = 1.0
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'type': self.type,
            'value': self.value,
            'parent_id': self.parent_id,
            'metadata': self.metadata,
            'discovered_at': self.discovered_at.isoformat(),
            'discovered_by': self.discovered_by,
            'confidence': self.confidence,
            'tags': self.tags
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Asset':
        data = data.copy()
        data['discovered_at'] = datetime.fromisoformat(data['discovered_at'])
        return cls(**data)


class AssetGraph:
    """Grafo de activos con relaciones padre-hijo"""
    
    def __init__(self):
        self.assets: Dict[str, Asset] = {}
        self.children: Dict[str, Set[str]] = defaultdict(set)
        self.by_type: Dict[str, Set[str]] = defaultdict(set)
        self.by_value: Dict[str, Set[str]] = defaultdict(set)
    
    def add(self, asset: Asset) -> str:
        """Añade un activo al grafo"""
        if asset.id in self.assets:
            # Actualizar existente
            existing = self.assets[asset.id]
            existing.metadata.update(asset.metadata)
            existing.confidence = max(existing.confidence, asset.confidence)
            existing.tags = list(set(existing.tags + asset.tags))
            return asset.id
        
        self.assets[asset.id] = asset
        self.by_type[asset.type].add(asset.id)
        self.by_value[asset.value].add(asset.id)
        
        if asset.parent_id:
            self.children[asset.parent_id].add(asset.id)
        
        return asset.id
    
    def get(self, asset_id: str) -> Optional[Asset]:
        return self.assets.get(asset_id)
    
    def get_children(self, asset_id: str) -> List[Asset]:
        return [self.assets[cid] for cid in self.children.get(asset_id, set()) if cid in self.assets]
    
    def get_by_type(self, asset_type: str) -> List[Asset]:
        return [self.assets[aid] for aid in self.by_type.get(asset_type, set())]
    
    def get_by_value(self, value: str) -> List[Asset]:
        return [self.assets[aid] for aid in self.by_value.get(value, set())]
    
    def get_tree(self, root_id: Optional[str] = None, max_depth: int = 10) -> Dict[str, Any]:
        """Obtiene el árbol de activos desde una raíz"""
        def build_node(aid: str, depth: int) -> Dict[str, Any]:
            if depth > max_depth:
                return {'id': aid, 'truncated': True}
            
            asset = self.assets.get(aid)
            if not asset:
                return {'id': aid, 'error': 'not_found'}
            
            node = asset.to_dict()
            children = self.get_children(aid)
            if children:
                node['children'] = [build_node(c.id, depth + 1) for c in children]
            return node
        
        if root_id:
            return build_node(root_id, 0)
        
        # Raíces (activos sin padre)
        roots = [aid for aid, a in self.assets.items() if not a.parent_id]
        return [build_node(r, 0) for r in roots]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'assets': {aid: a.to_dict() for aid, a in self.assets.items()},
            'children': {k: list(v) for k, v in self.children.items()}
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AssetGraph':
        graph = cls()
        for aid, adata in data.get('assets', {}).items():
            graph.assets[aid] = Asset.from_dict(adata)
            graph.by_type[adata['type']].add(aid)
            graph.by_value[adata['value']].add(aid)
        for parent, children in data.get('children', {}).items():
            graph.children[parent] = set(children)
        return graph


class AssetIntelligence:
    """Motor de inteligencia de activos - construye y mantiene el inventario"""
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.graph = AssetGraph()
        self.target_root_id = None
    
    def initialize_target(self, target: str) -> str:
        """Inicializa el target raíz"""
        # Normalizar target
        if target.startswith(('http://', 'https://')):
            from urllib.parse import urlparse
            parsed = urlparse(target)
            domain = parsed.netloc
        else:
            domain = target
        
        root_id = f"target_{self.session_id}"
        root = Asset(
            id=root_id,
            type='target',
            value=target,
            metadata={'original': target, 'domain': domain},
            discovered_by='user',
            tags=['root', 'scope']
        )
        self.graph.add(root)
        self.target_root_id = root_id
        return root_id
    
    def add_domain(self, domain: str, parent_id: Optional[str] = None, discovered_by: str = "") -> str:
        """Añade un dominio/subdominio"""
        asset_id = f"domain_{hash(domain) % 1000000}"
        asset = Asset(
            id=asset_id,
            type='subdomain' if parent_id else 'domain',
            value=domain,
            parent_id=parent_id or self.target_root_id,
            discovered_by=discovered_by,
            tags=['scope']
        )
        return self.graph.add(asset)
    
    def add_ip(self, ip: str, domain_id: str, discovered_by: str = "") -> str:
        """Añade una IP asociada a un dominio"""
        asset_id = f"ip_{hash(ip) % 1000000}"
        asset = Asset(
            id=asset_id,
            type='ip',
            value=ip,
            parent_id=domain_id,
            discovered_by=discovered_by,
            tags=['resolved']
        )
        return self.graph.add(asset)
    
    def add_port(self, port: int, protocol: str, service: str, ip_id: str, discovered_by: str = "") -> str:
        """Añade un puerto/servicio"""
        asset_id = f"port_{ip_id}_{port}_{protocol}"
        asset = Asset(
            id=asset_id,
            type='port',
            value=f"{port}/{protocol}",
            parent_id=ip_id,
            metadata={'port': port, 'protocol': protocol, 'service': service},
            discovered_by=discovered_by
        )
        return self.graph.add(asset)
    
    def add_service(self, name: str, version: str, port_id: str, discovered_by: str = "") -> str:
        """Añade detalle de servicio"""
        asset_id = f"service_{hash(name) % 1000000}_{port_id}"
        asset = Asset(
            id=asset_id,
            type='service',
            value=name,
            parent_id=port_id,
            metadata={'name': name, 'version': version},
            discovered_by=discovered_by
        )
        return self.graph.add(asset)
    
    def add_technology(self, tech: str, category: str, endpoint_id: Optional[str] = None, discovered_by: str = "") -> str:
        """Añade tecnología detectada"""
        asset_id = f"tech_{hash(tech) % 1000000}"
        asset = Asset(
            id=asset_id,
            type='technology',
            value=tech,
            parent_id=endpoint_id or self.target_root_id,
            metadata={'category': category},
            discovered_by=discovered_by,
            tags=['fingerprint']
        )
        return self.graph.add(asset)
    
    def add_endpoint(self, url: str, method: str, path: str, domain_id: str, discovered_by: str = "") -> str:
        """Añade endpoint descubierto"""
        from urllib.parse import urlparse
        parsed = urlparse(url)
        asset_id = f"endpoint_{hash(url) % 1000000}"
        asset = Asset(
            id=asset_id,
            type='endpoint',
            value=url,
            parent_id=domain_id,
            metadata={'method': method, 'path': path, 'url': url, 'host': parsed.netloc},
            discovered_by=discovered_by,
            tags=['discovered']
        )
        return self.graph.add(asset)
    
    def add_finding(self, finding: Dict[str, Any], parent_id: Optional[str] = None, discovered_by: str = "") -> str:
        """Añade hallazgo vinculado a un activo"""
        asset_id = f"finding_{hash(str(finding)) % 1000000}"
        asset = Asset(
            id=asset_id,
            type='finding',
            value=finding.get('title', finding.get('type', 'unknown')),
            parent_id=parent_id or self.target_root_id,
            metadata=finding,
            discovered_by=discovered_by,
            confidence=finding.get('confidence', 1.0),
            tags=['finding', finding.get('severity', 'info').lower()]
        )
        return self.graph.add(asset)
    
    def get_summary(self) -> Dict[str, Any]:
        """Resumen del inventario"""
        return {
            'total_assets': len(self.graph.assets),
            'by_type': {t: len(ids) for t, ids in self.graph.by_type.items()},
            'tree': self.graph.get_tree(self.target_root_id)
        }
    
    def export_json(self) -> str:
        return json.dumps(self.graph.to_dict(), indent=2)
    
    def link_finding_to_endpoint(self, finding_id: str, endpoint_id: str):
        """Vincula un hallazgo a un endpoint (actualiza parent)"""
        if finding_id in self.graph.assets:
            finding = self.graph.assets[finding_id]
            old_parent = finding.parent_id
            if old_parent and old_parent in self.graph.children:
                self.graph.children[old_parent].discard(finding_id)
            finding.parent_id = endpoint_id
            self.graph.children[endpoint_id].add(finding_id)


# Funciones de conveniencia
def create_asset_intelligence(session_id: str, target: str) -> AssetIntelligence:
    """Crea e inicializa AssetIntelligence para una sesión"""
    ai = AssetIntelligence(session_id)
    ai.initialize_target(target)
    return ai