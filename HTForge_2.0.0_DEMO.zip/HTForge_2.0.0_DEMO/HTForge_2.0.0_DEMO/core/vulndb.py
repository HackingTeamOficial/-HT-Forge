#!/usr/bin/env python3
"""core/vulndb.py - Base de datos de vulnerabilidades conocidas"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class VulnEntry:
    """Entrada de vulnerabilidad conocida"""
    id: str
    title: str
    description: str
    severity: str
    cvss: Optional[float]
    cwe: Optional[str]
    references: List[str]
    tags: List[str]
    affected_software: List[str]
    exploit_available: bool = False
    poc_available: bool = False


class VulnDB:
    """Base de datos local de vulnerabilidades (CVE, exploit-db, etc.)"""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or os.path.join(os.path.dirname(__file__), '..', 'data', 'vulndb.json')
        self._cache: Dict[str, VulnEntry] = {}
        self._load()
    
    def _load(self):
        """Carga base de datos local"""
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, 'r') as f:
                    data = json.load(f)
                for item in data:
                    entry = VulnEntry(**item)
                    self._cache[entry.id] = entry
            except Exception:
                pass
        
        # Cargar entries built-in si cache vacío
        if not self._cache:
            self._load_builtin()
    
    def _load_builtin(self):
        """Vulnerabilidades built-in para matching rápido"""
        builtin = [
            VulnEntry(
                id="CVE-2021-44228", title="Log4Shell",
                description="RCE en Apache Log4j2 via JNDI injection",
                severity="critical", cvss=10.0, cwe="CWE-502",
                references=["https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-44228"],
                tags=["rce", "java", "log4j"], affected_software=["log4j2"],
                exploit_available=True, poc_available=True
            ),
            VulnEntry(
                id="CVE-2022-22965", title="Spring4Shell",
                description="RCE en Spring Framework via Data Binding",
                severity="critical", cvss=9.8, cwe="CWE-502",
                references=["https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-22965"],
                tags=["rce", "java", "spring"], affected_software=["spring"],
                exploit_available=True, poc_available=True
            ),
            VulnEntry(
                id="CVE-2020-1472", title="Zerologon",
                description="Elevation of privilege en Netlogon",
                severity="critical", cvss=10.0, cwe="CWE-326",
                references=["https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-1472"],
                tags=["privilege-escalation", "windows"], affected_software=["windows-server"],
                exploit_available=True, poc_available=True
            ),
        ]
        for entry in builtin:
            self._cache[entry.id] = entry
    
    def lookup(self, vuln_id: str) -> Optional[VulnEntry]:
        return self._cache.get(vuln_id.upper())
    
    def search(self, query: str, limit: int = 20) -> List[VulnEntry]:
        """Busca por tags, software, descripción"""
        query = query.lower()
        results = []
        for entry in self._cache.values():
            haystack = ' '.join([
                entry.title, entry.description, 
                ' '.join(entry.tags), ' '.join(entry.affected_software)
            ]).lower()
            if query in haystack:
                results.append(entry)
                if len(results) >= limit:
                    break
        return results
    
    def get_by_tag(self, tag: str) -> List[VulnEntry]:
        return [e for e in self._cache.values() if tag in e.tags]
    
    def enrich_finding(self, finding: Dict) -> Dict:
        """Enriquece un hallazgo con info de CVE conocida"""
        # Buscar por tipo/módulo
        module = finding.get('module', '').lower()
        if 'sqli' in module:
            matches = self.search('sql injection')
        elif 'xss' in module:
            matches = self.search('cross-site scripting')
        elif 'rce' in module:
            matches = self.search('remote code execution')
        else:
            matches = []
        
        if matches:
            finding['cve_matches'] = [
                {'id': m.id, 'title': m.title, 'cvss': m.cvss, 'exploit': m.exploit_available}
                for m in matches[:3]
            ]
        return finding