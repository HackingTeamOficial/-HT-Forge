#!/usr/bin/env python3
"""
core/models.py - Modelos de datos centrales de HT Forge.

Se mantienen separados de engine/db para romper el acoplamiento circular:
    engine -> db -> (ScanSession) <- engine

Al residir en un módulo propio, db.py puede tipar con ScanSession sin
importar engine, y engine lo re-exporta para no romper imports existentes.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional


@dataclass
class ScanSession:
    """Sesión de escaneo activa - modelo central persistible"""

    id: str
    target: str
    profile: str
    started_at: datetime
    status: str = "created"
    findings: List[Dict] = field(default_factory=list)
    modules_run: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)

    def add_finding(self, finding: Dict):
        """Añade hallazgo a la sesión"""
        self.findings.append(finding)


__all__ = ["ScanSession"]
