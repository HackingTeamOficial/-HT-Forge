#!/usr/bin/env python3
"""HT Forge GUI server."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import sys
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.engine import get_engine
from core.profiles import PROFILES
from core.exporters import export_report, generate_infographic
from core.db import Database
from core.session_store import save as save_auth_session, get as get_auth_session, masked as masked_auth_session
from core.workbench import get_workbench
from core.license import install_license, license_status, LicenseError

RUNTIME = ROOT / "runtime"
CONFIG_FILE = RUNTIME / "config.json"
INDEX = ROOT / "ui" / "index.html"
STATIC = ROOT / "ui" / "static"


def json_safe(v):
    if v is None or isinstance(v, (str, int, float, bool)): return v
    if isinstance(v, dict): return {str(k): json_safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple, set)): return [json_safe(x) for x in v]
    if hasattr(v, "isoformat"): return v.isoformat()
    return str(v)


def session_dict(s):
    if isinstance(s, dict): return json_safe(s)
    return json_safe({"id": s.id, "target": s.target, "profile": s.profile, "started_at": s.started_at, "status": s.status, "findings": s.findings, "modules_run": s.modules_run, "errors": s.errors, "metadata": s.metadata})


class GUIHandler(BaseHTTPRequestHandler):
    server_version = "HTForge/2.0.0-demo"

    def log_message(self, fmt, *args):
        return

    def _send(self, status, data, content_type="application/json"):
        body = data if isinstance(data, bytes) else (json.dumps(json_safe(data), ensure_ascii=False).encode("utf-8") if content_type == "application/json" else str(data).encode("utf-8"))
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS"); self.send_header("Access-Control-Allow-Headers", "Content-Type"); self.end_headers(); self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0")); raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_OPTIONS(self):
        self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization"); self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS"); self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"): return self._file(INDEX, "text/html; charset=utf-8")
        if p.startswith("/static/"): return self._file(STATIC / Path(p[len("/static/"):]).name)
        if p == "/api/status": return self._send(200, {"ok": True, "version": "2.0.0", "edition": os.getenv("HTFORGE_EDITION","PREMIUM"), "workbench": True, "license": license_status()})
        if p == "/api/workbench/history": return self._send(200, get_workbench().list_history())
        if p.startswith("/api/workbench/history/"): return self._history_item(p.rsplit("/",1)[-1])
        if p == "/api/workbench/extensions": return self._send(200, get_workbench().list_extensions())
        if p == "/api/workbench/workspace": return self._send(200, get_workbench().get_workspace())
        if p.startswith("/api/workbench/fuzz/"): return self._fuzz_status(p.rsplit("/",1)[-1])
        if p == "/api/sessions": return self._send(200, self._sessions())
        if p.startswith("/api/sessions/") and p.endswith("/infographic.svg"):
            sid=p.split("/")[3]
            return self._infographic(sid)
        if p.startswith("/api/sessions/") and "/reports/" in p:
            parts=p.strip("/").split("/")
            if len(parts) >= 4:
                return self._report_file(parts[2], parts[3])
        if p.startswith("/api/sessions/"):
            return self._session(p.rsplit("/",1)[-1])
        self._send(404, {"error":"Ruta no encontrada"})

    def do_DELETE(self):
        p = urlparse(self.path).path
        try:
            if p == "/api/sessions":
                count = self.server.session_db.delete_all_sessions()
                self.server.sessions.clear()
                self.server.engines.clear()
                return self._send(200, {"ok": True, "deleted": count})
            if p.startswith("/api/sessions/"):
                sid = p.rsplit("/", 1)[-1]
                if sid in self.server.engines:
                    self.server.engines[sid].stop()
                    self.server.engines.pop(sid, None)
                self.server.sessions.pop(sid, None)
                deleted = self.server.session_db.delete_session(sid)
                return self._send(200, {"ok": True, "deleted": bool(deleted)})
            return self._send(404, {"error": "Ruta no encontrada"})
        except Exception as e:
            return self._send(400, {"error": str(e)})

    def do_POST(self):
        p = urlparse(self.path).path; data = self._body()
        try:

            if p == "/api/license":
                if data.get("key"):
                    return self._send(200, install_license(data["key"]))
                return self._send(200, license_status())
            if p == "/api/scan": return self._start_scan(data)
            if p == "/api/scan/stop": return self._stop_scan(data)
            if p == "/api/export": return self._export(data)
            if p == "/api/workbench/repeater": return self._repeater(data)
            if p == "/api/workbench/retest": return self._repeater({**data, "source": "retest"})
            if p == "/api/workbench/intruder": return self._intruder(data)
            if p == "/api/workbench/diff": return self._send(200, get_workbench().diff(data.get("left") or {}, data.get("right") or {}))
            if p == "/api/workbench/workspace": return self._send(200, get_workbench().update_workspace(data))
            if p == "/api/workbench/workspace/target": return self._send(200, get_workbench().add_target(data.get("target", "")))
            if p == "/api/workbench/openapi": return self._send(200, get_workbench().import_openapi(data.get("document", "")))
            if p == "/api/workbench/websocket": return self._send(200, get_workbench().websocket_send(data.get("url", ""), data.get("message", ""), data.get("timeout", 10), data.get("verify_ssl", False)))
            if p == "/api/workbench/history/clear": get_workbench().clear_history(); return self._send(200,{"ok":True})
            if p == "/api/auth/session":
                save_auth_session(data.get("target",""),data.get("session_id",""),data.get("token",""),data.get("session_cookie_name","sessionid")); return self._send(200,{"ok":True,"session":masked_auth_session(data.get("target",""))})
            self._send(404,{"error":"Ruta no encontrada"})
        except Exception as e:
            self._send(400,{"error":str(e)})

    def _repeater(self,data):
        try:return self._send(200,get_workbench().send(data,"repeater"))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _intruder(self,data):
        try:return self._send(202,get_workbench().start_fuzz(data.get("request") or {},data.get("position","url"),data.get("payloads") or [],data.get("workers",4)))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _history_item(self,eid):
        x=get_workbench().get_history(eid); return self._send(200,x) if x else self._send(404,{"error":"Intercambio no encontrado"})

    def _fuzz_status(self,jid):
        x=get_workbench().get_fuzz(jid); return self._send(200,x) if x else self._send(404,{"error":"Trabajo no encontrado"})

    def _file(self, path, content_type=None):
        try:
            body=path.read_bytes(); ct=content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"; return self._send(200,body,ct)
        except FileNotFoundError: return self._send(404,{"error":"Archivo no encontrado"})

    def _sessions(self):
        out=[]
        for r in self.server.session_db.list_sessions(100):
            s=dict(r); s["findings"]=s.get("findings_count",0); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); out.append(s)
        for sid,s in self.server.sessions.items(): out.append(session_dict(s))
        seen={}; [seen.__setitem__(x["id"],x) for x in out]; return list(seen.values())

    def _session(self,sid):
        if sid in self.server.sessions: return self._send(200,session_dict(self.server.sessions[sid]))
        r=self.server.session_db.get_session(sid)
        if not r:return self._send(404,{"error":"Sesión no encontrada"})
        s=dict(r); s["findings"]=self.server.session_db.get_findings(sid); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); return self._send(200,s)

    def _infographic(self, sid):
        s=self.server.sessions.get(sid)
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            # Stored sessions are reconstructed in the same shape used by _session.
            from core.models import ScanSession
            started=r.get("started_at") if isinstance(r,dict) else None
            try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
            except Exception: started=datetime.now()
            s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
        try:
            svg=generate_infographic(s, str(ROOT/"reports"))
            return self._file(Path(svg), "image/svg+xml; charset=utf-8")
        except Exception as exc:
            return self._send(500,{"error":str(exc)})

    def _start_scan(self,data):
        try: from core.license import require_license; require_license()
        except LicenseError as e: return self._send(403,{"error":str(e),"license_required":True,"license":license_status()})
        target=data.get("target","").strip(); profile=data.get("profile","full")
        if not target:return self._send(400,{"error":"Target requerido"})
        sid=str(uuid.uuid4())[:8]; config=data.get("config") or {}; config["session_id"]=sid; config.setdefault("reports_dir", str(ROOT/"reports")); config["modules"]=data.get("modules") or []
        engine=get_engine(config=config); self.server.engines[sid]=engine
        def worker():
            s=engine.scan(target,profile,options=config); self.server.sessions[sid]=s
        t=threading.Thread(target=worker,daemon=True); self.server.threads[sid]=t; t.start()
        # session object is created immediately by Engine; expose it once available
        for _ in range(50):
            if engine.session: self.server.sessions[sid]=engine.session; break
            time.sleep(.01)
        return self._send(202,{"session_id":sid})

    def _stop_scan(self,data):
        sid=data.get("session_id"); e=self.server.engines.get(sid)
        if not e:return self._send(404,{"error":"Escaneo no encontrado"})
        e.stop(); return self._send(200,{"ok":True})


    def _report_file(self, sid, fmt):
        if fmt not in {"svg", "html", "pdf", "json"}:
            return self._send(400, {"error": "Formato no soportado"})
        s=self.server.sessions.get(sid)
        report_path=None
        if s and isinstance(s.metadata, dict):
            report_path=(s.metadata.get("reports") or {}).get(fmt)
        if not report_path or not Path(str(report_path)).is_file():
            r=self.server.session_db.get_session(sid)
            if r:
                try:
                    meta=json.loads(r.get("metadata") or "{}")
                    report_path=(meta.get("reports") or {}).get(fmt)
                except Exception:
                    report_path=None
        # El SVG se puede regenerar bajo demanda. Esto evita que el panel quede vacío
        # si el escaneo terminó antes de persistir el mapa de reportes.
        if fmt == "svg" and (not report_path or not Path(str(report_path)).is_file()):
            try:
                if s is None:
                    r=self.server.session_db.get_session(sid)
                    if r:
                        from core.models import ScanSession
                        started=r.get("started_at")
                        try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
                        except Exception: started=datetime.now()
                        s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
                if s is not None:
                    report_path=generate_infographic(s, str(ROOT/"reports"))
                    if isinstance(s.metadata, dict):
                        s.metadata.setdefault("reports", {})["svg"]=report_path
                        try: self.server.session_db.update_session(s)
                        except Exception: pass
            except Exception as exc:
                return self._send(500, {"error": f"No se pudo generar el SVG: {exc}"})
        if not report_path or not Path(str(report_path)).is_file():
            return self._send(404, {"error": f"Reporte {fmt.upper()} no generado todavía"})
        path=Path(str(report_path)).resolve()
        try:
            path.relative_to((ROOT/"reports").resolve())
        except ValueError:
            return self._send(403, {"error": "Ruta de reporte no permitida"})
        cts={"svg":"image/svg+xml; charset=utf-8","html":"text/html; charset=utf-8","pdf":"application/pdf","json":"application/json; charset=utf-8"}
        return self._file(path, cts[fmt])

    def _export(self,data):
        sid=data.get("session_id"); fmt=data.get("format","json"); e=self.server.engines.get(sid); s=e.session if e and e.session else None
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            return self._send(400,{"error":"La exportación interactiva requiere sesión cargada"})
        return self._send(200,{"output":export_report(s,fmt)})

def run_server(host="127.0.0.1",port=9090,open_browser=True):
    
    try:
        server=ThreadingHTTPServer((host,port),GUIHandler)
    except OSError as exc:
        if getattr(exc,"errno",None)==98:
            raise RuntimeError(f"El puerto {port} ya está en uso. Cierra la instancia anterior de HT Forge o usa --port <puerto>." ) from exc
        raise
    server.sessions={}; server.engines={}; server.threads={}; server._lock=threading.RLock(); server.session_db=Database(os.getenv("HTFORGE_DB",str(ROOT/"runtime"/"htforge.db")))
    url=f"http://{host}:{port}"; print(f"🌐 HT Forge GUI corriendo en {url}")
    if open_browser: threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: server.shutdown()


if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--host",default="127.0.0.1"); ap.add_argument("--port",type=int,default=9090); ap.add_argument("--no-browser",action="store_true"); a=ap.parse_args(); run_server(a.host,a.port,not a.no_browser)
