"""HT Forge - Interfaz Web (GUI/API server)."""

__version__ = "1.8.3"
