# HT Forge 2.0.0 PREMIUM — Fix

## Intruder / Fuzzer
- Fixed an uncaught `ValueError: URL HTTP/HTTPS requerida` from background Intruder threads.
- Base requests are now validated synchronously before a fuzz job is created.
- Individual fuzz cases are isolated so one malformed case cannot terminate the worker thread.
- Job status now exposes an `errors` counter.
- GUI validates the Request Builder URL and payload list before launching Intruder.

## Regression
- Full test suite: 10/10 passed.
