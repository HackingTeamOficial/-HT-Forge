# HT Forge 1.8.7

- Recuperado el diseño de tarjetas de vulnerabilidad de HT Forge 1.8.3 en la vista **HALLAZGOS OBTENIDOS**.
- Se mantienen las funciones de Dashboard, historial, temas, acentos, voz, temporizador en tiempo real y reportes de 1.8.6.
# HT Forge 1.8.6 — Infographic Fixed v3 + Control UI

- Mantiene el estilo visual Infographic Fixed v3.
- Recupera el historial de sesiones con apertura y borrado individual.
- Añade borrado completo del historial desde Sesiones.
- Recupera Ajustes completos: tema claro/oscuro, presets de color y color personalizado.
- Añade control de intervalo de actualización, timeout de módulo y pausa configurable entre módulos.
- Añade avisos de voz al iniciar y finalizar un escaneo, con selección de idioma y prueba de voz.
- El contador de duración se actualiza en tiempo real mientras el escaneo está ejecutándose y conserva la duración final al terminar.
- El log de la GUI consume el buffer de eventos recientes del motor para mostrar el progreso real de módulos.
- Basado en el pacing de 1.8.5: la pausa entre módulos por defecto es 0,75 s y es configurable.
- Mantiene únicamente motores nativos Forge, sin servicios MCP externos.
