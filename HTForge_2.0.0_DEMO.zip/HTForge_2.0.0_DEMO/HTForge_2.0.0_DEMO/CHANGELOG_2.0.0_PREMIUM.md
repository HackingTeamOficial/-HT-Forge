# HT Forge 2.0.0 PREMIUM

## Workbench PREMIUM

Esta edición amplía la alpha Workbench con un flujo de testing manual integrado:

- Repeater HTTP con historial y editor de requests.
- Re-Test de intercambios guardados.
- Comparación diferencial de respuestas (status, headers y cuerpo).
- Intruder/Fuzzer con posiciones URL, query, body y header.
- Workspace persistente con targets y notas.
- Inventario de endpoints desde OpenAPI/Swagger JSON/YAML.
- Cliente WebSocket opcional mediante `websocket-client`.
- Registro de extensiones integradas del Workbench.
- Puente proxy local HTTP con registro; HTTPS funciona como túnel CONNECT sin MITM.

## Compatibilidad

- Se mantienen los módulos de escaneo existentes y la arquitectura de plugins.
- Se conserva la orientación a pruebas autorizadas, laboratorios, CTF y auditorías.
- No se habilita MITM HTTPS ni funciones de evasión.

## Validación

- `compileall`: OK
- Suite pytest: 9 tests OK
- Smoke tests de Workbench: OK
- Integración UI/API: OK
