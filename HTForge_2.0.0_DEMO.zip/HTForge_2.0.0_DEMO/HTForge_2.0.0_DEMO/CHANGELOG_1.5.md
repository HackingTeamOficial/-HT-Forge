# HT Forge 1.5

## Objetivo de esta entrega
Recuperar la fiabilidad del detector SQLi sin romper el resto del proyecto.

## Cambios
- SQLi: cobertura adaptativa de parámetros, con prioridad para parámetros dinámicos y numéricos.
- SQLi: recuperación del valor real desde `baseline_value`, `value` o la propia URL.
- SQLi: más contextos de pruebas booleanas y terminación por comentario.
- SQLi: firmas de errores para varios motores SQL.
- SQLi: normalización de contenido dinámico antes de comparar respuestas.
- SQLi: errores de red aislados por parámetro; un fallo no detiene el módulo completo.
- Cancelación: no se generan avisos repetidos de `HTTP request cancelled` después de STOP.
- MCP externo: eliminado del launcher, del core y de la CLI. Forge 1.5 es independiente de los cuatro servicios externos.
- GUI: banner único HT Forge, selector Claro/Oscuro conservado y versión actualizada a 1.5.
- Target inicial: no viene fijado a testfire.net.
- Se mantienen crawler, fingerprinting, archivos, JS, CBH, IDOR, XSS, LFI, traversal, RCE, SSRF, sesiones, reportes.

## Validación
- `tests/test_sqli_regression_14.py`: 3/3 pruebas OK.
- Compilación Python del proyecto: OK.
- Carga del PluginManager y del módulo SQLi: OK.

## GUI reference + SQLi validation pass
- Rebuilt `ui/index.html` around the approved HT Forge CiberSecurity dashboard layout.
- Single centered brand title; severity traffic-light counters across the top.
- Scan information and module matrix on the left; findings summary/donut on the upper-right; scan log below it.
- Removed the old tabs and visible authenticated-session form from the main dashboard.
- Kept Claro/Oscuro and configurable target input.
- SQLi differential comparison strengthened with token-level similarity and noisy-page tolerant checks.
- Added real-HTTP 9-parameter SQLi regression coverage.

### GUI — URLs de hallazgos medio a crítico
- Añadido en `LOG DEL ESCANEO` un bloque compacto `URLS DETECTADAS · MEDIO–CRÍTICO`.
- Muestra únicamente hallazgos con severidad `medium`, `high` o `critical`.
- Ordena las detecciones de crítica a media y evita duplicados.
- Muestra endpoint/target y, cuando existe, parámetro y tipo de hallazgo.
- Mantiene intacta la distribución general del Dashboard 1.5.
