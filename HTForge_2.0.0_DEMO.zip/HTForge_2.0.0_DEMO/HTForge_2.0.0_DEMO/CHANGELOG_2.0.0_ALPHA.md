# HT Forge 2.0.0-alpha

Primera base del Workbench de Testing Manual sobre HT Forge 1.8.11.

- Workbench independiente del motor de escaneo.
- Historial HTTP con hasta 500 intercambios.
- Repeater HTTP: editar y reenviar requests.
- Intruder/Fuzzer acotado para URL, body y headers.
- API preparada para ampliar Proxy/Intercept, WebSockets, APIs y extensiones.
- Se conserva el scanner, findings, scoring, reportes, temas y UI aprobada.

La alpha no activa todavía un MITM HTTPS ni pretende sustituir el proxy del sistema: esas capacidades forman la siguiente fase del Workbench.
