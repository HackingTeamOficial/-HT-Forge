# HT Forge 1.8.10

- Added community welcome voice message at scan start.
- Welcome message translated for Spanish, English, German and Russian.
- Kept the target announcement after the welcome message.
- Reduced speech volume to 45% and pitch to 0.92 for a softer voice.
- Prefer a masculine browser voice when one is available for the selected language.
- Existing dashboard, findings, reports, history, themes and scanner behavior preserved.
