# HT Forge 1.8.5

## AntV Infographic integration
- Añadida vista **Infografías** al Dashboard.
- Integración con `@antv/infographic` 0.2.20 mediante el bundle UMD oficial cargado desde unpkg.
- Generación visual a partir de los hallazgos de la sesión activa.
- Exportación del resultado a SVG desde la interfaz.
- No se modifican los módulos existentes de detección/escaneo.
- Compatible con los temas Claro/Oscuro del Dashboard.

- Añadido renderer SVG local de respaldo para que la infografía nunca quede vacía si falla AntV SSR.
- El HTML/PDF incluye automáticamente la infografía generada y conserva los hallazgos originales.
- Añadidos `tools/infographic_ssr.mjs` y `tools/setup_infographic.sh` autocontenidos.

- Renderer SVG local de respaldo para que la infografía nunca quede vacía si falla AntV SSR.
- HTML/PDF incluye automáticamente la infografía generada y conserva los hallazgos originales.
- Añadidos `tools/infographic_ssr.mjs` y `tools/setup_infographic.sh`.
