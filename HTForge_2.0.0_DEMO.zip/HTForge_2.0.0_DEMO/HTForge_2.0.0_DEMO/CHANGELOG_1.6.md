# HT Forge 1.6 — SQLi Verification Hardening

## Cambios
- SQLi usa PayloadCollection como fuente central de payloads.
- Las firmas de error SQL se reproducen una segunda vez antes de marcarse como confirmadas.
- Las diferencias booleanas TRUE/FALSE se reproducen antes de generar un hallazgo.
- Se conserva evidencia inicial y de confirmación.
- Límites de probes por parámetro para evitar explosión de peticiones.
- Presupuesto global SQLi de 240 s por defecto para cierre limpio en objetivos lentos.
- Timeout SQLi de petición de 4 s por defecto, configurable.
- Límite adaptativo de 30 parámetros por defecto, configurable.
- Estadísticas de presupuesto/probes en `sqli_stats`.

## Validación
Pruebas específicas SQLi + detectores locales: **11/11 OK**.

## UI branding cleanup
- Removed the oversized ASCII signature block from the About view.
- Replaced it with a compact HT Forge / Cybersecurity Platform / Hacking Team Community banner.
