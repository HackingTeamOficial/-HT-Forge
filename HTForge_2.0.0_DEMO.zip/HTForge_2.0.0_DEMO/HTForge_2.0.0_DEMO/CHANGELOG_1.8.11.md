# HT Forge 1.8.11

- Fixed the Dashboard infographic/report preview so the generated SVG appears in the lower-right report panel after a completed scan.
- The SVG endpoint now regenerates the infographic on demand if the report path was not persisted yet.
- The "Abrir SVG" action opens the same reliable infographic endpoint.
- Updated server/API version to 1.8.11.
- Preserved the approved 1.8.10 UI, findings cards, themes, history, voice, live timer, and native scan engine.
