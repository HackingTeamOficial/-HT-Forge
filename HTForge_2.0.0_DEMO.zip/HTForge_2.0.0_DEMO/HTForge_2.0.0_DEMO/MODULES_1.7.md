# HT Forge 1.7 — módulos

Nuevos módulos incorporados: `xxe`, `ssrf`, `path_traversal`, `open_redirect`, `crlf`, `command_injection`, `wordpress`, `joomla`, `drupal`, `plugins`, `api`, `graphql`.

Las comprobaciones de XXE/CMS/API/GraphQL son conservadoras y no ejecutan explotación destructiva. Command Injection usa únicamente canarios de eco controlados.
