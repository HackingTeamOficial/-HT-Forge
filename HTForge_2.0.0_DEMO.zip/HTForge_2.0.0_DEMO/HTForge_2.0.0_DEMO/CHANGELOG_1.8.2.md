# HT Forge 1.8.2

- XSS: clasificación conservadora entre reflexión, posible XSS y contexto ejecutable.
- XSS: respuestas 5xx no se elevan automáticamente a XSS confirmado.
- XXE: separación entre `xml_surface` y `xxe_parser_signal`.
- XXE: eliminación de señales ambiguas como `DOCTYPE`/`disallow-doctype` como prueba de vulnerabilidad.
- Evidencia enriquecida con content type, estado HTTP, reflexión y contexto ejecutable.
