<div align="center">

<img src="ui/static/logo.svg" alt="HT Forge" width="180">

# HT Forge

### Cybersecurity Operating Platform

**Reconocimiento · Crawling · Detección · Evidencias · Automatización · Motor nativo Forge**

Una plataforma modular para investigación de seguridad y pruebas autorizadas, diseñada para crecer desde un scanner web hasta un entorno unificado de operaciones de ciberseguridad.

[![Status](https://img.shields.io/badge/status-beta-orange.svg)](#estado-del-proyecto)
[![Python](https://img.shields.io/badge/python-3.11%2B-blue.svg)](#requisitos)
[![License](https://img.shields.io/badge/local-MIT-green.svg)](#licencia)

</div>

---

## ⚡ ¿Qué es HT Forge?

**HT Forge** nace con una idea sencilla: reunir en una única plataforma el trabajo que normalmente termina repartido entre múltiples herramientas.

Su arquitectura separa el **motor de ejecución**, los **módulos de seguridad**, el **sistema de findings**, la **interfaz web**, las **notificaciones** y la evolución futura del motor nativo Forge.

El objetivo es que un operador pueda pasar de:

```text
Objetivo autorizado
        ↓
Reconocimiento
        ↓
Descubrimiento de superficie
        ↓
Análisis de parámetros
        ↓
Detección
        ↓
Correlación de evidencias
        ↓
Findings y severidad
        ↓
Dashboard / Reportes
```

sin perder el control del proceso.

> **HT Forge está pensado para laboratorios, CTF, bug bounty autorizado, auditorías y pentesting con permiso.**

---

## 🧰 Características principales

### 🔎 Reconocimiento y descubrimiento

- Fingerprinting de tecnologías.
- Crawler web con descubrimiento de URLs.
- Extracción de parámetros GET y formularios POST.
- Detección de archivos y recursos potencialmente sensibles.
- Análisis de JavaScript para indicadores de secretos.
- Reconocimiento pasivo.
- Perfiles de escaneo adaptados al objetivo.

### 🧪 Módulos de seguridad

La plataforma dispone de una arquitectura modular para ejecutar detectores de forma independiente y combinarlos en perfiles completos.

Entre los módulos integrados en esta línea se encuentran:

- **SQL Injection (SQLi)**
- **Cross-Site Scripting (XSS)**
- **IDOR**
- **Command Injection / RCE**
- **LFI**
- **Path Traversal**
- **SSRF**
- análisis de archivos sensibles
- secretos en JavaScript
- fingerprinting tecnológico
- crawler y descubrimiento
- reconocimiento pasivo

Los módulos están desacoplados del motor para facilitar su evolución, pruebas y sustitución.

### 🎯 SQLi con enfoque basado en evidencias

El detector SQLi está evolucionando hacia una combinación de:

- detección basada en errores;
- pruebas booleanas;
- comparación diferencial;
- baseline de la respuesta original;
- soporte para parámetros GET y POST;
- firmas de distintos motores SQL;
- correlación de señales antes de crear un finding.

La prioridad es **reducir falsos positivos**, no simplemente aumentar el número de alertas.

### 🕷️ XSS

El módulo XSS analiza parámetros descubiertos y comprueba reflexión y contexto de salida para identificar casos de XSS reflejado en objetivos autorizados.

### 🔐 IDOR

El módulo IDOR busca parámetros que representen identificadores de recursos y compara respuestas para localizar posibles accesos indebidos.

Un posible IDOR se trata como tal hasta disponer de suficiente evidencia de autorización/aislamiento entre recursos.

### ⚙️ RCE / Command Injection

Forge incorpora un detector de command injection/RCE orientado a **comprobaciones controladas y no destructivas**, con evidencia asociada al resultado.

La clasificación debe distinguir entre:

- reflexión de un valor;
- indicios de procesamiento;
- evidencia suficiente de ejecución controlada.

Esto evita convertir una simple reflexión HTTP en un falso `Critical`.

---

## 🧠 Motor de Forge

El corazón de la plataforma es un motor que coordina sesiones, módulos, HTTP, findings, scoring y eventos de interfaz.

```text
                     ┌─────────────────┐
                     │    HT Forge     │
                     │       GUI       │
                     └────────┬────────┘
                              │
                     ┌────────▼────────┐
                     │      Engine     │
                     └────────┬────────┘
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
    ┌─────▼─────┐       ┌─────▼─────┐       ┌─────▼─────┐
    │ Discovery │       │ Detectors │       │ Forge Core │
    └─────┬─────┘       └─────┬─────┘       └─────┬─────┘
          │                   │                   │
          └───────────────────┼───────────────────┘
                              │
                       ┌──────▼──────┐
                       │  Findings   │
                       │   + Score   │
                       └──────┬──────┘
                              │
                ┌─────────────┼─────────────┐
                │             │             │
             Dashboard     Reports
```

### Principios del motor

- Sesiones de escaneo aisladas.
- Estado centralizado de ejecución.
- Control de parada y timeout.
- Ejecución modular.
- Evidencia asociada a cada finding.
- Deduplicación de findings.
- Persistencia mediante SQLite.
- Eventos para actualizar la GUI en tiempo real.

---

## 🖥️ Interfaz web

HT Forge incluye una interfaz web local para controlar y visualizar los escaneos.

### Dashboard

Muestra de un vistazo:

- estado del escaneo;
- progreso de módulos;
- Critical / High / Medium / Low / Info;
- hallazgos recientes;
- módulos activos;
- sesión actual.

### 🌗 Claro / Oscuro

El selector de tema forma parte permanente de la interfaz de HT Forge.

- modo oscuro;
- modo claro;
- persistencia de la elección en el navegador;
- aplicación global a la interfaz.

> El selector de tema se mantendrá como característica estándar en las futuras versiones de Forge.

---

## HT Forge 1.8

Esta versión elimina la dependencia y el arranque de los cuatro servicios MCP externos. El escaneo utiliza únicamente módulos nativos de Forge.

### SQLi 1.5
- selección de parámetros con cobertura adaptativa;
- recuperación del valor real desde URL/crawler/formulario;
- pruebas de errores y diferenciales booleanos en varios contextos;
- normalización de contenido dinámico;
- confirmación reproducible antes de crear un hallazgo;
- aislamiento de errores de red por parámetro.

### Infografía de seguridad
HT Forge 1.8.7 incluye una infografía de seguridad integrada en los reportes HTML/PDF. El bundle AntV del Dashboard se usa cuando está disponible y, ante cualquier fallo de CDN/SSR, se activa automáticamente un renderer SVG local determinista. Los datos de hallazgos no se modifican.


## 1.8.7 — GUI

La interfaz conserva el diseño **Infographic Fixed v3** e incorpora historial de escaneos con borrado, temas claro/oscuro, color de acento personalizable, avisos de voz de inicio/finalización y contador de duración en tiempo real. El ritmo entre módulos es configurable y no sustituye las comprobaciones reales.
