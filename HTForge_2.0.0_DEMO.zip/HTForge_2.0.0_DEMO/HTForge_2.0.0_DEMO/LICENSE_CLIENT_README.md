# HT Forge 1.7 — Cliente

Edición local de HT Forge. No requiere keys, activación ni conexión a un servidor de licencias para ejecutar escaneos.

El paquete no incluye ningún panel administrativo ni servidor de licencias.
