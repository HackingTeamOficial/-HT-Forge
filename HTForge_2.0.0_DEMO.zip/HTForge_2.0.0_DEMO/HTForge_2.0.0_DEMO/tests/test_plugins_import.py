"""tests/test_plugins_import.py

Smoke test de contrato mínimo para plugins.

`core/plugin.py::PluginManager._load_plugin` captura CUALQUIER excepción
al cargar un plugin y solo hace `print(f"[WARN] ...")` — si un plugin
deja de importar (typo, dependencia movida, etc.) el scan sigue
corriendo con menos detectores y nadie se entera salvo que lea stdout.
Este test hace explícito ese fallo en CI en vez de en producción.
"""
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.plugin import PluginManager  # noqa: E402


@pytest.fixture(scope="module")
def manager() -> PluginManager:
    return PluginManager()


def test_all_plugin_files_loaded(manager: PluginManager):
    """Todo archivo plugins/*.py (no privado) debe terminar registrado.

    Si esto falla, corré `PluginManager()` manualmente para ver el
    [WARN] con la excepción real — ese es el bug a arreglar.
    """
    plugins_dir = PROJECT_ROOT / "plugins"
    expected = {
        p.stem for p in plugins_dir.glob("*.py")
        if not p.stem.startswith("_") and p.stem != "__init__"
    }
    loaded = set(manager.get_available())
    missing = expected - loaded
    assert not missing, f"Plugins que no cargaron (ver [WARN] en stdout): {sorted(missing)}"


def test_every_plugin_exposes_callable_run(manager: PluginManager):
    for name in manager.get_available():
        plugin = manager.get(name)
        assert callable(plugin.run_func), f"{name}: run/main no es invocable"
