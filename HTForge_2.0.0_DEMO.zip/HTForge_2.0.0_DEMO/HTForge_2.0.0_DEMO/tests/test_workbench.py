from http.server import BaseHTTPRequestHandler, HTTPServer
import threading
import json

from core.workbench import Workbench

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type','text/plain')
        self.end_headers()
        self.wfile.write(self.path.encode())
    def log_message(self,*args): pass

def test_repeater_and_intruder_history():
    server=HTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        wb=Workbench(); base=f'http://127.0.0.1:{server.server_port}/?id=1'
        r=wb.send({'method':'GET','url':base})
        assert r['status']==200 and 'id=1' in r['response_body']
        job=wb.start_fuzz({'method':'GET','url':f'http://127.0.0.1:{server.server_port}/?id=FUZZ'},'url',['1','2'],workers=2)
        import time
        for _ in range(50):
            j=wb.get_fuzz(job['id'])
            if j['status']=='completed': break
            time.sleep(.02)
        assert j['completed']==2
        assert len(wb.list_history())>=3
    finally:
        server.shutdown()

def test_diff_openapi_workspace(tmp_path):
    wb = Workbench(str(tmp_path / "workspace.json"))
    d = wb.diff({'status': 200, 'response_headers': {'X': '1'}, 'response_body': 'abc'},
                {'status': 200, 'response_headers': {'X': '2'}, 'response_body': 'adc'})
    assert d['body_changed'] and d['changed_headers'] == ['X']
    spec = wb.import_openapi({'openapi': '3.0.0', 'info': {'title': 'Lab'}, 'paths': {'/a': {'get': {}}}})
    assert spec['title'] == 'Lab' and spec['endpoints'][0]['path'] == '/a'
    wb.add_target('http://127.0.0.1:8080')
    wb.update_workspace({'notes': 'assessment'})
    assert Workbench(str(tmp_path / "workspace.json")).workspace['notes'] == 'assessment'


def test_intruder_rejects_empty_url_without_background_thread():
    wb = Workbench()
    try:
        wb.start_fuzz({'method': 'GET', 'url': ''}, 'url', ['x'])
    except ValueError as exc:
        assert 'URL HTTP/HTTPS válida' in str(exc)
    else:
        raise AssertionError('Intruder debe rechazar una URL vacía antes de crear el job')
