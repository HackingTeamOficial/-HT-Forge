import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from plugins.xss import _classify_reflection
from plugins.xxe import PARSER_ERRORS


def test_xss_html_executable_is_high():
    payload='<script>alert(1)</script>'
    raw, executable, severity = _classify_reflection(payload, payload, 'text/html; charset=utf-8', 200)
    assert raw is True and executable is True and severity == 'high'


def test_xss_json_reflection_is_not_high():
    payload='<script>alert(1)</script>'
    raw, executable, severity = _classify_reflection(payload, '{"value":"'+payload+'"}', 'application/json', 200)
    assert raw is True and executable is False and severity == 'low'


def test_xss_server_error_never_claims_executable():
    payload='<script>alert(1)</script>'
    raw, executable, severity = _classify_reflection(payload, '<html>'+payload+'</html>', 'text/html', 500)
    assert raw is True and executable is False and severity == 'medium'


def test_xxe_secure_doctype_denial_is_not_parser_signal():
    assert PARSER_ERRORS.search('DOCTYPE is disallowed') is None


def test_xxe_parser_error_is_signal():
    assert PARSER_ERRORS.search('XMLSyntaxError: entity not defined') is not None
