# HT Forge 1.8

## Payload engine
- Centralized `core/payloads_1_8.py` registry.
- 96 bounded detection probes/pairs across 15 families.
- Expanded SQLi and XSS coverage through the compatibility facade.
- Expanded SSTI, command-injection canary, LDAP, NoSQL and XPath probes.
- Added payload inventory module for scan reproducibility.
- Preserved existing module APIs and `core/payloads.py` imports.
- Added explicit attribution/reference to Swissky's PayloadsAllTheThings.

## Detection quality
Payload expansion does not automatically convert reflection, HTTP 500/400,
or parser surfaces into confirmed vulnerabilities. Existing evidence and
confidence rules remain the source of truth.

## Version
1.8.0


## Payload expansion / quality pass
- Expanded SQLi error and boolean-differential coverage with encoded syntax and additional DB-neutral variants.
- Added additional inert XSS context probes using a local `HTFORGE_XSS` console marker.
- Expanded safe SSTI arithmetic probes.
- RCE canary findings are now classified as high/possible until execution is independently confirmed.
- Core package version aligned to 1.8.

## Validation merge
- Preserved the 1.8.1 validation improvements for path-based IDOR/BOLA detection and technology fingerprinting.
- RCE now uses the stronger validation signal while keeping the result at candidate/high confidence until independently confirmed.
