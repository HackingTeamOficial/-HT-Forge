# HT Forge 1.8 — Payload Registry

Curated, bounded detection probes inspired by the public taxonomy in [PayloadsAllTheThings](https://github.com/swisskyrepo/PayloadsAllTheThings). The registry is **not** a verbatim mirror.

## Families

| Family | Count | Use |
|---|---:|---|
| `sqli_error` | 30 | detection-safe bounded probes/pairs |
| `sqli_boolean_num_pairs` | 10 | detection-safe bounded probes/pairs |
| `sqli_boolean_text_pairs` | 8 | detection-safe bounded probes/pairs |
| `xss` | 10 | detection-safe bounded probes/pairs |
| `xss_context` | 6 | detection-safe bounded probes/pairs |
| `ssti` | 8 | detection-safe bounded probes/pairs |
| `cmdi_unix` | 5 | detection-safe bounded probes/pairs |
| `cmdi_windows` | 3 | detection-safe bounded probes/pairs |
| `traversal` | 8 | detection-safe bounded probes/pairs |
| `ssrf` | 5 | detection-safe bounded probes/pairs |
| `open_redirect` | 3 | detection-safe bounded probes/pairs |
| `crlf` | 3 | detection-safe bounded probes/pairs |
| `ldap` | 6 | detection-safe bounded probes/pairs |
| `nosql` | 8 | detection-safe bounded probes/pairs |
| `xpath` | 5 | detection-safe bounded probes/pairs |
| `xml_syntax` | 3 | detection-safe bounded probes/pairs |

**Total bounded probes/pairs: 121.**

## Quality rules
- SQLi: error signatures and boolean differential checks; no data extraction or time-delay payloads.
- XSS: reflection/context checks with inert local markers; no credential/cookie exfiltration.
- SSTI: arithmetic-only rendering checks.
- RCE/command injection: unique echo canaries only; a reflected canary is not treated as proof of execution.
- XXE: syntax/surface detection only; no file-read or external callback payloads.
- SSRF: local/canonical endpoints only in automatic mode.
