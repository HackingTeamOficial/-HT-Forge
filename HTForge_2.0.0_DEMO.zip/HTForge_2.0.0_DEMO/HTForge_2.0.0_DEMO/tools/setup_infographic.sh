#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
command -v node >/dev/null 2>&1 || { echo "[ERROR] Node.js no está instalado. El fallback local de HT Forge no lo necesita, pero el renderer CLI sí."; exit 1; }
node --version
# No descargamos dependencias: el renderer incluido es autocontenido.
node tools/infographic_ssr.mjs <<'JSON' >/tmp/htforge_infographic_test.svg
{"target":"http://127.0.0.1:8080","counts":{"critical":1,"high":2,"medium":3,"low":4,"info":5},"risk":"ALTO","indicator":58}
JSON
head -c 120 /tmp/htforge_infographic_test.svg | grep -q '<svg' || { echo '[ERROR] El renderer no produjo SVG válido'; exit 1; }
echo '[OK] HT Forge Infographic runtime verificado (renderer local SVG).'
