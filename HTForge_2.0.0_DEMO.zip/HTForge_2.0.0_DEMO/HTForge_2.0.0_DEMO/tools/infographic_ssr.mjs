#!/usr/bin/env node
/**
 * HT Forge Infographic renderer.
 *
 * This renderer is intentionally dependency-free so reports never become
 * unavailable because Node/AntV SSR is missing or changes API shape.
 * It consumes JSON from stdin (or a JSON file argument) and emits valid SVG.
 * The dashboard can still use the official AntV browser bundle when available.
 */
import fs from 'node:fs';

const input = process.argv[2] ? fs.readFileSync(process.argv[2], 'utf8') : fs.readFileSync(0, 'utf8');
const data = JSON.parse(input);

const esc = (v) => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const counts = Object.assign({critical:0,high:0,medium:0,low:0,info:0}, data.counts || {});
const target = esc(data.target || 'Sin target');
const total = Object.values(counts).reduce((a,b)=>a+Number(b||0),0);
const risk = esc(data.risk || 'INFORMATIVO');
const indicator = Number(data.indicator ?? 100);
const rows = [
  ['CRITICAL', counts.critical, '#8b1e2d'],
  ['HIGH', counts.high, '#c2410c'],
  ['MEDIUM', counts.medium, '#b45309'],
  ['LOW', counts.low, '#15803d'],
  ['INFO', counts.info, '#2563eb']
];
const max = Math.max(1, ...rows.map(r => Number(r[1] || 0)));
const barRows = rows.map(([label,value,fill],i)=>{
  const y = 190 + i*58;
  const w = Math.max(0, Math.min(520, 520*Number(value||0)/max));
  return `<text x="80" y="${y}" font-family="Arial,Helvetica,sans-serif" font-size="18" font-weight="700" fill="#172033">${label}</text><rect x="220" y="${y-18}" width="520" height="24" rx="12" fill="#e8edf5"/><rect x="220" y="${y-18}" width="${w.toFixed(1)}" height="24" rx="12" fill="${fill}"/><text x="765" y="${y}" font-family="Arial,Helvetica,sans-serif" font-size="18" font-weight="700" fill="#172033">${Number(value||0)}</text>`;
}).join('\n');

const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="900" height="620" viewBox="0 0 900 620" role="img" aria-label="HT Forge security infographic">
<rect width="900" height="620" rx="18" fill="#ffffff"/>
<rect x="24" y="24" width="852" height="572" rx="14" fill="#f8fafc" stroke="#dbe3ee"/>
<text x="80" y="78" font-family="Arial,Helvetica,sans-serif" font-size="30" font-weight="800" fill="#14213d">HT Forge — Security Assessment</text>
<text x="80" y="110" font-family="Arial,Helvetica,sans-serif" font-size="16" fill="#64748b">Target: ${target}</text>
<text x="80" y="145" font-family="Arial,Helvetica,sans-serif" font-size="16" fill="#64748b">Resumen de hallazgos · ${total} hallazgo(s)</text>
<rect x="625" y="55" width="190" height="92" rx="14" fill="#ffffff" stroke="#dbe3ee"/>
<text x="645" y="82" font-family="Arial,Helvetica,sans-serif" font-size="13" fill="#64748b">RIESGO GLOBAL</text>
<text x="645" y="113" font-family="Arial,Helvetica,sans-serif" font-size="25" font-weight="800" fill="#14213d">${risk}</text>
<text x="645" y="134" font-family="Arial,Helvetica,sans-serif" font-size="13" fill="#64748b">Indicador ${indicator}/100</text>
${barRows}
<line x1="80" y1="492" x2="820" y2="492" stroke="#dbe3ee"/>
<text x="80" y="530" font-family="Arial,Helvetica,sans-serif" font-size="14" fill="#64748b">HT Forge · Hacking Team · Uso autorizado únicamente</text>
<text x="80" y="558" font-family="Arial,Helvetica,sans-serif" font-size="13" fill="#94a3b8">Renderer: local SVG fallback (deterministic, no external runtime required)</text>
</svg>`;

if (!svg.trim().startsWith('<svg') && !svg.trim().startsWith('<?xml')) throw new Error('Renderer devolvió una salida que no es SVG');
process.stdout.write(svg);
