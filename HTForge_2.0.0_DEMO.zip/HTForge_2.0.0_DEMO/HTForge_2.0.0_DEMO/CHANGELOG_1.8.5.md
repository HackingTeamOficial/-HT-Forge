# HT Forge 1.8.6 — Deep Scan / Dashboard

- Mantiene el Dashboard Infographic Fixed v3 como referencia visual.
- Nuevo modo de ejecución `deep`: más tiempo real por módulo, sin `sleep` artificial como sustituto de detección.
- Pacing entre módulos configurable para evitar ráfagas de peticiones y permitir observar el progreso.
- Los módulos que siguen siendo de revisión humana se marcan como `DEFERRED/HUMAN_REVIEW` en lugar de simular una comprobación.
- Progreso por módulo y duración acumulada visibles en CLI/GUI.
- Se conserva el núcleo nativo sin MCP externos.
