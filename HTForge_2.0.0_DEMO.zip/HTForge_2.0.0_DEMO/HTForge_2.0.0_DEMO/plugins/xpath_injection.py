"""HT Forge 1.7 - XPath Injection candidate detector."""
from plugins._new_detectors_common import error_probe
from core.payloads_1_8 import XPATH
PLUGIN_TYPE="xpath_injection"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    error_probe(ctx,PLUGIN_TYPE,"XPath Injection",
        [r"XPathException",r"XPath.*error",r"javax\.xml\.xpath",r"invalid.*xpath",r"expression.*error"],
        list(XPATH))
    return {}
