"""HT Forge 1.7 - SSTI candidate detector."""
from urllib.parse import quote
from core.payloads_1_8 import SSTI
from plugins._new_detectors_common import targets, query_params, probe_param, response_text, add
PLUGIN_TYPE="ssti"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    probes=list(SSTI)
    for base in targets(ctx):
        ps=query_params(base)
        if not ps: continue
        for i,(name,_) in enumerate(ps[:8]):
            for payload,expected in probes:
                u,r=probe_param(ctx,base,i,payload)
                if r is not None and expected in response_text(r):
                    add(ctx,PLUGIN_TYPE,f"Posible SSTI en parámetro {name}","medium",
                        "La expresión de prueba produjo un resultado evaluado; confirmar el motor de plantillas y el contexto manualmente.",
                        u,{"parameter":name,"probe":payload,"result":expected},"medium")
                    break
    return {}
