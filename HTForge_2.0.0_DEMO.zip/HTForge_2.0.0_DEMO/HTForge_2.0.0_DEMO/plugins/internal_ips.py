#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Internal IP disclosure.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='internal_ips'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
import re
def run(ctx):
 r=request(ctx,ctx.target)
 if not r:return {}
 text=getattr(r,"text","")[:50000]
 ips=sorted(set(re.findall(r"\b(?:10\.\d{1,3}|192\.168\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3})\.\d{1,3}\b",text)))
 if ips:add(ctx,"Direcciones IP internas expuestas","low","Se observaron direcciones RFC1918 en contenido público.",ctx.target,{"count":len(ips)},"high")
 return {}

