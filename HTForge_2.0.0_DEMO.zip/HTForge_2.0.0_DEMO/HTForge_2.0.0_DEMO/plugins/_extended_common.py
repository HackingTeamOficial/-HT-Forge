from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse, urljoin
import re

def request(ctx, url):
    try:
        return ctx.req("GET", url, timeout=8)
    except Exception as e:
        ctx.log("debug", f"probe failed: {e}")
        return None

def add(ctx, title, severity="info", detail="", url=None, evidence=None, confidence="medium"):
    f={"type":PLUGIN_TYPE,"severity":severity,"title":title,"detail":detail,"confidence":confidence,"requires_human_review":True}
    if url: f["url"]=url
    if evidence: f["evidence"]=evidence
    ctx.finding(f)

def urls_from_ctx(ctx):
    urls=ctx.get("discovered_urls",[]) or []
    return list(dict.fromkeys([ctx.target]+[u for u in urls if isinstance(u,str) and u.startswith(("http://","https://"))]))[:30]

def params(url):
    return parse_qsl(urlparse(url).query, keep_blank_values=True)

def check_reflection(ctx, label, severity="low"):
    seen=set()
    for base in urls_from_ctx(ctx):
        ps=params(base)
        if not ps: continue
        for i,(k,v) in enumerate(ps[:8]):
            marker=f"HTF_{label.upper()}_{i}"
            q=list(ps); q[i]=(k,marker)
            u=urlunparse(urlparse(base)._replace(query=urlencode(q,doseq=True)))
            r=request(ctx,u)
            if r is not None and marker in getattr(r,"text","") and u not in seen:
                seen.add(u); add(ctx,f"Posible {label} en parámetro {k}",severity,f"El valor de prueba no ejecutable fue reflejado por la aplicación. Esto es un indicador y requiere validación manual.",u,{"parameter":k,"marker":marker,"status":getattr(r,"status_code",None)},"low")

