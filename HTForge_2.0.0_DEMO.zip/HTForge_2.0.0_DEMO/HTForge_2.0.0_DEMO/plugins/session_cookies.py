#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Session and Cookie Security.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='session_cookies'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
from urllib.parse import urlparse
def run(ctx):
 r=request(ctx,ctx.target)
 if not r:return {}
 for c in getattr(r,"headers",{}).get("set-cookie","").split(";"):
  pass
 raw=getattr(r,"headers",{}).get("set-cookie","")
 low=raw.lower()
 if raw:
  for attr,title in [("secure","Cookie sin Secure"),("httponly","Cookie sin HttpOnly"),("samesite","Cookie sin SameSite")]:
   if attr not in low:add(ctx,title,"low","La respuesta establece cookies sin el atributo de seguridad indicado.",ctx.target,{"set-cookie":raw[:1000]},"medium")
 return {"findings":ctx.get_report().get("findings",[])}

