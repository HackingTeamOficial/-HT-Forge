"""HT Forge 1.7 - JWT key/algorithm confusion candidate detector.
Parses observed JWTs without forging or altering authentication requests.
"""
import base64, json, re
from plugins._new_detectors_common import add

PLUGIN_TYPE='jwt_key_confusion'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]
JWT_RE=re.compile(r'^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$')

def _b64(s):
    return base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4))

def _tokens(ctx):
    vals=[]
    for key in ('authorization','Authorization','token','jwt','access_token','id_token'):
        v=ctx.get(key,None)
        if isinstance(v,str): vals.append(v.removeprefix('Bearer ').strip())
    for u in [ctx.target]+(ctx.get('discovered_urls',[]) or []):
        if isinstance(u,str):
            vals.extend(re.findall(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?![A-Za-z0-9_-])',u))
    return list(dict.fromkeys(vals))[:50]

def run(ctx):
    for token in _tokens(ctx):
        if not JWT_RE.match(token): continue
        try: header=json.loads(_b64(token.split('.')[0]).decode('utf-8'))
        except Exception: continue
        alg=str(header.get('alg','')).upper(); kid=header.get('kid')
        if alg in {'HS256','HS384','HS512'} and kid:
            add(ctx,PLUGIN_TYPE,'JWT HS* con kid — revisar posible confusión de claves','medium',
                'El token observado usa una familia HMAC y referencia un kid. Esto por sí solo no demuestra key confusion; revisar que el servidor no reutilice material de clave asimétrico como secreto HMAC.',ctx.target,
                {'algorithm':alg,'kid':str(kid)[:200],'token_source':'observed'},'low')
    return {}
