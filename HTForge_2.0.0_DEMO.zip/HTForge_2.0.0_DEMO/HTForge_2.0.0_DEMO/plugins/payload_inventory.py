"""HT Forge 1.8 payload inventory plugin.

Reports the available bounded payload families to the scan log. It performs
no network requests and is useful for diagnostics/reproducibility.
"""
from core.payloads_1_8 import PAYLOAD_COUNTS
__version__="1.8"; __author__="HT Team"; PHASE="recon"; REQUIRES=[]
def run(ctx):
    total=sum(PAYLOAD_COUNTS.values())
    ctx.log("info", f"HT Forge 1.8 payload registry: {total} bounded probes/pairs across {len(PAYLOAD_COUNTS)} families")
    ctx._payload_inventory = dict(PAYLOAD_COUNTS)
    return {"payload_inventory": PAYLOAD_COUNTS}
