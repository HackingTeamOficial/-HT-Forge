#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Unnecessarily exposed services.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='exposed_services'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
def run(ctx):
    ctx.log("debug", "Módulo exposed_services habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
