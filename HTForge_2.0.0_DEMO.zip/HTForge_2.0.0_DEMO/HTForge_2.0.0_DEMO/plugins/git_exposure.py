#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: .git exposed.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='git_exposure'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
from urllib.parse import urljoin
def run(ctx):
 u=urljoin(ctx.target,"/.git/HEAD"); r=request(ctx,u)
 if r and getattr(r,"status_code",0)==200 and "ref:" in getattr(r,"text",""): add(ctx,"Repositorio .git expuesto","high","/.git/HEAD es accesible públicamente.",u,{"status":r.status_code},"high")
 return {}

