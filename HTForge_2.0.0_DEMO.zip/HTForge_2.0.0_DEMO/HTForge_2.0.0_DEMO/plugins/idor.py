#!/usr/bin/env python3
"""IDOR/BOLA differential detector for authorized labs and assessments."""
import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context

ID_PARAM = re.compile(r'(^|_)(id|uid|user|account|order|document|file|invoice|profile|customer|object)(_|$)', re.I)
PATH_ID = re.compile(r'(?P<prefix>/)(?P<id>\d+)(?P<suffix>(?:/|$))')

def _set_param(url, param, value):
    p=urlsplit(url); pairs=parse_qsl(p.query, keep_blank_values=True); out=[]; replaced=False
    for k,v in pairs:
        if k==param and not replaced: out.append((k,str(value))); replaced=True
        else: out.append((k,v))
    if not replaced: out.append((param,str(value)))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))

def _set_path_id(url, old, new):
    p=urlsplit(url)
    path=p.path.replace('/'+str(old)+'/', '/'+str(new)+'/', 1)
    if path == p.path:
        path=p.path[:-len(str(old))] + str(new) if p.path.endswith(str(old)) else p.path
    return urlunsplit((p.scheme,p.netloc,path,p.query,p.fragment))

def _fp(resp):
    text=(getattr(resp,'text','') or '')
    return (int(getattr(resp,'status_code',0) or 0), len(text), hashlib.sha256(text[:10000].encode('utf-8','ignore')).hexdigest())

def _candidate(info):
    param=str(info.get('param') or '')
    if ID_PARAM.search(param): return ('query', param)
    url=str(info.get('url',''))
    m=PATH_ID.search(url)
    if m: return ('path', m.group('id'))
    return (None, None)

def run(ctx: Context):
    findings=[]
    params=ctx.get('discovered_params', []) or []
    candidates=[]
    for p in params:
        kind,key=_candidate(p)
        if kind: candidates.append((p,kind,key))
    if not candidates:
        candidates=[({'url':ctx.target,'param':'id','method':'GET','baseline_value':'1'},'query','id')]
    ctx.log('info', f'Analizando IDOR/BOLA en {ctx.target} ({len(candidates)} candidatos)')
    for info,kind,key in candidates[:int(ctx.config.get('idor_max_params',30))]:
        if ctx.stopped or str(info.get('method','GET')).upper()!='GET': continue
        url=str(info.get('url',ctx.target)); original=str(info.get('baseline_value') or '')
        if kind=='path':
            m=PATH_ID.search(url); original=m.group('id') if m else '1'
            make=lambda v: _set_path_id(url, original, v)
            param=f'path:{original}'
        else:
            if not original.isdigit(): original='1'
            make=lambda v: _set_param(url,key,v)
            param=key
        try:
            base=ctx.req('GET',make(original),timeout=10); bfp=_fp(base)
            variants=[]
            n=int(original)
            for val in (n+1,n+2,n+10):
                if ctx.stopped: break
                resp=ctx.req('GET',make(val),timeout=10); fp=_fp(resp)
                # Distinct successful object responses are a candidate, not proof.
                if fp[0] in (200,206) and fp[2]!=bfp[2] and fp[1]>0:
                    variants.append((val,fp))
            if variants:
                findings.append({'type':'idor','severity':'medium','title':'Posible IDOR / BOLA',
                    'detail':f"El identificador '{param}' permite obtener respuestas distintas sin que el detector pueda demostrar autorización.",
                    'confidence':0.55 if len(variants)==1 else 0.72,
                    'evidence':{'url':url,'parameter':param,'method':'GET',
                        'baseline':{'id':original,'status':bfp[0],'length':bfp[1]},
                        'variants':[{'id':v,'status':fp[0],'length':fp[1]} for v,fp in variants],
                        'note':'Candidato BOLA/IDOR. La confirmación requiere comparar dos identidades/sesiones y verificar propiedad del objeto.'},
                    'url':url,'parameter':param})
                ctx.log('ok', f'Posible IDOR/BOLA en {param}')
        except Exception as e:
            if not ctx.stopped: ctx.log('warn', f'Error probando IDOR en {param}: {e}')
    return {'findings':findings}

__version__='1.8.1'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
