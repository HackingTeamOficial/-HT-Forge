"""HT Forge 1.7 - NoSQL Injection candidate detector."""
from plugins._new_detectors_common import error_probe
from core.payloads_1_8 import NOSQL
PLUGIN_TYPE="nosql_injection"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    error_probe(ctx,PLUGIN_TYPE,"NoSQL Injection",
        [r"Mongo(?:Error|ServerError)",r"MongoDB",r"BSON",r"CastError",r"Mongoose",r"$where",r"query selector"],
        list(NOSQL))
    return {}
