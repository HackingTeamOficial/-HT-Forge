"""HT Forge 1.7 - JWT alg:none detector.
Only identifies observed tokens declaring an unsecured algorithm; it never forges a token.
"""
import base64, json, re
from plugins._new_detectors_common import add

PLUGIN_TYPE='jwt_alg_none'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]
JWT_RE=re.compile(r'^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$')

def _decode(s):
    return json.loads(base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4)).decode('utf-8'))

def _tokens(ctx):
    vals=[]
    for key in ('authorization','Authorization','token','jwt','access_token','id_token'):
        v=ctx.get(key,None)
        if isinstance(v,str): vals.append(v.removeprefix('Bearer ').strip())
    for u in [ctx.target]+(ctx.get('discovered_urls',[]) or []):
        if isinstance(u,str): vals += re.findall(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?![A-Za-z0-9_-])',u)
    return list(dict.fromkeys(vals))[:50]

def run(ctx):
    for token in _tokens(ctx):
        if not JWT_RE.match(token): continue
        try: header=_decode(token.split('.')[0])
        except Exception: continue
        alg=str(header.get('alg','')).lower()
        if alg=='none':
            add(ctx,PLUGIN_TYPE,'JWT declara algoritmo none','high',
                'Se observó un JWT cuyo encabezado declara alg=none. Esto no confirma que el servidor acepte el token sin firma; requiere validación humana de la política de verificación.',ctx.target,
                {'algorithm':'none','token_source':'observed','token_prefix':token[:24]+'…'},'high')
    return {}
