#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: API keys exposure.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='api_keys'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
import re
def run(ctx):
 for u in urls_from_ctx(ctx):
  r=request(ctx,u)
  if not r: continue
  text=getattr(r,"text","")[:50000]
  if re.search(r"(?i)(api[_-]?key|access[_-]?token|client[_-]?secret)\s*[:=]\s*[\"']?[A-Za-z0-9_\-]{16,}",text): add(ctx,"Posible API key/credencial expuesta","high","Se detectó un patrón de secreto en contenido público; el valor no se incluye en el hallazgo.",u,None,"medium")
 return {}

