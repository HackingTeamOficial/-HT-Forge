#!/usr/bin/env python3
"""plugins/jsecret.py - Detección de secretos en JavaScript"""

import re
from typing import Dict, List
from core.context import Context

JS_SECRET_PATTERNS = [
    (re.compile(r'["\']?api[_-]?key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']'), 'API Key'),
    (re.compile(r'["\']?secret[_-]?key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']'), 'Secret Key'),
    (re.compile(r'["\']?access[_-]?token["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']'), 'Access Token'),
    (re.compile(r'["\']?auth[_-]?token["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']'), 'Auth Token'),
    (re.compile(r'AKIA[0-9A-Z]{16}'), 'AWS Access Key ID'),
    (re.compile(r'[a-zA-Z0-9/+=]{40}'), 'Generic Secret (base64-like)'),
    (re.compile(r'sk_live_[0-9a-zA-Z]{24}'), 'Stripe Live Key'),
    (re.compile(r'sk_test_[0-9a-zA-Z]{24}'), 'Stripe Test Key'),
    (re.compile(r'xoxb-[0-9]+-[0-9]+-[a-zA-Z0-9]+'), 'Slack Bot Token'),
    (re.compile(r'ghp_[a-zA-Z0-9]{36}'), 'GitHub PAT'),
    (re.compile(r'glpat-[a-zA-Z0-9\-_]{20}'), 'GitLab PAT'),
    (re.compile(r'firebase_[a-zA-Z0-9_\-]{30,}'), 'Firebase Key'),
    (re.compile(r'AIza[0-9A-Za-z\-_]{35}'), 'Google API Key'),
]


def run(ctx: Context) -> Dict:
    """Analiza archivos JS en busca de secretos"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Analizando JavaScript en busca de secretos: {target}")
    
    # Obtener URLs descubiertas por crawler
    js_urls = ctx.get('discovered_js_urls', [])
    
    # Si no hay URLs JS, buscar en el HTML principal
    if not js_urls:
        try:
            resp = ctx.req('GET', target, timeout=10)
            content = resp.text
            # Extraer scripts
            scripts = re.findall(r'<script[^>]*src=["\']([^"\']+)["\']', content, re.IGNORECASE)
            for src in scripts:
                from urllib.parse import urljoin
                js_urls.append(urljoin(target, src))
            # También inline scripts
            inline_scripts = re.findall(r'<script[^>]*>(.*?)</script>', content, re.IGNORECASE | re.DOTALL)
            for script in inline_scripts:
                if len(script) > 100:
                    js_urls.append(f"inline://{target}")
        except Exception:
            pass
    
    # Analizar cada JS
    for js_url in js_urls[:20]:
        if ctx.stopped:
            break
        
        if js_url.startswith('inline://'):
            continue  # Ya analizado inline
        
        try:
            resp = ctx.req('GET', js_url, timeout=8)
            content = resp.text
            
            if len(content) < 100:
                continue
            
            found_secrets = []
            for pattern, name in JS_SECRET_PATTERNS:
                matches = pattern.findall(content)
                if matches:
                    for match in matches[:3]:
                        found_secrets.append({'type': name, 'value': match[:50]})
            
            if found_secrets:
                findings.append({
                    'type': 'js_secret',
                    'severity': 'high',
                    'title': 'Secretos en JavaScript',
                    'detail': f"Secrets encontrados en {js_url}",
                    'evidence': {
                        'url': js_url,
                        'secrets': found_secrets,
                        'file_size': len(content)
                    },
                    'url': js_url
                })
                ctx.log('ok', f"Secretos en JS: {js_url}")
                
        except Exception as e:
            ctx.log('warn', f"Error analizando JS {js_url}: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = ["crawler"]