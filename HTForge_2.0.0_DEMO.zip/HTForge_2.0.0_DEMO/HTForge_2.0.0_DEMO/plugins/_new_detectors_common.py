"""Helpers used only by the new 1.7 extended detectors.
Existing HT Forge modules do not import this file.
"""
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
import re

def req(ctx, url, **kwargs):
    try:
        return ctx.req("GET", url, **kwargs)
    except Exception as exc:
        ctx.log("debug", f"probe failed: {exc}")
        return None

def add(ctx, plugin_type, title, severity, detail, url=None, evidence=None, confidence="low"):
    f={"type":plugin_type,"severity":severity,"title":title,"detail":detail,
       "confidence":confidence,"requires_human_review":True}
    if url: f["url"]=url
    if evidence: f["evidence"]=evidence
    ctx.finding(f)

def targets(ctx, limit=20):
    raw=ctx.get("discovered_urls",[]) or []
    out=[]
    for u in [ctx.target]+raw:
        if isinstance(u,str) and u.startswith(("http://","https://")) and u not in out:
            out.append(u)
    return out[:limit]

def query_params(url):
    return parse_qsl(urlparse(url).query, keep_blank_values=True)

def probe_param(ctx, url, index, value):
    ps=query_params(url)
    if not ps or index >= len(ps): return None, None
    original=ps[index][1]
    ps[index]=(ps[index][0], value)
    u=urlunparse(urlparse(url)._replace(query=urlencode(ps,doseq=True)))
    return u, req(ctx,u,allow_redirects=True)

def response_text(r):
    return str(getattr(r,"text","") or "")

def error_probe(ctx, plugin_type, label, patterns, payloads, severity="medium"):
    """Look for differential error evidence after inert syntax probes.
    This is intentionally a candidate detector; it never claims exploitation.
    """
    for base in targets(ctx):
        ps=query_params(base)
        if not ps: continue
        baseline=req(ctx,base)
        if baseline is None: continue
        base_text=response_text(baseline)
        for i,(name,value) in enumerate(ps[:8]):
            for payload in payloads:
                u,r=probe_param(ctx,base,i,payload)
                if r is None: continue
                text=response_text(r)
                hits=[p for p in patterns if re.search(p,text,re.I)]
                if hits and not any(re.search(p,base_text,re.I) for p in patterns):
                    add(ctx,plugin_type,f"Posible {label} en parámetro {name}",severity,
                        "La respuesta presenta errores o cambios compatibles con una entrada especialmente interpretada; requiere validación humana.",
                        u,{"parameter":name,"probe":payload,"matched":hits[:3],"status":getattr(r,"status_code",None)},"low")
                    break

def reflection_probe(ctx, plugin_type, label, markers):
    for base in targets(ctx):
        ps=query_params(base)
        if not ps: continue
        for i,(name,value) in enumerate(ps[:8]):
            marker=markers[i % len(markers)]
            u,r=probe_param(ctx,base,i,marker)
            if r is not None and marker in response_text(r):
                add(ctx,plugin_type,f"Indicador de {label} en parámetro {name}","low",
                    "El marcador fue reflejado; esto es únicamente un indicador y requiere validación manual.",
                    u,{"parameter":name,"marker":marker},"low")
