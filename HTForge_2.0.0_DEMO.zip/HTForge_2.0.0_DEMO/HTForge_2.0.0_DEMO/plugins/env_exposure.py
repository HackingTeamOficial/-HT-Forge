#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: .env exposed.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='env_exposure'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
from urllib.parse import urljoin
def run(ctx):
 for p in ("/.env","/.env.local","/.env.production"):
  u=urljoin(ctx.target,p); r=request(ctx,u)
  if r and getattr(r,"status_code",0)==200 and any(x in getattr(r,"text","") for x in ("APP_","DB_","SECRET","API_KEY","PASSWORD")): add(ctx,"Archivo de entorno potencialmente expuesto","high","Se encontró un archivo de entorno accesible; no se almacena su contenido.",u,{"status":r.status_code},"high")
 return {}

