"""HT Forge 1.7 - HTTP Request Smuggling candidate detector.
Passive/differential checks only; it does not send ambiguous CL/TE attack requests.
"""
from plugins._new_detectors_common import req, add
PLUGIN_TYPE="http_smuggling"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    r=req(ctx,ctx.target,allow_redirects=False)
    if r is None: return {}
    h={str(k).lower():str(v) for k,v in getattr(r,"headers",{}).items()}
    server=h.get("server","")
    via=h.get("via","")
    te=h.get("transfer-encoding","")
    cl=h.get("content-length","")
    if te and cl:
        add(ctx,PLUGIN_TYPE,"Configuración HTTP que requiere revisión para request smuggling","medium",
            "La respuesta expone simultáneamente Transfer-Encoding y Content-Length. Esto no demuestra vulnerabilidad, pero merece revisión de normalización entre proxies y backend.",
            ctx.target,{"transfer_encoding":te,"content_length":cl,"server":server,"via":via},"low")
    elif server and via:
        add(ctx,PLUGIN_TYPE,"Cadena de proxy/backend detectada — revisar request smuggling","info",
            "Se observaron cabeceras que sugieren más de una capa HTTP; revisar discrepancias de parsing manualmente.",
            ctx.target,{"server":server,"via":via},"low")
    return {}
