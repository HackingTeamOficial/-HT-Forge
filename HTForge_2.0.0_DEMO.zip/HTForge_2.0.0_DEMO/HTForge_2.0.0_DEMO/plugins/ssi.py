"""HT Forge 1.7 - Server-Side Includes candidate detector."""
from plugins._new_detectors_common import reflection_probe
PLUGIN_TYPE="ssi"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    # Marker is harmless and only identifies reflection; no executable SSI directive is sent.
    reflection_probe(ctx,PLUGIN_TYPE,"Server-Side Includes",["HTF_SSI_MARKER_7A1","HTF_SSI_MARKER_7B2"])
    return {}
