#!/usr/bin/env python3
"""Fingerprint y comprobaciones básicas de WordPress."""
from urllib.parse import urljoin
from core.context import Context
PATHS=['/wp-login.php','/wp-json/','/wp-content/','/wp-includes/']
def run(ctx):
    ctx.log("debug", "Módulo wordpress habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
