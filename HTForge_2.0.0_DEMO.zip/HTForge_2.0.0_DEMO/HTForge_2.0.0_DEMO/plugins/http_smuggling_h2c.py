"""HT Forge 1.7 - HTTP/2 cleartext (h2c) candidate detector.
Uses a conservative protocol-upgrade probe and reports only observable support.
"""
from plugins._new_detectors_common import req, add, targets

PLUGIN_TYPE='http_smuggling_h2c'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]

def run(ctx):
    for base in targets(ctx, 20):
        if not base.startswith('http://'): continue
        try:
            r=ctx.req('OPTIONS',base,headers={
                'Connection':'Upgrade, HTTP2-Settings',
                'Upgrade':'h2c',
                'HTTP2-Settings':'AAMAAABkAAQAAP__',
            },allow_redirects=False,timeout=6)
        except Exception as exc:
            ctx.log('debug',f'h2c probe failed: {exc}')
            continue
        h={str(k).lower():str(v) for k,v in (getattr(r,'headers',{}) or {}).items()}
        status=int(getattr(r,'status_code',0) or 0)
        if status==101 and 'h2c' in h.get('upgrade','').lower():
            add(ctx,PLUGIN_TYPE,'HTTP/2 Cleartext (h2c) soportado','medium',
                'El servidor aceptó una actualización h2c. Revisar si proxies, balanceadores y backend comparten la misma política de protocolo y si el endpoint debe aceptar HTTP/2 sin TLS.',base,
                {'status':status,'upgrade':h.get('upgrade',''),'connection':h.get('connection','')},'high')
    return {}
