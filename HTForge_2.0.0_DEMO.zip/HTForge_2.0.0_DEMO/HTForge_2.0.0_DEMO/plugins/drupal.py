#!/usr/bin/env python3
"""Fingerprint de Drupal sin explotación."""
import re
from urllib.parse import urljoin
from core.context import Context
PATHS=['/core/CHANGELOG.txt','/user/login','/sites/default/']
def run(ctx):
    ctx.log("debug", "Módulo drupal habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
