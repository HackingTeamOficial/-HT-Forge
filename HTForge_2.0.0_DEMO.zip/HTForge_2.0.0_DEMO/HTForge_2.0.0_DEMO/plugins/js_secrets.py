#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: JavaScript secrets.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='js_secrets'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
import re
def run(ctx):
 for u in urls_from_ctx(ctx):
  r=request(ctx,u)
  if not r:continue
  for s in re.findall(r"(?i)(?:api[_-]?key|secret|token)[\"']?\s*[:=]\s*[\"']([A-Za-z0-9_\-]{20,})",getattr(r,"text",""))[:3]: add(ctx,"Posible secreto en JavaScript/contenido","high","Se detectó un patrón de secreto; el valor se omite por seguridad.",u,None,"low")
 return {}

