#!/usr/bin/env python3
from typing import Dict
"""Non-destructive command-injection/RCE indicator for authorized assessments.

Uses a unique echo canary instead of destructive commands or file reads. A
finding requires the exact server-side canary to appear in the response.
"""
import secrets
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context
from core.payloads_1_8 import CMDI_UNIX, CMDI_WINDOWS

UNIX_PAYLOADS = CMDI_UNIX
WINDOWS_PAYLOADS = CMDI_WINDOWS
PARAM_NAMES = re.compile(r'(^|_)(cmd|command|exec|execute|ping|host|ip|query|target)(_|$)', re.I)

def _set_param(url,param,value):
    p=urlsplit(url); pairs=parse_qsl(p.query,keep_blank_values=True); out=[]; replaced=False
    for k,v in pairs:
        if k==param and not replaced: out.append((k,value)); replaced=True
        else: out.append((k,v))
    if not replaced: out.append((param,value))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))

def run(ctx: Context) -> Dict:
    findings=[]
    params=ctx.get('discovered_params',[])
    params=[p for p in params if PARAM_NAMES.search(str(p.get('param','')))] or [
        {'url':ctx.target,'param':'cmd','method':'GET'}, {'url':ctx.target,'param':'exec','method':'GET'}, {'url':ctx.target,'param':'command','method':'GET'}]
    ctx.log('info', f"Analizando RCE en {ctx.target}")
    token='HTFORGE_'+secrets.token_hex(5)
    payloads=UNIX_PAYLOADS+WINDOWS_PAYLOADS
    for info in params[:int(ctx.config.get('rce_max_params',8))]:
        if ctx.stopped: break
        if str(info.get('method','GET')).upper()!='GET': continue
        url=str(info.get('url',ctx.target)); param=str(info.get('param'))
        for template in payloads:
            if ctx.stopped: break
            payload=template.format(token=token)
            try:
                resp=ctx.req('GET',_set_param(url,param,payload),timeout=10)
                text=getattr(resp,'text','') or ''
                status = int(getattr(resp, 'status_code', 0) or 0)
                # Stronger indicator: successful response, canary present, and the
                # complete injected payload is not simply reflected back. This is
                # still reported as a candidate, not proof of code execution.
                if token in text and status in (200,201,202,204,206,301,302,303,307,308) and payload not in text:
                    findings.append({'type':'rce','severity':'high','title':'Posible Command Injection / RCE — requiere confirmación',
                        'detail':f"Canario procesado en '{param}' sin reflejo del payload completo. Requiere confirmación independiente de ejecución.",
                        'confidence':0.85,
                        'evidence':{'url':_set_param(url,param,payload),'parameter':param,'payload':payload,'canary':token,'response_status':status},
                        'url':url,'parameter':param})
                    ctx.log('ok', f"Posible RCE/command injection en {param}; requiere confirmación")
                    break
            except Exception as e:
                if not ctx.stopped: ctx.log('warn',f"Error probando RCE en {param}: {e}")
    return {'findings':findings}

__version__='2.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
