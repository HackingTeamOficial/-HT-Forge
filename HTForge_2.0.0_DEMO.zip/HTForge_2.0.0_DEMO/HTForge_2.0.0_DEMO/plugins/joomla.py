#!/usr/bin/env python3
"""Fingerprint de Joomla sin explotación."""
import re
from urllib.parse import urljoin
from core.context import Context
PATHS=['/administrator/','/language/en-GB/en-GB.xml','/templates/']
def run(ctx):
    ctx.log("debug", "Módulo joomla habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
