#!/usr/bin/env python3
"""Detección conservadora de superficies XML potencialmente expuestas a XXE.
No intenta leer archivos ni usar servicios externos; solo identifica endpoints
XML y señales de parser XML en respuestas.
"""
import re
from urllib.parse import urljoin
from core.context import Context
XML_HINTS=re.compile(r'xml|soap|wsdl|saml|rss|atom',re.I)
PARSER_ERRORS=re.compile(r'(SAXParseException|XMLSyntaxError|EntityRef|external entity|entity .* not defined|parser error)',re.I)

def run(ctx: Context):
    findings=[]; target=ctx.target; urls=[]
    for u in [target, urljoin(target,'/xmlrpc.php'), urljoin(target,'/soap'), urljoin(target,'/api/xml'), urljoin(target,'/sitemap.xml')]:
        if u not in urls: urls.append(u)
    for info in ctx.get('discovered_urls',[])[:40]:
        if XML_HINTS.search(info) and info not in urls: urls.append(info)
    ctx.log('info',f"Buscando superficies XML/XXE en {target}")
    for url in urls[:20]:
        if ctx.stopped: break
        try:
            r=ctx.req('GET',url,timeout=8); ct=r.headers.get('Content-Type',''); text=r.text[:8000]
            ct_xml='xml' in ct.lower()
            parser_signal=bool(PARSER_ERRORS.search(text))
            if not (ct_xml or parser_signal):
                continue
            if parser_signal:
                severity='medium'; title='Señal de parser XML — revisar XXE'; confidence=0.72
                detail='Señal del parser XML observada; requiere validación controlada para confirmar XXE.'
                finding_type='xxe_parser_signal'
            else:
                severity='info'; title='Superficie XML detectada'; confidence=0.35
                detail='Endpoint relacionado con XML detectado; no se ha demostrado procesamiento inseguro de entidades externas.'
                finding_type='xml_surface'
            findings.append({'type':finding_type,'severity':severity,'title':title,'detail':detail,
                'confidence':confidence,'evidence':{'url':url,'content_type':ct,
                'parser_signal':parser_signal,'http_status':getattr(r,'status_code',None)},'url':url})
        except Exception as e:
            ctx.log('warn',f"Error XXE {url}: {e}")
    return {'findings':findings}

__version__='1.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
