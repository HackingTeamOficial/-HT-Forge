"""HT Forge 1.7 - Software/version disclosure detector."""
import re
from plugins._new_detectors_common import req, add
PLUGIN_TYPE="version_disclosure"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    r=req(ctx,ctx.target,allow_redirects=False)
    if r is None:return {}
    h=getattr(r,"headers",{}) or {}
    for key,value in h.items():
        k=str(key).lower(); v=str(value or "").strip()
        if k in ("server","x-powered-by","x-generator") and v:
            # Only flag actual component/version-looking values, not every header value.
            if re.search(r"\b(?:apache|nginx|iis|php|asp\.net|express|tomcat|jetty|server|\w+)[ /_-]*v?\d+(?:\.\d+){1,3}\b",v,re.I):
                add(ctx,PLUGIN_TYPE,"Información de versión expuesta","info",
                    f"La cabecera {k} revela información de software o versión.",ctx.target,{k:v},"high")
    return {}
