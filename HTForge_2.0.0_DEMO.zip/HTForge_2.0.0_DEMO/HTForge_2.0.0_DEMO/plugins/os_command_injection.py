"""HT Forge 1.7 - OS Command Injection candidate detector."""
from plugins._new_detectors_common import error_probe
PLUGIN_TYPE="os_command_injection"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    error_probe(ctx,PLUGIN_TYPE,"OS Command Injection",
        [r"command not found",r"syntax error",r"/bin/(?:sh|bash)",r"cmd\.exe",r"powershell",r"unexpected token"],
        ["'",'"',';','&&','|','$(x)','`x`'])
    return {}
