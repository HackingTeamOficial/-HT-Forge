#!/usr/bin/env python3
"""plugins/recon_cbh.py - Reconocimiento pasivo estilo CBH (Censys/BinaryEdge/Shodan)"""

import os
from typing import Dict, List
from core.context import Context


def run(ctx: Context) -> Dict:
    """Reconocimiento pasivo usando APIs públicas"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Reconocimiento pasivo (CBH) en {target}")
    
    # Extraer dominio
    from urllib.parse import urlparse
    domain = urlparse(target).netloc
    if not domain:
        domain = target
    
    # Subfinder (si está disponible)
    subfinder_bin = '/usr/local/go/bin/subfinder'
    if os.path.exists(subfinder_bin):
        try:
            import subprocess
            result = subprocess.run(
                [subfinder_bin, '-d', domain, '-silent', '-max-time', '30'],
                capture_output=True, text=True, timeout=60
            )
            subdomains = [s.strip() for s in result.stdout.split('\n') if s.strip()]
            if subdomains:
                ctx.set('discovered_subdomains', subdomains)
                findings.append({
                    'type': 'subdomains',
                    'severity': 'info',
                    'title': f'Subdominios encontrados ({len(subdomains)})',
                    'detail': f"Subfinder: {', '.join(subdomains[:10])}{'...' if len(subdomains) > 10 else ''}",
                    'evidence': {'subdomains': subdomains, 'source': 'subfinder'},
                    'url': target
                })
                ctx.log('ok', f"Subdominios: {len(subdomains)}")
        except Exception as e:
            ctx.log('warn', f"Subfinder error: {e}")
    
    # httpx para verificar vivos
    httpx_bin = '/usr/local/go/bin/httpx'
    if os.path.exists(httpx_bin) and ctx.get('discovered_subdomains'):
        try:
            import subprocess
            subs = '\n'.join(ctx.get('discovered_subdomains', [])[:50])
            result = subprocess.run(
                [httpx_bin, '-silent', '-status-code', '-title', '-tech-detect'],
                input=subs, capture_output=True, text=True, timeout=60
            )
            alive = [l for l in result.stdout.split('\n') if l.strip()]
            if alive:
                findings.append({
                    'type': 'live_hosts',
                    'severity': 'info',
                    'title': f'Hosts vivos ({len(alive)})',
                    'detail': f"httpx confirmó {len(alive)} hosts respondiendo",
                    'evidence': {'hosts': alive, 'source': 'httpx'},
                    'url': target
                })
                ctx.log('ok', f"Hosts vivos: {len(alive)}")
        except Exception as e:
            ctx.log('warn', f"httpx error: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []