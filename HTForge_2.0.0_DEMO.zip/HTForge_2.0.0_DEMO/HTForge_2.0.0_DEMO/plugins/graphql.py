#!/usr/bin/env python3
"""Descubrimiento de endpoints GraphQL sin ejecutar consultas de introspección."""
from urllib.parse import urljoin
from core.context import Context
PATHS=['/graphql','/api/graphql','/graphql/']
def run(ctx):
    ctx.log("debug", "Módulo graphql habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
