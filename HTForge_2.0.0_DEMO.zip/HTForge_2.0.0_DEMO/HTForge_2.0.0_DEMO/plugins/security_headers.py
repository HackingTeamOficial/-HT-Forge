"""HT Forge 1.7 - Security headers detector."""
from plugins._new_detectors_common import req, add
PLUGIN_TYPE="security_headers"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    r=req(ctx,ctx.target,allow_redirects=False)
    if r is None:return {}
    h={str(k).lower():str(v) for k,v in getattr(r,"headers",{}).items()}
    required=[("content-security-policy","Falta Content-Security-Policy"),
              ("x-content-type-options","Falta X-Content-Type-Options"),
              ("referrer-policy","Falta Referrer-Policy"),
              ("permissions-policy","Falta Permissions-Policy")]
    if str(ctx.target).lower().startswith("https://"):
        required.insert(1,("strict-transport-security","Falta Strict-Transport-Security"))
    for key,title in required:
        if key not in h:
            add(ctx,PLUGIN_TYPE,title,"low","Cabecera de seguridad no observada en la respuesta inicial; revisar según el tipo de recurso y política de la aplicación.",ctx.target,{"missing":key},"high")
    return {}
