#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Directory listing.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='directory_listing'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
def run(ctx):
 for u in urls_from_ctx(ctx):
  r=request(ctx,u)
  if r and getattr(r,"status_code",0)==200 and "index of /" in getattr(r,"text","").lower(): add(ctx,"Directory Listing detectado","medium","La respuesta parece ser un listado de directorio.",u,{"status":r.status_code},"high")
 return {}

