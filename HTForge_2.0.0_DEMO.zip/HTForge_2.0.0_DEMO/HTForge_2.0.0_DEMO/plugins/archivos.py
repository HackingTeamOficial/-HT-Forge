#!/usr/bin/env python3
"""plugins/archivos.py - Descubrimiento de archivos sensibles"""

import re
from typing import Dict, List
from core.context import Context

SENSITIVE_FILES = [
    '.git/config', '.git/HEAD', '.gitignore',
    '.env', '.env.local', '.env.production', '.env.development',
    'config.php', 'config.json', 'config.yaml', 'config.yml',
    'settings.py', 'local_settings.py', 'settings.local.py',
    'wp-config.php', 'configuration.php', 'settings.php',
    'docker-compose.yml', 'docker-compose.yaml', 'Dockerfile',
    'package.json', 'composer.json', 'requirements.txt', 'Pipfile', 'pyproject.toml',
    'robots.txt', 'sitemap.xml', 'security.txt',
    'backup.sql', 'dump.sql', 'database.sql',
    'id_rsa', 'id_dsa', 'id_ecdsa', 'id_ed25519',
    'authorized_keys', 'known_hosts',
    '.htaccess', '.htpasswd', 'web.config',
    'phpinfo.php', 'info.php', 'test.php',
    'server-status', 'server-info',
    'api-docs', 'swagger.json', 'openapi.json',
    'README.md', 'CHANGELOG.md', 'LICENSE',
    '.DS_Store', 'Thumbs.db',
]

SENSITIVE_PATTERNS = [
    (re.compile(r'AKIA[0-9A-Z]{16}'), 'AWS Access Key'),
    (re.compile(r'[a-zA-Z0-9/+=]{40}'), 'Generic API Key'),
    (re.compile(r'sk_live_[0-9a-zA-Z]{24}'), 'Stripe Live Key'),
    (re.compile(r'sk_test_[0-9a-zA-Z]{24}'), 'Stripe Test Key'),
    (re.compile(r'xoxb-[0-9]+-[0-9]+-[a-zA-Z0-9]+'), 'Slack Bot Token'),
    (re.compile(r'xoxp-[0-9]+-[0-9]+-[a-zA-Z0-9]+'), 'Slack User Token'),
    (re.compile(r'ghp_[a-zA-Z0-9]{36}'), 'GitHub Personal Access Token'),
    (re.compile(r'gho_[a-zA-Z0-9]{36}'), 'GitHub OAuth Token'),
    (re.compile(r'glpat-[a-zA-Z0-9\-_]{20}'), 'GitLab Personal Access Token'),
]


def run(ctx: Context) -> Dict:
    """Busca archivos sensibles expuestos"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Buscando archivos sensibles en {target}")
    
    base_url = target.rstrip('/')
    try:
        baseline = ctx.req('GET', base_url, timeout=8, allow_redirects=True)
        baseline_body = getattr(baseline, 'content', b'') or b''
        baseline_hash = __import__('hashlib').sha256(baseline_body).hexdigest()
        baseline_type = (baseline.headers.get('Content-Type','') or '').lower()
    except Exception:
        baseline_body = b''; baseline_hash = ''; baseline_type = ''
    
    for filepath in SENSITIVE_FILES[:30]:  # Limitar
        if ctx.stopped:
            break
        
        test_url = f"{base_url}/{filepath}"
        
        try:
            resp = ctx.req('GET', test_url, timeout=8, allow_redirects=True)
            
            if resp.status_code == 200:
                content = resp.text
                # Muchos sitios devuelven la misma página 200 para cualquier
                # ruta (SPA/catch-all). No marcarla como archivo expuesto.
                body = getattr(resp, 'content', b'') or b''
                body_hash = __import__('hashlib').sha256(body).hexdigest()
                if baseline_hash and body_hash == baseline_hash:
                    continue
                ctype = (resp.headers.get('Content-Type','') or '').lower()
                if 'text/html' in ctype and filepath not in ('swagger.json','openapi.json','robots.txt','sitemap.xml','security.txt'):
                    # Para HTML exigimos una señal del archivo solicitado.
                    if filepath not in content and not any(marker in content_lower for marker in ('password', 'secret', 'api_key', 'private_key', 'database', 'authorization')):
                        continue
                content_lower = content.lower()
                
                # Verificar si es contenido real (no página de error genérica)
                if len(content) > 50 and 'not found' not in content_lower and '404' not in content_lower[:100]:
                    
                    # Buscar patrones sensibles
                    matched_patterns = []
                    for pattern, name in SENSITIVE_PATTERNS:
                        if pattern.search(content):
                            matched_patterns.append(name)
                    
                    severity = 'high' if matched_patterns else 'medium'
                    if filepath in ('.env', 'config.php', 'wp-config.php', 'settings.py', 'id_rsa', '.git/config'):
                        severity = 'critical'
                    
                    findings.append({
                        'type': 'sensitive_file',
                        'severity': severity,
                        'title': f'Archivo sensible expuesto: {filepath}',
                        'detail': f"Archivo accesible: {test_url}" + (f" | Patrones: {', '.join(matched_patterns)}" if matched_patterns else ""),
                        'evidence': {
                            'url': test_url,
                            'file': filepath,
                            'status_code': resp.status_code,
                            'content_length': len(content),
                            'matched_patterns': matched_patterns,
                            'preview': content[:300]
                        },
                        'url': test_url
                    })
                    ctx.log('ok', f"Archivo sensible: {filepath}")
                    
        except Exception as e:
            pass  # Silencioso para archivos que no existen
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []