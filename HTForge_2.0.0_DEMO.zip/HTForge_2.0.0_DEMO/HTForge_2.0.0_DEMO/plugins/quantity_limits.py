#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Missing quantity limits.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='quantity_limits'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
def run(ctx):
    ctx.log("debug", "Módulo quantity_limits habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
