#!/usr/bin/env python3
"""Detección de redirecciones abiertas mediante una comprobación controlada."""
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
from core.context import Context
PARAMS={'next','url','uri','redirect','redirect_url','return','return_url','continue','dest','destination','link'}
CANARY='https://example.com/'
def set_param(url,name,value):
    p=urlsplit(url); q=parse_qsl(p.query,keep_blank_values=True); out=[]; found=False
    for k,v in q:
        if k==name and not found: out.append((k,value)); found=True
        else: out.append((k,v))
    if not found: out.append((name,value))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))
def run(ctx):
    ctx.log("debug", "Módulo open_redirect habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
