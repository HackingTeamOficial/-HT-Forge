#!/usr/bin/env python3
"""Descubrimiento seguro de superficies API comunes."""
from urllib.parse import urljoin
from core.context import Context
PATHS=['/openapi.json','/swagger.json','/swagger/','/api/','/api/docs','/docs']
def run(ctx):
    ctx.log("debug", "Módulo api habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
