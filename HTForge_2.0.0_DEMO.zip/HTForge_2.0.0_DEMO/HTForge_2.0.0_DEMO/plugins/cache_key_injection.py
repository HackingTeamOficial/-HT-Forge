"""HT Forge 1.7 - Cache-key injection candidate detector.
Conservative checks for cache/CDN indicators and potentially unkeyed inputs.
No cache poisoning payloads are sent.
"""
from urllib.parse import urlparse, parse_qsl
from plugins._new_detectors_common import req, add, targets

PLUGIN_TYPE='cache_key_injection'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]
CACHE_HEADERS={'age','x-cache','x-cache-hits','cf-cache-status','x-served-by','x-cache-status','via','cache-control','vary','etag'}
SUSPICIOUS_INPUTS={'x-forwarded-host','x-forwarded-proto','x-forwarded-port','x-original-url','x-rewrite-url'}

def run(ctx):
    for base in targets(ctx, 20):
        r=req(ctx,base,allow_redirects=False)
        if r is None: continue
        h={str(k).lower():str(v) for k,v in (getattr(r,'headers',{}) or {}).items()}
        cache={k:h[k] for k in CACHE_HEADERS if k in h}
        if not cache: continue
        qs={k for k,_ in parse_qsl(urlparse(base).query,keep_blank_values=True)}
        vary={x.strip().lower() for x in h.get('vary','').split(',') if x.strip()}
        evidence={'cache_headers':cache,'query_parameters':sorted(qs)[:30],'vary':sorted(vary)}
        if 'vary' not in h or not vary:
            add(ctx,PLUGIN_TYPE,'Configuración de caché requiere revisión de clave','low',
                'Se detectaron indicadores de caché/CDN sin una política Vary visible. Esto no confirma una inyección de clave; revisar qué entradas forman la cache key y cuáles se excluyen.',base,evidence,'low')
        elif SUSPICIOUS_INPUTS & vary:
            add(ctx,PLUGIN_TYPE,'Entrada sensible participa en Vary — revisar cache key','low',
                'Una cabecera relacionada con reescritura/proxy aparece en Vary. Revisar la correspondencia entre Vary, cache key y normalización del proxy.',base,evidence,'low')
    return {}
