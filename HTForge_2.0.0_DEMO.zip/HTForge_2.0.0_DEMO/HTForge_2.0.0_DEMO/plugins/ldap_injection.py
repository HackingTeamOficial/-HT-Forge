"""HT Forge 1.7 - LDAP Injection candidate detector."""
from plugins._new_detectors_common import error_probe
from core.payloads_1_8 import LDAP
PLUGIN_TYPE="ldap_injection"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    error_probe(ctx,PLUGIN_TYPE,"LDAP Injection",
        [r"ldap",r"invalid filter",r"filter.*error",r"javax\.naming",r"LdapException",r"Bad search filter"],
        list(LDAP))
    return {}
