"""HT Forge 1.7 - WebSocket smuggling candidate detector.
Passive/evidence-oriented checks. Does not attempt to hijack or tunnel traffic.
"""
import re
from plugins._new_detectors_common import req, add, targets, response_text

PLUGIN_TYPE='websocket_smuggling'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]

WS_RE = re.compile(r'(?:(?:wss?|https?)://[^\s\"\'<>]+|/[^\s\"\'<>]*)', re.I)

def run(ctx):
    seen=set()
    for base in targets(ctx, 20):
        r=req(ctx, base, allow_redirects=False)
        if r is None: continue
        h={str(k).lower():str(v) for k,v in (getattr(r,'headers',{}) or {}).items()}
        text=response_text(r)
        upgrade=h.get('upgrade','').lower()
        connection=h.get('connection','').lower()
        candidates=[]
        for m in re.finditer(r'(?:(?:wss?|https?)://[^\s\"\'<>]+|/[^\s\"\'<>]*(?:websocket|socket|ws)[^\s\"\'<>]*)', text, re.I):
            candidates.append(m.group(0)[:300])
        if 'websocket' in upgrade or ('upgrade' in connection and candidates):
            evidence={'url':base,'upgrade':upgrade,'connection':connection,'candidates':candidates[:10]}
            key=(base,upgrade,tuple(candidates[:3]))
            if key not in seen:
                seen.add(key)
                add(ctx,PLUGIN_TYPE,'Superficie WebSocket detectada — revisar smuggling','medium',
                    'Se observó una ruta/cabecera compatible con WebSocket. Las diferencias de parsing entre proxy y backend requieren validación manual; este módulo no intenta explotar el canal.',base,evidence,'low')
    return {}
