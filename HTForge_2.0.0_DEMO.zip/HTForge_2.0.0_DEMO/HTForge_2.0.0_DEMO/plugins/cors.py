#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: CORS misconfiguration.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='cors'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
def run(ctx):
 r=request(ctx,ctx.target)
 if not r:return {}
 h={k.lower():v for k,v in getattr(r,"headers",{}).items()}
 acao=h.get("access-control-allow-origin","")
 if acao=="*": add(ctx,"CORS permite cualquier origen","medium","La respuesta incluye Access-Control-Allow-Origin: *; revisar si el recurso es sensible.",ctx.target,{"acao":acao},"medium")
 return {}

