#!/usr/bin/env python3
"""Detección controlada de command injection con canario no destructivo."""
import secrets
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
from core.context import Context
PARAMS={'cmd','command','exec','execute','ping','host','query','target','ip'}
def set_param(url,name,value):
    p=urlsplit(url); q=parse_qsl(p.query,keep_blank_values=True); out=[]; found=False
    for k,v in q:
        if k==name and not found: out.append((k,value)); found=True
        else: out.append((k,v))
    if not found: out.append((name,value))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))
def run(ctx):
    ctx.log("debug", "Módulo command_injection habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
