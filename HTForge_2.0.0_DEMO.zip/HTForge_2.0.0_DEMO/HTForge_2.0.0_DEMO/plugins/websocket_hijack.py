"""HT Forge 1.7 - WebSocket hijacking candidate detector.
Passive checks for authentication/origin protections visible to the HTTP layer.
"""
import re
from plugins._new_detectors_common import req, add, targets, response_text

PLUGIN_TYPE='websocket_hijack'
__version__='1.7'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]

def run(ctx):
    for base in targets(ctx, 20):
        r=req(ctx, base, allow_redirects=False)
        if r is None: continue
        h={str(k).lower():str(v) for k,v in (getattr(r,'headers',{}) or {}).items()}
        text=response_text(r)
        ws_hint = ('websocket' in h.get('upgrade','').lower() or
                   bool(re.search(r'(?i)(?:wss?://|websocket|socket\.io)', text)))
        if not ws_hint: continue
        evidence={'url':base,'upgrade':h.get('upgrade',''),'connection':h.get('connection',''),'set_cookie':h.get('set-cookie','')[:1200]}
        detail=('Se detectó una superficie WebSocket, pero una respuesta HTTP normal no permite confirmar el control de Origin o la autenticación del handshake. Revisar manualmente el handshake y los controles de sesión.')
        add(ctx,PLUGIN_TYPE,'Superficie WebSocket — revisar protección contra hijacking','medium',detail,base,evidence,'low')
    return {}
