#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Debug mode enabled.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='debug_mode'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
def run(ctx):
 r=request(ctx,ctx.target)
 if not r:return {}
 text=getattr(r,"text","").lower()[:20000]
 markers=["traceback (most recent call last)","debug mode","werkzeug debugger","django debug"]
 for m in markers:
  if m in text:add(ctx,"Posible modo debug expuesto","medium","Se observó un indicador de modo debug en la respuesta.",ctx.target,{"marker":m},"medium"); break
 return {}

