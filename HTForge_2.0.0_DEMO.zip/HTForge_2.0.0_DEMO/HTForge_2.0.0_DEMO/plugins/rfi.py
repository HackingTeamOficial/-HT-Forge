"""HT Forge 1.7 - Remote File Inclusion candidate detector.
Uses only a harmless, non-existent marker URL; no remote file is supplied.
"""
from urllib.parse import urlparse
from plugins._new_detectors_common import targets, query_params, probe_param, response_text, add
PLUGIN_TYPE="rfi"; __version__="1.7"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    marker="https://htforge.invalid/htforge-rfi-probe.txt"
    for base in targets(ctx):
        ps=query_params(base)
        if not ps: continue
        for i,(name,_) in enumerate(ps[:8]):
            u,r=probe_param(ctx,base,i,marker)
            if r is None: continue
            text=response_text(r).lower()
            indicators=["htforge-rfi-probe","failed to open stream","include(","require(","remote file"]
            if any(x in text for x in indicators):
                add(ctx,PLUGIN_TYPE,f"Posible RFI en parámetro {name}","medium",
                    "La aplicación mostró un indicador compatible con el procesamiento de una referencia remota; el recurso de prueba no existe y requiere validación humana.",
                    u,{"parameter":name,"marker_host":"htforge.invalid","status":getattr(r,"status_code",None)},"low")
    return {}
