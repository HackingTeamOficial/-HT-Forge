#!/usr/bin/env python3
"""Comprobaciones básicas de exposición de directorios de plugins."""
from urllib.parse import urljoin
from core.context import Context
PATHS=['/wp-content/plugins/','/plugins/','/modules/','/extensions/']
def run(ctx):
    ctx.log("debug", "Módulo plugins habilitado; requiere flujo específico o revisión humana para confirmación.")
    return {}
