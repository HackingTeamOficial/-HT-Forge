#!/usr/bin/env python3
"""HT Forge 1.7 extended detector: Exposed backups.
Non-destructive candidate detector; human validation required.
"""
try:
    from plugins._extended_common import *
except ImportError:
    from _extended_common import *
PLUGIN_TYPE='backup_exposure'
__version__="1.7"
__author__="HT Team"
PHASE="attack"
REQUIRES=[]
from urllib.parse import urljoin
def run(ctx):
 for p in ("/backup.zip","/backup.tar.gz","/site.zip","/db.sql"):
  u=urljoin(ctx.target,p); r=request(ctx,u)
  if r and getattr(r,"status_code",0)==200 and len(getattr(r,"content",b""))>0: add(ctx,"Posible copia de seguridad expuesta","medium","Se encontró un recurso de backup accesible; validar manualmente antes de descargar o analizar contenido.",u,{"status":r.status_code,"length":len(r.content)},"medium")
 return {}

