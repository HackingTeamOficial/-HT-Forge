# HT Forge scan lifecycle

Forge 1.5 ejecuta únicamente módulos nativos del proyecto. No existe una fase ni un worker MCP externo.

Lifecycle:
RUNNING -> RECON -> ATTACK -> REPORTS -> COMPLETED

Cancellation:
STOP_REQUESTED -> cancel current HTTP work -> await module -> STOPPED

Un módulo detenido no debe contaminar la siguiente ejecución: el cliente HTTP se reinicia después de una cancelación o timeout.
