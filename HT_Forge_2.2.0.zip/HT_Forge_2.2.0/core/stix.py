#!/usr/bin/env python3
"""core/stix.py - Exportación STIX 2.1 para HT Forge.

Convierte hallazgos de escaneo a objetos STIX (Structured Threat Information
eXpression) para interoperabilidad con plataformas de inteligencia de amenazas.

STIX 2.1 es un estándar OASIS para compartir inteligencia de amenazas cibernéticas.
Este módulo genera bundles STIX válidos con indicadores, datos observados y
vulnerabilidades.
"""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pathlib import Path


def _uuid4() -> str:
    return str(uuid.uuid4())


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _extract_iocs(findings: List[Dict]) -> Dict[str, List[str]]:
    """Extrae IOCs (IPs, dominios, hashes, URLs) de los hallazgos."""
    ips: List[str] = []
    domains: List[str] = []
    hashes: List[str] = []
    urls: List[str] = []
    emails: List[str] = []

    ip_re = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
    domain_re = re.compile(r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b')
    hash_re = re.compile(r'\b[a-fA-F0-9]{32,128}\b')
    url_re = re.compile(r'https?://[^\s<>"{}|\\^`\[\]]+')
    email_re = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')

    for f in findings or []:
        # Buscar en URL del hallazgo
        url = f.get("url") or f.get("endpoint") or ""
        if url:
            urls.append(url)
            # Extraer dominio de la URL
            m = re.match(r'https?://([^/:]+)', url)
            if m:
                domains.append(m.group(1))

        # Buscar en evidencia
        ev = f.get("evidence") or {}
        ev_str = json.dumps(ev, ensure_ascii=False, default=str)

        for ip in ip_re.findall(ev_str):
            if ip not in ips:
                ips.append(ip)
        for domain in domain_re.findall(ev_str):
            if domain not in domains and not domain.startswith('www.'):
                domains.append(domain)
        for h in hash_re.findall(ev_str):
            if h not in hashes:
                hashes.append(h)
        for u in url_re.findall(ev_str):
            if u not in urls:
                urls.append(u)
        for e in email_re.findall(ev_str):
            if e not in emails:
                emails.append(e)

    return {
        "ips": ips[:100],
        "domains": domains[:100],
        "hashes": hashes[:100],
        "urls": urls[:100],
        "emails": emails[:50],
    }


def _make_indicator(pattern: str, labels: List[str], description: str = "") -> Dict:
    """Crea un objeto STIX Indicator."""
    return {
        "type": "indicator",
        "spec_version": "2.1",
        "id": f"indicator--{_uuid4()}",
        "created": _now_iso(),
        "modified": _now_iso(),
        "name": description or "IOC from HT Forge scan",
        "description": description,
        "pattern": pattern,
        "pattern_type": "stix",
        "valid_from": _now_iso(),
        "labels": labels,
    }


def _make_observed_data(observable: Dict, object_refs: List[str]) -> Dict:
    """Crea un objeto STIX Observed Data."""
    return {
        "type": "observed-data",
        "spec_version": "2.1",
        "id": f"observed-data--{_uuid4()}",
        "created": _now_iso(),
        "modified": _now_iso(),
        "first_observed": _now_iso(),
        "last_observed": _now_iso(),
        "number_observed": 1,
        "object_refs": object_refs,
    }


def _make_vulnerability(finding: Dict) -> Optional[Dict]:
    """Crea un objeto STIX Vulnerability desde un hallazgo."""
    cve = finding.get("cve") or finding.get("evidence", {}).get("cve")
    if not cve:
        return None
    return {
        "type": "vulnerability",
        "spec_version": "2.1",
        "id": f"vulnerability--{_uuid4()}",
        "created": _now_iso(),
        "modified": _now_iso(),
        "name": cve,
        "description": finding.get("title") or finding.get("detail") or "",
        "external_references": [
            {
                "source_name": "cve",
                "external_id": cve,
            }
        ],
    }


def _make_sighting(indicator_id: str, finding: Dict) -> Dict:
    """Crea un objeto STIX Sighting."""
    return {
        "type": "sighting",
        "spec_version": "2.1",
        "id": f"sighting--{_uuid4()}",
        "created": _now_iso(),
        "modified": _now_iso(),
        "sighting_of_ref": indicator_id,
        "description": finding.get("title") or "",
        "count": 1,
    }


def findings_to_stix_bundle(findings: List[Dict], session_info: Optional[Dict] = None) -> Dict:
    """Convierte hallazgos de HT Forge a un bundle STIX 2.1.

    Args:
        findings: Lista de hallazgos (dicts con keys como severity, title, url, evidence, etc.)
        session_info: Información opcional de la sesión (id, target, profile, etc.)

    Returns:
        Dict con bundle STIX 2.1 válido.
    """
    objects: List[Dict] = []
    iocs = _extract_iocs(findings)

    # Indicadores de IP
    for ip in iocs["ips"]:
        objects.append(_make_indicator(
            pattern=f"[ipv4-addr:value = '{ip}']",
            labels=["malicious-activity"],
            description=f"IP address observed in scan: {ip}",
        ))

    # Indicadores de dominio
    for domain in iocs["domains"]:
        objects.append(_make_indicator(
            pattern=f"[domain-name:value = '{domain}']",
            labels=["malicious-activity"],
            description=f"Domain observed in scan: {domain}",
        ))

    # Indicadores de hash
    for h in iocs["hashes"]:
        objects.append(_make_indicator(
            pattern=f"[file:hashes.MD5 = '{h}']",
            labels=["malicious-activity"],
            description=f"File hash observed in scan: {h}",
        ))

    # Indicadores de URL
    for url in iocs["urls"]:
        objects.append(_make_indicator(
            pattern=f"[url:value = '{url}']",
            labels=["malicious-activity"],
            description=f"URL observed in scan: {url}",
        ))

    # Indicadores de email
    for email in iocs["emails"]:
        objects.append(_make_indicator(
            pattern=f"[email-addr:value = '{email}']",
            labels=["malicious-activity"],
            description=f"Email address observed in scan: {email}",
        ))

    # Vulnerabilidades y sightings por hallazgo
    for f in findings or []:
        vuln = _make_vulnerability(f)
        if vuln:
            objects.append(vuln)

        # Crear un indicator genérico para el hallazgo si no tiene CVE
        if not f.get("cve"):
            url = f.get("url") or f.get("endpoint") or ""
            if url:
                ind = _make_indicator(
                    pattern=f"[url:value = '{url}']",
                    labels=["vulnerability"],
                    description=f.get("title") or "Vulnerability indicator",
                )
                objects.append(ind)
                objects.append(_make_sighting(ind["id"], f))

    # Añadir metadata de la sesión como identity
    if session_info:
        objects.append({
            "type": "identity",
            "spec_version": "2.1",
            "id": f"identity--{_uuid4()}",
            "created": _now_iso(),
            "modified": _now_iso(),
            "name": "HT Forge Scanner",
            "identity_class": "tool",
            "description": f"Scan session {session_info.get('id', 'unknown')} on {session_info.get('target', 'unknown')}",
        })

    bundle = {
        "type": "bundle",
        "id": f"bundle--{_uuid4()}",
        "objects": objects,
    }

    return bundle


def export_stix(findings: List[Dict], session_info: Optional[Dict] = None, output_path: Optional[str] = None) -> str:
    """Exporta hallazgos a un archivo STIX 2.1 JSON.

    Args:
        findings: Lista de hallazgos
        session_info: Información opcional de la sesión
        output_path: Ruta de salida (opcional)

    Returns:
        Ruta del archivo generado
    """
    bundle = findings_to_stix_bundle(findings, session_info)

    if output_path:
        path = Path(output_path)
    else:
        path = Path(f"htforge_stix_{session_info.get('id', 'export') if session_info else 'export'}.json")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
    return str(path)
