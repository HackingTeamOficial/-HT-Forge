#!/usr/bin/env python3
"""core/engine.py - Motor principal de HT Forge (unificado con EngineControl)"""

import os
import sys
import json
import time
import uuid
import threading
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

from .models import ScanSession
from .context import Context
from .plugin import PluginManager
from .profiles import get_profile, list_profiles, resolve_modules
from .http_client import HTTPClient
from .db import Database
from .scoring import RiskScorer
from .exporters import export_all_reports, generate_infographic


def _default_reports() -> str:
    try:
        from .exporters import default_reports_dir
        return default_reports_dir()
    except Exception:
        return "reports"
from .vulndb import VulnDB
from .control import EngineControl, ControlState, ControlConfig
from .license import require_license
from .integrity import verify_integrity

verify_integrity()


# Re-export para mantener compatibilidad con imports existentes
# (from core.engine import ScanSession)
__all__ = ['Engine', 'ScanSession', 'get_engine']

def _redact_sensitive(value):
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            lk = str(k).lower()
            if any(x in lk for x in ('token', 'authorization', 'password', 'secret')):
                out[k] = '[REDACTED]'
            else:
                out[k] = _redact_sensitive(v)
        return out
    if isinstance(value, list):
        return [_redact_sensitive(v) for v in value]
    return value


class Engine:
    """Motor principal de HT Forge - Orquesta todo el pipeline usando EngineControl como única fuente de verdad"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        
        # Componentes core
        self.http = HTTPClient(self.config.get('http', {}))
        self.db = Database(self.config.get('db_path', 'runtime/htforge.db'))
        self.plugins = PluginManager()
        self.scorer = RiskScorer()
        self.vulndb = VulnDB()
        
        # Control unificado - ÚNICA fuente de verdad para estado
        self.control = EngineControl(ControlConfig(
            max_concurrent_modules=self.config.get('max_concurrent', 3),
            module_timeout=self.config.get('module_timeout', 300),
            global_timeout=self.config.get('global_timeout', 3600),
            auto_stop_on_critical=self.config.get('auto_stop_on_critical', False),
            pause_on_finding=self.config.get('pause_on_finding', False)
        ))
        
        # Registrar callbacks del control para emitir eventos
        self.control.register_callback('state_change', self._on_state_change)
        self.control.register_callback('module_start', self._on_module_start)
        self.control.register_callback('module_end', self._on_module_end)
        self.control.register_callback('finding', self._on_finding)
        self.control.register_callback('error', self._on_error)
        
        # Callbacks para UI/CLI (externos)
        self.on_finding: Optional[Callable] = None
        self.on_log: Optional[Callable] = None
        self.on_progress: Optional[Callable] = None
        self.on_module_start: Optional[Callable] = None
        self.on_module_end: Optional[Callable] = None
        self.on_state_change: Optional[Callable] = None
        
        # Sesión actual
        self.session: Optional[ScanSession] = None
        self._module_threads: List[threading.Thread] = []
        self._scan_context: Optional[Context] = None
        # Watchdog global (idea #5): deadline monotónica del escaneo.
        # Se arma en scan(); None = sin límite adicional al de control.
        self._scan_deadline: Optional[float] = None
    
    # --- Callbacks internos del EngineControl ---
    
    def _on_state_change(self, state: ControlState):
        self.emit({'type': 'state_change', 'state': state.value})
        if self.on_state_change:
            self.on_state_change({'state': state.value})
    
    def _on_module_start(self, module: str):
        self.emit({'type': 'module_start', 'module': module})
        if self.on_module_start:
            self.on_module_start({'module': module})
    
    def _on_module_end(self, data: Dict):
        self.emit({'type': 'module_end', **data})
        if self.on_module_end:
            self.on_module_end(data)
    
    def _on_finding(self, finding: Dict):
        self.emit({'type': 'finding', **finding})
        if self.on_finding:
            self.on_finding(finding)
    
    def _on_error(self, error: str):
        self.emit({'type': 'error', 'error': error})
    
    # --- Emisión de eventos para UI/CLI ---
    
    def emit(self, event: Dict):
        """Emite eventos para UI/CLI y conserva un buffer acotado para el dashboard en vivo."""
        etype = event.get('type')
        # La GUI consulta la sesión en memoria. Guardamos los eventos recientes
        # para que el log pueda reproducir el avance real sin depender de stdout.
        if self.session is not None and etype in ('log', 'progress', 'module_start', 'module_end', 'finding', 'error'):
            meta = self.session.metadata.setdefault('events', [])
            level = event.get('level') or ('error' if etype == 'error' else 'info')
            msg = event.get('msg') or event.get('module') or event.get('error') or ''
            if etype == 'progress' and not msg:
                msg = f"Progreso {int(event.get('current', 0)) + 1}/{event.get('total', 0)}"
            meta.append({'type': etype, 'level': level, 'msg': str(msg), 'ts': datetime.now().isoformat()})
            if len(meta) > 400:
                del meta[:-400]

        if etype == 'finding' and self.on_finding:
            self.on_finding(event)
        elif etype == 'log' and self.on_log:
            self.on_log(event)
        elif etype == 'progress' and self.on_progress:
            self.on_progress(event)
        elif etype == 'module_start' and self.on_module_start:
            self.on_module_start(event)
        elif etype == 'module_end' and self.on_module_end:
            self.on_module_end(event)
        elif etype == 'state_change' and self.on_state_change:
            self.on_state_change(event)
        
        # Log interno
        if etype in ('finding', 'log', 'error'):
            level = event.get('level', 'info')
            msg = event.get('msg', '')
            print(f"[{level.upper()}] {msg}")
    
    # --- API principal ---
    
    def scan(self, target: str, profile: str = 'full', options: Optional[Dict] = None) -> ScanSession:
        """Ejecuta escaneo completo usando EngineControl.

        Ejecuta un escaneo local sin dependencia de servicios de licencias.
        """
        require_license()

        # Validar target
        if not target.startswith(('http://', 'https://')):
            target = 'https://' + target
        
        # Crear sesión (reutiliza create_session)
        session = self.create_session(target, profile, session_id=(options or {}).get('session_id'))
        
        # Resolver módulos del perfil
        available = self.plugins.get_available()
        recon_order, attack_order, mode = resolve_modules(profile, available)

        # Permitir selección explícita desde GUI/CLI sin perder el orden por fases.
        requested = (options or {}).get('modules')
        if requested:
            requested = list(dict.fromkeys(requested))
            recon_order = [m for m in recon_order if m in requested]
            attack_order = [m for m in attack_order if m in requested]
            for m in requested:
                if m in available and m not in recon_order and m not in attack_order:
                    phase = getattr(self.plugins.get(m).module, 'PHASE', 'attack')
                    (recon_order if phase == 'recon' else attack_order).append(m)
        # Forge 1.5 usa únicamente módulos nativos del proyecto.
        all_modules = recon_order + attack_order
        session.metadata = {
            'profile': profile,
            'mode': mode,
            'recon_modules': recon_order,
            'attack_modules': attack_order,
            'options': _redact_sensitive(options or {}),
            'events': []
        }
        
        # Iniciar control (estado STARTING -> RUNNING)
        self.http.reset_cancel()
        self.control.start(len(all_modules))
        self.control.running()
        # Watchdog global (idea #5): el escaneo SIEMPRE termina.
        try:
            budget_s = float((options or {}).get(
                'scan_max_seconds', self.control.config.global_timeout))
        except (TypeError, ValueError):
            budget_s = 3600.0
        self._scan_deadline = time.monotonic() + max(60.0, budget_s)
        # Reflejar el estado de ejecución en la sesión (la GUI sondea session.status).
        session.status = 'running'
        
        self.emit({'type': 'log', 'level': 'info', 'msg': f"Iniciando escaneo {profile} en {target}"})
        self.emit({'type': 'progress', 'current': 0, 'total': len(all_modules), 'phase': 'init'})
        
        # Un único Context por sesión: los módulos comparten descubrimientos,
        # assets y evidencia entre fases.
        self._scan_context = Context(target, self)
        self._scan_context.session_id = session.id
        self._scan_context.profile = session.profile
        self._scan_context.config = options or {}
        self._scan_context.phase = 'recon'
        self._scan_context._report = {'findings': []}
        # Índice O(1) tipo+url+param+ctx -> finding (el merge lineal colgaba
        # el pipeline con miles de hallazgos: parecía "running" eternamente).
        self._gindex = {}

        try:
            # FASE 1: Reconocimiento
            if recon_order:
                self._run_phase('recon', recon_order, session)
            
            # Verificar stop
            if self.control.should_stop():
                raise KeyboardInterrupt("Parado por usuario")
            
            # FASE 2: Ataque
            if attack_order:
                self._run_phase('attack', attack_order, session)
            
            session.status = 'completed'
            # Robustez: si algún módulo falló a nivel individual pero el
            # pipeline terminó, marcamos completed_with_errors (no 'error' global).
            if session.errors:
                session.status = 'completed_with_errors'
            self.emit({'type': 'log', 'level': 'ok', 'msg': f"Escaneo completado: {len(session.findings)} hallazgos, {len(session.errors)} errores de modulo"})
            
        except KeyboardInterrupt:
            session.status = 'interrupted'
            self.control.stop()
            self.emit({'type': 'log', 'level': 'warn', 'msg': 'Escaneo interrumpido'})
        except Exception as e:
            session.status = 'error'
            session.errors.append(str(e))
            self.control.error(str(e))
            self.emit({'type': 'log', 'level': 'error', 'msg': f"Error: {e}"})
        finally:
            # Estado final
            self.control.stopped()
            # Consolidar descubrimientos compartidos del contexto para que la GUI
            # y los reportes puedan mostrar las URLs y tecnologías reales observadas.
            if self._scan_context is not None:
                discovered = self._scan_context.get('discovered_urls', []) or []
                params = self._scan_context.get('discovered_params', []) or []
                technologies = self._scan_context.get('technologies', []) or []
                if discovered:
                    session.metadata['discovered_urls'] = list(dict.fromkeys(str(x) for x in discovered if x))
                if params:
                    session.metadata['discovered_params'] = params[:250]
                if technologies:
                    session.metadata['technologies'] = list(dict.fromkeys(str(x) for x in technologies if x))
            session.metadata['ended_at'] = datetime.now().isoformat()
            # Métricas de ejecución (punto 5: medir comportamiento)
            elapsed = (datetime.now() - session.started_at).total_seconds()
            session.metadata['metrics'] = {
                'elapsed_seconds': round(elapsed, 2),
                'modules_requested': len(session.modules_run) + len(session.errors),
                'modules_completed': len(session.modules_run),
                'modules_failed': len(session.errors),
                'findings_generated': len(session.findings),
                'duplicates_merged': int(session.metadata.get('duplicates_merged', 0) or 0),
                'status': session.status,
            }
            # Escalera SQLi (idea #5): dos técnicas independientes -> CONFIRMED.
            # Corre ANTES de persistir para que DB y sesión coincidan.
            try:
                from .confirm_policy import correlate_session as _correlate_session
                session.metadata['ladder'] = _correlate_session(session)
            except Exception:
                pass
            # Persistir hallazgos en tabla findings (no solo en el JSON de sesión)
            if session.findings:
                try:
                    self.db.save_findings(session.id, session.findings)
                except Exception:
                    pass
            # Resumen accionable (idea #4): solo CONFIRMED/VERIFIED/LIKELY.
            try:
                from .evidence import actionable_summary as _actionable_summary
                session.metadata['actionable'] = _actionable_summary(session.findings)
            except Exception:
                pass
            # Revisión IA solo-evidencia (idea #9): opt-in, nunca decide.
            if self.config.get('ai_review'):
                try:
                    from .ai_evidence import review_session as _ai_review
                    session.metadata['ai_review'] = _ai_review(
                        session, int(self.config.get('ai_review_limit', 25)))
                except Exception as exc:
                    session.errors.append(f'ai_review: {exc}')
            self.db.update_session(session)
            # Generación automática de TODOS los formatos al finalizar el escaneo.
            # Se generan siempre, incluso si hay errores de módulos.
            try:
                report_dir = self.config.get('reports_dir') or _default_reports()
                reports = export_all_reports(session, output_dir=report_dir)
                # Always create the infographic SVG as a first-class report artifact.
                try:
                    reports['svg'] = generate_infographic(session, output_dir=report_dir)
                except Exception as exc:
                    session.errors.append(f'svg report: {exc}')
                session.metadata['reports'] = reports
                self.db.update_session(session)
                self.emit({'type': 'log', 'level': 'ok', 'msg': f"Reportes generados en {report_dir}: {sorted(reports.keys())}"})
            except Exception as exc:
                session.errors.append(f'reports: {exc}')
                self.emit({'type': 'log', 'level': 'warn', 'msg': f'No se pudieron generar todos los reportes: {exc}'})
            # Cierre garantizado del pipeline (idea #5): SCAN FINISHED.
            try:
                self.emit({'type': 'log', 'level': 'ok',
                           'msg': f"SCAN FINISHED · {session.status} · 100% · "
                                  f"{len(session.findings)} hallazgos · "
                                  f"reportes: {sorted((session.metadata.get('reports') or {}).keys())}"})
            except Exception:
                pass

        return session
    
    def _run_phase(self, phase: str, modules: List[str], session: ScanSession):
        """Ejecuta una fase (recon o attack) secuencialmente"""
        for i, module_name in enumerate(modules):
            # Verificar stop/pausa ANTES de cada módulo
            self.control.wait_if_paused()
            if self.control.should_stop():
                break
            # Watchdog global (idea #5): presupuesto temporal agotado.
            if self._scan_deadline is not None and \
                    time.monotonic() >= self._scan_deadline:
                session.errors.append('watchdog: presupuesto temporal agotado')
                self.emit({'type': 'log', 'level': 'warn',
                           'msg': 'Watchdog: fin del presupuesto temporal, cerrando pipeline'})
                break
            
            # Notificar inicio de módulo (control emite callback)
            self.control.module_start(module_name)
            if self._scan_context is not None:
                self._scan_context.set('current_module', module_name)
            session.metadata['current_module'] = module_name
            self.emit({'type': 'progress', 'current': i, 'total': len(modules), 'phase': phase, 'module': module_name})
            self.emit({'type': 'log', 'level': 'info', 'msg': f'[{phase.upper()}] Módulo {i + 1}/{len(modules)}: {module_name}'})
            
            module_started = time.monotonic()
            try:
                module = self.plugins.get(module_name)
                if module:
                    # _run_phase también se usa directamente por tests/integraciones.
                    # Si no existe un contexto de scan creado por scan(), créalo aquí
                    # para no romper la ejecución del plugin.
                    ctx = self._scan_context
                    if ctx is None:
                        ctx = Context(session.target, self)
                        ctx.session_id = session.id
                        ctx.profile = session.profile
                        ctx.config = dict(self.config or {})
                        ctx._report = {'findings': []}
                        self._scan_context = ctx
                    ctx.phase = phase
                    ctx._skip_module = False
                    
                    # Llenar ctx.findings con hallazgos acumulados para que
                    # plugins de análisis (correlation, ir_response) vean lo
                    # que detectaron plugins anteriores en el pipeline.
                    if phase == 'attack' and session.findings:
                        ctx.set('findings', list(session.findings))
                    
                    # Ejecutar con timeout usando run_func del plugin
                    result = self._run_with_timeout(module.run_func, ctx, timeout=self.control.config.module_timeout)
                    
                    session.modules_run.append(module_name)
                    
                    # Unificar findings devueltos y findings enviados con ctx.finding().
                    raw_findings = []
                    if isinstance(ctx.get_report(), dict):
                        raw_findings.extend(ctx.get_report().get('findings', []))
                    if result and isinstance(result, dict):
                        raw_findings.extend(result.get('findings', []))
                    
                    # Vaciar el buffer del contexto para que no se re-procese en el
                    # siguiente plugin; el storage de descubrimientos permanece intacto.
                    ctx._report = {'findings': []}
                    try:
                        from core.evidence import normalize_finding as _normalize_finding
                        from urllib.parse import urlsplit as _us
                    except Exception:
                        _normalize_finding = None
                        _us = None
                    def _gkey(f):
                        try:
                            ev = f.get('evidence') if isinstance(f.get('evidence'), dict) else {}
                            url = str(f.get('url') or f.get('endpoint') or ev.get('url') or '')
                            if _us is not None and url.startswith(('http://', 'https://')):
                                try:
                                    _p = _us(url)
                                    url = (_p.scheme.lower() + '://' + _p.netloc.lower() + (_p.path or '/')).rstrip('/')
                                except Exception:
                                    url = url.split('#')[0].split('?')[0].rstrip('/')
                            else:
                                url = url.split('#')[0].split('?')[0].rstrip('/')
                            param = str(f.get('parameter') or f.get('param') or ev.get('parameter') or '').lower()
                            typ = str(f.get('type') or '').lower()
                            # Contexto de evidencia: mismo endpoint+parámetro pero
                            # distinto contexto (técnica, contexto XSS, nivel SSRF)
                            # son hallazgos distintos; mismo contexto se fusiona.
                            ctx = '|'.join(str(ev.get(k) or '') for k in (
                                'technique', 'reflection_context', 'ssrf_level',
                                'matched_signature', 'signature')).lower()[:200]
                            return (typ, url, param, ctx)
                        except Exception:
                            return None
                    # Índice global de la sesión para deduplicar entre módulos.
                    if '_gseen' not in session.metadata or not isinstance(session.metadata.get('_gseen'), dict):
                        _gseen = {}
                        for _ef in (session.findings or []):
                            _k = _gkey(_ef if isinstance(_ef, dict) else {})
                            if _k: _gseen.setdefault(repr(_k), 0)
                        session.metadata['_gseen'] = {'keys': sorted(_gseen.keys()), 'merged': int(session.metadata.get('metrics', {}).get('duplicates_merged', 0)) if isinstance(session.metadata.get('metrics'), dict) else 0}
                    _gkeys = set(session.metadata['_gseen'].get('keys', []))
                    _merged = int(session.metadata['_gseen'].get('merged', 0))
                    # Índice runtime para fusión O(1) (no va a metadata/DB).
                    _gindex = getattr(self, '_gindex', None)
                    if not isinstance(_gindex, dict):
                        _gindex = {}
                        self._gindex = _gindex
                    if not _gindex and session.findings:
                        for _ef in session.findings:
                            try:
                                _ek = _gkey(_ef if isinstance(_ef, dict) else {})
                                if _ek:
                                    _gindex.setdefault(repr(_ek), _ef)
                            except Exception:
                                pass
                    seen = set()
                    seen3 = set()
                    for f in raw_findings:
                        if not isinstance(f, dict):
                            continue
                        f = dict(f)
                        f['module'] = module_name
                        f['phase'] = phase
                        # Unificar un finding emitido por ctx.finding() y el
                        # mismo finding devuelto por module.run_func(). No usamos
                        # toda evidence como clave porque una de las dos rutas
                        # puede añadir metadatos diferentes.
                        evidence = f.get('evidence') if isinstance(f.get('evidence'), dict) else {}
                        f_url = f.get('url') or f.get('endpoint') or evidence.get('url')
                        f_param = f.get('parameter') or evidence.get('parameter')
                        f_payload = f.get('payload') or evidence.get('payload')
                        key = (f.get('type'), f.get('title'), f.get('severity'), f_url, f_param, f_payload)
                        # Algunos módulos devuelven un resumen sin URL/evidence
                        # después de haber emitido el finding completo mediante
                        # ctx.finding(). En ese caso lo consideramos el mismo
                        # finding si coincide tipo/título/severidad/parámetro.
                        if key in seen or (key[:3] in seen3 and (any(
                            k[:3] == key[:3] and (
                                (f_param is not None and k[4] == f_param) or
                                (f_param is None and f_url is None and k[4] is not None)
                            ) for k in seen))):
                            continue
                        seen.add(key)
                        seen3.add(key[:3])
                        if _normalize_finding is not None:
                            try:
                                f = _normalize_finding(f)
                            except Exception:
                                pass
                        # Política de confirmación 9.x: score ponderado +
                        # reglas por tipo. Solo degrada estados no defendibles.
                        try:
                            from core.confirm_policy import apply_policy as _apply_policy
                            f = _apply_policy(f)
                        except Exception:
                            pass
                        # Deduplicación global entre módulos: mismo tipo+URL normalizada+parámetro+ctx.
                        _gk = _gkey(f)
                        _gkr = repr(_gk) if _gk else None
                        if _gkr and _gkr in _gkeys:
                            # Fusión O(1) en el hallazgo ya registrado.
                            try:
                                _ef = _gindex.get(_gkr)
                                if _ef is None:
                                    for _cand in session.findings:
                                        if repr(_gkey(_cand)) == _gkr:
                                            _ef = _cand
                                            _gindex[_gkr] = _ef
                                            break
                                if _ef is not None:
                                    _eev = _ef.setdefault('evidence', {})
                                    if isinstance(_eev, dict):
                                        _also = _eev.setdefault('also_seen_at', [])
                                        _u = f.get('url') or (f.get('evidence') or {}).get('url')
                                        if _u and _u not in _also:
                                            if len(_also) < 20:
                                                _also.append(str(_u)[:300])
                            except Exception:
                                pass
                            _merged += 1
                            continue
                        if _gkr:
                            _gkeys.add(_gkr)
                        f['scored'] = self.scorer.score(f)
                        f = self.vulndb.enrich_finding(f)
                        try:
                            from core.finding_kb import enrich as _kb_enrich
                            f = _kb_enrich(f)
                        except Exception:
                            pass
                        try:
                            _ev2 = f.get('evidence') if isinstance(f.get('evidence'), dict) else {}
                            _vs = str(f.get('verification_state') or 'CANDIDATE').upper()
                            _conf = float(f.get('confidence', 0) or 0)
                            f['human_verification'] = {
                                'state': _vs,
                                'evidences': len([k for k in _ev2.keys() if k]) if isinstance(_ev2, dict) else 0,
                                'reproducible': bool(_ev2.get('reproduced') or _ev2.get('retest') or f.get('verified') is True),
                                'differential': bool(_ev2.get('comparison') or _ev2.get('baseline') or _ev2.get('response_pair')),
                                'secondary_check': bool(_ev2.get('retest') or _ev2.get('confirmation') or f.get('verified') is True),
                                'confidence': round(_conf if _conf <= 1.0 else _conf / 100.0, 2),
                                'engine': 'HT Forge Core',
                                'requires_human_review': bool(f.get('requires_human_review', _vs not in ('VERIFIED', 'CONFIRMED', 'REFUTED'))),
                            }
                        except Exception:
                            pass
                        # ID estable del hallazgo (idea #10): HTF-<sesión>-<n>.
                        try:
                            _seq = int(session.metadata.get('finding_seq', 0) or 0) + 1
                            session.metadata['finding_seq'] = _seq
                            if not str(f.get('finding_id', '')).startswith('HTF-'):
                                f['finding_id'] = f"HTF-{str(session.id)[:8]}-{_seq:04d}"
                        except Exception:
                            pass
                        session.findings.append(f)
                        try:
                            if _gkr:
                                _gindex[_gkr] = f
                        except Exception:
                            pass
                        self.control.finding(f)
                    
                    elapsed_module = time.monotonic() - module_started
                    session.metadata.setdefault('module_timings', {})[module_name] = round(elapsed_module, 2)
                    # Persistir índice global de dedup + contador para métricas/UI.
                    try:
                        session.metadata['_gseen'] = {'keys': sorted(_gkeys), 'merged': _merged}
                        session.metadata['duplicates_merged'] = _merged
                    except Exception:
                        pass
                    self.emit({'type': 'log', 'level': 'ok', 'msg': f'Módulo {module_name} finalizado en {elapsed_module:.2f}s'})
                    self.control.module_end(module_name, 'ok')
                else:
                    self.emit({'type': 'log', 'level': 'warn', 'msg': f"Módulo {module_name} no encontrado"})
                    self.control.module_end(module_name, 'missing')
                    
            except Exception as e:
                elapsed_module = time.monotonic() - module_started
                session.metadata.setdefault('module_timings', {})[module_name] = round(elapsed_module, 2)
                session.errors.append(f"{module_name}: {e}")
                self.control.module_end(module_name, 'error')
                # El callback 'error' ya se disparó
            
            session.metadata['current_module'] = None
            if self._scan_context is not None:
                self._scan_context.set('current_module', None)
            # Pacing configurable: evita una ráfaga de peticiones y hace visible el
            # avance real del pipeline. No sustituye comprobaciones reales.
            delay = float(self.config.get('module_delay', 0.75))
            if delay > 0:
                end = time.monotonic() + delay
                while time.monotonic() < end:
                    if self.control.should_stop():
                        break
                    time.sleep(min(0.10, end - time.monotonic()))
    
    def _reset_http_client(self):
        """Reemplaza el cliente HTTP después de cancelar una ejecución.

        Un timeout de módulo no debe dejar el estado cancelado contaminando los
        módulos siguientes. El hilo del módulo anterior conserva su referencia
        al cliente viejo y puede terminar sin afectar al cliente nuevo.
        """
        old = self.http
        try:
            old.close()
        except Exception:
            pass
        self.http = HTTPClient(self.config.get('http', {}))
        return self.http

    def _run_with_timeout(self, func: Callable, *args, timeout: int = 300):
        """Ejecuta función con timeout. Soporta funciones sync y async."""
        import asyncio
        result = [None]
        exc = [None]
        
        def target():
            try:
                res = func(*args)
                if asyncio.iscoroutine(res):
                    res = asyncio.run(res)
                result[0] = res
            except Exception as e:
                exc[0] = e
        
        t = threading.Thread(target=target, daemon=True)
        t.start()
        deadline = time.monotonic() + timeout
        while t.is_alive():
            if self.control.should_stop():
                self.http.cancel()
                # Dar al módulo un breve margen para salir de su petición actual.
                t.join(0.5)
                raise KeyboardInterrupt("Parado por usuario")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self.http.cancel()
                # A timeout is module-local. Rebuild the client so the next
                # module starts with a clean cancellation state.
                self._reset_http_client()
                raise TimeoutError(f"Módulo excedió {timeout}s")
            t.join(min(0.1, remaining))
        
        if exc[0]:
            raise exc[0]
        
        return result[0]
    
    def stop(self):
        """Detiene escaneo actual - usa control unificado"""
        self.control.stop()
        try:
            self.http.cancel()
        except Exception:
            pass
        self.emit({'type': 'log', 'level': 'warn', 'msg': 'Deteniendo escaneo...'})
    
    def pause(self):
        """Pausa escaneo"""
        self.control.pause()
        self.emit({'type': 'log', 'level': 'info', 'msg': 'Escaneo pausado'})
    
    def resume(self):
        """Reanuda escaneo"""
        self.control.resume()
        self.emit({'type': 'log', 'level': 'info', 'msg': 'Escaneo reanudado'})
    
    def get_progress(self) -> Dict:
        """Obtiene progreso actual"""
        return self.control.get_progress()
    
    def get_report(self, format: str = 'json') -> str:
        """Genera reporte de la sesión actual"""
        if not self.session:
            return "Sin sesión activa"
        
        from .exporters import export_report
        return export_report(self.session, format)
    
    def list_profiles(self) -> Dict:
        return list_profiles()

    def create_session(self, target: str, profile: str = 'full', session_id: Optional[str] = None) -> ScanSession:
        """Crea una nueva sesión de escaneo"""
        session = ScanSession(
            id=session_id or str(uuid.uuid4())[:8],
            target=target,
            profile=profile,
            started_at=datetime.now()
        )
        self.session = session
        self.db.create_session(session)
        return session


# Instancia global para CLI (lazy)
_engine_instance = None

def get_engine(config: Optional[Dict] = None) -> Engine:
    """Obtiene instancia global del motor (singleton lazy)"""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = Engine(config)
    return _engine_instance