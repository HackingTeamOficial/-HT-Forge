"""core/telegram.py - Avisos de hallazgos y resúmenes por Telegram (Bot API, solo stdlib).

Config (orden de prioridad): variables de entorno HTFORGE_TG_TOKEN / HTFORGE_TG_CHAT,
después config/telegram.json en el runtime. Todo el envío es fire-and-forget en
hilos daemon y nunca eleva excepciones al escaneo.
"""
from __future__ import annotations
import json
import os
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

API_BASE = "https://api.telegram.org"
TIMEOUT = 12


def _runtime_dir() -> Path:
    env = os.getenv("HTFORGE_RUNTIME")
    if env:
        return Path(env)
    for var in ("LOCALAPPDATA", "APPDATA"):
        val = os.getenv(var)
        if val:
            return Path(val) / "HT Forge" / "runtime"
    return Path.home() / ".htforge"


def config_path() -> Path:
    return _runtime_dir() / "config" / "telegram.json"


def get_config() -> Dict[str, Any]:
    """Config efectiva. Nunca incluye el token completo en claro fuera de este módulo."""
    cfg: Dict[str, Any] = {
        "enabled": False,
        "token": "",
        "chat_id": "",
        "notify_findings": True,
        "notify_summary": True,
        "min_severity": "medium",
        "only_actionable": True,
        # Notificación por tipo de hallazgo de plugins 2.2.0
        "notify_ioc": True,
        "notify_secret": True,
        "notify_ir": True,
        "notify_traffic": True,
        "notify_threat_intel": True,
        "notify_ssl": True,
        "notify_headers": True,
        "notify_file_forensics": True,
        "notify_correlation": True,
        "notify_report_enhancement": True,
    }
    try:
        fp = config_path()
        if fp.is_file():
            cfg.update(json.loads(fp.read_text()) or {})
    except Exception:
        pass
    if os.getenv("HTFORGE_TG_TOKEN"):
        cfg["token"] = os.getenv("HTFORGE_TG_TOKEN", "")
    if os.getenv("HTFORGE_TG_CHAT"):
        cfg["chat_id"] = os.getenv("HTFORGE_TG_CHAT", "")
    return cfg


_TELEGRAM_KEYS = ("enabled", "token", "chat_id", "notify_findings",
                  "notify_summary", "min_severity", "only_actionable",
                  "notify_ioc", "notify_secret", "notify_ir", "notify_traffic",
                  "notify_threat_intel", "notify_ssl", "notify_headers",
                  "notify_file_forensics", "notify_correlation", "notify_report_enhancement")


def save_config(data: Dict[str, Any]) -> Dict[str, Any]:
    cfg = get_config()
    for k in _TELEGRAM_KEYS:
        if k in data:
            cfg[k] = data[k]
    cfg["enabled"] = bool(cfg.get("enabled"))
    cfg["notify_findings"] = bool(cfg.get("notify_findings", True))
    cfg["notify_summary"] = bool(cfg.get("notify_summary", True))
    cfg["only_actionable"] = bool(cfg.get("only_actionable", True))
    for k in _NEW_PLUGIN_CONFIG_KEYS:
        cfg[k] = bool(cfg.get(k, True))
    sev = str(cfg.get("min_severity", "medium")).lower()
    cfg["min_severity"] = sev if sev in ("critical", "high", "medium", "low", "info") else "medium"
    fp = config_path()
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(json.dumps({k: cfg[k] for k in _TELEGRAM_KEYS}))
    try:
        os.chmod(fp, 0o600)
    except Exception:
        pass
    return status()


def status() -> Dict[str, Any]:
    cfg = get_config()
    tok = str(cfg.get("token") or "")
    return {
        "enabled": bool(cfg.get("enabled")) and bool(tok) and bool(str(cfg.get("chat_id") or "")),
        "configured": bool(tok) and bool(str(cfg.get("chat_id") or "")),
        "token_set": bool(tok),
        "token_hint": ("…" + tok[-4:]) if len(tok) > 4 else "",
        "chat_id": str(cfg.get("chat_id") or ""),
        "notify_findings": bool(cfg.get("notify_findings", True)),
        "notify_summary": bool(cfg.get("notify_summary", True)),
        "min_severity": str(cfg.get("min_severity", "medium")),
        "only_actionable": bool(cfg.get("only_actionable", True)),
        "notify_ioc": bool(cfg.get("notify_ioc", True)),
        "notify_secret": bool(cfg.get("notify_secret", True)),
        "notify_ir": bool(cfg.get("notify_ir", True)),
        "notify_traffic": bool(cfg.get("notify_traffic", True)),
        "notify_threat_intel": bool(cfg.get("notify_threat_intel", True)),
        "notify_ssl": bool(cfg.get("notify_ssl", True)),
        "notify_headers": bool(cfg.get("notify_headers", True)),
        "notify_file_forensics": bool(cfg.get("notify_file_forensics", True)),
        "notify_correlation": bool(cfg.get("notify_correlation", True)),
        "notify_report_enhancement": bool(cfg.get("notify_report_enhancement", True)),
    }


_SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
_SEV_EMOJI = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"}


def _passes_severity(severity: str, minimum: str) -> bool:
    return _SEV_ORDER.get(str(severity or "info").lower(), 0) >= _SEV_ORDER.get(str(minimum or "medium").lower(), 2)


def _send(token: str, chat_id: str, text: str) -> Dict[str, Any]:
    url = f"{API_BASE}/bot{token}/sendMessage"
    body = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": text, "disable_web_page_preview": "true"}).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode() or "{}")


def _async_send(text: str) -> None:
    def _run():
        try:
            cfg = get_config()
            if not cfg.get("enabled") or not cfg.get("token") or not cfg.get("chat_id"):
                return
            _send(str(cfg["token"]), str(cfg["chat_id"]), text[:3900])
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


_STATE_BADGE = {
    "CONFIRMED": "✅ CONFIRMADO",
    "VERIFIED": "✔️ VERIFICADO",
    "LIKELY": "🟡 PROBABLE",
    "CANDIDATE": "⚪ CANDIDATO",
    "INCONCLUSIVE": "❔ NO CONCLUYENTE",
    "MANUAL": "👁 REQUIERE REVISIÓN",
    "PROBED": "🔎 SONDEADO",
    "DISCOVERED": "📡 DETECTADO",
    "CORRELATED": "🔗 CORRELACIONADO",
    "REFUTED": "⛔ REFUTADO",
}

_ACTIONABLE = {"CONFIRMED", "VERIFIED", "LIKELY"}

# Tipos de hallazgo de plugins 2.2.0 que usan el formateador especializado
_NEW_PLUGIN_TYPES = {
    "ioc_match", "suspicious_pattern",
    "secret_exposure", "secret_in_header",
    "ir_playbook",
    "information_disclosure", "possible_c2_beacon", "possible_data_exfiltration",
    "threat_intel",
    "ssl_error", "ssl_expiration", "ssl_weak_tls", "ssl_weak_cipher", "ssl_hostname_mismatch",
    "missing_security_header", "misconfigured_security_header", "information_disclosure_header",
    "suspicious_file_content", "sensitive_file_exposed",
    "correlated_finding", "attack_chain", "risk_assessment",
    "enhanced_report",
}

# Prefijos de config para notificación por tipo de hallazgo
_NEW_PLUGIN_CONFIG_KEYS = (
    "notify_ioc", "notify_secret", "notify_ir", "notify_traffic",
    "notify_threat_intel", "notify_ssl", "notify_headers", "notify_file_forensics",
    "notify_correlation", "notify_report_enhancement",
)


def _short_endpoint(url: str) -> str:
    """Ruta sin query (los payloads no se filtran en el aviso)."""
    try:
        from urllib.parse import urlsplit
        p = urlsplit(str(url or ""))
        path = p.path or "/"
        return f"{p.netloc}{path}" if p.netloc else path
    except Exception:
        return str(url or "—")[:80]


def _short_host(url: str) -> str:
    try:
        from urllib.parse import urlsplit
        return urlsplit(str(url or "")).netloc or str(url or "—")[:60]
    except Exception:
        return str(url or "—")[:60]


def _clip(text: Any, limit: int = 140) -> str:
    t = str(text or "").replace("\n", " ").strip()
    return t if len(t) <= limit else t[: limit - 1] + "…"


def _evidence_lines(ev: Dict[str, Any]) -> List[str]:
    """Evidencia legible: solo claves con significado, jamás el dict crudo."""
    if not isinstance(ev, dict):
        return []
    out: List[str] = []
    base = ev.get("baseline") if isinstance(ev.get("baseline"), dict) else {}
    comp = ev.get("comparison") if isinstance(ev.get("comparison"), dict) else {}
    if base or comp:
        bs = base.get("status", "?") if base else "?"
        bb = base.get("bytes", base.get("id", "?")) if base else "?"
        cs = comp.get("status", "?") if comp else "?"
        cb = comp.get("bytes", comp.get("id", "?")) if comp else "?"
        secs = comp.get("seconds")
        tail = f" en {secs}s" if secs else ""
        out.append(f"• baseline {bs}/{bb} → sonda {cs}/{cb}{tail}")
    for key, label in (("matched_signature", "firma"), ("matched", "firma"),
                       ("signature", "firma"), ("technique", "técnica"),
                       ("ssrf_level", "nivel SSRF")):
        if ev.get(key):
            out.append(f"• {label}: {_clip(ev[key], 80)}")
            break
    techs = ev.get("techniques")
    if isinstance(techs, list) and len(techs) >= 2:
        out.append(f"• técnicas: {', '.join(str(t) for t in techs[:3])}")
    repro: List[str] = []
    if ev.get("retest") is True:
        repro.append(f"retest sí ({ev.get('retest_count', 2)})")
    if ev.get("second_file"):
        repro.append("2º fichero sí")
    if ev.get("reproduced") and ev.get("retest") is not True:
        repro.append("reproducible")
    if repro:
        out.append("• " + " · ".join(repro))
    if ev.get("timing_differential") and not (
            isinstance(ev.get("comparison"), dict) and ev["comparison"].get("seconds")):
        out.append(f"• diferencial temporal: {ev.get('timing_differential')}s")
    cross = (ev.get("authorization_matrix") or {}).get("cross_context") \
        if isinstance(ev.get("authorization_matrix"), dict) else None
    if isinstance(cross, dict) and cross.get("result"):
        out.append(f"• 2º contexto: {cross.get('result')} "
                   f"({str(cross.get('context_b', ''))})".strip())
    elif ev.get("verification_needed"):
        out.append("• pendiente: 2º contexto de autorización")
    for key in ("level_reasons", "policy_reasons"):
        vals = ev.get(key)
        if isinstance(vals, list) and vals:
            out.append(f"• {_clip(vals[0], 100)}")
            break
    return out[:6]


def _cve_line(f: Dict[str, Any], ev: Dict[str, Any]) -> str:
    """Línea CVE/CWE: directa del hallazgo o primer match conocido."""
    cve = f.get("cve") or ev.get("cve") or ""
    cwe = f.get("cwe") or ev.get("cwe") or ""
    exploit = ""
    if not cve:
        matches = f.get("cve_matches") or ev.get("cve_matches") or []
        if isinstance(matches, list) and matches:
            m = matches[0] if isinstance(matches[0], dict) else {}
            cve = str(m.get("id") or "")
            cwe = cwe or str(m.get("cwe") or "")
            if m.get("exploit"):
                exploit = " · exploit conocido"
    parts = []
    if cve:
        parts.append(str(cve))
    if cwe:
        parts.append(str(cwe))
    if not parts:
        return ""
    return "🛡 " + " / ".join(parts) + exploit


_PLUGIN_ICONS = {
    "ioc_match": "🎯",
    "suspicious_pattern": "⚠️",
    "secret_exposure": "🔑",
    "secret_in_header": "🔑",
    "ir_playbook": "🚨",
    "information_disclosure": "📡",
    "possible_c2_beacon": "📡",
    "possible_data_exfiltration": "📤",
    "threat_intel": "🛡",
    "ssl_error": "🔒",
    "ssl_expiration": "🔒",
    "ssl_weak_tls": "🔒",
    "ssl_weak_cipher": "🔒",
    "ssl_hostname_mismatch": "🔒",
    "missing_security_header": "🛡",
    "misconfigured_security_header": "🛡",
    "information_disclosure_header": "📡",
    "suspicious_file_content": "📄",
    "sensitive_file_exposed": "📄",
    "correlated_finding": "🔗",
    "attack_chain": "⛓",
    "risk_assessment": "📊",
    "enhanced_report": "📊",
}

_PLUGIN_TYPE_CONFIG = {
    "ioc_match": "notify_ioc",
    "suspicious_pattern": "notify_ioc",
    "secret_exposure": "notify_secret",
    "secret_in_header": "notify_secret",
    "ir_playbook": "notify_ir",
    "information_disclosure": "notify_traffic",
    "possible_c2_beacon": "notify_traffic",
    "possible_data_exfiltration": "notify_traffic",
    "threat_intel": "notify_threat_intel",
    "ssl_error": "notify_ssl",
    "ssl_expiration": "notify_ssl",
    "ssl_weak_tls": "notify_ssl",
    "ssl_weak_cipher": "notify_ssl",
    "ssl_hostname_mismatch": "notify_ssl",
    "missing_security_header": "notify_headers",
    "misconfigured_security_header": "notify_headers",
    "information_disclosure_header": "notify_headers",
    "suspicious_file_content": "notify_file_forensics",
    "sensitive_file_exposed": "notify_file_forensics",
    "correlated_finding": "notify_correlation",
    "attack_chain": "notify_correlation",
    "risk_assessment": "notify_correlation",
    "enhanced_report": "notify_report_enhancement",
}


def _plugin_config_key_for_type(finding_type: str) -> str:
    """Devuelve la clave de config que controla la notificación de un tipo de hallazgo 2.2.0."""
    return _PLUGIN_TYPE_CONFIG.get(finding_type, "")


def _plugin_detail_lines(f: Dict[str, Any], ev: Dict[str, Any]) -> List[str]:
    """Líneas de detalle específicas para cada tipo de hallazgo de plugin 2.2.0."""
    ftype = str(f.get("type") or "").lower()
    out: List[str] = []
    if ftype == "ioc_match":
        out.append(f"• Tipo IOC: {ev.get('ioc_type', '?')}")
        out.append(f"• Valor: {_clip(ev.get('ioc_value', '?'), 120)}")
        out.append(f"• Fuente: {ev.get('source', '?')}")
    elif ftype == "suspicious_pattern":
        out.append(f"• Patrón: {ev.get('pattern_type', '?')}")
        out.append(f"• Valor: {_clip(ev.get('pattern_value', '?'), 120)}")
    elif ftype in ("secret_exposure", "secret_in_header"):
        out.append(f"• Tipo secreto: {ev.get('secret_type', f.get('secret_type', '?'))}")
        out.append(f"• Source: {ev.get('source', f.get('source', '?'))}")
        out.append(f"• Preview: {ev.get('value_preview', '?')}")
    elif ftype == "ir_playbook":
        pb = ev.get("playbook")
        if isinstance(pb, dict):
            out.append(f"• Playbook: {pb.get('title', '?')}")
            out.append(f"• Prioridad: {pb.get('priority', '?')} · SLA: {pb.get('sla_hours', '?')}h")
            actions = pb.get("actions")
            if isinstance(actions, list):
                out.append(f"• Acciones: {len(actions)} pasos")
    elif ftype in ("information_disclosure", "information_disclosure_header"):
        out.append(f"• Cabecera: {ev.get('header', f.get('param', '?'))}")
        out.append(f"• Valor: {_clip(ev.get('value', ev.get('current_value', '?')), 100)}")
        rec = ev.get("recommendation")
        if rec:
            out.append(f"• Recomendación: {_clip(rec, 100)}")
    elif ftype == "possible_c2_beacon":
        out.append(f"• Host: {ev.get('host', f.get('host', '?'))}")
        out.append(f"• Intervalo: ~{ev.get('interval_seconds', '?')}s")
        out.append(f"• Muestras: {ev.get('samples', '?')}")
    elif ftype == "possible_data_exfiltration":
        out.append(f"• URL: {_clip(ev.get('url', f.get('url', '')), 160)}")
        out.append(f"• Body size: {ev.get('body_size', f.get('body_size', '?'))} bytes")
    elif ftype == "threat_intel":
        cves = ev.get("cves")
        if isinstance(cves, list):
            out.append(f"• CVEs: {len(cves)}")
            for cve in cves[:3]:
                if isinstance(cve, dict):
                    out.append(f"  - {cve.get('cve', '?')} ({cve.get('severity', '?')}): "
                               f"{_clip(cve.get('description', ''), 80)}")
        techs = ev.get("technologies")
        if isinstance(techs, list):
            out.append(f"• Tecnologías: {', '.join(str(t) for t in techs[:5])}")
    elif ftype in ("ssl_error", "ssl_expiration", "ssl_weak_tls", "ssl_weak_cipher", "ssl_hostname_mismatch"):
        if ev.get("status"):
            out.append(f"• Estado: {ev['status']}")
        if ev.get("days_remaining") is not None:
            out.append(f"• Días restantes: {ev['days_remaining']}")
        if ev.get("tls_version"):
            out.append(f"• TLS: {ev['tls_version']}")
        if ev.get("cipher"):
            out.append(f"• Cipher: {ev['cipher']}")
        if ev.get("cert_domains"):
            out.append(f"• Cert SANs: {', '.join(str(d) for d in ev['cert_domains'][:5])}")
    elif ftype == "missing_security_header":
        out.append(f"• Cabecera: {ev.get('header', f.get('param', '?'))}")
        out.append(f"• Descripción: {ev.get('description', '?')}")
        rec = ev.get("recommendation")
        if rec:
            out.append(f"• Recomendación: {rec}")
    elif ftype == "misconfigured_security_header":
        out.append(f"• Cabecera: {ev.get('header', f.get('param', '?'))}")
        out.append(f"• Valor actual: {_clip(ev.get('current_value', '?'), 100)}")
        rec = ev.get("recommendation")
        if rec:
            out.append(f"• Recomendación: {rec}")
    elif ftype == "suspicious_file_content":
        out.append(f"• Patrón: {ev.get('pattern', f.get('param', '?'))}")
        out.append(f"• Match: {_clip(ev.get('match', ''), 100)}")
        out.append(f"• Fichero: {ev.get('filename', f.get('url', '?'))}")
    elif ftype == "sensitive_file_exposed":
        out.append(f"• Extensión: {ev.get('extension', f.get('param', '?'))}")
        out.append(f"• Descripción: {ev.get('description', '?')}")
    elif ftype == "correlated_finding":
        out.append(f"• Regla: {ev.get('rule_name', '?')}")
        out.append(f"• Tipos requeridos: {', '.join(ev.get('required_types', []))}")
        sf = ev.get("source_findings")
        if isinstance(sf, list):
            out.append(f"• Hallazgos fuente: {len(sf)}")
    elif ftype == "attack_chain":
        chain = ev.get("chain")
        if isinstance(chain, list):
            out.append(f"• Cadena: {' → '.join(str(s) for s in chain)}")
        if ev.get("description"):
            out.append(f"• Descripción: {_clip(ev['description'], 120)}")
    elif ftype == "risk_assessment":
        out.append(f"• Score: {ev.get('risk_score', '?')}")
        out.append(f"• Nivel: {ev.get('risk_level', '?')}")
        sc = ev.get("severity_counts")
        if isinstance(sc, dict):
            out.append(f"• Por severidad: "
                       f"🔴{sc.get('critical', 0)} 🟠{sc.get('high', 0)} "
                       f"🟡{sc.get('medium', 0)} 🔵{sc.get('low', 0)}")
    elif ftype == "enhanced_report":
        st = ev.get("statistics")
        if isinstance(st, dict):
            out.append(f"• Total hallazgos: {st.get('total', '?')}")
            out.append(f"• Críticos: {st.get('critical_count', 0)} · Altos: {st.get('high_count', 0)}")
    return out


def format_new_plugin_finding(f: Dict[str, Any], target: str = "") -> str:
    """Formatea hallazgos de plugins 2.2.0 con detalle especializado por tipo.

    A diferencia de format_finding (hallazgos de motores de verificación),
    aquí se prioriza la evidencia propia de cada plugin: IOC valor/fuente,
    playbook prioridad/SLA, secreto tipo/source, regla de correlación, etc.
    """
    ftype = str(f.get("type") or "").lower()
    sev = str(f.get("severity") or "info").lower()
    icon = _PLUGIN_ICONS.get(ftype, "🧩")
    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    url = str(f.get("url") or f.get("endpoint") or "")
    lines = [
        f"🛡 HT FORGE · PLUGIN 2.2.0 · {_SEV_EMOJI.get(sev, '⚪')} [{sev.upper()}]",
        f"{icon} {f.get('title') or ftype.replace('_', ' ').title()}",
        f"🆔 {f.get('finding_id') or '—'}",
    ]
    if target or url:
        lines.append(f"🎯 {_short_host(target or url)}")
    if url:
        lines.append(f"🔗 {_clip(url, 220)}")
    param = f.get("parameter") or f.get("param") or ""
    if param:
        lines.append(f"📌 Parámetro: {param}")
    cwe = f.get("cwe") or ev.get("cwe") or ""
    if cwe:
        lines.append(f"🛡 {cwe}")
    detail_lines = _plugin_detail_lines(f, ev)
    if detail_lines:
        lines.append("🔬 Evidencia:")
        lines.extend(detail_lines)
    detail = str(f.get("detail") or f.get("description") or "")
    if detail:
        lines.append(f"📝 {_clip(detail, 220)}")
    module = f.get("module") or ""
    if module:
        lines.append(f"🧩 Módulo: {module}")
    lines.append("📋 Detalle y descarga en el panel → Reportes")
    return "\n".join(lines)[:1500]


def format_finding(f: Dict[str, Any], target: str = "") -> str:
    sev = str(f.get("severity") or "info").lower()
    state = str(f.get("verification_state") or "CANDIDATE").upper()
    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    try:
        conf = f.get("confidence", "")
        conf_n = float(conf)
        conf_txt = f"{int(conf_n * 100) if conf_n <= 1 else int(conf_n)}%"
    except (TypeError, ValueError):
        conf_txt = str(conf) if conf != "" else "—"
    score = ev.get("evidence_score", "?")
    url = str(f.get("url") or f.get("endpoint") or "")
    method = str(f.get("method") or ev.get("method") or "GET").upper()
    lines = [
        f"🛡 HT FORGE · {_STATE_BADGE.get(state, state)} · score {score}",
        f"{_SEV_EMOJI.get(sev, '⚪')} [{sev.upper()}] "
        f"{f.get('title') or f.get('type') or 'Hallazgo'}",
        f"🆔 {f.get('finding_id') or '—'}",
        f"🎯 {_short_host(target or url)}",
        f"🔗 {_clip(url, 220)} ({method})",
    ]
    cve_line = _cve_line(f, ev)
    if cve_line:
        lines.append(cve_line)
    param = f.get("parameter") or f.get("param") or ev.get("parameter")
    if param:
        lines.append(f"📌 Parámetro: {param}")
    payload = f.get("payload") or ev.get("payload")
    if payload:
        lines.append(f"💉 Payload: {_clip(payload, 100)}")
    lines.append(f"🎲 Confianza: {conf_txt} · Módulo: {f.get('module') or '?'}")
    detail = str(f.get("detail") or f.get("description") or "")
    if detail:
        lines.append(f"📝 {_clip(detail, 220)}")
    ev_lines = _evidence_lines(ev)
    if ev_lines:
        lines.append("🔬 Evidencia:")
        lines.extend(ev_lines)
    lines.append("📋 Detalle y descarga en el panel → Reportes")
    return "\n".join(lines)[:1500]


def notify_finding(finding: Dict[str, Any], target: str = "") -> None:
    try:
        cfg = get_config()
        if not cfg.get("enabled") or not cfg.get("notify_findings"):
            return
        if not _passes_severity(str(finding.get("severity") or "info"), str(cfg.get("min_severity", "medium"))):
            return
        ftype = str(finding.get("type") or "").lower()
        is_new_plugin = ftype in _NEW_PLUGIN_TYPES
        if is_new_plugin:
            # Los plugins 2.2.0 no usan verification_state; se notifican según su config específica
            config_key = _plugin_config_key_for_type(ftype)
            if config_key and not cfg.get(config_key, True):
                return
        elif cfg.get("only_actionable", True):
            state = str(finding.get("verification_state") or "CANDIDATE").upper()
            if state not in _ACTIONABLE:
                return
        if is_new_plugin:
            formatted = format_new_plugin_finding(finding, target)
        else:
            formatted = format_finding(finding, target)
        _async_send("🛡 HT Forge — nuevo hallazgo\n\n" + formatted)
    except Exception:
        pass


def format_summary(session: Any) -> str:
    try:
        findings: List[Dict[str, Any]] = list(getattr(session, "findings", []) or [])
    except Exception:
        findings = []
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    act = dict(counts)
    states = {"CONFIRMED": 0, "VERIFIED": 0, "LIKELY": 0}
    for f in findings:
        if not isinstance(f, dict):
            continue
        s = str(f.get("severity") or "info").lower()
        if s in counts:
            counts[s] += 1
        st = str(f.get("verification_state") or "").upper()
        if st in states:
            states[st] += 1
            if s in act:
                act[s] += 1
    n_act = sum(act.values())
    target = getattr(session, "target", "—")
    profile = getattr(session, "profile", "")
    meta = getattr(session, "metadata", None)
    elapsed = ""
    try:
        secs = (meta or {}).get("metrics", {}).get("elapsed_seconds")
        elapsed = f" · {int(float(secs))}s" if secs is not None else ""
    except (TypeError, ValueError):
        pass
    lines = [
        "🛡 HT FORGE · SCAN FINISHED",
        f"🎯 {_short_host(str(target))}" + (f" · perfil {profile}" if profile else "") + elapsed,
        f"📊 {len(findings)} hallazgos ({n_act} accionables)",
        (f"🔴{act['critical']} 🟠{act['high']} 🟡{act['medium']} "
         f"🔵{act['low']} ⚪{act['info']}  (accionables)"),
        (f"✅{states['CONFIRMED']} confirmados · "
         f"✔️{states['VERIFIED']} verificados · "
         f"🟡{states['LIKELY']} probables"),
    ]
    # Top accionable sin duplicados por (severidad, título, endpoint).
    seen = set()
    top: List[str] = []
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    ranked = sorted(
        [f for f in findings if isinstance(f, dict)
         and str(f.get("verification_state") or "").upper() in _ACTIONABLE],
        key=lambda f: (order.get(str(f.get("severity") or "info").lower(), 5),
                       str(f.get("title") or "")))
    for f in ranked:
        sev = str(f.get("severity") or "info").lower()
        state = str(f.get("verification_state") or "").upper()
        badge = {"CONFIRMED": "✅", "VERIFIED": "✔️", "LIKELY": "🟡"}.get(state, "•")
        key = (sev, str(f.get("title") or f.get("type") or "?"),
               _short_endpoint(str(f.get("url") or "")))
        if key in seen:
            continue
        seen.add(key)
        param = f.get("parameter") or f.get("param") or ""
        extra = f" (par. {param})" if param else ""
        cve = str(f.get("cve") or (f.get("evidence") or {}).get("cve") or "")
        if not cve:
            _m = f.get("cve_matches") or []
            if isinstance(_m, list) and _m and isinstance(_m[0], dict):
                cve = str(_m[0].get("id") or "")
        if cve:
            extra += f" · {cve}"
        top.append(f"{badge} [{sev.upper()}] {key[1]} — {key[2]}{extra}")
        if len(top) >= 8:
            break
    if top:
        lines.append("TOP:")
        lines.extend(top)
    lines.append("📋 Detalle y descarga en el panel → Reportes")
    return "\n".join(lines)[:3500]


def notify_summary(session: Any) -> None:
    try:
        cfg = get_config()
        if not cfg.get("enabled") or not cfg.get("notify_summary"):
            return
        _async_send(format_summary(session))
    except Exception:
        pass


def test_message() -> Dict[str, Any]:
    """Envía un mensaje de prueba de forma síncrona. Devuelve el resultado (lanza si falla)."""
    cfg = get_config()
    if not cfg.get("token") or not cfg.get("chat_id"):
        raise ValueError("Configura token y chat_id primero")
    started = time.monotonic()
    res = _send(str(cfg["token"]), str(cfg["chat_id"]),
                "🛡 HT Forge — conexión Telegram verificada ✅")
    return {"ok": bool(res.get("ok")), "took_s": round(time.monotonic() - started, 2), "response": res}
