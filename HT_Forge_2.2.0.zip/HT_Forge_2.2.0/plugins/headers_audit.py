"""
Headers Audit — Auditoría de seguridad de cabeceras HTTP.
Verifica la presencia y correcta configuración de cabeceras de seguridad.
"""
from typing import Dict, List

PLUGIN_NAME = "headers_audit"
PLUGIN_DESCRIPTION = "Auditoría de cabeceras de seguridad HTTP: HSTS, CSP, X-Frame-Options, etc."
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Cabeceras de seguridad requeridas y sus configuraciones esperadas
SECURITY_HEADERS = {
    'strict-transport-security': {
        'description': 'HSTS (HTTP Strict Transport Security)',
        'required': True,
        'severity_if_missing': 'high',
        'check': lambda v: 'max-age=' in v.lower() and int(v.split('max-age=')[1].split(';')[0]) >= 31536000,
        'recommendation': 'Strict-Transport-Security: max-age=31536000; includeSubDomains',
    },
    'content-security-policy': {
        'description': 'CSP (Content Security Policy)',
        'required': True,
        'severity_if_missing': 'high',
        'check': lambda v: len(v) > 10 and 'default-src' in v.lower(),
        'recommendation': "Content-Security-Policy: default-src 'self'; script-src 'self'",
    },
    'x-frame-options': {
        'description': 'X-Frame-Options (protección contra clickjacking)',
        'required': True,
        'severity_if_missing': 'medium',
        'check': lambda v: v.upper() in ('DENY', 'SAMEORIGIN'),
        'recommendation': 'X-Frame-Options: DENY',
    },
    'x-content-type-options': {
        'description': 'X-Content-Type-Options (protección contra MIME sniffing)',
        'required': True,
        'severity_if_missing': 'medium',
        'check': lambda v: v.lower() == 'nosniff',
        'recommendation': 'X-Content-Type-Options: nosniff',
    },
    'referrer-policy': {
        'description': 'Referrer Policy',
        'required': False,
        'severity_if_missing': 'low',
        'check': lambda v: v.lower() in ('no-referrer', 'strict-origin-when-cross-origin', 'same-origin'),
        'recommendation': 'Referrer-Policy: strict-origin-when-cross-origin',
    },
    'permissions-policy': {
        'description': 'Permissions Policy',
        'required': False,
        'severity_if_missing': 'low',
        'check': lambda v: len(v) > 5,
        'recommendation': 'Permissions-Policy: camera=(), microphone=(), geolocation=()',
    },
    'x-xss-protection': {
        'description': 'X-XSS-Protection (obsoleto pero aún usado)',
        'required': False,
        'severity_if_missing': 'info',
        'check': lambda v: v.lower() in ('1; mode=block', '0'),
        'recommendation': 'X-XSS-Protection: 1; mode=block',
    },
}

# Cabeceras que deben estar ausentes (fugas de información)
HEADERS_TO_REMOVE = {
    'server': 'Revela información del servidor',
    'x-powered-by': 'Revela tecnología backend',
    'x-aspnet-version': 'Revela versión de ASP.NET',
    'x-generator': 'Revela generador de CMS',
}

def _check_security_headers(headers: Dict[str, str], url: str) -> List[Dict]:
    """Verifica la presencia y configuración de cabeceras de seguridad."""
    findings = []
    headers_lower = {k.lower(): v for k, v in headers.items()}
    
    for header, config in SECURITY_HEADERS.items():
        if header not in headers_lower:
            if config['required']:
                findings.append({
                    'type': 'missing_security_header',
                    'severity': config['severity_if_missing'],
                    'confidence': 95,
                    'url': url,
                    'param': header,
                    'description': f"Cabecera de seguridad faltante: {config['description']}",
                    'evidence': {
                        'header': header,
                        'description': config['description'],
                        'recommendation': config['recommendation'],
                    },
                    'cwe': 'CWE-693',
                    'references': ['https://owasp.org/www-project-secure-headers/'],
                })
        else:
            # Verificar configuración
            value = headers_lower[header]
            if not config['check'](value):
                findings.append({
                    'type': 'misconfigured_security_header',
                    'severity': 'medium',
                    'confidence': 85,
                    'url': url,
                    'param': header,
                    'description': f"Cabecera de seguridad mal configurada: {config['description']}",
                    'evidence': {
                        'header': header,
                        'current_value': value,
                        'recommendation': config['recommendation'],
                    },
                    'cwe': 'CWE-693',
                    'references': ['https://owasp.org/www-project-secure-headers/'],
                })
    
    return findings

def _check_information_disclosure(headers: Dict[str, str], url: str) -> List[Dict]:
    """Verifica cabeceras que revelan información sensible."""
    findings = []
    headers_lower = {k.lower(): v for k, v in headers.items()}
    
    for header, description in HEADERS_TO_REMOVE.items():
        if header in headers_lower:
            findings.append({
                'type': 'information_disclosure_header',
                'severity': 'low',
                'confidence': 90,
                'url': url,
                'param': header,
                'description': f"Cabecera revela información: {description}",
                'evidence': {
                    'header': header,
                    'value': headers_lower[header],
                    'description': description,
                },
                'cwe': 'CWE-200',
                'references': ['https://owasp.org/www-project-web-security-testing-guide/'],
            })
    
    return findings

async def run(ctx):
    """Ejecuta la auditoría de cabeceras de seguridad."""
    findings = []
    
    # Obtener respuestas cacheadas
    cached_responses = ctx.get('cached_responses', {})
    
    if not cached_responses:
        ctx.log('info', "Headers Audit: No hay respuestas cacheadas para analizar")
        return {'plugin': PLUGIN_NAME, 'findings': [], 'stats': {}}
    
    for url, response in cached_responses.items():
        if not isinstance(response, dict):
            continue
        
        headers = response.get('headers', {})
        if not headers:
            continue
        
        # 1. Verificar cabeceras de seguridad
        security_findings = _check_security_headers(headers, url)
        findings.extend(security_findings)
        
        # 2. Verificar fugas de información
        disclosure_findings = _check_information_disclosure(headers, url)
        findings.extend(disclosure_findings)
    
    ctx.log('info', f"Headers Audit: {len(findings)} hallazgos en {len(cached_responses)} respuestas")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'responses_analyzed': len(cached_responses),
            'missing_headers': len([f for f in findings if f['type'] == 'missing_security_header']),
            'misconfigured_headers': len([f for f in findings if f['type'] == 'misconfigured_security_header']),
            'information_disclosure': len([f for f in findings if f['type'] == 'information_disclosure_header']),
        }
    }