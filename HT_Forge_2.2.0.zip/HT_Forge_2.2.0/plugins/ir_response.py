"""
IR Response — Playbooks de respuesta a incidentes.
Genera planes de respuesta automatizados basados en los hallazgos detectados.
"""
from typing import Dict, List

PLUGIN_NAME = "ir_response"
PLUGIN_DESCRIPTION = "Generación de playbooks de respuesta a incidentes basados en hallazgos"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Mapeo de tipos de hallazgo a playbooks
PLAYBOOKS = {
    'sqli': {
        'title': 'SQL Injection — Respuesta Inmediata',
        'priority': 'P1',
        'actions': [
            '1. Aislar el endpoint afectado (WAF rule temporal)',
            '2. Revisar logs de acceso para identificar el origen del ataque',
            '3. Rotar credenciales de base de datos',
            '4. Parchear consultas parametrizadas',
            '5. Verificar integridad de datos (posible manipulación)',
        ],
        'sla_hours': 4,
    },
    'xss': {
        'title': 'Cross-Site Scripting — Respuesta Inmediata',
        'priority': 'P2',
        'actions': [
            '1. Identificar el parámetro vulnerable',
            '2. Implementar output encoding contextual',
            '3. Revisar CSP (Content Security Policy)',
            '4. Buscar posible robo de sesiones',
            '5. Notificar a usuarios afectados si hay datos comprometidos',
        ],
        'sla_hours': 24,
    },
    'rce': {
        'title': 'Remote Code Execution — Respuesta Inmediata',
        'priority': 'P0',
        'actions': [
            '1. Aislar el servidor inmediatamente',
            '2. Preservar evidencia (memoria, disco, logs)',
            '3. Identificar vector de explotación',
            '4. Parchear vulnerabilidad',
            '5. Rotar todas las credenciales del servidor',
            '6. Analizar persistencia (backdoors, cron jobs)',
            '7. Revisar movimiento lateral',
        ],
        'sla_hours': 1,
    },
    'ssrf': {
        'title': 'Server-Side Request Forgery — Respuesta Inmediata',
        'priority': 'P1',
        'actions': [
            '1. Restringir acceso a red interna desde el endpoint',
            '2. Implementar allowlist de dominios/IPs',
            '3. Deshabilitar esquemas de URL no necesarios (file://, gopher://)',
            '4. Revisar logs para identificar requests internos',
        ],
        'sla_hours': 4,
    },
    'lfi': {
        'title': 'Local File Inclusion — Respuesta Inmediata',
        'priority': 'P1',
        'actions': [
            '1. Validar y sanitizar rutas de archivo',
            '2. Implementar allowlist de directorios',
            '3. Deshabilitar inclusiones remotas',
            '4. Revisar logs para identificar archivos accedidos',
        ],
        'sla_hours': 4,
    },
    'idor': {
        'title': 'Insecure Direct Object Reference — Respuesta Inmediata',
        'priority': 'P2',
        'actions': [
            '1. Implementar autorización por objeto',
            '2. Usar IDs no secuenciales (UUIDs)',
            '3. Verificar ownership antes de cada acceso',
            '4. Revisar logs de acceso a objetos',
        ],
        'sla_hours': 24,
    },
    'open_redirect': {
        'title': 'Open Redirect — Respuesta Inmediata',
        'priority': 'P3',
        'actions': [
            '1. Implementar allowlist de dominios de redirección',
            '2. Validar URLs de destino',
            '3. Deshabilitar redirecciones a dominios arbitrarios',
        ],
        'sla_hours': 72,
    },
    'default_credentials': {
        'title': 'Credenciales por defecto — Respuesta Inmediata',
        'priority': 'P0',
        'actions': [
            '1. Cambiar todas las contraseñas por defecto inmediatamente',
            '2. Forzar cambio de contraseña en próximo login',
            '3. Implementar política de contraseñas robusta',
            '4. Revisar logs de acceso',
        ],
        'sla_hours': 1,
    },
}

# Mapeo de CWE a tipo de playbook
CWE_TO_PLAYBOOK = {
    'CWE-89': 'sqli',
    'CWE-79': 'xss',
    'CWE-94': 'rce',
    'CWE-918': 'ssrf',
    'CWE-98': 'lfi',
    'CWE-639': 'idor',
    'CWE-601': 'open_redirect',
    'CWE-798': 'default_credentials',
}

def _map_finding_to_playbook(finding: Dict) -> Dict:
    """Mapea un hallazgo a su playbook correspondiente."""
    finding_type = finding.get('type', '').lower()
    cwe = finding.get('cwe', '')
    
    # Primero intenta por tipo
    if finding_type in PLAYBOOKS:
        return PLAYBOOKS[finding_type]
    
    # Luego por CWE
    if cwe in CWE_TO_PLAYBOOK:
        return PLAYBOOKS[CWE_TO_PLAYBOOK[cwe]]
    
    # Fallback: generar playbook genérico
    return {
        'title': f"Respuesta genérica para {finding_type or 'hallazgo desconocido'}",
        'priority': 'P2',
        'actions': [
            '1. Analizar el hallazgo en detalle',
            '2. Determinar el alcance del impacto',
            '3. Implementar mitigación',
            '4. Verificar la corrección',
        ],
        'sla_hours': 24,
    }

async def run(ctx):
    """Genera playbooks de respuesta basados en hallazgos."""
    findings = []
    
    # Obtener hallazgos del contexto
    session_findings = ctx.get('findings', [])
    
    if not session_findings:
        ctx.log('info', "IR Response: No hay hallazgos para generar playbooks")
        return {
            'plugin': PLUGIN_NAME,
            'findings': [],
            'stats': {'playbooks_generated': 0}
        }
    
    # Obtener playbooks ya generados para evitar duplicados
    existing_playbooks = ctx.get('ir_playbooks', [])
    generated_types = {pb.get('trigger_type') for pb in existing_playbooks}
    
    # Generar playbooks para hallazgos críticos y altos
    for finding in session_findings:
        severity = finding.get('severity', '').lower()
        if severity not in ('critical', 'high'):
            continue
        
        finding_type = finding.get('type', '').lower()
        if finding_type in generated_types:
            continue
        
        playbook = _map_finding_to_playbook(finding)
        
        finding_ir = {
            'type': 'ir_playbook',
            'severity': 'info',
            'confidence': 100,
            'url': finding.get('url', ''),
            'param': finding.get('param', ''),
            'description': f"Playbook IR generado: {playbook['title']}",
            'evidence': {
                'trigger_type': finding_type,
                'trigger_severity': severity,
                'playbook': playbook,
            },
            'cwe': finding.get('cwe', ''),
            'references': [],
        }
        findings.append(finding_ir)
        generated_types.add(finding_type)
    
    ctx.log('info', f"IR Response: {len(findings)} playbooks generados")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'playbooks_generated': len(findings),
            'critical_findings': len([f for f in session_findings if f.get('severity') == 'critical']),
        }
    }