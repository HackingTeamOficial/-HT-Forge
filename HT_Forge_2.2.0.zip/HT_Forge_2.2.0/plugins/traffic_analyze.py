"""
Traffic Analyzer — Análisis de tráfico HTTP para detectar patrones C2,
beacons regulares, y fugas de información en cabeceras.
"""
import re
import time
from collections import defaultdict
from typing import Dict, List
from urllib.parse import urlparse

PLUGIN_NAME = "traffic_analyze"
PLUGIN_DESCRIPTION = "Análisis de tráfico HTTP: detección de C2, beacons, y fugas de información en cabeceras"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Cabeceras que pueden revelar información sensible
SENSITIVE_HEADERS = {
    'server': ' Revela versión exacta del servidor',
    'x-powered-by': ' Revela tecnología backend',
    'x-aspnet-version': ' Revela versión de ASP.NET',
    'x-generator': ' Revela generador de CMS',
    'x-runtime': ' Revela framework runtime',
    'via': ' Revela proxy inverso',
    'x-cache': ' Revela configuración de caché',
}

# Patrones de beacons C2 (intervalos regulares)
BEACON_INTERVAL_THRESHOLD = 5  # segundos
BEACON_MIN_SAMPLES = 3

def _analyze_headers(headers: Dict[str, str]) -> List[Dict]:
    """Analiza cabeceras HTTP en busca de fugas de información."""
    findings = []
    headers_lower = {k.lower(): v for k, v in headers.items()}
    
    for header, description in SENSITIVE_HEADERS.items():
        if header in headers_lower:
            findings.append({
                'type': 'information_disclosure',
                'header': header,
                'value': headers_lower[header],
                'description': f"Cabecera '{header}' {description}: {headers_lower[header]}",
                'severity': 'low',
                'confidence': 80,
            })
    
    return findings

def _detect_beacons(requests_log: List[Dict]) -> List[Dict]:
    """Detecta patrones de beacons C2 basados en intervalos regulares."""
    findings = []
    
    # Agrupa requests por host
    host_requests = defaultdict(list)
    for req in requests_log:
        url = req.get('url', '')
        parsed = urlparse(url)
        host = parsed.netloc
        timestamp = req.get('timestamp', 0)
        host_requests[host].append({
            'path': parsed.path,
            'timestamp': timestamp,
            'method': req.get('method', 'GET'),
        })
    
    # Busca intervalos regulares
    for host, reqs in host_requests.items():
        if len(reqs) < BEACON_MIN_SAMPLES:
            continue
        
        # Ordena por timestamp
        reqs.sort(key=lambda x: x['timestamp'])
        
        # Calcula intervalos
        intervals = []
        for i in range(1, len(reqs)):
            interval = reqs[i]['timestamp'] - reqs[i-1]['timestamp']
            intervals.append(interval)
        
        if not intervals:
            continue
        
        # Verifica si los intervalos son regulares (baja desviación estándar)
        avg_interval = sum(intervals) / len(intervals)
        variance = sum((x - avg_interval) ** 2 for x in intervals) / len(intervals)
        std_dev = variance ** 0.5
        
        # Si la desviación es baja respecto al promedio, es un patrón regular
        if std_dev < avg_interval * 0.3 and avg_interval < 60:
            findings.append({
                'type': 'possible_c2_beacon',
                'host': host,
                'path_pattern': reqs[0]['path'],
                'interval_seconds': round(avg_interval, 1),
                'samples': len(reqs),
                'description': f"Posible beacon C2 detectado: {host}{reqs[0]['path']} cada ~{avg_interval:.1f}s",
                'severity': 'critical',
                'confidence': 85,
            })
    
    return findings

def _detect_data_exfiltration(requests_log: List[Dict]) -> List[Dict]:
    """Detecta posibles exfiltraciones de datos (POST grandes a dominios externos)."""
    findings = []
    
    for req in requests_log:
        if req.get('method') != 'POST':
            continue
        
        url = req.get('url', '')
        parsed = urlparse(url)
        body_size = req.get('body_size', 0)
        
        # Si el POST es grande (>10KB) y va a un dominio diferente al target
        if body_size > 10000:
            findings.append({
                'type': 'possible_data_exfiltration',
                'url': url,
                'body_size': body_size,
                'description': f"Posible exfiltración: POST de {body_size} bytes a {url}",
                'severity': 'high',
                'confidence': 60,
            })
    
    return findings

async def run(ctx):
    """Ejecuta el análisis de tráfico."""
    findings = []
    
    # Obtener requests log del contexto
    requests_log = ctx.get('requests_log', [])
    
    if not requests_log:
        ctx.log('info', "Traffic Analyzer: No hay requests log disponibles")
        return {
            'plugin': PLUGIN_NAME,
            'findings': [],
            'stats': {'requests_analyzed': 0}
        }
    
    # 1. Analizar cabeceras de todas las respuestas
    for req in requests_log:
        headers = req.get('response_headers', {})
        if headers:
            header_findings = _analyze_headers(headers)
            for hf in header_findings:
                hf['url'] = req.get('url', '')
                findings.append(hf)
    
    # 2. Detectar beacons C2
    beacon_findings = _detect_beacons(requests_log)
    findings.extend(beacon_findings)
    
    # 3. Detectar exfiltraciones
    exfil_findings = _detect_data_exfiltration(requests_log)
    findings.extend(exfil_findings)
    
    ctx.log('info', f"Traffic Analyzer: {len(findings)} hallazgos en {len(requests_log)} requests")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'requests_analyzed': len(requests_log),
            'beacons_detected': len(beacon_findings),
            'exfiltration_detected': len(exfil_findings),
        }
    }