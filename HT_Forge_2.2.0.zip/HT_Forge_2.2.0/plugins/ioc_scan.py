"""
IOC Scanner — Motor de detección de Indicadores de Compromiso.
Busca dominios, IPs, hashes y URLs en el contenido escaneado
y los verifica contra listas locales de IOCs y feeds configurables.
"""
import re
import json
import hashlib
from pathlib import Path
from typing import Dict, List, Set

PLUGIN_NAME = "ioc_scan"
PLUGIN_DESCRIPTION = "Detección de IOCs (dominios, IPs, hashes, URLs) contra listas locales y feeds"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Patrones de extracción
IP_PATTERN = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
DOMAIN_PATTERN = re.compile(r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b')
URL_PATTERN = re.compile(r'https?://[^\s<>"{}|\\^`\[\]]+')
HASH_PATTERN = re.compile(r'\b[a-fA-F0-9]{32,64}\b')

# Dominios/URLs comunes que no son IOCs
FALSE_POSITIVE_DOMAINS = {
    'w3.org', 'localhost', 'example.com', 'schemas.xmlsoap.org',
    'apache.org', 'nginx.org', 'github.com', 'stackoverflow.com',
    'google.com', 'microsoft.com', 'apple.com', 'amazon.com',
    'cloudflare.com', 'akamai.com', 'fastly.com',
}

# Cabeceras de usuario comunes en C2
SUSPICIOUS_USER_AGENTS = [
    'meterpreter', 'cobalt strike', 'empire', 'posh',
    'nc', 'netcat', 'ncat', 'socat',
]

def _load_local_iocs(ctx) -> Dict[str, Set[str]]:
    """Carga IOCs desde archivos locales en runtime/iocs/."""
    iocs = {'ips': set(), 'domains': set(), 'urls': set(), 'hashes': set()}
    ioc_dir = Path(ctx.config.get('ioc_dir', 'runtime/iocs'))
    if not ioc_dir.exists():
        return iocs
    for f in ioc_dir.glob('*.txt'):
        try:
            for line in f.read_text(errors='ignore').splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if IP_PATTERN.fullmatch(line):
                    iocs['ips'].add(line)
                elif DOMAIN_PATTERN.fullmatch(line):
                    iocs['domains'].add(line.lower())
                elif URL_PATTERN.fullmatch(line):
                    iocs['urls'].add(line)
                elif HASH_PATTERN.fullmatch(line):
                    iocs['hashes'].add(line.lower())
        except Exception:
            pass
    return iocs

def _extract_iocs_from_content(content: str) -> Dict[str, Set[str]]:
    """Extrae IOCs potenciales de un string."""
    return {
        'ips': set(IP_PATTERN.findall(content)),
        'domains': set(d.lower() for d in DOMAIN_PATTERN.findall(content)),
        'urls': set(URL_PATTERN.findall(content)),
        'hashes': set(h.lower() for h in HASH_PATTERN.findall(content)),
    }

def _check_against_feeds(iocs: Dict[str, Set[str]], local_iocs: Dict[str, Set[str]]) -> List[Dict]:
    """Cruza IOCs extraídos con listas locales."""
    matches = []
    for ioc_type, values in iocs.items():
        local_set = local_iocs.get(ioc_type, set())
        for val in values:
            if val in local_set:
                matches.append({
                    'type': ioc_type,
                    'value': val,
                    'source': 'local_iocs',
                })
    return matches

def _check_suspicious_patterns(content: str) -> List[Dict]:
    """Busca patrones sospechosos de C2 en el contenido."""
    findings = []
    content_lower = content.lower()
    
    # User-agents sospechosos
    for ua in SUSPICIOUS_USER_AGENTS:
        if ua in content_lower:
            findings.append({
                'type': 'suspicious_user_agent',
                'value': ua,
                'source': 'pattern_match',
            })
    
    # Patrones de beacon C2 (llamadas regulares a un endpoint)
    beacon_pattern = re.compile(r'(?:GET|POST)\s+/[a-z0-9_\-]{10,}/[a-z0-9_\-]{10,}', re.IGNORECASE)
    for match in beacon_pattern.findall(content):
        findings.append({
            'type': 'possible_c2_beacon',
            'value': match,
            'source': 'pattern_match',
        })
    
    return findings

async def run(ctx):
    """Ejecuta el escaneo de IOCs."""
    findings = []
    
    # 1. Cargar IOCs locales
    local_iocs = _load_local_iocs(ctx)
    
    # 2. Extraer IOCs del contenido escaneado
    all_content = []
    
    # URLs descubiertas
    discovered_urls = ctx.get('discovered_urls', [])
    for url in discovered_urls:
        all_content.append(url)
    
    # Parámetros descubiertos
    discovered_params = ctx.get('discovered_params', [])
    for param in discovered_params:
        if isinstance(param, dict):
            url = param.get('url', '')
            if url:
                all_content.append(url)
    
    # Responses cacheadas (si existen)
    cached_responses = ctx.get('cached_responses', {})
    for url, response in cached_responses.items():
        if isinstance(response, dict):
            body = response.get('body', '')
            headers = response.get('headers', '')
            all_content.append(body)
            all_content.append(str(headers))
    
    # 3. Extraer IOCs de todo el contenido
    combined_content = '\n'.join(all_content)
    extracted = _extract_iocs_from_content(combined_content)
    
    # 4. Filtrar falsos positivos
    extracted['domains'] = {d for d in extracted['domains'] if d not in FALSE_POSITIVE_DOMAINS}
    
    # 5. Verificar contra feeds locales
    feed_matches = _check_against_feeds(extracted, local_iocs)
    
    for match in feed_matches:
        finding = {
            'type': 'ioc_match',
            'severity': 'critical',
            'confidence': 90,
            'url': match.get('value', ''),
            'param': match['type'],
            'description': f"IOC detectado: {match['type']} = {match['value']} (fuente: {match['source']})",
            'evidence': {
                'ioc_type': match['type'],
                'ioc_value': match['value'],
                'source': match['source'],
            },
            'cwe': 'CWE-1104',
            'references': ['https://attack.mitre.org/'],
        }
        findings.append(finding)
    
    # 6. Buscar patrones sospechosos de C2
    suspicious = _check_suspicious_patterns(combined_content)
    for s in suspicious:
        finding = {
            'type': 'suspicious_pattern',
            'severity': 'high',
            'confidence': 70,
            'url': '',
            'param': s['type'],
            'description': f"Patrón sospechoso de C2: {s['value']}",
            'evidence': {
                'pattern_type': s['type'],
                'pattern_value': s['value'],
            },
            'cwe': 'CWE-1104',
            'references': ['https://attack.mitre.org/'],
        }
        findings.append(finding)
    
    # 7. Reportar estadísticas
    ctx.log('info', f"IOC Scan: {len(feed_matches)} matches contra feeds, {len(suspicious)} patrones sospechosos")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'urls_scanned': len(discovered_urls),
            'ips_extracted': len(extracted['ips']),
            'domains_extracted': len(extracted['domains']),
            'hashes_extracted': len(extracted['hashes']),
            'feed_matches': len(feed_matches),
            'suspicious_patterns': len(suspicious),
        }
    }