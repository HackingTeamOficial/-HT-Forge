"""
SSL/TLS Audit — Análisis de certificados SSL/TLS.
Verifica expiración, debilidades, certificados autofirmados y dominios no coincidentes.
"""
import re
import ssl
import socket
from datetime import datetime, timedelta
from typing import Dict, List
from urllib.parse import urlparse

PLUGIN_NAME = "ssl_audit"
PLUGIN_DESCRIPTION = "Análisis de certificados SSL/TLS: expiración, debilidades, autofirmados"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Versiones de TLS inseguras
INSECURE_TLS_VERSIONS = {
    'SSLv2': 'SSLv2 está obsoleto y es inseguro',
    'SSLv3': 'SSLv3 está obsoleto y es inseguro (POODLE)',
    'TLSv1': 'TLS 1.0 está obsoleto y es inseguro',
    'TLSv1.1': 'TLS 1.1 está obsoleto y es inseguro',
}

# Cipher suites débiles
WEAK_CIPHERS = [
    'RC4', 'DES', '3DES', 'MD5', 'NULL', 'EXPORT',
    'anon', 'IDEA', 'SEED',
]

def _get_certificate_info(hostname: str, port: int = 443) -> Dict:
    """Obtiene información del certificado SSL de un host."""
    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        with socket.create_connection((hostname, port), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                version = ssock.version()
                
                return {
                    'subject': cert.get('subject', ''),
                    'issuer': cert.get('issuer', ''),
                    'not_before': cert.get('notBefore', ''),
                    'not_after': cert.get('notAfter', ''),
                    'serial_number': cert.get('serialNumber', ''),
                    'cipher': cipher[0] if cipher else '',
                    'tls_version': version,
                    'san': cert.get('subjectAltName', []),
                }
    except Exception as e:
        return {'error': str(e)}

def _check_expiration(not_after: str) -> Dict:
    """Verifica si el certificado está próximo a expirar."""
    try:
        # Parsear fecha del certificado
        expiry = datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z')
        now = datetime.utcnow()
        days_until_expiry = (expiry - now).days
        
        if days_until_expiry < 0:
            return {'status': 'expired', 'days': days_until_expiry, 'severity': 'critical'}
        elif days_until_expiry < 30:
            return {'status': 'expiring_soon', 'days': days_until_expiry, 'severity': 'high'}
        elif days_until_expiry < 90:
            return {'status': 'expiring', 'days': days_until_expiry, 'severity': 'medium'}
        else:
            return {'status': 'valid', 'days': days_until_expiry, 'severity': 'info'}
    except Exception:
        return {'status': 'unknown', 'days': 0, 'severity': 'info'}

def _check_tls_version(version: str) -> Dict:
    """Verifica si la versión de TLS es segura."""
    if version in INSECURE_TLS_VERSIONS:
        return {
            'status': 'insecure',
            'version': version,
            'description': INSECURE_TLS_VERSIONS[version],
            'severity': 'high',
        }
    return {'status': 'secure', 'version': version, 'severity': 'info'}

def _check_cipher(cipher: str) -> Dict:
    """Verifica si el cipher suite es débil."""
    for weak in WEAK_CIPHERS:
        if weak in cipher:
            return {
                'status': 'weak',
                'cipher': cipher,
                'description': f"Cipher débil: {weak}",
                'severity': 'high',
            }
    return {'status': 'secure', 'cipher': cipher, 'severity': 'info'}

def _check_hostname_match(cert_info: Dict, hostname: str) -> Dict:
    """Verifica si el certificado coincide con el hostname."""
    san = cert_info.get('san', [])
    if not san:
        return {'status': 'no_san', 'severity': 'medium'}
    
    # Extraer dominios del SAN
    cert_domains = [d[1] for d in san if d[0] == 'DNS']
    
    # Verificar coincidencia exacta o wildcard
    for domain in cert_domains:
        if domain == hostname:
            return {'status': 'match', 'domain': domain, 'severity': 'info'}
        if domain.startswith('*.') and hostname.endswith(domain[1:]):
            return {'status': 'wildcard_match', 'domain': domain, 'severity': 'info'}
    
    return {'status': 'mismatch', 'cert_domains': cert_domains, 'severity': 'high'}

async def run(ctx):
    """Ejecuta la auditoría SSL/TLS."""
    findings = []
    
    # Obtener target del contexto
    target = ctx.get('target', '')
    if not target:
        ctx.log('info', "SSL Audit: No hay target definido")
        return {'plugin': PLUGIN_NAME, 'findings': [], 'stats': {}}
    
    parsed = urlparse(target)
    hostname = parsed.hostname
    port = parsed.port or 443
    
    if not hostname:
        ctx.log('info', "SSL Audit: No se pudo extraer hostname del target")
        return {'plugin': PLUGIN_NAME, 'findings': [], 'stats': {}}
    
    # 1. Obtener información del certificado
    cert_info = _get_certificate_info(hostname, port)
    
    if 'error' in cert_info:
        finding = {
            'type': 'ssl_error',
            'severity': 'medium',
            'confidence': 100,
            'url': target,
            'param': '',
            'description': f"Error al obtener certificado SSL: {cert_info['error']}",
            'evidence': {'error': cert_info['error']},
            'cwe': 'CWE-295',
            'references': [],
        }
        findings.append(finding)
    else:
        # 2. Verificar expiración
        expiry_check = _check_expiration(cert_info.get('not_after', ''))
        if expiry_check['severity'] in ('critical', 'high', 'medium'):
            finding = {
                'type': 'ssl_expiration',
                'severity': expiry_check['severity'],
                'confidence': 95,
                'url': target,
                'param': '',
                'description': f"Certificado SSL {expiry_check['status']}: {expiry_check['days']} días restantes",
                'evidence': {
                    'status': expiry_check['status'],
                    'days_remaining': expiry_check['days'],
                    'not_after': cert_info.get('not_after', ''),
                },
                'cwe': 'CWE-295',
                'references': ['https://tools.ietf.org/html/rfc5280'],
            }
            findings.append(finding)
        
        # 3. Verificar versión TLS
        tls_check = _check_tls_version(cert_info.get('tls_version', ''))
        if tls_check['severity'] == 'high':
            finding = {
                'type': 'ssl_weak_tls',
                'severity': 'high',
                'confidence': 90,
                'url': target,
                'param': '',
                'description': f"TLS inseguro: {tls_check['description']}",
                'evidence': {
                    'tls_version': tls_check['version'],
                    'description': tls_check['description'],
                },
                'cwe': 'CWE-326',
                'references': ['https://tools.ietf.org/html/rfc8996'],
            }
            findings.append(finding)
        
        # 4. Verificar cipher
        cipher_check = _check_cipher(cert_info.get('cipher', ''))
        if cipher_check['severity'] == 'high':
            finding = {
                'type': 'ssl_weak_cipher',
                'severity': 'high',
                'confidence': 85,
                'url': target,
                'param': '',
                'description': f"Cipher débil: {cipher_check['description']}",
                'evidence': {
                    'cipher': cipher_check['cipher'],
                    'description': cipher_check['description'],
                },
                'cwe': 'CWE-326',
                'references': ['https://tools.ietf.org/html/rfc7465'],
            }
            findings.append(finding)
        
        # 5. Verificar coincidencia de hostname
        hostname_check = _check_hostname_match(cert_info, hostname)
        if hostname_check['severity'] == 'high':
            finding = {
                'type': 'ssl_hostname_mismatch',
                'severity': 'high',
                'confidence': 90,
                'url': target,
                'param': '',
                'description': f"Certificado no coincide con hostname: {hostname_check.get('cert_domains', [])}",
                'evidence': {
                    'hostname': hostname,
                    'cert_domains': hostname_check.get('cert_domains', []),
                },
                'cwe': 'CWE-295',
                'references': ['https://tools.ietf.org/html/rfc6125'],
            }
            findings.append(finding)
    
    ctx.log('info', f"SSL Audit: {len(findings)} hallazgos para {hostname}")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'host_checked': hostname,
            'findings_count': len(findings),
        }
    }