"""
Secret Hunter — Detección avanzada de fugas de información.
Busca secretos en respuestas HTML, headers, y archivos descargados.
"""
import re
import base64
from typing import Dict, List, Set

PLUGIN_NAME = "secret_hunter"
PLUGIN_DESCRIPTION = "Detección avanzada de secretos: API keys, tokens, contraseñas en contenido y headers"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Patrones de secretos (mejorados respecto a jsecret)
SECRET_PATTERNS = {
    'aws_access_key': re.compile(r'AKIA[0-9A-Z]{16}'),
    'aws_secret_key': re.compile(r'[0-9a-zA-Z/+]{40}'),
    'github_token': re.compile(r'ghp_[0-9a-zA-Z]{36}'),
    'github_oauth': re.compile(r'gho_[0-9a-zA-Z]{36}'),
    'gitlab_token': re.compile(r'glpat-[0-9a-zA-Z\-]{20}'),
    'slack_token': re.compile(r'xox[baprs]-[0-9a-zA-Z\-]{10,}'),
    'stripe_key': re.compile(r'sk_live_[0-9a-zA-Z]{24}'),
    'stripe_test': re.compile(r'sk_test_[0-9a-zA-Z]{24}'),
    'google_api': re.compile(r'AIza[0-9A-Za-z\-_]{35}'),
    'firebase': re.compile(r'AAAA[A-Za-z0-9_\-]{7}:[A-Za-z0-9_\-]{140}'),
    'jwt': re.compile(r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+'),
    'private_key': re.compile(r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'),
    'password_in_url': re.compile(r'[a-zA-Z]{3,10}://[^\s:]+:([^\s@]+)@'),
    'email_password': re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[:\s]+[^\s]{6,}'),
    'api_key_header': re.compile(r'(?:api[_-]?key|api[_-]?secret|x[_-]?api[_-]?key)["\s]*[:=]["\s]*([a-zA-Z0-9_\-]{16,})', re.IGNORECASE),
    'bearer_token': re.compile(r'Bearer\s+[a-zA-Z0-9_\-\.]+'),
    'basic_auth': re.compile(r'Basic\s+[a-zA-Z0-9+/=]{20,}'),
}

# Cabeceras que pueden contener secretos
SENSITIVE_HEADERS = {
    'authorization': 'Token de autorización',
    'x-api-key': 'API key',
    'x-auth-token': 'Token de autenticación',
    'cookie': 'Cookies (pueden contener sesiones)',
    'set-cookie': 'Cookies de respuesta',
    'x-csrf-token': 'Token CSRF',
    'x-xsrf-token': 'Token XSRF',
}

def _calculate_entropy(s: str) -> float:
    """Calcula la entropía de Shannon de un string."""
    import math
    if not s:
        return 0.0
    prob = [float(s.count(c)) / len(s) for c in set(s)]
    entropy = -sum(p * math.log2(p) for p in prob if p > 0)
    return entropy

def _is_high_entropy(value: str, threshold: float = 3.5) -> bool:
    """Verifica si un string tiene alta entropía (posible secreto)."""
    return _calculate_entropy(value) > threshold

def _scan_content(content: str, source: str) -> List[Dict]:
    """Escanea contenido en busca de secretos."""
    findings = []
    
    for secret_type, pattern in SECRET_PATTERNS.items():
        matches = pattern.findall(content)
        for match in matches:
            if isinstance(match, tuple):
                match = match[0] if match else ''
            if not match:
                continue
            
            # Filtrar falsos positivos por entropía
            if len(match) > 20 and not _is_high_entropy(match):
                continue
            
            findings.append({
                'type': 'secret_exposure',
                'secret_type': secret_type,
                'value': match[:50] + '...' if len(match) > 50 else match,
                'source': source,
                'severity': 'critical' if secret_type in ('private_key', 'aws_secret_key') else 'high',
                'confidence': 90,
                'description': f"Secreto expuesto: {secret_type} encontrado en {source}",
                'evidence': {
                    'secret_type': secret_type,
                    'value_preview': match[:20] + '...',
                    'source': source,
                },
                'cwe': 'CWE-798',
                'references': ['https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_credentials'],
            })
    
    return findings

def _scan_headers(headers: Dict[str, str], url: str) -> List[Dict]:
    """Escanea cabeceras HTTP en busca de secretos."""
    findings = []
    headers_lower = {k.lower(): v for k, v in headers.items()}
    
    for header, description in SENSITIVE_HEADERS.items():
        if header in headers_lower:
            value = headers_lower[header]
            # No reportar cookies vacías o genéricas
            if header in ('cookie', 'set-cookie') and len(value) < 20:
                continue
            
            findings.append({
                'type': 'secret_in_header',
                'secret_type': header,
                'value': value[:50] + '...' if len(value) > 50 else value,
                'source': f'header:{header}',
                'severity': 'high',
                'confidence': 85,
                'description': f"Secreto en cabecera: {description}",
                'evidence': {
                    'header_name': header,
                    'value_preview': value[:20] + '...',
                    'url': url,
                },
                'cwe': 'CWE-798',
                'references': ['https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_credentials'],
            })
    
    return findings

async def run(ctx):
    """Ejecuta la búsqueda de secretos."""
    findings = []
    
    # 1. Escanear contenido de respuestas cacheadas
    cached_responses = ctx.get('cached_responses', {})
    for url, response in cached_responses.items():
        if isinstance(response, dict):
            body = response.get('body', '')
            headers = response.get('headers', {})
            
            # Escanear body
            body_findings = _scan_content(body, f'body:{url}')
            findings.extend(body_findings)
            
            # Escanear headers
            header_findings = _scan_headers(headers, url)
            findings.extend(header_findings)
    
    # 2. Escanear URLs descubiertas (pueden contener credenciales)
    for url in ctx.get('discovered_urls', []):
        url_findings = _scan_content(url, f'url:{url}')
        findings.extend(url_findings)
    
    # 3. Escanear parámetros descubiertos
    for param in ctx.get('discovered_params', []):
        if isinstance(param, dict):
            url = param.get('url', '')
            param_name = param.get('name', '')
            param_value = param.get('value', '')
            
            # Buscar secretos en valores de parámetros
            if param_value:
                param_findings = _scan_content(param_value, f'param:{param_name}')
                findings.extend(param_findings)
    
    # 4. Deduplicar por tipo+valor
    seen = set()
    unique_findings = []
    for f in findings:
        key = (f['secret_type'], f['value'])
        if key not in seen:
            seen.add(key)
            unique_findings.append(f)
    
    ctx.log('info', f"Secret Hunter: {len(unique_findings)} secretos únicos encontrados")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': unique_findings,
        'stats': {
            'secrets_found': len(unique_findings),
            'by_type': {},
        }
    }