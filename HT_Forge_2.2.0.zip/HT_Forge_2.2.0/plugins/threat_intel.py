"""
Threat Intelligence — Enriquecimiento de hallazgos con inteligencia de amenazas.
Consulta APIs de threat intel (OTX, MISP) para enriquecer dominios, IPs y hashes.
"""
import json
import hashlib
from typing import Dict, List, Set
from urllib.parse import urlparse

PLUGIN_NAME = "threat_intel"
PLUGIN_DESCRIPTION = "Enriquecimiento de hallazgos con inteligencia de amenazas (OTX, MISP, CVE)"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Fuentes de threat intel configurables
DEFAULT_FEEDS = {
    'otx': {'url': 'https://otx.alienvault.com/api/v1/indicators', 'enabled': False},
    'misp': {'url': '', 'enabled': False},
    'abuseipdb': {'url': 'https://api.abuseipdb.com/api/v2/check', 'enabled': False},
}

# CVEs conocidos por tecnología (mapeo simplificado)
KNOWN_CVES = {
    'apache': [
        {'cve': 'CVE-2021-41773', 'severity': 'critical', 'description': 'Path traversal en Apache 2.4.49'},
        {'cve': 'CVE-2021-42013', 'severity': 'critical', 'description': 'Path traversal en Apache 2.4.50'},
    ],
    'nginx': [
        {'cve': 'CVE-2021-23017', 'severity': 'high', 'description': 'DNS resolver off-by-one'},
    ],
    'php': [
        {'cve': 'CVE-2019-11043', 'severity': 'critical', 'description': 'RCE en PHP-FPM'},
    ],
    'wordpress': [
        {'cve': 'CVE-2022-21661', 'severity': 'high', 'description': 'SQLi en WordPress < 5.8.3'},
    ],
    'openssl': [
        {'cve': 'CVE-2022-3602', 'severity': 'critical', 'description': 'X.509 buffer overflow'},
    ],
}

def _extract_indicators(ctx) -> Dict[str, Set[str]]:
    """Extrae indicadores (IPs, dominios, hashes) del contexto."""
    indicators = {'ips': set(), 'domains': set(), 'hashes': set()}
    
    # De URLs descubiertas
    for url in ctx.get('discovered_urls', []):
        parsed = urlparse(url)
        if parsed.hostname:
            indicators['domains'].add(parsed.hostname)
    
    # De parámetros
    for param in ctx.get('discovered_params', []):
        if isinstance(param, dict):
            url = param.get('url', '')
            parsed = urlparse(url)
            if parsed.hostname:
                indicators['domains'].add(parsed.hostname)
    
    # De hallazgos existentes
    for finding in ctx.get('findings', []):
        url = finding.get('url', '')
        parsed = urlparse(url)
        if parsed.hostname:
            indicators['domains'].add(parsed.hostname)
    
    return indicators

def _check_known_cves(technology: str) -> List[Dict]:
    """Busca CVEs conocidos para una tecnología."""
    tech_lower = technology.lower()
    cves = []
    for key, cve_list in KNOWN_CVES.items():
        if key in tech_lower:
            cves.extend(cve_list)
    return cves

def _enrich_finding_with_cve(finding: Dict, cves: List[Dict]) -> Dict:
    """Enriquece un hallazgo con información de CVE."""
    if not cves:
        return finding
    
    finding['cve_matches'] = cves
    finding['cve_count'] = len(cves)
    return finding

async def run(ctx):
    """Ejecuta el enriquecimiento con threat intel."""
    findings = []
    
    # 1. Extraer indicadores del contexto
    indicators = _extract_indicators(ctx)
    
    # 2. Obtener tecnologías detectadas
    tech_findings = [f for f in ctx.get('findings', []) if f.get('type') == 'tech_fingerprint']
    technologies = set()
    for tf in tech_findings:
        tech = tf.get('evidence', {}).get('technology', '')
        if tech:
            technologies.add(tech)
    
    # 3. Buscar CVEs conocidos para cada tecnología
    all_cves = []
    for tech in technologies:
        cves = _check_known_cves(tech)
        for cve in cves:
            cve['technology'] = tech
            all_cves.append(cve)
    
    # 4. Crear hallazgos de threat intel
    if all_cves:
        finding = {
            'type': 'threat_intel',
            'severity': 'high',
            'confidence': 85,
            'url': '',
            'param': '',
            'description': f"Threat Intel: {len(all_cves)} CVEs conocidos encontrados para tecnologías detectadas",
            'evidence': {
                'technologies': list(technologies),
                'cves': all_cves,
                'indicators_extracted': {
                    'ips': len(indicators['ips']),
                    'domains': len(indicators['domains']),
                    'hashes': len(indicators['hashes']),
                },
            },
            'cwe': 'CWE-1104',
            'references': ['https://cve.mitre.org/', 'https://nvd.nist.gov/'],
        }
        findings.append(finding)
    
    # 5. Enriquecer hallazgos existentes con CVEs
    for finding in ctx.get('findings', []):
        url = finding.get('url', '')
        parsed = urlparse(url)
        if parsed.hostname:
            # Buscar CVEs para el dominio
            domain_cves = []
            for tech in technologies:
                domain_cves.extend(_check_known_cves(tech))
            if domain_cves:
                _enrich_finding_with_cve(finding, domain_cves)
    
    ctx.log('info', f"Threat Intel: {len(all_cves)} CVEs encontrados, {len(indicators['domains'])} dominios analizados")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'indicators_extracted': len(indicators['domains']) + len(indicators['ips']),
            'cves_found': len(all_cves),
            'technologies_analyzed': len(technologies),
        }
    }