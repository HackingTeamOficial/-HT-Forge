"""
Correlation Engine — Correlación avanzada de hallazgos.
Detecta patrones entre hallazgos y genera nuevos hallazgos correlacionados.
"""
from typing import Dict, List, Set, Tuple
from collections import defaultdict

PLUGIN_NAME = "correlation"
PLUGIN_DESCRIPTION = "Correlación avanzada de hallazgos: detecta patrones y genera hallazgos correlacionados"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Reglas de correlación
CORRELATION_RULES = [
    {
        'name': 'xss_csrf',
        'description': 'XSS + CSRF en el mismo endpoint',
        'requires': ['xss', 'csrf'],
        'severity': 'critical',
        'confidence': 85,
        'cwe': 'CWE-352',
    },
    {
        'name': 'sqli_lfi',
        'description': 'SQLi + LFI en el mismo endpoint',
        'requires': ['sqli', 'lfi'],
        'severity': 'critical',
        'confidence': 80,
        'cwe': 'CWE-89',
    },
    {
        'name': 'ssrf_rce',
        'description': 'SSRF + RCE en el mismo endpoint',
        'requires': ['ssrf', 'rce'],
        'severity': 'critical',
        'confidence': 85,
        'cwe': 'CWE-918',
    },
    {
        'name': 'idor_bola',
        'description': 'IDOR + BOLA en el mismo endpoint',
        'requires': ['idor', 'bola'],
        'severity': 'high',
        'confidence': 80,
        'cwe': 'CWE-639',
    },
    {
        'name': 'open_redirect_xss',
        'description': 'Open Redirect + XSS en el mismo endpoint',
        'requires': ['open_redirect', 'xss'],
        'severity': 'high',
        'confidence': 75,
        'cwe': 'CWE-601',
    },
    {
        'name': 'default_creds_rce',
        'description': 'Credenciales por defecto + RCE',
        'requires': ['default_credentials', 'rce'],
        'severity': 'critical',
        'confidence': 90,
        'cwe': 'CWE-798',
    },
    {
        'name': 'missing_auth_sensitive',
        'description': 'Autorización rota + exposición de datos',
        'requires': ['broken_access_control', 'api_data_exposure'],
        'severity': 'critical',
        'confidence': 85,
        'cwe': 'CWE-639',
    },
    {
        'name': 'sqli_error_lfi',
        'description': 'SQLi + LFI + Error disclosure',
        'requires': ['sqli', 'lfi', 'stack_traces'],
        'severity': 'critical',
        'confidence': 80,
        'cwe': 'CWE-89',
    },
]

def _group_findings_by_url(findings: List[Dict]) -> Dict[str, List[Dict]]:
    """Agrupa hallazgos por URL."""
    by_url = defaultdict(list)
    for f in findings:
        url = f.get('url', '')
        if url:
            by_url[url].append(f)
    return by_url

def _check_correlation_rules(url_findings: List[Dict], rules: List[Dict]) -> List[Dict]:
    """Verifica reglas de correlación para un conjunto de hallazgos."""
    correlated = []
    finding_types = {f.get('type', '').lower() for f in url_findings}
    
    for rule in rules:
        required = set(rule['requires'])
        if required.issubset(finding_types):
            # Todos los tipos requeridos están presentes
            correlated.append({
                'type': 'correlated_finding',
                'severity': rule['severity'],
                'confidence': rule['confidence'],
                'url': url_findings[0].get('url', ''),
                'param': '',
                'description': f"Correlación detectada: {rule['description']}",
                'evidence': {
                    'rule_name': rule['name'],
                    'required_types': list(required),
                    'matched_types': list(required),
                    'source_findings': [
                        {'type': f.get('type'), 'url': f.get('url'), 'param': f.get('param')}
                        for f in url_findings
                        if f.get('type', '').lower() in required
                    ],
                },
                'cwe': rule['cwe'],
                'references': ['https://attack.mitre.org/'],
            })
    
    return correlated

def _detect_attack_chains(findings: List[Dict]) -> List[Dict]:
    """Detecta cadenas de ataque (múltiples hallazgos que forman un chain)."""
    chains = []
    
    # Agrupa por URL
    by_url = _group_findings_by_url(findings)
    
    for url, url_findings in by_url.items():
        # Busca cadenas de ataque conocidas
        finding_types = {f.get('type', '').lower() for f in url_findings}
        
        # Chain: Recon → Vulnerabilidad → Explotación
        if 'tech_fingerprint' in finding_types and 'sqli' in finding_types:
            chains.append({
                'type': 'attack_chain',
                'severity': 'critical',
                'confidence': 90,
                'url': url,
                'param': '',
                'description': f"Cadena de ataque: Fingerprint → SQLi en {url}",
                'evidence': {
                    'chain': ['tech_fingerprint', 'sqli'],
                    'description': 'Identificación de tecnología seguida de inyección SQL',
                },
                'cwe': 'CWE-89',
                'references': ['https://attack.mitre.org/'],
            })
        
        # Chain: Auth bypass → Data exposure
        if 'auth_bypass' in finding_types and 'api_data_exposure' in finding_types:
            chains.append({
                'type': 'attack_chain',
                'severity': 'critical',
                'confidence': 90,
                'url': url,
                'param': '',
                'description': f"Cadena de ataque: Auth Bypass → Data Exposure en {url}",
                'evidence': {
                    'chain': ['auth_bypass', 'api_data_exposure'],
                    'description': 'Bypass de autenticación seguido de exposición de datos',
                },
                'cwe': 'CWE-306',
                'references': ['https://attack.mitre.org/'],
            })
    
    return chains

def _calculate_risk_score(findings: List[Dict]) -> Dict:
    """Calcula un score de riesgo basado en la correlación de hallazgos."""
    if not findings:
        return {'score': 0, 'level': 'none'}
    
    # Contar hallazgos por severidad
    severity_counts = defaultdict(int)
    for f in findings:
        severity = f.get('severity', 'info').lower()
        severity_counts[severity] += 1
    
    # Calcular score ponderado
    score = (
        severity_counts.get('critical', 0) * 10 +
        severity_counts.get('high', 0) * 5 +
        severity_counts.get('medium', 0) * 2 +
        severity_counts.get('low', 0) * 1
    )
    
    # Determinar nivel
    if score >= 20:
        level = 'critical'
    elif score >= 10:
        level = 'high'
    elif score >= 5:
        level = 'medium'
    elif score >= 1:
        level = 'low'
    else:
        level = 'none'
    
    return {'score': score, 'level': level, 'severity_counts': dict(severity_counts)}

async def run(ctx):
    """Ejecuta la correlación de hallazgos."""
    findings = []
    
    # Obtener hallazgos del contexto
    session_findings = ctx.get('findings', [])
    
    if not session_findings:
        ctx.log('info', "Correlation: No hay hallazgos para correlacionar")
        return {'plugin': PLUGIN_NAME, 'findings': [], 'stats': {}}
    
    # 1. Agrupar hallazgos por URL
    by_url = _group_findings_by_url(session_findings)
    
    # 2. Verificar reglas de correlación
    for url, url_findings in by_url.items():
        correlated = _check_correlation_rules(url_findings, CORRELATION_RULES)
        findings.extend(correlated)
    
    # 3. Detectar cadenas de ataque
    chains = _detect_attack_chains(session_findings)
    findings.extend(chains)
    
    # 4. Calcular score de riesgo
    risk_score = _calculate_risk_score(session_findings)
    
    # 5. Crear hallazgo de riesgo global
    if risk_score['level'] in ('critical', 'high'):
        findings.append({
            'type': 'risk_assessment',
            'severity': risk_score['level'],
            'confidence': 95,
            'url': '',
            'param': '',
            'description': f"Evaluación de riesgo global: {risk_score['level'].upper()} (score: {risk_score['score']})",
            'evidence': {
                'risk_score': risk_score['score'],
                'risk_level': risk_score['level'],
                'severity_counts': risk_score['severity_counts'],
                'total_findings': len(session_findings),
            },
            'cwe': 'CWE-1104',
            'references': ['https://owasp.org/www-community/OWASP_Risk_Rating_Methodology'],
        })
    
    ctx.log('info', f"Correlation: {len(findings)} hallazgos correlacionados, riesgo: {risk_score['level']}")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'correlated_findings': len(findings),
            'attack_chains': len(chains),
            'risk_score': risk_score['score'],
            'risk_level': risk_score['level'],
        }
    }