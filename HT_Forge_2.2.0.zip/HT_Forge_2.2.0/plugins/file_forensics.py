"""
File Forensics — Análisis forense básico de archivos.
Busca metadatos, strings sospechosos y patrones en archivos descargados.
"""
import re
import base64
from typing import Dict, List, Set
from pathlib import Path

PLUGIN_NAME = "file_forensics"
PLUGIN_DESCRIPTION = "Análisis forense básico de archivos: metadatos, strings sospechosos, patrones"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

# Extensiones de archivo sensibles
SENSITIVE_EXTENSIONS = {
    '.env': 'Archivo de entorno (puede contener credenciales)',
    '.config': 'Archivo de configuración',
    '.ini': 'Archivo de configuración INI',
    '.yml': 'Archivo YAML (puede contener credenciales)',
    '.yaml': 'Archivo YAML (puede contener credenciales)',
    '.json': 'Archivo JSON (puede contener datos sensibles)',
    '.xml': 'Archivo XML (puede contener datos sensibles)',
    '.sql': 'Archivo SQL (puede contener datos sensibles)',
    '.bak': 'Archivo de backup',
    '.old': 'Archivo antiguo (posible backup)',
    '.swp': 'Archivo de swap de Vim',
    '.swo': 'Archivo de swap de Vim',
    '.log': 'Archivo de log (puede contener información sensible)',
    '.tmp': 'Archivo temporal',
    '.temp': 'Archivo temporal',
    '.cache': 'Archivo de caché',
    '.pem': 'Archivo de certificado/clave privada',
    '.key': 'Archivo de clave privada',
    '.crt': 'Archivo de certificado',
    '.p12': 'Archivo de certificado PKCS#12',
    '.pfx': 'Archivo de certificado PKCS#12',
    '.db': 'Archivo de base de datos',
    '.sqlite': 'Archivo de base de datos SQLite',
    '.mdb': 'Archivo de base de datos Access',
    '.frm': 'Archivo de tabla MySQL',
    '.myd': 'Archivo de datos MySQL',
    '.myi': 'Archivo de índice MySQL',
}

# Patrones de contenido sospechoso
SUSPICIOUS_PATTERNS = {
    'php_eval': re.compile(r'eval\s*\(', re.IGNORECASE),
    'php_system': re.compile(r'system\s*\(', re.IGNORECASE),
    'php_exec': re.compile(r'exec\s*\(', re.IGNORECASE),
    'php_shell_exec': re.compile(r'shell_exec\s*\(', re.IGNORECASE),
    'php_passthru': re.compile(r'passthru\s*\(', re.IGNORECASE),
    'php_popen': re.compile(r'popen\s*\(', re.IGNORECASE),
    'php_proc_open': re.compile(r'proc_open\s*\(', re.IGNORECASE),
    'php_assert': re.compile(r'assert\s*\(', re.IGNORECASE),
    'php_base64_decode': re.compile(r'base64_decode\s*\(', re.IGNORECASE),
    'php_str_rot13': re.compile(r'str_rot13\s*\(', re.IGNORECASE),
    'php_gzinflate': re.compile(r'gzinflate\s*\(', re.IGNORECASE),
    'php_strrev': re.compile(r'strrev\s*\(', re.IGNORECASE),
    'php_create_function': re.compile(r'create_function\s*\(', re.IGNORECASE),
    'php_preg_replace_e': re.compile(r'preg_replace\s*\(.*/e', re.IGNORECASE),
    'asp_response_write': re.compile(r'Response\.Write\s*\(', re.IGNORECASE),
    'asp_eval': re.compile(r'eval\s*\(', re.IGNORECASE),
    'jsp_runtime_exec': re.compile(r'Runtime\.getRuntime\(\)\.exec\s*\(', re.IGNORECASE),
    'python_eval': re.compile(r'eval\s*\(', re.IGNORECASE),
    'python_exec': re.compile(r'exec\s*\(', re.IGNORECASE),
    'python_os_system': re.compile(r'os\.system\s*\(', re.IGNORECASE),
    'python_subprocess': re.compile(r'subprocess\.(call|run|Popen)', re.IGNORECASE),
    'javascript_eval': re.compile(r'eval\s*\(', re.IGNORECASE),
    'javascript_function': re.compile(r'new Function\s*\(', re.IGNORECASE),
    'javascript_document_write': re.compile(r'document\.write\s*\(', re.IGNORECASE),
    'shell_exec': re.compile(r'exec\s*\(', re.IGNORECASE),
    'shell_system': re.compile(r'system\s*\(', re.IGNORECASE),
    'shell_popen': re.compile(r'popen\s*\(', re.IGNORECASE),
    'shell_backticks': re.compile(r'`[^`]+`'),
    'shell_dollar_paren': re.compile(r'\$\([^)]+\)'),
    'sql_select': re.compile(r'SELECT\s+.*\s+FROM', re.IGNORECASE),
    'sql_insert': re.compile(r'INSERT\s+INTO', re.IGNORECASE),
    'sql_update': re.compile(r'UPDATE\s+.*\s+SET', re.IGNORECASE),
    'sql_delete': re.compile(r'DELETE\s+FROM', re.IGNORECASE),
    'sql_drop': re.compile(r'DROP\s+TABLE', re.IGNORECASE),
    'sql_union': re.compile(r'UNION\s+SELECT', re.IGNORECASE),
    'password_pattern': re.compile(r'password\s*[=:]\s*["\']?[^\s"\']+', re.IGNORECASE),
    'secret_pattern': re.compile(r'secret\s*[=:]\s*["\']?[^\s"\']+', re.IGNORECASE),
    'token_pattern': re.compile(r'token\s*[=:]\s*["\']?[^\s"\']+', re.IGNORECASE),
    'api_key_pattern': re.compile(r'api[_-]?key\s*[=:]\s*["\']?[^\s"\']+', re.IGNORECASE),
    'private_key': re.compile(r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'),
    'aws_access_key': re.compile(r'AKIA[0-9A-Z]{16}'),
    'github_token': re.compile(r'ghp_[0-9a-zA-Z]{36}'),
    'slack_token': re.compile(r'xox[baprs]-[0-9a-zA-Z\-]{10,}'),
    'jwt': re.compile(r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+'),
    'ip_address': re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b'),
    'email': re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'),
    'url': re.compile(r'https?://[^\s<>"{}|\\^`\[\]]+'),
    'base64_long': re.compile(r'[a-zA-Z0-9+/]{100,}={0,2}'),
    'hex_long': re.compile(r'[a-fA-F0-9]{100,}'),
}

def _get_file_extension(filename: str) -> str:
    """Obtiene la extensión de un archivo."""
    return Path(filename).suffix.lower()

def _is_sensitive_extension(ext: str) -> bool:
    """Verifica si una extensión es sensible."""
    return ext in SENSITIVE_EXTENSIONS

def _scan_content(content: str, filename: str) -> List[Dict]:
    """Escanea el contenido de un archivo en busca de patrones sospechosos."""
    findings = []
    
    for pattern_name, pattern in SUSPICIOUS_PATTERNS.items():
        matches = pattern.findall(content)
        if matches:
            # Limitar a los primeros 5 matches
            for match in matches[:5]:
                if isinstance(match, tuple):
                    match = match[0] if match else ''
                if not match:
                    continue
                
                findings.append({
                    'type': 'suspicious_file_content',
                    'severity': 'high' if pattern_name in ('php_eval', 'php_system', 'php_exec', 'jsp_runtime_exec', 'python_eval', 'python_exec') else 'medium',
                    'confidence': 80,
                    'url': filename,
                    'param': pattern_name,
                    'description': f"Contenido sospechoso en {filename}: {pattern_name}",
                    'evidence': {
                        'pattern': pattern_name,
                        'match': match[:100] if len(match) > 100 else match,
                        'filename': filename,
                    },
                    'cwe': 'CWE-94' if 'eval' in pattern_name or 'exec' in pattern_name else 'CWE-200',
                    'references': ['https://owasp.org/www-community/attacks/Code_Injection'],
                })
    
    return findings

def _check_file_metadata(filename: str, size: int = 0) -> List[Dict]:
    """Verifica metadatos de archivo."""
    findings = []
    ext = _get_file_extension(filename)
    
    if _is_sensitive_extension(ext):
        description = SENSITIVE_EXTENSIONS.get(ext, 'Archivo sensible')
        findings.append({
            'type': 'sensitive_file_exposed',
            'severity': 'high' if ext in ('.env', '.pem', '.key', '.p12', '.pfx', '.db', '.sql') else 'medium',
            'confidence': 90,
            'url': filename,
            'param': ext,
            'description': f"Archivo sensible expuesto: {description}",
            'evidence': {
                'extension': ext,
                'description': description,
                'size': size,
            },
            'cwe': 'CWE-538',
            'references': ['https://owasp.org/www-community/vulnerabilities/Information_exposure_through_files'],
        })
    
    return findings

async def run(ctx):
    """Ejecuta el análisis forense de archivos."""
    findings = []
    
    # Obtener archivos descubiertos del contexto
    discovered_files = ctx.get('discovered_files', [])
    cached_responses = ctx.get('cached_responses', {})
    
    # 1. Analizar archivos descubiertos por URL
    for file_info in discovered_files:
        if isinstance(file_info, dict):
            filename = file_info.get('url', file_info.get('path', ''))
            content = file_info.get('content', '')
            size = file_info.get('size', 0)
        else:
            filename = str(file_info)
            content = ''
            size = 0
        
        if not filename:
            continue
        
        # Verificar metadatos
        metadata_findings = _check_file_metadata(filename, size)
        findings.extend(metadata_findings)
        
        # Escanear contenido si está disponible
        if content:
            content_findings = _scan_content(content, filename)
            findings.extend(content_findings)
    
    # 2. Analizar archivos en respuestas cacheadas
    for url, response in cached_responses.items():
        if not isinstance(response, dict):
            continue
        
        # Verificar si la URL parece un archivo
        parsed_url = url.split('?')[0]
        ext = _get_file_extension(parsed_url)
        if ext and _is_sensitive_extension(ext):
            body = response.get('body', '')
            if body:
                content_findings = _scan_content(body, url)
                findings.extend(content_findings)
    
    # 3. Deduplicar por tipo+archivo
    seen = set()
    unique_findings = []
    for f in findings:
        key = (f['type'], f['url'], f['param'])
        if key not in seen:
            seen.add(key)
            unique_findings.append(f)
    
    ctx.log('info', f"File Forensics: {len(unique_findings)} hallazgos en {len(discovered_files)} archivos")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': unique_findings,
        'stats': {
            'files_analyzed': len(discovered_files),
            'suspicious_content': len([f for f in unique_findings if f['type'] == 'suspicious_file_content']),
            'sensitive_files': len([f for f in unique_findings if f['type'] == 'sensitive_file_exposed']),
        }
    }