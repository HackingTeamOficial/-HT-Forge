"""
Report Enhancement — Mejoras en reportes y visualización.
Genera estadísticas avanzadas, gráficos de tendencia y exportaciones adicionales.
"""
import json
from typing import Dict, List
from collections import defaultdict
from datetime import datetime

PLUGIN_NAME = "report_enhancement"
PLUGIN_DESCRIPTION = "Mejoras en reportes: estadísticas avanzadas, tendencias, exportaciones STIX/TAXII"
PLUGIN_PHASE = "attack"
PLUGIN_REQUIRES_MCP = False

def _calculate_statistics(findings: List[Dict]) -> Dict:
    """Calcula estadísticas avanzadas de hallazgos."""
    stats = {
        'total': len(findings),
        'by_severity': defaultdict(int),
        'by_type': defaultdict(int),
        'by_cwe': defaultdict(int),
        'by_confidence': defaultdict(int),
        'critical_count': 0,
        'high_count': 0,
        'medium_count': 0,
        'low_count': 0,
        'info_count': 0,
        'verified_count': 0,
        'candidate_count': 0,
        'refuted_count': 0,
    }
    
    for f in findings:
        severity = f.get('severity', 'info').lower()
        finding_type = f.get('type', 'unknown')
        cwe = f.get('cwe', 'unknown')
        confidence = f.get('confidence', 0)
        state = f.get('state', '').lower()
        
        stats['by_severity'][severity] += 1
        stats['by_type'][finding_type] += 1
        stats['by_cwe'][cwe] += 1
        
        if confidence >= 80:
            stats['by_confidence']['high'] += 1
        elif confidence >= 50:
            stats['by_confidence']['medium'] += 1
        else:
            stats['by_confidence']['low'] += 1
        
        if severity == 'critical':
            stats['critical_count'] += 1
        elif severity == 'high':
            stats['high_count'] += 1
        elif severity == 'medium':
            stats['medium_count'] += 1
        elif severity == 'low':
            stats['low_count'] += 1
        else:
            stats['info_count'] += 1
        
        if state == 'verified':
            stats['verified_count'] += 1
        elif state == 'candidate':
            stats['candidate_count'] += 1
        elif state == 'refuted':
            stats['refuted_count'] += 1
    
    # Convert defaultdicts to regular dicts for JSON serialization
    stats['by_severity'] = dict(stats['by_severity'])
    stats['by_type'] = dict(stats['by_type'])
    stats['by_cwe'] = dict(stats['by_cwe'])
    stats['by_confidence'] = dict(stats['by_confidence'])
    
    return stats

def _generate_trend_data(findings: List[Dict]) -> List[Dict]:
    """Genera datos de tendencia para gráficos."""
    # Agrupa hallazgos por tipo y severidad
    trend = defaultdict(lambda: defaultdict(int))
    
    for f in findings:
        finding_type = f.get('type', 'unknown')
        severity = f.get('severity', 'info').lower()
        trend[finding_type][severity] += 1
    
    # Convierte a formato de gráfico
    chart_data = []
    for finding_type, severities in trend.items():
        chart_data.append({
            'type': finding_type,
            'data': dict(severities),
        })
    
    return chart_data

def _generate_stix_bundle(findings: List[Dict], target: str) -> Dict:
    """Genera un bundle STIX 2.1 con los hallazgos como indicadores."""
    stix_objects = []
    
    for i, f in enumerate(findings):
        finding_type = f.get('type', 'unknown')
        url = f.get('url', '')
        severity = f.get('severity', 'info').lower()
        
        # Mapear severidad a confianza STIX
        confidence_map = {
            'critical': 90,
            'high': 75,
            'medium': 50,
            'low': 25,
            'info': 10,
        }
        confidence = confidence_map.get(severity, 50)
        
        # Crear indicador STIX
        indicator = {
            'type': 'indicator',
            'spec_version': '2.1',
            'id': f'indicator--{i}',
            'created': datetime.utcnow().isoformat() + 'Z',
            'modified': datetime.utcnow().isoformat() + 'Z',
            'name': f'{finding_type} en {target}',
            'description': f.get('description', ''),
            'pattern': f"[url:value = '{url}']" if url else f"[domain-name:value = '{target}']",
            'pattern_type': 'stix',
            'valid_from': datetime.utcnow().isoformat() + 'Z',
            'confidence': confidence,
            'labels': [finding_type, severity],
        }
        stix_objects.append(indicator)
    
    bundle = {
        'type': 'bundle',
        'id': f'bundle--{datetime.utcnow().timestamp()}',
        'objects': stix_objects,
    }
    
    return bundle

def _generate_executive_summary(findings: List[Dict], target: str) -> Dict:
    """Genera un resumen ejecutivo del escaneo."""
    stats = _calculate_statistics(findings)
    
    # Hallazgos críticos y altos
    critical_high = [f for f in findings if f.get('severity', '').lower() in ('critical', 'high')]
    
    # Tipos de vulnerabilidad más comunes
    top_types = sorted(stats['by_type'].items(), key=lambda x: x[1], reverse=True)[:5]
    
    summary = {
        'target': target,
        'scan_date': datetime.utcnow().isoformat() + 'Z',
        'total_findings': stats['total'],
        'critical': stats['critical_count'],
        'high': stats['high_count'],
        'medium': stats['medium_count'],
        'low': stats['low_count'],
        'info': stats['info_count'],
        'top_vulnerability_types': [{'type': t, 'count': c} for t, c in top_types],
        'critical_high_findings': [
            {
                'type': f.get('type'),
                'url': f.get('url', ''),
                'severity': f.get('severity'),
                'description': f.get('description', '')[:100],
            }
            for f in critical_high[:10]
        ],
        'recommendations': [
            'Priorizar la remediación de hallazgos críticos y altos',
            'Implementar WAF como medida temporal',
            'Realizar revisión de código de los endpoints afectados',
            'Establecer monitoreo continuo de seguridad',
        ] if critical_high else [
            'Mantener las buenas prácticas de seguridad implementadas',
            'Realizar escaneos periódicos',
            'Mantener dependencias actualizadas',
        ],
    }
    
    return summary

async def run(ctx):
    """Genera mejoras de reporte."""
    findings = []
    
    # Obtener hallazgos del contexto
    session_findings = ctx.get('findings', [])
    target = ctx.get('target', '')
    
    if not session_findings:
        ctx.log('info', "Report Enhancement: No hay hallazgos para generar reportes")
        return {'plugin': PLUGIN_NAME, 'findings': [], 'stats': {}}
    
    # 1. Calcular estadísticas
    stats = _calculate_statistics(session_findings)
    
    # 2. Generar datos de tendencia
    trend_data = _generate_trend_data(session_findings)
    
    # 3. Generar bundle STIX
    stix_bundle = _generate_stix_bundle(session_findings, target)
    
    # 4. Generar resumen ejecutivo
    executive_summary = _generate_executive_summary(session_findings, target)
    
    # 5. Crear hallazgo de reporte mejorado
    finding = {
        'type': 'enhanced_report',
        'severity': 'info',
        'confidence': 100,
        'url': target,
        'param': '',
        'description': f"Reporte mejorado generado: {stats['total']} hallazgos analizados",
        'evidence': {
            'statistics': stats,
            'trend_data': trend_data,
            'stix_bundle_id': stix_bundle.get('id', ''),
            'executive_summary': executive_summary,
        },
        'cwe': '',
        'references': [],
    }
    findings.append(finding)
    
    ctx.log('info', f"Report Enhancement: {stats['total']} hallazgos analizados, {stats['critical_count']} críticos")
    
    return {
        'plugin': PLUGIN_NAME,
        'findings': findings,
        'stats': {
            'total_findings': stats['total'],
            'critical': stats['critical_count'],
            'high': stats['high_count'],
            'medium': stats['medium_count'],
            'low': stats['low_count'],
            'info': stats['info_count'],
            'stix_indicators': len(stix_bundle.get('objects', [])),
        }
    }