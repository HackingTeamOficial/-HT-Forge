"""End-to-end benchmark of the actual HT Forge SQLi/XSS plugins.

Runs only against a temporary HTTP fixture bound to 127.0.0.1. No external
network access, credentials, real secrets, or data extraction are involved.
"""
from __future__ import annotations
import html
import threading
import urllib.parse
from collections import defaultdict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from core.context import Context
from plugins import sqli, xss

class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        value = next(iter(params.values()), ["1"])[0]
        status = 200
        headers = {"Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store"}
        if parsed.path == "/sqli/vulnerable":
            # Simulated database error only after syntax-breaking input.
            body = ("<html>Database response: You have an error in your SQL syntax "
                    "near synthetic input</html>") if ("'" in value or '"' in value) else "<html>Search results: 1</html>"
        elif parsed.path == "/sqli/safe":
            body = "<html>Search results: 1</html>"
        elif parsed.path == "/xss/vulnerable":
            body = "<html><body>" + value + "</body></html>"
        elif parsed.path == "/xss/escaped":
            body = "<html><body>" + html.escape(value) + "</body></html>"
        else:
            status, body = 404, "Not found"
        data = body.encode("utf-8")
        self.send_response(status)
        for key, val in headers.items():
            self.send_header(key, val)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

_CASES = [
    {"id":"sqli-production-vulnerable", "detector":"sqli", "path":"/sqli/vulnerable?lookupTerm=1", "param":"lookupTerm", "truth":True},
    {"id":"sqli-production-safe", "detector":"sqli", "path":"/sqli/safe?lookupTerm=1", "param":"lookupTerm", "truth":False},
    {"id":"xss-production-vulnerable", "detector":"xss", "path":"/xss/vulnerable?displayName=1", "param":"displayName", "truth":True},
    {"id":"xss-production-escaped", "detector":"xss", "path":"/xss/escaped?displayName=1", "param":"displayName", "truth":False},
]

def _run_case(base: str, case: dict[str, Any]) -> dict[str, Any]:
    url = base + case["path"]
    cfg = {
        "sqli_max_params": 1, "sqli_time_budget": 18, "sqli_request_timeout": 2,
        "sqli_time_based": False, "xss_max_params": 1, "xss_request_timeout": 2,
    }
    # Deliberately omit discovered_params: this verifies the plugin's normal
    # fallback discovers query keys directly from the target URL.
    ctx = Context(target=url, config=cfg)
    plugin = sqli if case["detector"] == "sqli" else xss
    result = plugin.run(ctx)
    findings = result.get("findings", []) if isinstance(result, dict) else []
    if case["detector"] == "sqli":
        detected = any(str(f.get("type", "")).lower() == "sqli" for f in findings)
    else:
        detected = any(str(f.get("type", "")).lower().startswith("xss") and
                       f.get("verification_state") == "VERIFIED" for f in findings)
    outcome = "TP" if case["truth"] and detected else "FN" if case["truth"] else "FP" if detected else "TN"
    return {"case_id": case["id"], "detector": case["detector"],
            "expected_vulnerable": case["truth"], "detected": detected,
            "outcome": outcome, "finding_count": len(findings),
            "finding_titles": [str(f.get("title", f.get("type", "finding"))) for f in findings[:5]]}

def run_production_detector_benchmark() -> dict[str, Any]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    rows = []
    try:
        for case in _CASES:
            try:
                rows.append(_run_case(base, case))
            except Exception as exc:
                rows.append({"case_id": case["id"], "detector": case["detector"],
                             "expected_vulnerable": case["truth"], "detected": False,
                             "outcome": "FN" if case["truth"] else "TN", "error": type(exc).__name__})
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)
    grouped = defaultdict(lambda: {"TP":0, "FP":0, "FN":0, "TN":0, "cases":0})
    for row in rows:
        group = grouped[row["detector"]]
        group[row["outcome"]] += 1
        group["cases"] += 1
    metrics = {}
    for detector, g in grouped.items():
        precision = g["TP"] / (g["TP"] + g["FP"]) if g["TP"] + g["FP"] else 0.0
        recall = g["TP"] / (g["TP"] + g["FN"]) if g["TP"] + g["FN"] else 0.0
        specificity = g["TN"] / (g["TN"] + g["FP"]) if g["TN"] + g["FP"] else 0.0
        metrics[detector] = {**g, "precision_pct": round(100*precision, 1),
            "recall_pct": round(100*recall, 1), "specificity_pct": round(100*specificity, 1),
            "false_positive_rate_pct": round(100*(1-specificity), 1)}
    total = {k:sum(v[k] for v in metrics.values()) for k in ("TP", "FP", "FN", "TN", "cases")}
    total["precision_pct"] = round(100*total["TP"]/(total["TP"]+total["FP"]), 1) if total["TP"]+total["FP"] else 0.0
    total["recall_pct"] = round(100*total["TP"]/(total["TP"]+total["FN"]), 1) if total["TP"]+total["FN"] else 0.0
    return {"ok": total["FP"] == 0 and total["FN"] == 0, "timestamp": datetime.now(timezone.utc).isoformat(),
        "scope": "Prueba end-to-end de plugins reales SQLi/XSS contra fixture HTTP temporal en 127.0.0.1; sin tráfico externo",
        "metrics": metrics, "aggregate": total, "cases": rows,
        "limitations": ["Son cuatro casos de regresión controlados, no una estimación estadística de precisión en aplicaciones reales.",
            "SQLi usa un error de base de datos simulado; no ejecuta consultas ni extrae datos.",
            "XSS comprueba reflexión HTML cruda frente a reflexión escapada; no ejecuta JavaScript en un navegador.",
            "La validación completa requiere más fixtures por contexto, motor SQL, método HTTP y tecnología."]}
