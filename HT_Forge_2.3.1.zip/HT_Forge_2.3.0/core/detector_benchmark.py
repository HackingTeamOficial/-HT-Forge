"""Offline safety benchmark for HT Forge evidence policy.

Uses only synthetic findings. It does not contact targets or execute payloads.
This measures policy invariants, not end-to-end detector precision/recall.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from core.confirm_policy import apply_policy
from core.evidence import STATE_RANK

_CASES: list[dict[str, Any]] = [
    {"id":"ssti-marker-only", "label":"SSTI marker without demonstrated consequence", "expected_max":"LIKELY",
     "finding":{"type":"ssti_possible","module":"ssti","severity":"high","verification_state":"CONFIRMED","evidence":{"marker":"SYNTHETIC_MARKER"}}},
    {"id":"xss-reflection-escaped", "label":"Escaped XSS reflection is not executable proof", "expected_max":"LIKELY",
     "finding":{"type":"xss","module":"xss","severity":"high","verification_state":"CONFIRMED","evidence":{"raw_reflection":"<script>","reflection_context":"html_text","escaped":True,"matched_signature":"reflection"}}},
    {"id":"ssrf-url-only", "label":"SSRF URL acceptance without connection evidence", "expected_max":"CANDIDATE",
     "finding":{"type":"ssrf","module":"ssrf","severity":"high","verification_state":"CONFIRMED","evidence":{}}},
    {"id":"xxe-internal-entity", "label":"XXE internal entity does not prove external entity access", "expected_max":"VERIFIED",
     "finding":{"type":"xxe","module":"xxe","severity":"high","verification_state":"CONFIRMED","title":"XXE test","evidence":{"technique":"internal-entity","retest_count":2,"replayed_confirmation":True}}},
    {"id":"sqli-marker", "label":"SQLi title/marker without reproducibility is not confirmed", "expected_max":"VERIFIED",
     "finding":{"type":"sqli","module":"sqli","severity":"high","verification_state":"CONFIRMED","title":"Possible SQL error","evidence":{"matched_signature":"sql error"}}},
    {"id":"generic-empty-evidence", "label":"Generic finding with empty evidence cannot be confirmed", "expected_max":"VERIFIED",
     "finding":{"type":"unknown_test","module":"unknown","severity":"high","verification_state":"CONFIRMED","evidence":{}}},
]


def run_detector_benchmark() -> dict[str, Any]:
    results = []
    for case in _CASES:
        finding = apply_policy(deepcopy(case["finding"]))
        state = str(finding.get("verification_state") or "CANDIDATE").upper()
        max_state = case["expected_max"]
        passed = STATE_RANK.get(state, 0) <= STATE_RANK.get(max_state, 0)
        results.append({"id":case["id"], "label":case["label"], "passed":passed,
                        "expected_max_state":max_state, "actual_state":state,
                        "evidence_score":(finding.get("evidence") or {}).get("evidence_score", 0),
                        "policy_reasons":(finding.get("evidence") or {}).get("policy_reasons", [])})
    passed_count = sum(1 for r in results if r["passed"])
    return {
        "ok": passed_count == len(results),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "scope": "offline synthetic evidence-policy benchmark; no target traffic",
        "passed": passed_count,
        "total": len(results),
        "cases": results,
        "metrics": {"invariant_pass_rate_pct": round(100 * passed_count / len(results), 1) if results else 0,
                    "overconfirmation_violations": sum(1 for r in results if not r["passed"])},
        "limitations": [
            "This is not a real-world detector precision/recall benchmark.",
            "It evaluates only evidence-state policy invariants on synthetic findings.",
            "End-to-end accuracy requires a labelled vulnerable/non-vulnerable lab corpus and manual adjudication."
        ]
    }
