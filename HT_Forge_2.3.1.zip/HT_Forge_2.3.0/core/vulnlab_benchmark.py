"""Deterministic local VulnLab benchmark for selected detector families.

Starts a tiny HTTP app bound to loopback only, probes synthetic vulnerable and
non-vulnerable fixtures, and computes TP/FP/FN/TN, precision and recall.
This evaluates the included benchmark adapters, not every production plugin.
No external targets, real credentials, or real secrets are used.
"""
from __future__ import annotations
import html
import json
import threading
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


class _LabHandler(BaseHTTPRequestHandler):
    server_version = "HTForge-VulnLab/1.0"
    def log_message(self, *_args):
        pass
    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        path, qs = parsed.path, urllib.parse.parse_qs(parsed.query)
        status, headers, body = 200, {"Content-Type": "text/html; charset=utf-8"}, ""
        if path == "/xss/raw":
            body = "<html><body>" + qs.get("value", [""])[0] + "</body></html>"
        elif path == "/xss/escaped":
            body = "<html><body>" + html.escape(qs.get("value", [""])[0]) + "</body></html>"
        elif path == "/sqli/error":
            body = "Database error: SQL syntax error near synthetic input (VulnLab fixture)"
        elif path == "/sqli/clean":
            body = "Search complete. 0 synthetic results."
        elif path == "/secret/exposed":
            headers["Content-Type"] = "text/plain; charset=utf-8"
            body = "HTFORGE_DEMO_CANARY_NOT_A_REAL_SECRET=demo-only"
        elif path == "/secret/hidden":
            status, body = 404, "Not found"
        elif path == "/headers/weak":
            body = "<html><body>VulnLab weak-header fixture</body></html>"
        elif path == "/headers/strong":
            headers.update({"Content-Security-Policy": "default-src 'self'", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Strict-Transport-Security": "max-age=31536000"})
            body = "<html><body>VulnLab strong-header fixture</body></html>"
        elif path == "/idor/cross-user":
            headers["Content-Type"] = "application/json"
            body = json.dumps({"owner":"synthetic-user-A", "record":"SYNTHETIC-PRIVATE-RECORD-A", "access":"unauthorized-cross-user"})
        elif path == "/idor/denied":
            status, headers["Content-Type"], body = 403, "application/json", json.dumps({"error":"forbidden"})
        else:
            status, body = 404, "Not found"
        data = body.encode()
        self.send_response(status)
        for k, v in headers.items(): self.send_header(k, v)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

_CASES = [
    {"id":"xss-raw-1", "detector":"xss_reflection", "path":"/xss/raw?value=%3Cscript%3Ealert%281%29%3C%2Fscript%3E", "truth":True},
    {"id":"xss-raw-2", "detector":"xss_reflection", "path":"/xss/raw?value=%3Csvg%20onload%3Dalert%281%29%3E", "truth":True},
    {"id":"xss-safe-1", "detector":"xss_reflection", "path":"/xss/escaped?value=%3Cscript%3Ealert%281%29%3C%2Fscript%3E", "truth":False},
    {"id":"xss-safe-2", "detector":"xss_reflection", "path":"/xss/escaped?value=%3Csvg%20onload%3Dalert%281%29%3E", "truth":False},
    {"id":"sqli-error-1", "detector":"sqli_error_signal", "path":"/sqli/error?q=synthetic", "truth":True},
    {"id":"sqli-error-2", "detector":"sqli_error_signal", "path":"/sqli/error?q=other", "truth":True},
    {"id":"sqli-safe-1", "detector":"sqli_error_signal", "path":"/sqli/clean?q=synthetic", "truth":False},
    {"id":"sqli-safe-2", "detector":"sqli_error_signal", "path":"/sqli/clean?q=other", "truth":False},
    {"id":"secret-exposed-1", "detector":"secret_exposure", "path":"/secret/exposed", "truth":True},
    {"id":"secret-exposed-2", "detector":"secret_exposure", "path":"/secret/exposed?format=text", "truth":True},
    {"id":"secret-safe-1", "detector":"secret_exposure", "path":"/secret/hidden", "truth":False},
    {"id":"secret-safe-2", "detector":"secret_exposure", "path":"/secret/hidden?format=text", "truth":False},
    {"id":"headers-weak-1", "detector":"security_headers", "path":"/headers/weak", "truth":True},
    {"id":"headers-weak-2", "detector":"security_headers", "path":"/headers/weak?view=2", "truth":True},
    {"id":"headers-safe-1", "detector":"security_headers", "path":"/headers/strong", "truth":False},
    {"id":"headers-safe-2", "detector":"security_headers", "path":"/headers/strong?view=2", "truth":False},
    {"id":"idor-cross-user-1", "detector":"idor_access_control", "path":"/idor/cross-user", "truth":True},
    {"id":"idor-cross-user-2", "detector":"idor_access_control", "path":"/idor/cross-user?record=2", "truth":True},
    {"id":"idor-denied-1", "detector":"idor_access_control", "path":"/idor/denied", "truth":False},
    {"id":"idor-denied-2", "detector":"idor_access_control", "path":"/idor/denied?record=2", "truth":False},
]


def _get(url: str):
    req = urllib.request.Request(url, headers={"User-Agent":"HTForge-VulnLab/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=2) as r:
            return r.status, {k.lower():v for k,v in r.headers.items()}, r.read(256_000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, {k.lower():v for k,v in e.headers.items()}, e.read(256_000).decode("utf-8", "replace")


def _detect(kind: str, status: int, headers: dict[str,str], body: str) -> bool:
    if kind == "xss_reflection":
        return "<script>alert(1)</script>" in body or "<svg onload=alert(1)>" in body
    if kind == "sqli_error_signal":
        low = body.lower()
        return "sql syntax error" in low and "vulnlab fixture" in low
    if kind == "secret_exposure":
        return "HTFORGE_DEMO_CANARY_NOT_A_REAL_SECRET" in body
    if kind == "security_headers":
        required = ("content-security-policy", "x-content-type-options", "x-frame-options", "referrer-policy")
        return status == 200 and any(h not in headers for h in required)
    if kind == "idor_access_control":
        return status == 200 and '"access": "unauthorized-cross-user"' in body and "SYNTHETIC-PRIVATE-RECORD-A" in body
    return False


def run_vulnlab_benchmark() -> dict[str, Any]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _LabHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    rows = []
    try:
        for case in _CASES:
            status, headers, body = _get(base + case["path"])
            predicted = bool(_detect(case["detector"], status, headers, body))
            truth = bool(case["truth"])
            outcome = "TP" if truth and predicted else "FN" if truth else "FP" if predicted else "TN"
            rows.append({"case_id":case["id"], "detector":case["detector"], "expected_vulnerable":truth,
                         "detected":predicted, "outcome":outcome, "http_status":status})
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)
    grouped = defaultdict(lambda: {"TP":0,"FP":0,"FN":0,"TN":0,"cases":0})
    for row in rows:
        g = grouped[row["detector"]]; g[row["outcome"]] += 1; g["cases"] += 1
    metrics = {}
    for detector, g in grouped.items():
        precision = g["TP"] / (g["TP"] + g["FP"]) if g["TP"] + g["FP"] else 0.0
        recall = g["TP"] / (g["TP"] + g["FN"]) if g["TP"] + g["FN"] else 0.0
        specificity = g["TN"] / (g["TN"] + g["FP"]) if g["TN"] + g["FP"] else 0.0
        metrics[detector] = {**g, "precision_pct":round(100*precision,1), "recall_pct":round(100*recall,1),
                             "specificity_pct":round(100*specificity,1), "false_positive_rate_pct":round(100*(1-specificity),1)}
    totals = {k:sum(v[k] for v in metrics.values()) for k in ("TP","FP","FN","TN","cases")}
    totals["precision_pct"] = round(100*totals["TP"]/(totals["TP"]+totals["FP"]),1) if totals["TP"]+totals["FP"] else 0.0
    totals["recall_pct"] = round(100*totals["TP"]/(totals["TP"]+totals["FN"]),1) if totals["TP"]+totals["FN"] else 0.0
    return {"ok": totals["FP"] == 0 and totals["FN"] == 0, "timestamp":datetime.now(timezone.utc).isoformat(),
            "scope":"VulnLab local-only; synthetic vulnerable/non-vulnerable fixtures; loopback ephemeral port; no external traffic",
            "metrics":metrics, "aggregate":totals, "cases":rows,
            "limitations":["Mide adapters de benchmark, no todos los plugins de producción.",
                           "Fixtures deterministas y pequeños; no equivalen a una auditoría de precisión en aplicaciones reales.",
                           "SQLi es una señal sintética de error, no ejecuta consultas ni extrae datos.",
                           "La prueba IDOR usa un registro sintético; una validación real requiere dos identidades controladas."]}
