"""Local, non-invasive quality checks for HT Forge detectors and evidence policy.

This lab never sends requests to scan targets. It checks imports and synthetic
findings only; passing checks are not a substitute for detection benchmarks.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def run_quality_lab() -> dict[str, Any]:
    from core.module_health import summary as module_summary
    from core.confirm_policy import apply_policy
    from core.evidence import normalize_finding, evidence_score

    modules = module_summary()
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "passed": bool(ok), "detail": detail})

    # Synthetic policy tests: a bare marker must not become CONFIRMED.
    marker = {"type": "ssti_possible", "module": "ssti", "severity": "high",
              "verification_state": "CONFIRMED", "evidence": {"marker": "TEST_MARKER"}}
    marker_out = apply_policy(marker)
    check("marker_not_auto_confirmed",
          marker_out.get("verification_state") != "CONFIRMED",
          f"Estado obtenido: {marker_out.get('verification_state')}")

    # XSS reflection without executable context must not remain confirmed.
    xss = {"type": "xss", "module": "xss", "severity": "high",
           "verification_state": "CONFIRMED",
           "evidence": {"raw_reflection": "<script>", "reflection_context": "html_text",
                        "escaped": True, "baseline": "control", "matched_signature": "reflection"}}
    xss_out = apply_policy(xss)
    check("xss_reflection_not_auto_confirmed",
          xss_out.get("verification_state") != "CONFIRMED",
          f"Estado obtenido: {xss_out.get('verification_state')}")

    # Normalize must preserve the declared known state and always expose evidence.
    norm = normalize_finding({"type": "demo", "verification_state": "CANDIDATE", "evidence": {"baseline": "ok"}})
    check("finding_normalization", norm.get("verification_state") == "CANDIDATE" and isinstance(norm.get("evidence_quality"), str),
          f"Estado={norm.get('verification_state')}; calidad={norm.get('evidence_quality')}")

    # A score should be bounded and deterministic for a fixed synthetic evidence object.
    ev = {"baseline": "control", "matched_signature": "synthetic", "retest_count": 2}
    score_a, score_b = evidence_score(ev), evidence_score(dict(ev))
    check("evidence_score_deterministic", score_a == score_b and 0 <= score_a["score"] <= 100,
          f"Puntuación sintética: {score_a['score']}/100")

    broken = int(modules.get("broken", 0))
    check("plugin_import_health", broken == 0,
          f"Plugins importables: {modules.get('functional', 0)} funcionales; {modules.get('discovery_only', 0)} discovery-only; {broken} con error")

    passed = sum(1 for item in checks if item["passed"])
    return {
        "ok": passed == len(checks),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "scope": "local synthetic checks; no target traffic generated",
        "passed": passed,
        "total": len(checks),
        "modules": {k: modules.get(k, 0) for k in ("total", "functional", "discovery_only", "broken")},
        "checks": checks,
        "limitations": [
            "Import success does not prove that a detector correctly detects vulnerabilities.",
            "No external targets, credentials, payloads, or network requests are used.",
            "A full benchmark needs a controlled vulnerable/non-vulnerable test corpus."
        ]
    }
