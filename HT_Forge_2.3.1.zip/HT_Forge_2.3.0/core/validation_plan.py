"""Safe, deterministic next-step plans for reviewing a finding.

Plans are advisory and do not execute requests, shell commands, or payloads.
They favor controlled test identities, synthetic records, and minimal proof.
"""
from __future__ import annotations
from typing import Any

_CATALOG = {
    "sqli": ("Validar posible inyección SQL", [
        "Revisar la petición original y conservar una respuesta baseline sin modificar.",
        "Repetir únicamente en un entorno autorizado con un caso de control y otro de prueba no destructivo.",
        "Comparar código HTTP, estructura de respuesta y diferencias reproducibles; descartar errores transitorios.",
        "No extraer tablas ni registros reales: documentar el impacto potencial y usar datos sintéticos para demostrarlo."
    ], "No realizar enumeración ni extracción de datos."),
    "xss": ("Validar contexto de XSS", [
        "Identificar si el dato aparece en HTML, atributo, JavaScript, URL o DOM.",
        "Comprobar si el valor se escapa o codifica correctamente y si existe un contexto ejecutable.",
        "En un laboratorio autorizado, usar una prueba inocua que no lea cookies, tokens ni información de usuario.",
        "Guardar fragmento de respuesta, contexto, controles y resultado de repetición."
    ], "No recolectar cookies, tokens ni sesiones."),
    "idor": ("Validar control de acceso entre identidades", [
        "Usar dos cuentas de prueba y dos recursos sintéticos creados para el test.",
        "Registrar la respuesta legítima del propietario como baseline.",
        "Con la segunda cuenta, probar solo el identificador del recurso de laboratorio y comprobar autorización del servidor.",
        "Guardar la matriz identidad-recurso-resultado sin consultar datos de terceros."
    ], "No acceder a recursos ni datos de usuarios reales."),
    "bola": ("Validar autorización por objeto (BOLA)", [
        "Preparar dos identidades y objetos de prueba bajo control del evaluador.",
        "Comparar acceso del propietario frente a acceso de la otra identidad.",
        "Verificar que el control se aplica en servidor y no solo en la interfaz.",
        "Adjuntar peticiones redactadas y resultados mínimos reproducibles."
    ], "No enumerar identificadores reales ni descargar colecciones."),
    "ssrf": ("Validar SSRF con receptor controlado", [
        "Confirmar que el activo y la funcionalidad están dentro del alcance autorizado.",
        "Usar únicamente un receptor HTTP de pruebas controlado por el equipo.",
        "Correlacionar la petición de prueba con los registros del receptor; un timeout por sí solo no confirma SSRF.",
        "No consultar metadatos cloud ni direcciones internas de producción."
    ], "No sondear redes internas ni endpoints de metadatos."),
    "secret": ("Validar exposición de secreto sin utilizarlo", [
        "Identificar el tipo de secreto y el contexto donde aparece.",
        "Redactar el valor en capturas e informes y registrar solo una huella segura cuando proceda.",
        "Validar con el propietario si el secreto es de prueba, está activo y cuál es su alcance.",
        "Recomendar revocación/rotación y búsqueda de exposición secundaria."
    ], "No autenticarse ni probar privilegios con el secreto encontrado."),
    "auth": ("Validar autenticación y gestión de sesiones", [
        "Documentar el flujo autorizado de inicio de sesión, recuperación y cierre de sesión.",
        "Usar cuentas de prueba separadas y comprobar expiración, rotación y revocación de sesiones.",
        "Revisar controles de MFA y respuestas ante intentos inválidos sin realizar ataques de fuerza bruta.",
        "Registrar únicamente tokens redactados y resultados mínimos reproducibles."
    ], "No probar credenciales de terceros ni capturar sesiones reales."),
    "api_access": ("Validar autorización y exposición de datos en API", [
        "Identificar el contrato OpenAPI/GraphQL y elegir objetos sintéticos dentro del alcance.",
        "Comparar respuestas con dos identidades de prueba y permisos distintos.",
        "Revisar campos inesperados, mass assignment y controles del lado del servidor.",
        "Guardar una matriz de rol, operación, recurso y resultado con datos redactados."
    ], "No enumerar identificadores reales ni extraer registros de producción."),
    "jwt_oauth": ("Revisar configuración JWT/OAuth/OIDC", [
        "Inspeccionar metadatos públicos y configuración documentada del flujo autorizado.",
        "Comprobar validación de issuer, audience, expiración, algoritmo y redirect URI mediante casos de prueba.",
        "Usar tokens sintéticos o de laboratorio y verificar rechazo de variantes inválidas.",
        "Registrar configuración observada y pasos de reproducción sin publicar tokens."
    ], "No falsificar tokens para acceder a cuentas ni reutilizar tokens reales."),
    "xxe": ("Validar procesamiento XML de forma controlada", [
        "Confirmar que el endpoint acepta XML y que está incluido en el alcance.",
        "Usar un documento benigno de prueba y revisar configuración de entidades externas.",
        "Si se requiere una prueba externa, usar únicamente un receptor de laboratorio controlado.",
        "Distinguir expansión interna de entidad, interacción externa y lectura de archivos; documentar solo la evidencia mínima."
    ], "No leer archivos del sistema ni consultar recursos internos."),
    "ssti": ("Validar posible inyección en plantillas", [
        "Identificar el contexto de plantilla y conservar una respuesta baseline.",
        "Usar expresiones aritméticas inocuas en un laboratorio autorizado y comparar con texto literal de control.",
        "Repetir la prueba para descartar reflejos, caché y errores transitorios.",
        "No ejecutar comandos del sistema; documentar el motor solo si la evidencia lo sustenta."
    ], "No encadenar SSTI con ejecución de comandos ni acceso al sistema."),
    "file_upload": ("Validar controles de subida de archivos", [
        "Usar un archivo inocuo con nombre y contenido únicos en una cuenta de prueba.",
        "Comprobar validación de tipo, tamaño, nombre, almacenamiento y permisos de acceso.",
        "Verificar si el archivo se sirve como contenido inerte y si queda aislado del código ejecutable.",
        "Eliminar los artefactos de prueba al terminar y registrar la respuesta del servidor."
    ], "No subir webshells, malware ni archivos destinados a ejecutar código."),
    "default": ("Validar el hallazgo de forma controlada", [
        "Confirmar que el activo y la ruta están dentro del alcance autorizado.",
        "Conservar la petición y respuesta originales como baseline.",
        "Diseñar un control negativo y una prueba de bajo impacto que discrimine la hipótesis.",
        "Repetir el resultado, registrar limitaciones y mantener INCONCLUSIVE si la evidencia no es suficiente."
    ], "No realizar extracción, persistencia ni cambios destructivos.")
}


def build_validation_plan(finding: dict[str, Any]) -> dict[str, Any]:
    f = finding if isinstance(finding, dict) else {}
    text = " ".join(str(f.get(k) or "") for k in ("type", "module", "title", "category")).lower()
    if any(k in text for k in ("sqli", "sql injection", "sql_injection")):
        key = "sqli"
    elif any(k in text for k in ("xss", "cross-site scripting")):
        key = "xss"
    elif any(k in text for k in ("idor", "bola", "broken object level authorization")):
        key = "bola" if "bola" in text else "idor"
    elif "ssrf" in text or "server-side request forgery" in text:
        key = "ssrf"
    elif any(k in text for k in ("secret", "credential", "token exposure", "key exposure")):
        key = "secret"
    elif any(k in text for k in ("oauth", "oidc", "jwt", "openid connect")):
        key = "jwt_oauth"
    elif any(k in text for k in ("authentication", "authn", "session", "mfa", "login")):
        key = "auth"
    elif any(k in text for k in ("mass assignment", "api", "bola", "authorization", "access control", "idor")):
        key = "api_access"
    elif any(k in text for k in ("xxe", "xml external entity")):
        key = "xxe"
    elif any(k in text for k in ("ssti", "template injection")):
        key = "ssti"
    elif any(k in text for k in ("file upload", "file_upload", "upload validation", "unrestricted upload")):
        key = "file_upload"
    else:
        key = "default"
    title, steps, guardrail = _CATALOG[key]
    return {
        "ok": True,
        "plan_type": key,
        "title": title,
        "finding": {"type": str(f.get("type") or "unknown"), "title": str(f.get("title") or "Hallazgo")[:200],
                    "url": str(f.get("url") or "")[:500], "verification_state": str(f.get("verification_state") or "CANDIDATE")},
        "steps": list(steps),
        "guardrail": guardrail,
        "execution": "advisory_only",
        "network_requests_sent": False,
        "shell_commands_executed": False,
        "requires_authorized_scope": True
    }
