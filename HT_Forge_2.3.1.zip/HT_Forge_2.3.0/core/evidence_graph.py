"""Build a sanitized, deterministic, richer evidence-correlation graph."""
from __future__ import annotations
from hashlib import sha256
from typing import Any
from urllib.parse import urlsplit

SENSITIVE_KEYS = {"request", "response", "request_body", "response_body", "cookie", "authorization", "token", "password", "secret", "payload", "snippet", "raw_reflection", "response_excerpt"}


def _id(kind: str, value: str) -> str:
    return kind + "_" + sha256((kind + "\0" + value).encode("utf-8", "replace")).hexdigest()[:12]


def _safe_endpoint(url: str) -> str:
    try:
        p = urlsplit(str(url))
        if p.scheme.lower() not in ("http", "https") or not p.netloc:
            return ""
        # Query, fragment and user-info are intentionally excluded.
        host = p.hostname or ""
        if p.port:
            host += f":{p.port}"
        return (p.scheme.lower() + "://" + host.lower() + (p.path or "/"))[:180]
    except Exception:
        return ""


def build_evidence_graph(findings: list[dict[str, Any]], max_findings: int = 300) -> dict[str, Any]:
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[tuple[str, str, str], dict[str, Any]] = {}

    def node(kind, value, label, **extra):
        key = _id(kind, str(value))
        nodes.setdefault(key, {"id": key, "kind": kind, "label": str(label)[:180], **extra})
        return key

    def edge(src, dst, relation):
        edges[(src, dst, relation)] = {"source": src, "target": dst, "relation": relation}

    used = 0
    for f in (findings or [])[:max(0, int(max_findings))]:
        if not isinstance(f, dict):
            continue
        used += 1
        ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
        title = str(f.get("title") or f.get("type") or "Finding")
        typ = str(f.get("type") or f.get("module") or "unknown").lower()
        raw_url = str(f.get("url") or f.get("endpoint") or ev.get("url") or "")
        safe_url = _safe_endpoint(raw_url)
        param = str(f.get("parameter") or f.get("param") or ev.get("parameter") or ev.get("param") or "").strip()[:100]
        technique = str(ev.get("technique") or f.get("technique") or typ).strip()[:100]
        state = str(f.get("verification_state") or "CANDIDATE").upper()
        severity = str(f.get("severity") or "info").lower()
        confidence = f.get("confidence")
        try:
            confidence = round(max(0.0, min(1.0, float(confidence))), 3) if confidence is not None else None
        except (TypeError, ValueError):
            confidence = None
        # IDs use the sanitized endpoint, never query values or raw payloads.
        fid = node("finding", title + "|" + safe_url + "|" + param + "|" + typ,
                   title, state=state, severity=severity, module=str(f.get("module") or typ),
                   finding_type=typ, confidence=confidence)
        if safe_url:
            uid = node("endpoint", safe_url, safe_url)
            edge(fid, uid, "observed_at")
        if param:
            pid = node("parameter", (safe_url + "|" + param).lower(), param)
            edge(fid, pid, "tests_parameter")
            if safe_url:
                edge(pid, node("endpoint", safe_url, safe_url), "belongs_to")
        if technique:
            tid = node("technique", technique.lower(), technique)
            edge(fid, tid, "detected_by")
        technology = str(f.get("technology") or ev.get("technology") or "").strip()
        if technology:
            tid = node("technology", technology.lower(), technology)
            edge(fid, tid, "associated_with")
        # Show evidence coverage, not evidence contents. Never expose payloads,
        # response excerpts, tokens, cookies or other raw values in the graph.
        evkeys = [k for k, v in ev.items() if v not in (None, "", [], {}) and str(k).lower() not in SENSITIVE_KEYS]
        for key in sorted(evkeys)[:16]:
            value_type = type(ev[key]).__name__
            eid = node("evidence", str(key) + ":" + value_type, str(key).replace("_", " ").title(),
                       field=str(key), value_type=value_type)
            edge(fid, eid, "supported_by")
    return {
        "ok": True, "graph_type": "sanitized_evidence_graph", "finding_count": used,
        "node_count": len(nodes), "edge_count": len(edges),
        "nodes": list(nodes.values()), "edges": list(edges.values()),
        "summary": {
            "by_type": _counts(findings, "type", max_findings),
            "by_state": _counts(findings, "verification_state", max_findings, default="CANDIDATE"),
            "by_severity": _counts(findings, "severity", max_findings, default="info"),
            "with_parameter": sum(1 for f in (findings or [])[:max(0, int(max_findings))] if isinstance(f, dict) and (f.get("parameter") or f.get("param") or (isinstance(f.get("evidence"), dict) and (f["evidence"].get("parameter") or f["evidence"].get("param"))))),
        },
        "privacy": "Query strings, user-info, raw payloads, response excerpts and credential-like values are omitted."
    }


def _counts(findings, key, limit, default="unknown"):
    counts = {}
    for finding in (findings or [])[:max(0, int(limit))]:
        if not isinstance(finding, dict):
            continue
        value = str(finding.get(key) or default).lower()
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items()))
