# HT Forge 2.3.0 — Quality Foundation

## Added
- Detector Quality Lab in HT Forge AI: local synthetic checks for evidence normalization, scoring determinism, conservative marker/XSS verdict policy, and plugin import health.
- `GET /api/quality-lab` endpoint. It performs local checks only and does not generate traffic to scan targets.
- AI analyst action to prepare a finding-specific validation plan for SQLi, XSS, IDOR/BOLA, SSRF, and exposed secrets. Plans are advisory and explicitly do not execute commands or network requests.
- Regression tests for the Quality Lab and conservative confirmation behavior.

## Fixed
- Fixed a `KeyError` in `core/confirm_policy.py` when degrading a low-evidence `LIKELY` finding. `CANDIDATE` is a state without a score threshold, so the policy now degrades monotonically without indexing it in `STATE_MIN_SCORE`.

## Validation notes
- The Quality Lab currently checks synthetic examples and module imports. Import success is not proof that a detector has accurate detection coverage.
- This release does not claim an independently measured false-positive or false-negative rate. That requires a controlled vulnerable/non-vulnerable benchmark corpus.
- The existing AI remains advisory/read-only; no arbitrary shell execution or automated extraction of real user data was added.


## Incremento de calidad (misma versión 2.3.0)
- Añadido VulnLab local con 20 casos sintéticos vulnerables/no vulnerables y métricas TP/FP/FN/TN, precisión, recall, especificidad y FPR por adaptador.
- Añadido Evidence Graph con nodos y relaciones sanitizados; query strings y valores de evidencia sensibles no se exportan.
- Reforzado el panel de IA con etiqueta explícita de asistente de validación de laboratorio no ejecutor.
- Añadidas pruebas para métricas del VulnLab y redacción de datos en el grafo.
- Sin cambio de versión: permanece 2.3.0.

## Corrección de cobertura SQLi/XSS (misma versión 2.3.0)

- SQLi y XSS ahora extraen parámetros existentes directamente de la query string cuando el crawler no ha proporcionado `discovered_params`. Antes, SQLi solo intentaba `id`/`q` y XSS `q`/`search`, por lo que endpoints con nombres como `lookupTerm`, `artist` o `displayName` podían quedar fuera del análisis.
- El botón VulnLab ahora ejecuta los plugins reales `plugins.sqli` y `plugins.xss` contra una aplicación de prueba temporal en loopback, incluyendo casos vulnerables y negativos. El benchmark usa parámetros no genéricos para comprobar la cobertura de fallback.
- Alcance medido: 4 casos controlados (1 SQLi vulnerable, 1 SQLi seguro, 1 XSS reflejado sin escapar, 1 XSS escapado). Es una prueba de regresión, no una garantía de detección en aplicaciones reales.
