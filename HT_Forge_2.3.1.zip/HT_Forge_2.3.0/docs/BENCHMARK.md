# HT Forge Benchmark — metodología

Comparación objetiva HT Forge vs ZAP / Burp / Nuclei. Sin promesas:
demostrar o no, con resultados reproducibles.

## Métricas

- **Detection**: hallazgos totales y accionables (CONFIRMED/VERIFIED/LIKELY).
- **True/false positives**: estados de verificación + retest como proxy;
  etiquetado manual para TP/FP/FN en la hoja de resultados.
- **Confirmation**: tasa con par baseline→sonda (`response_pair`) y con retest.
- **Evidence quality**: tasas de `response_pair`, `retest`, `cwe`.
- **Coverage**: módulos ejecutados (`modules_run`) vs solicitados.
- **Tiempo**: `duration_s` de pared.
- **Deduplicación**: `duplicate_rate` sobre (tipo, url, parámetro).
- **Errores**: `error_count` + lista.

## Separación de entornos

- **Benchmark público externo**: labs públicos (p. ej. Acuforum de Acunetix)
  y objetivos autorizados. Solo detección, sin volcado de datos.
- **Laboratorio propio** (HT Forge VulnLab local): desarrollo y regresión.
  Aquí sí se permite explotación completa contra datos sintéticos.

Nunca se mezcla: el lab propio no sirve para afirmar superioridad
frente a terceros.

## Reproducir

```bash
python3 tools/benchmark.py --target http://127.0.0.1:8080 --profile full
python3 tools/benchmark.py --target http://127.0.0.1:8080 --modules sqli xss
```

Resultados en `tools/benchmark_results/bench_<ts>.json`.

## Ediciones

DEMO = experiencia completa con límite de capacidad (trial de 24 h a
acceso total, sin recortes de funciones). PRO (~199–299 €/año, hipótesis)
y PREMIUM (~799–1.499 €/año, hipótesis) amplían vigencia y uso
empresarial. Precios pendientes de validación comercial.


## VulnLab local integrado (2.3.0)

Desde **HT Forge AI → VulnLab**, `GET /api/vulnlab-benchmark` levanta un servidor de fixtures temporal enlazado exclusivamente a `127.0.0.1` y puerto efímero. Ejecuta 20 casos sintéticos vulnerables/no vulnerables para estos adaptadores: `xss_reflection`, `sqli_error_signal`, `secret_exposure`, `security_headers` e `idor_access_control`. Mide por adaptador TP/FP/FN/TN, precisión, recall, especificidad y tasa de falsos positivos.

Este benchmark es reproducible y útil para probar la infraestructura y los adaptadores de prueba. **No representa aún el rendimiento de los plugins de producción**, ni debe publicitarse como una medición general de HT Forge. El siguiente paso de ingeniería es conectar cada adaptador a la interfaz real de su plugin y ampliar el corpus con variantes de contexto y controles negativos.

## Evidence Graph

`POST /api/evidence-graph` acepta una lista de hallazgos y produce nodos/relaciones de hallazgo, endpoint, tecnología y campos de evidencia. El grafo elimina query strings y no copia valores de request/response, cookies, tokens o secretos. Limita el procesamiento a 300 hallazgos por petición.

## Asistente de laboratorio controlado

El planificador es consultivo: propone controles y pasos de validación específicos, pero no ejecuta shell, payloads, extracción ni solicitudes externas. Las demostraciones de impacto deben utilizar identidades y registros sintéticos en un laboratorio bajo control del evaluador.
