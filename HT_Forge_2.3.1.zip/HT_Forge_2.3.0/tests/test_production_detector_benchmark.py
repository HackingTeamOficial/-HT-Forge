import unittest
from core.production_detector_benchmark import run_production_detector_benchmark

class ProductionDetectorBenchmarkTests(unittest.TestCase):
    def test_real_sqli_and_xss_plugins_on_local_fixtures(self):
        result = run_production_detector_benchmark()
        self.assertEqual(result['aggregate']['cases'], 4)
        self.assertIn('sqli', result['metrics'])
        self.assertIn('xss', result['metrics'])
        self.assertEqual(result['aggregate']['FP'], 0, result['cases'])
        self.assertEqual(result['aggregate']['FN'], 0, result['cases'])
        self.assertIn('plugins reales', result['scope'])

if __name__ == '__main__':
    unittest.main()
