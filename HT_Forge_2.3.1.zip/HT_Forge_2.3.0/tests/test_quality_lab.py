import unittest

from core.quality_lab import run_quality_lab
from core.confirm_policy import apply_policy
from core.validation_plan import build_validation_plan
from core.detector_benchmark import run_detector_benchmark


class QualityLabTests(unittest.TestCase):
    def test_quality_lab_has_checks_and_scope(self):
        result = run_quality_lab()
        self.assertGreaterEqual(result["total"], 5)
        self.assertEqual(result["total"], len(result["checks"]))
        self.assertIn("no target traffic", result["scope"])

    def test_marker_only_finding_is_not_confirmed(self):
        finding = {"type": "ssti_possible", "module": "ssti", "severity": "high",
                   "verification_state": "CONFIRMED", "evidence": {"marker": "test"}}
        self.assertNotEqual(apply_policy(finding)["verification_state"], "CONFIRMED")

    def test_reflection_only_xss_is_not_confirmed(self):
        finding = {"type": "xss", "module": "xss", "severity": "high",
                   "verification_state": "CONFIRMED", "evidence": {
                       "raw_reflection": "<script>", "reflection_context": "html_text",
                       "escaped": True, "baseline": "control", "matched_signature": "reflection"}}
        self.assertNotEqual(apply_policy(finding)["verification_state"], "CONFIRMED")


    def test_detector_benchmark_has_no_overconfirmation_violations(self):
        result = run_detector_benchmark()
        self.assertEqual(result["total"], len(result["cases"]))
        self.assertEqual(result["passed"], result["total"])
        self.assertEqual(result["metrics"]["overconfirmation_violations"], 0)
        self.assertIn("no target traffic", result["scope"])

    def test_validation_plan_covers_additional_families(self):
        samples = [
            ({"type": "oauth_misconfiguration"}, "jwt_oauth"),
            ({"type": "authentication_session"}, "auth"),
            ({"type": "mass_assignment_api"}, "api_access"),
            ({"type": "xxe"}, "xxe"),
            ({"type": "ssti"}, "ssti"),
            ({"type": "file_upload"}, "file_upload"),
        ]
        for finding, expected in samples:
            plan = build_validation_plan(finding)
            self.assertEqual(plan["plan_type"], expected)
            self.assertFalse(plan["network_requests_sent"])
            self.assertFalse(plan["shell_commands_executed"])

    def test_validation_plan_is_advisory_and_non_executing(self):
        plan = build_validation_plan({"type": "idor", "title": "BOLA candidate", "url": "https://lab.invalid/api/item/1"})
        self.assertTrue(plan["ok"])
        self.assertEqual(plan["execution"], "advisory_only")
        self.assertFalse(plan["network_requests_sent"])
        self.assertFalse(plan["shell_commands_executed"])
        self.assertGreaterEqual(len(plan["steps"]), 3)


if __name__ == "__main__":
    unittest.main()
