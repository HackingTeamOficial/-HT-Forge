import unittest
from core.vulnlab_benchmark import run_vulnlab_benchmark
from core.evidence_graph import build_evidence_graph

class VulnLabBenchmarkTests(unittest.TestCase):
    def test_local_fixture_benchmark_metrics(self):
        result = run_vulnlab_benchmark()
        self.assertEqual(result['aggregate']['cases'], 20)
        self.assertEqual(result['aggregate']['FP'], 0)
        self.assertEqual(result['aggregate']['FN'], 0)
        self.assertEqual(result['aggregate']['TP'], 10)
        self.assertEqual(result['aggregate']['TN'], 10)
        self.assertEqual(len(result['metrics']), 5)
        self.assertIn('no external traffic', result['scope'])

    def test_graph_redacts_query_and_raw_secrets(self):
        graph = build_evidence_graph([{
            'type':'test', 'title':'Test finding', 'url':'https://example.invalid/path?token=SECRET',
            'verification_state':'CANDIDATE', 'evidence':{'response_excerpt':'SECRET_RESPONSE', 'matched_signature':'test'}
        }])
        serialized = str(graph)
        self.assertNotIn('token=SECRET', serialized)
        self.assertNotIn('SECRET_RESPONSE', serialized)
        self.assertIn('supported_by', serialized)
        self.assertGreater(graph['node_count'], 1)

    def test_graph_correlates_sqli_xss_parameters_and_states_without_raw_payloads(self):
        graph = build_evidence_graph([
            {'type':'sqli', 'title':'SQL injection candidate', 'module':'sqli', 'url':'https://example.invalid/item?id=7&token=secret', 'parameter':'id', 'severity':'high', 'verification_state':'VERIFIED', 'confidence':0.91, 'evidence':{'technique':'boolean-differential','payload':'SECRET_PAYLOAD','response_excerpt':'SECRET_BODY','matched_signature':'SQLSTATE'}},
            {'type':'xss_reflected', 'title':'Reflected XSS', 'module':'xss', 'url':'https://example.invalid/search?q=secret', 'parameter':'q', 'severity':'medium', 'verification_state':'CANDIDATE', 'confidence':0.62, 'evidence':{'reflection_context':'html_text','marker':'SECRET_MARKER'}},
        ])
        kinds = {n['kind'] for n in graph['nodes']}
        self.assertTrue({'finding','endpoint','parameter','technique','evidence'} <= kinds)
        self.assertIn('tests_parameter', {e['relation'] for e in graph['edges']})
        self.assertEqual(graph['summary']['by_type'], {'sqli':1, 'xss_reflected':1})
        serialized = str(graph)
        for secret in ('SECRET_PAYLOAD','SECRET_BODY','SECRET_MARKER','token=secret','q=secret'):
            self.assertNotIn(secret, serialized)

if __name__ == '__main__': unittest.main()
