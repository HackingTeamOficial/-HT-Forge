"""HT Forge - Plugins (módulos de seguridad).

Los plugins se cargan dinámicamente por core/plugin.py vía importlib,
pero se declara como paquete para permitir `pip install -e .`.
"""

__version__ = "1.5"
