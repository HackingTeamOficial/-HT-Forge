#!/usr/bin/env python3
from typing import Dict
"""IDOR candidate detector for authorized assessments.

Looks for object-like parameters and compares authenticated/session responses
when the same request is replayed with nearby identifiers. It reports a
candidate, not a confirmed authorization bypass, unless the application
provides strong evidence of distinct resources.
"""
import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context
from core.payloads import IDOR_VALUES

ID_PARAM = re.compile(r'(^|_)(id|user|account|order|document|file|invoice|profile|customer|object)(_|$)', re.I)

def _set_param(url, param, value):
    p=urlsplit(url); pairs=parse_qsl(p.query, keep_blank_values=True); out=[]; replaced=False
    for k,v in pairs:
        if k==param and not replaced: out.append((k,str(value))); replaced=True
        else: out.append((k,v))
    if not replaced: out.append((param,str(value)))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))

def _fp(resp):
    text=(getattr(resp,'text','') or '')
    return (int(getattr(resp,'status_code',0) or 0), len(text), hashlib.sha256(text[:5000].encode('utf-8','ignore')).hexdigest())

def run(ctx: Context) -> Dict:
    findings=[]
    params=ctx.get('discovered_params', [])
    candidates=[p for p in params if ID_PARAM.search(str(p.get('param','')))]
    if not candidates:
        candidates=[{'url':ctx.target,'param':'id','method':'GET'}]
    ctx.log('info', f"Analizando IDOR en {ctx.target}")
    for info in candidates[:int(ctx.config.get('idor_max_params',12))]:
        if ctx.stopped: break
        if str(info.get('method','GET')).upper()!='GET':
            continue
        url=str(info.get('url',ctx.target)); param=str(info.get('param'))
        try:
            original=str(info.get('baseline_value','1'))
            base=ctx.req('GET',_set_param(url,param,original),timeout=10); bfp=_fp(base)
            variants=[]
            try: n=int(original)
            except ValueError: n=1
            for val in [n+1,n+2,n+10]:
                if ctx.stopped: break
                resp=ctx.req('GET',_set_param(url,param,val),timeout=10)
                fp=_fp(resp)
                if fp[0] in (200,206) and fp[2]!=bfp[2] and len(getattr(resp,'text','') or '')>0:
                    variants.append((val,fp))
            if len(variants)>=2:
                evidence={'url':url,'parameter':param,'method':'GET','baseline':{'id':original,'status':bfp[0],'length':bfp[1]},
                          'variants':[{'id':v,'status':fp[0],'length':fp[1]} for v,fp in variants],
                          'note':'Candidato IDOR: respuestas de objetos distintos son accesibles. Confirmar autorización con dos identidades/sesiones.'}
                findings.append({'type':'idor','severity':'medium','title':'Posible IDOR','detail':f"El parámetro '{param}' permite acceder a respuestas distintas para identificadores consecutivos",'confidence':0.68,'evidence':evidence,'url':url,'parameter':param})
                ctx.log('ok', f"Posible IDOR en {param}")
        except Exception as e:
            if not ctx.stopped: ctx.log('warn', f"Error probando IDOR en {param}: {e}")
    return {'findings':findings}

__version__='2.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
