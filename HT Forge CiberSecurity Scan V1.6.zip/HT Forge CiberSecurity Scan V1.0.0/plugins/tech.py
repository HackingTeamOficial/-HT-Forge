#!/usr/bin/env python3
"""plugins/tech.py - Fingerprinting de tecnologías"""

import re
from typing import Dict, List
from core.context import Context

TECH_SIGNATURES = {
    'nginx': [r'Server:\s*nginx', r'nginx/'],
    'apache': [r'Server:\s*Apache', r'Apache/'],
    'iis': [r'Server:\s*Microsoft-IIS', r'X-Powered-By:\s*ASP\.NET'],
    'php': [r'X-Powered-By:\s*PHP', r'\.php', r'PHPSESSID'],
    'python': [r'Server:\s*gunicorn', r'Server:\s*uvicorn', r'X-Powered-By:\s*Python', r'Django', r'Flask'],
    'nodejs': [r'X-Powered-By:\s*Express', r'X-Powered-By:\s*Next\.js', r'Server:\s*Node\.js'],
    'java': [r'Server:\s*Apache-Coyote', r'Server:\s*Jetty', r'Server:\s*Tomcat', r'X-Powered-By:\s*Servlet', r'JSESSIONID'],
    'ruby': [r'Server:\s*Passenger', r'X-Powered-By:\s*Rails', r'_session_id'],
    'go': [r'Server:\s*Go', r'X-Powered-By:\s*Go'],
    'wordpress': [r'wp-content', r'wp-includes', r'WordPress', r'/wp-json/', r'generator.*WordPress'],
    'drupal': [r'Drupal', r'drupal\.js', r'X-Drupal-Cache', r'X-Generator:\s*Drupal'],
    'joomla': [r'Joomla', r'option=com_', r'X-Content-Encoded-By:\s*Joomla'],
    'laravel': [r'laravel_session', r'X-Powered-By:\s*Laravel'],
    'symfony': [r'X-Powered-By:\s*Symfony', r'SYMFONY'],
    'django': [r'csrftoken', r'Django', r'X-Frame-Options:\s*DENY'],
    'flask': [r'session=.*\.' , r'X-Powered-By:\s*Flask'],
    'express': [r'X-Powered-By:\s*Express', r'connect\.sid'],
    'spring': [r'JSESSIONID', r'Spring', r'X-Powered-By:\s*Spring'],
    'aspnet': [r'__VIEWSTATE', r'ASP\.NET', r'X-AspNet-Version', r'X-AspNetMvc-Version'],
    'cloudflare': [r'Server:\s*cloudflare', r'__cfduid', r'cf-ray'],
    'aws': [r'Server:\s*AmazonS3', r'x-amz-', r'Server:\s*AWS'],
    'gcp': [r'Server:\s*Google Frontend', r'x-goog-'],
    'azure': [r'Server:\s*Microsoft-HTTPAPI', r'x-ms-'],
}


def run(ctx: Context) -> Dict:
    """Detecta tecnologías del target"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Fingerprinting tecnologías en {target}")
    
    try:
        resp = ctx.req('GET', target, timeout=15)
        headers = dict(resp.headers)
        content = resp.text
        combined = str(headers) + '\n' + content[:5000]
        
        detected = []
        
        for tech, patterns in TECH_SIGNATURES.items():
            for pattern in patterns:
                if re.search(pattern, combined, re.IGNORECASE):
                    detected.append(tech)
                    break
        
        if detected:
            # Deduplicar y ordenar
            detected = sorted(list(set(detected)))
            
            findings.append({
                'type': 'tech_fingerprint',
                'severity': 'info',
                'title': 'Tecnologías detectadas',
                'detail': f"Identificadas: {', '.join(detected)}",
                'evidence': {
                    'technologies': detected,
                    'headers': {k: v for k, v in headers.items() if k.lower() in ('server', 'x-powered-by', 'x-frame-options', 'x-content-type-options')}
                },
                'url': target
            })
            ctx.log('ok', f"Tecnologías: {', '.join(detected)}")
        else:
            ctx.log('info', "No se detectaron tecnologías específicas")
            
    except Exception as e:
        ctx.log('warn', f"Error en fingerprinting: {e}")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []