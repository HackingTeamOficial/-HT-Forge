#!/usr/bin/env python3
"""Reflected XSS detector for authorized assessments."""
import html
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode
from core.context import Context
from core.payloads import PayloadCollection

XSS_PAYLOADS=PayloadCollection.XSS

def _set_query_param(url,param,value):
    p=urlsplit(str(url)); pairs=parse_qsl(p.query,keep_blank_values=True); out=[]; replaced=False
    for k,v in pairs:
        if k==param and not replaced: out.append((k,value)); replaced=True
        elif k!=param: out.append((k,v))
    if not replaced: out.append((param,value))
    return urlunsplit((p.scheme,p.netloc,p.path,urlencode(out),p.fragment))

def _post(ctx,info,param,payload):
    data=dict(info.get('form_data') or {}); data[param]=payload
    return ctx.req('POST',str(info.get('url',ctx.target)),data=data,
                   headers={'Content-Type':'application/x-www-form-urlencoded'},timeout=float(ctx.config.get('xss_request_timeout',8)))

def run(ctx:Context):
    target=ctx.target; findings=[]
    params=(ctx.get('discovered_params',[]) or [
        {'url':target,'param':'q','method':'GET'},
        {'url':target,'param':'search','method':'GET'}])[:int(ctx.config.get('xss_max_params',50))]
    ctx.log('info',f'Iniciando detección XSS en {target}')
    for info in params:
        if ctx.stopped: break
        param=str(info.get('param') or ''); method=str(info.get('method','GET')).upper()
        if not param: continue
        for payload in XSS_PAYLOADS:
            if ctx.stopped: break
            try:
                if method=='POST':
                    resp=_post(ctx,info,param,payload); test_url=str(info.get('url',target))
                else:
                    test_url=_set_query_param(info.get('url',target),param,payload)
                    resp=ctx.req('GET',test_url,timeout=float(ctx.config.get('xss_request_timeout',8)))
                text=getattr(resp,'text','') or ''
                # Exact raw reflection is strong evidence for reflected XSS.
                # Also recognize entities only when the raw dangerous delimiter
                # remains unescaped; fully HTML-escaped output is not a finding.
                raw=payload in text
                if raw:
                    f={'type':'xss_reflected','severity':'high','title':'XSS Reflejado',
                       'detail':f'Payload reflejado sin escapar en el parámetro {param}.',
                       'evidence':{'url':test_url,'parameter':param,'payload':payload,
                                   'method':method,'response_status':getattr(resp,'status_code',None)},
                       'url':test_url,'parameter':param}
                    findings.append(f); ctx.log('ok',f'XSS reflejado en {param}'); break
            except (TimeoutError,ConnectionError,RuntimeError) as exc:
                ctx.log('warn',f'XSS {param}: {exc}')
            except Exception as exc:
                ctx.log('warn',f'XSS {param}: {exc}')
    return {'findings':findings}

__version__='1.2.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
