# HT Forge 1.6 — Cliente

Este paquete contiene únicamente el cliente HT Forge y su cliente de licencias.

## Licencia requerida

Una instalación comercial necesita una key emitida por el HT Forge Control Center.
Sin una licencia válida, el motor no inicia ningún escaneo, tanto desde CLI como desde la GUI.

El servidor de licencias se configura en `runtime/license_server.txt` o mediante `HTFORGE_LICENSE_URL`.
