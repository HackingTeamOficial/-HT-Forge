#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PORT="${HT_FORGE_PORT:-9090}"
HOST="${HT_FORGE_HOST:-127.0.0.1}"
echo "=== HT Forge 1.6 ==="
echo "Native Forge engines only (no external MCP services)"
exec python3 ui/server.py --host "$HOST" --port "$PORT"
