#!/usr/bin/env python3
"""HT Forge GUI + License Control Center server."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import sys
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.engine import get_engine
from core.profiles import PROFILES
from core.exporters import export_report
from core.db import Database
from core.session_store import save as save_auth_session, get as get_auth_session, masked as masked_auth_session

RUNTIME = ROOT / "runtime"
CONFIG_FILE = RUNTIME / "config.json"
INDEX = ROOT / "ui" / "index.html"
STATIC = ROOT / "ui" / "static"


def json_safe(v):
    if isinstance(v, dict): return {str(k): json_safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [json_safe(x) for x in v]
    if hasattr(v, "isoformat"): return v.isoformat()
    return v


def session_dict(s):
    if isinstance(s, dict): return json_safe(s)
    return json_safe({"id": s.id, "target": s.target, "profile": s.profile, "started_at": s.started_at, "status": s.status, "findings": s.findings, "modules_run": s.modules_run, "errors": s.errors, "metadata": s.metadata})


class GUIHandler(BaseHTTPRequestHandler):
    server_version = "HTForge/1.6"

    def log_message(self, fmt, *args):
        return

    def _send(self, status, data, content_type="application/json"):
        body = data if isinstance(data, bytes) else (json.dumps(json_safe(data), ensure_ascii=False).encode("utf-8") if content_type == "application/json" else str(data).encode("utf-8"))
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers(); self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0")); raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_OPTIONS(self):
        self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization"); self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS"); self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"): return self._file(INDEX, "text/html; charset=utf-8")
        if p.startswith("/static/"): return self._file(STATIC / Path(p[len("/static/"):]).name)
        if p == "/api/status": return self._send(200, {"ok": True, "version": "1.6", "license_client": True})
        if p == "/api/sessions": return self._send(200, self._sessions())
        if p.startswith("/api/sessions/"):
            return self._session(p.rsplit("/",1)[-1])
        if p == "/api/license/status": return self._license_get()
        self._send(404, {"error":"Ruta no encontrada"})

    def do_POST(self):
        p = urlparse(self.path).path; data = self._body()
        try:
            if p == "/api/license/activate":
                from core import license_manager as lm
                result = lm._request("/api/license/activate", {
                    "key": data.get("key", ""),
                    "device_id": data.get("device_id") or lm.get_device_id(),
                    "platform": data.get("platform", ""),
                    "version": data.get("version", "1.6"),
                    "device_name": data.get("device_name", "HT Forge"),
                })
                if result.get("ok"):
                    result["key"] = data.get("key", "")
                    result["checked_at"] = time.time()
                    lm._save(result)
                return self._send(200, result)
            if p == "/api/license/heartbeat":
                from core import license_manager as lm
                return self._send(200, lm._request("/api/license/heartbeat", {
                    "key": data.get("key", "") or lm.license_key(),
                    "device_id": data.get("device_id") or lm.get_device_id(),
                    "platform": data.get("platform", ""),
                    "version": data.get("version", "1.6"),
                    "device_name": data.get("device_name", "HT Forge"),
                }))
            if p == "/api/scan": return self._start_scan(data)
            if p == "/api/scan/stop": return self._stop_scan(data)
            if p == "/api/export": return self._export(data)
            if p == "/api/auth/session":
                save_auth_session(data.get("target",""),data.get("session_id",""),data.get("token",""),data.get("session_cookie_name","sessionid")); return self._send(200,{"ok":True,"session":masked_auth_session(data.get("target",""))})
            self._send(404,{"error":"Ruta no encontrada"})
        except Exception as e:
            self._send(400,{"error":str(e)})

    def _file(self, path, content_type=None):
        try:
            body=path.read_bytes(); ct=content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"; return self._send(200,body,ct)
        except FileNotFoundError: return self._send(404,{"error":"Archivo no encontrado"})

    def _sessions(self):
        out=[]
        for r in self.server.session_db.list_sessions(100):
            s=dict(r); s["findings"]=s.get("findings_count",0); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); out.append(s)
        for sid,s in self.server.sessions.items(): out.append(session_dict(s))
        seen={}; [seen.__setitem__(x["id"],x) for x in out]; return list(seen.values())

    def _session(self,sid):
        if sid in self.server.sessions: return self._send(200,session_dict(self.server.sessions[sid]))
        r=self.server.session_db.get_session(sid)
        if not r:return self._send(404,{"error":"Sesión no encontrada"})
        s=dict(r); s["findings"]=self.server.session_db.get_findings(sid); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); return self._send(200,s)

    def _start_scan(self,data):
        target=data.get("target","").strip(); profile=data.get("profile","full")
        if not target:return self._send(400,{"error":"Target requerido"})
        sid=str(uuid.uuid4())[:8]; config=data.get("config") or {}; config["session_id"]=sid; config["modules"]=data.get("modules") or []
        engine=get_engine(config=config); self.server.engines[sid]=engine
        def worker():
            s=engine.scan(target,profile,options=config); self.server.sessions[sid]=s
        t=threading.Thread(target=worker,daemon=True); self.server.threads[sid]=t; t.start()
        # session object is created immediately by Engine; expose it once available
        for _ in range(50):
            if engine.session: self.server.sessions[sid]=engine.session; break
            time.sleep(.01)
        return self._send(202,{"session_id":sid})

    def _stop_scan(self,data):
        sid=data.get("session_id"); e=self.server.engines.get(sid)
        if not e:return self._send(404,{"error":"Escaneo no encontrado"})
        e.stop(); return self._send(200,{"ok":True})

    def _export(self,data):
        sid=data.get("session_id"); fmt=data.get("format","json"); e=self.server.engines.get(sid); s=e.session if e and e.session else None
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            return self._send(400,{"error":"La exportación interactiva requiere sesión cargada"})
        return self._send(200,{"output":export_report(s,fmt)})

    def _license_get(self):
        try:
            from core.license_manager import sync_license, get_device_id
            d = sync_license()
            d["device_id"] = get_device_id()
        except Exception as exc:
            d = {"valid": False, "status": "OFFLINE", "plan": "FREE", "features": {}, "error": str(exc)}
        return self._send(200,d)


def run_server(host="127.0.0.1",port=9090,open_browser=True):
    server=ThreadingHTTPServer((host,port),GUIHandler); server.sessions={}; server.engines={}; server.threads={}; server._lock=threading.RLock(); server.session_db=Database(os.getenv("HTFORGE_DB",str(ROOT/"runtime"/"htforge.db")))
    url=f"http://{host}:{port}"; print(f"🌐 HT Forge GUI corriendo en {url}")
    if open_browser: threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: server.shutdown()


if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--host",default="127.0.0.1"); ap.add_argument("--port",type=int,default=9090); ap.add_argument("--no-browser",action="store_true"); a=ap.parse_args(); run_server(a.host,a.port,not a.no_browser)
