#!/usr/bin/env python3
"""HT Forge client-side license manager.

The client keeps a persistent device id and synchronizes license state with the
Control Center. Revocation/suspension is therefore reflected on the next
heartbeat instead of being a purely local UI toggle.
"""
from __future__ import annotations

import json
import os
import secrets
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / "runtime"
RUNTIME.mkdir(parents=True, exist_ok=True)
LICENSE_FILE = RUNTIME / ".ht_license.json"
DEVICE_FILE = RUNTIME / "device_id"
LICENSE_SERVER_URL = os.getenv("HTFORGE_LICENSE_URL", "").strip()
OFFLINE_GRACE = int(os.getenv("HTFORGE_LICENSE_OFFLINE_GRACE", "300"))
STATUSES = {"ACTIVE", "PAST_DUE", "SUSPENDED", "EXPIRED", "REVOKED"}


def get_device_id() -> str:
    try:
        if DEVICE_FILE.exists():
            value = DEVICE_FILE.read_text(encoding="utf-8").strip()
            if value:
                return value
        value = secrets.token_hex(16)
        DEVICE_FILE.write_text(value, encoding="utf-8")
        try: os.chmod(DEVICE_FILE, 0o600)
        except OSError: pass
        return value
    except Exception:
        return secrets.token_hex(16)


def _load() -> dict:
    try: return json.loads(LICENSE_FILE.read_text(encoding="utf-8")) if LICENSE_FILE.exists() else {}
    except Exception: return {}


def _save(data: dict):
    tmp = LICENSE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    try: os.chmod(tmp, 0o600)
    except OSError: pass
    tmp.replace(LICENSE_FILE)
    try: os.chmod(LICENSE_FILE, 0o600)
    except OSError: pass


def license_key() -> str:
    return os.getenv("HT_LICENSE_KEY", "").strip() or _load().get("key", "")


def _server_url() -> str:
    env = os.getenv("HTFORGE_LICENSE_URL", "").strip()
    if env:
        return env.rstrip("/")
    cfg = RUNTIME / "license_server.txt"
    try:
        value = cfg.read_text(encoding="utf-8").strip()
        if value:
            return value.rstrip("/")
    except OSError:
        pass
    return "http://127.0.0.1:9191"


def _request(path: str, payload: dict | None = None, timeout: int = 5) -> dict:
    base = _server_url()
    if not base:
        raise RuntimeError("Servidor de licencias no configurado")
    url = base + path
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST" if data else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def sync_license() -> dict:
    key = license_key()
    cached = _load()
    if not key:
        return {"valid": False, "status": "REVOKED", "plan": "FREE", "features": {}}
    payload = {"key": key, "device_id": get_device_id(), "platform": os.name, "version": "1.6", "device_name": os.getenv("HOSTNAME", "HT Forge")}
    try:
        result = _request("/api/license/heartbeat", payload, timeout=5)
        result["checked_at"] = time.time()
        result["key"] = key
        _save(result)
        return result
    except Exception as exc:
        age = time.time() - float(cached.get("checked_at", 0) or 0)
        cached["offline"] = True
        cached["offline_error"] = str(exc)
        if cached.get("status") in {"SUSPENDED", "REVOKED", "EXPIRED", "PAST_DUE"}:
            cached["valid"] = False
        elif age > OFFLINE_GRACE:
            cached["valid"] = False
            cached["status"] = "OFFLINE"
        return cached if cached else {"valid": False, "status": "OFFLINE"}


def activate(key: str) -> dict:
    key = key.strip()
    if not key: return {"ok": False, "message": "Introduce una licencia"}
    result = _request("/api/license/activate", {"key": key, "device_id": get_device_id(), "platform": os.name, "version": "1.6", "device_name": os.getenv("HOSTNAME", "HT Forge")})
    if result.get("ok"):
        result["key"] = key
        result["checked_at"] = time.time()
        _save(result)
    return result


def decide_license() -> tuple[str, str, str | None]:
    d = sync_license()
    return d.get("status", "REVOKED"), d.get("plan", "FREE"), d.get("expires_at")


def can_run_sqlx() -> bool:
    d = sync_license()
    return bool(d.get("valid") and d.get("features", {}).get("sqli", False))


def can_run_crawler() -> bool:
    d = sync_license()
    return bool(d.get("valid") and d.get("features", {}).get("crawler", False))


def can_run_feature(feature: str) -> bool:
    """Return whether the current server-authorized license grants a feature."""
    d = sync_license()
    return bool(d.get("valid") and d.get("features", {}).get(feature, False))


def get_license_message() -> str:
    status, plan, expires = decide_license()
    if status == "ACTIVE": return f"Licencia {plan} — Activa" + (f" — expira {expires[:10]}" if expires else "")
    if status == "PAST_DUE": return "Pago atrasado. Renueva para continuar."
    if status == "SUSPENDED": return "Licencia suspendida por el administrador."
    if status == "EXPIRED": return "Licencia expirada."
    if status == "REVOKED": return "Licencia revocada."
    return "Servidor de licencias no disponible."


if __name__ == "__main__":
    print(json.dumps(sync_license(), indent=2, ensure_ascii=False))
