#!/usr/bin/env python3
"""core/exporters.py - Exportadores de reportes (JSON, HTML, PDF)"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any
from pathlib import Path

try:
    from weasyprint import HTML
    WEASYPRINT_AVAILABLE = True
except ImportError:
    WEASYPRINT_AVAILABLE = False

try:
    from fpdf import FPDF
    FPDF_AVAILABLE = True
except ImportError:
    FPDF_AVAILABLE = False

from .models import ScanSession


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HT Forge - Reporte de Seguridad</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: #f5f5f5; color: #333; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #2c3e50; margin: 0; font-size: 28px; }
        .header .subtitle { color: #7f8c8d; margin-top: 5px; }
        .meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .meta-card { background: #ecf0f1; padding: 15px; border-radius: 6px; }
        .meta-card .label { font-size: 12px; color: #7f8c8d; text-transform: uppercase; }
        .meta-card .value { font-size: 16px; font-weight: 600; color: #2c3e50; }
        .summary { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 30px; }
        .severity-box { text-align: center; padding: 15px; border-radius: 6px; color: white; }
        .severity-box.critical { background: #c0392b; }
        .severity-box.high { background: #e67e22; }
        .severity-box.medium { background: #f39c12; }
        .severity-box.low { background: #27ae60; }
        .severity-box.info { background: #3498db; }
        .severity-box .count { font-size: 24px; font-weight: bold; }
        .severity-box .label { font-size: 11px; text-transform: uppercase; }
        .finding { border: 1px solid #ecf0f1; border-radius: 6px; margin-bottom: 20px; overflow: hidden; }
        .finding-header { padding: 15px; display: flex; justify-content: space-between; align-items: center; }
        .finding-title { font-weight: 600; font-size: 16px; }
        .severity-badge { padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .severity-badge.critical { background: #c0392b; color: white; }
        .severity-badge.high { background: #e67e22; color: white; }
        .severity-badge.medium { background: #f39c12; color: white; }
        .severity-badge.low { background: #27ae60; color: white; }
        .severity-badge.info { background: #3498db; color: white; }
        .finding-body { padding: 0 15px 15px; }
        .finding-row { display: grid; grid-template-columns: 120px 1fr; gap: 10px; margin-bottom: 8px; font-size: 14px; }
        .finding-row .label { color: #7f8c8d; font-weight: 500; }
        .evidence { background: #f8f9fa; border-left: 3px solid #3498db; padding: 10px; margin-top: 10px; font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 200px; overflow: auto; }
        .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1; color: #7f8c8d; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛡️ HT Forge - Reporte de Seguridad</h1>
            <div class="subtitle">{{ session.target }} • {{ session.profile }} • {{ session.started_at }}</div>
        </div>
        
        <div class="meta">
            <div class="meta-card">
                <div class="label">ID de Sesión</div>
                <div class="value">{{ session.id }}</div>
            </div>
            <div class="meta-card">
                <div class="label">Objetivo</div>
                <div class="value">{{ session.target }}</div>
            </div>
            <div class="meta-card">
                <div class="label">Perfil</div>
                <div class="value">{{ session.profile }}</div>
            </div>
            <div class="meta-card">
                <div class="label">Estado</div>
                <div class="value">{{ session.status }}</div>
            </div>
            <div class="meta-card">
                <div class="label">Inicio</div>
                <div class="value">{{ session.started_at }}</div>
            </div>
            <div class="meta-card">
                <div class="label">Fin</div>
                <div class="value">{{ session.metadata.get('ended_at', 'N/A') }}</div>
            </div>
        </div>
        
        <div class="summary">
            <div class="severity-box critical">
                <div class="count">{{ counts.critical }}</div>
                <div class="label">Crítico</div>
            </div>
            <div class="severity-box high">
                <div class="count">{{ counts.high }}</div>
                <div class="label">Alto</div>
            </div>
            <div class="severity-box medium">
                <div class="count">{{ counts.medium }}</div>
                <div class="label">Medio</div>
            </div>
            <div class="severity-box low">
                <div class="count">{{ counts.low }}</div>
                <div class="label">Bajo</div>
            </div>
            <div class="severity-box info">
                <div class="count">{{ counts.info }}</div>
                <div class="label">Info</div>
            </div>
        </div>
        
        {% if findings %}
        <h2>📋 Hallazgos Detectados</h2>
        {% for finding in findings %}
        <div class="finding">
            <div class="finding-header" style="background: {{ severity_color(finding.severity) }}22;">
                <span class="finding-title">{{ finding.title }}</span>
                <span class="severity-badge {{ finding.severity }}">{{ finding.severity }}</span>
            </div>
            <div class="finding-body">
                <div class="finding-row">
                    <span class="label">Módulo</span>
                    <span>{{ finding.module }}</span>
                </div>
                <div class="finding-row">
                    <span class="label">Fase</span>
                    <span>{{ finding.phase }}</span>
                </div>
                <div class="finding-row">
                    <span class="label">URL</span>
                    <span>{{ finding.url }}</span>
                </div>
                <div class="finding-row">
                    <span class="label">Score</span>
                    <span>{{ finding.scored }}/10 ({{ risk_level(finding.scored) }})</span>
                </div>
                <div class="finding-row">
                    <span class="label">Detalle</span>
                    <span>{{ finding.detail }}</span>
                </div>
                {% if finding.evidence %}
                <div class="evidence">{{ finding.evidence | tojson(indent=2) }}</div>
                {% endif %}
            </div>
        </div>
        {% endfor %}
        {% else %}
        <div style="text-align: center; padding: 40px; color: #7f8c8d;">
            <h3>✅ No se detectaron vulnerabilidades</h3>
            <p>El objetivo parece seguro frente a los módulos ejecutados.</p>
        </div>
        {% endif %}
        
        <div class="footer">
            Generado por HT Forge v1.2 • {{ generated_at }}<br>
            <em>Uso autorizado únicamente • Reporte confidencial</em>
        </div>
    </div>
</body>
</html>
"""


def export_report(session: ScanSession, format: str = 'json', output_dir: str = 'reports') -> str:
    """Exporta reporte en formato solicitado"""
    format = format.lower()
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if format == 'json':
        path = out_dir / f'htforge_report_{session.id}.json'
        path.write_text(_export_json(session), encoding='utf-8')
        return str(path)
    elif format == 'html':
        path = out_dir / f'htforge_report_{session.id}.html'
        path.write_text(_export_html(session), encoding='utf-8')
        return str(path)
    elif format == 'pdf':
        return _export_pdf(session, str(out_dir))
    else:
        raise ValueError(f"Formato no soportado: {format}")


def _export_json(session: ScanSession) -> str:
    """Exporta a JSON"""
    data = {
        'session': {
            'id': session.id,
            'target': session.target,
            'profile': session.profile,
            'started_at': session.started_at.isoformat(),
            'ended_at': session.metadata.get('ended_at'),
            'status': session.status,
            'modules_run': session.modules_run,
            'errors': session.errors,
            'metadata': session.metadata,
        },
        'findings': session.findings,
        'summary': _count_severities(session.findings),
        'generated_at': datetime.now().isoformat()
    }
    return json.dumps(data, indent=2, ensure_ascii=False)


def _export_html(session: ScanSession) -> str:
    """Exporta a HTML usando template Jinja2"""
    try:
        from jinja2 import Template
    except ImportError:
        return _export_json(session)
    
    counts = _count_severities(session.findings)
    
    def severity_color(sev):
        colors = {'critical': '#c0392b', 'high': '#e67e22', 'medium': '#f39c12', 'low': '#27ae60', 'info': '#3498db'}
        return colors.get(sev.lower(), '#3498db')
    
    def risk_level(score):
        if score >= 9: return 'CRITICAL'
        elif score >= 7: return 'HIGH'
        elif score >= 5: return 'MEDIUM'
        elif score >= 3: return 'LOW'
        return 'INFO'
    
    template = Template(HTML_TEMPLATE)
    return template.render(
        session=session,
        findings=session.findings,
        counts=counts,
        severity_color=severity_color,
        risk_level=risk_level,
        generated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )


def _export_pdf(session: ScanSession, output_dir: str = 'reports') -> str:
    """Exporta a PDF"""
    # Primero generar HTML
    html_content = _export_html(session)
    
    if WEASYPRINT_AVAILABLE:
        output_path = str(Path(output_dir) / f"htforge_report_{session.id}.pdf")
        HTML(string=html_content).write_pdf(output_path)
        return output_path
    elif FPDF_AVAILABLE:
        return _export_pdf_fpdf(session, output_dir)
    else:
        # Fallback: guardar HTML
        output_path = str(Path(output_dir) / f"htforge_report_{session.id}.html")
        with open(output_path, 'w') as f:
            f.write(html_content)
        return output_path


def _export_pdf_fpdf(session: ScanSession, output_dir: str = 'reports') -> str:
    """Exporta a PDF usando fpdf2"""
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 20)
    pdf.cell(0, 15, 'HT Forge - Reporte de Seguridad', ln=True, align='C')
    pdf.set_font('Helvetica', '', 10)
    pdf.cell(0, 8, f"Target: {session.target} | Perfil: {session.profile} | Sesion: {session.id}", ln=True, align='C')
    pdf.ln(10)
    
    counts = _count_severities(session.findings)
    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 8, 'Resumen de Hallazgos', ln=True)
    pdf.set_font('Helvetica', '', 10)
    
    for sev, count in counts.items():
        pdf.cell(0, 6, f"  {sev.capitalize()}: {count}", ln=True)
    
    pdf.ln(5)
    
    for finding in session.findings:
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.set_font('Helvetica', 'B', 11)
        pdf.cell(0, 7, finding.get('title', 'Sin título'), ln=True)
        pdf.set_font('Helvetica', '', 9)
        pdf.cell(0, 5, f"  Modulo: {finding.get('module')} | Severidad: {finding.get('severity')} | Score: {finding.get('scored')}/10", ln=True)
        pdf.cell(0, 5, f"  URL: {finding.get('url', 'N/A')}", ln=True)
        detail = finding.get('detail', '')[:200]
        if detail:
            pdf.multi_cell(0, 5, f"  {detail}")
        pdf.ln(3)
    
    output_path = str(Path(output_dir) / f"htforge_report_{session.id}.pdf")
    pdf.output(output_path)
    return output_path


def export_all_reports(session: ScanSession, output_dir: str = 'reports') -> Dict[str, str]:
    """Genera automáticamente JSON, HTML y PDF en el directorio de reportes."""
    results = {}
    for fmt in ('json', 'html', 'pdf'):
        try:
            results[fmt] = export_report(session, fmt, output_dir=output_dir)
        except Exception as exc:
            results[fmt] = f'ERROR: {exc}'
    return results


def _count_severities(findings: List[Dict]) -> Dict[str, int]:
    counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    for f in findings:
        sev = f.get('severity', 'info').lower()
        if sev in counts:
            counts[sev] += 1
    return counts