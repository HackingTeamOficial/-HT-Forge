#!/usr/bin/env python3
"""core/plugin.py - Sistema de plugins de HT Forge"""

import os
import sys
import importlib.util
from pathlib import Path
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass


@dataclass
class Plugin:
    """Representa un plugin cargado"""
    name: str
    module: Any
    run_func: Callable
    metadata: Dict = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {
                'name': self.name,
                'version': getattr(self.module, '__version__', '1.0.0'),
                'description': getattr(self.module, '__doc__', ''),
                'author': getattr(self.module, '__author__', ''),
                'phase': getattr(self.module, 'PHASE', 'attack'),
                'requires': getattr(self.module, 'REQUIRES', []),
            }


class PluginManager:
    """Gestor de plugins - Carga, registra y ejecuta módulos"""
    
    def __init__(self, plugins_dir: Optional[str] = None):
        self.plugins: Dict[str, Plugin] = {}
        self.plugins_dir = plugins_dir or os.path.join(os.path.dirname(__file__), '..', 'plugins')
        self._load_all()
    
    def _load_all(self):
        """Carga todos los plugins del directorio"""
        plugins_path = Path(self.plugins_dir)
        if not plugins_path.exists():
            return
        
        for py_file in plugins_path.glob('*.py'):
            if py_file.name.startswith('_') or py_file.name == '__init__.py':
                continue
            
            self._load_plugin(py_file)
    
    def _load_plugin(self, py_file: Path):
        """Carga un plugin individual"""
        name = py_file.stem
        try:
            spec = importlib.util.spec_from_file_location(name, py_file)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            
            # Buscar función run
            run_func = getattr(module, 'run', None) or getattr(module, 'main', None)
            if not run_func:
                return
            
            plugin = Plugin(name=name, module=module, run_func=run_func)
            self.plugins[name] = plugin
            
        except Exception as e:
            print(f"[WARN] No se pudo cargar plugin {name}: {e}")
    
    def register(self, name: str, run_func: Callable, metadata: Optional[Dict] = None):
        """Registra un plugin manualmente (para módulos internos)"""
        class DummyModule:
            pass
        module = DummyModule()
        if metadata:
            for k, v in metadata.items():
                setattr(module, k, v)
        
        plugin = Plugin(name=name, module=module, run_func=run_func, metadata=metadata or {})
        self.plugins[name] = plugin
    
    def get(self, name: str) -> Optional[Plugin]:
        return self.plugins.get(name)
    
    def get_available(self) -> List[str]:
        return list(self.plugins.keys())
    
    # Alias para compatibilidad
    list_plugins = get_available
    
    def load_plugin(self, name: str) -> Any:
        """Carga y retorna el módulo de un plugin por nombre (para tests)"""
        plugin = self.get(name)
        if plugin:
            return plugin.module
        return None
    
    def run(self, name: str, ctx: 'Context') -> Any:
        """Ejecuta un plugin por nombre"""
        plugin = self.get(name)
        if plugin:
            return plugin.run_func(ctx)
        return None
    
    def list_all(self) -> Dict:
        return {name: p.metadata for name, p in self.plugins.items()}


# Alias para compatibilidad con tests
PluginLoader = PluginManager