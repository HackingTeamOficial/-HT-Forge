#!/usr/bin/env python3
"""core/http.py - Cliente HTTP de HT Forge"""

from typing import Dict, Any, Optional
import time
import threading

# Lazy imports - only imported when actually needed
_requests = None
_HTTPAdapter = None
_Retry = None
_requests_exceptions = None

def _import_requests():
    global _requests, _HTTPAdapter, _Retry, _requests_exceptions
    if _requests is None:
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        _requests = requests
        _HTTPAdapter = HTTPAdapter
        _Retry = Retry
        _requests_exceptions = requests.exceptions
    return _requests, _HTTPAdapter, _Retry, _requests_exceptions


class HTTPClient:
    """Cliente HTTP con reintentos, timeouts y session pooling"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._session = None
        self._initialized = False
        self._cancel_event = threading.Event()
        
        # Timeouts
        self.timeout = self.config.get('timeout', (10, 30))
        self.verify_ssl = self.config.get('verify_ssl', False)
        self.allow_redirects = self.config.get('allow_redirects', True)
        self.auth = self.config.get('auth', {}) or {}
    
    def _ensure_session(self):
        """Inicializa la session de forma lazy"""
        if self._initialized:
            return
        requests, HTTPAdapter, Retry, _ = _import_requests()
        self._session = requests.Session()
        
        # Silenciar avisos de TLS cuando verify_ssl=False (por diseño en pentest autorizado)
        if not self.verify_ssl:
            try:
                import urllib3
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            except Exception:
                pass
        
        # Configurar reintentos
        retry_strategy = Retry(
            total=self.config.get('retries', 0),
            backoff_factor=self.config.get('backoff', 0.0),
            status_forcelist=[429, 502, 503, 504],
            raise_on_status=False,
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST", "PUT", "DELETE"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        
        # Headers por defecto
        self._session.headers.update({
            'User-Agent': self.config.get('user_agent', 'HT-Forge/1.5 (+https://github.com/htforge)'),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        })
        
        self._initialized = True
    
    def request(self, method: str, url: str, **kwargs) -> Any:
        """Realiza petición HTTP"""
        requests, _, _, requests_exceptions = _import_requests()
        self._ensure_session()
        
        # Merge timeouts
        timeout = kwargs.pop('timeout', self.timeout)
        verify = kwargs.pop('verify', self.verify_ssl)
        allow_redirects = kwargs.pop('allow_redirects', self.allow_redirects)
        
        # Headers extra
        headers = kwargs.pop('headers', {})
        merged_headers = {**self._session.headers, **headers}
        # Autenticación persistente por sesión: nunca se registra en logs/findings.
        session_id = str(self.auth.get('session_id', '') or '').strip()
        token = str(self.auth.get('token', '') or '').strip()
        if session_id and 'Cookie' not in merged_headers:
            cookie_name = self.auth.get('session_cookie_name', 'sessionid')
            merged_headers['Cookie'] = f'{cookie_name}={session_id}'
        if token and 'Authorization' not in merged_headers:
            merged_headers['Authorization'] = f'Bearer {token}'
        if self._cancel_event.is_set():
            raise RuntimeError("HTTP request cancelled")
        try:
            resp = self._session.request(
                method=method.upper(),
                url=url,
                timeout=timeout,
                verify=verify,
                allow_redirects=allow_redirects,
                headers=merged_headers,
                **kwargs
            )
            return resp
        except requests_exceptions.Timeout:
            raise TimeoutError(f"Timeout en {method} {url}")
        except requests_exceptions.ConnectionError:
            raise ConnectionError(f"Error de conexión a {url}")
        except Exception as e:
            raise RuntimeError(f"Error HTTP: {e}")
    
    def get(self, url: str, **kwargs) -> Any:
        return self.request('GET', url, **kwargs)
    
    def post(self, url: str, **kwargs) -> Any:
        return self.request('POST', url, **kwargs)
    
    def head(self, url: str, **kwargs) -> Any:
        return self.request('HEAD', url, **kwargs)
    
    def cancel(self):
        """Cancela peticiones en curso y futuras de esta sesión."""
        self._cancel_event.set()
        if self._session:
            try:
                self._session.close()
            except Exception:
                pass

    def reset_cancel(self):
        # A cancelled scan must not poison the next scan. Recreate the requests
        # Session so sockets/connection pools from the cancelled run cannot be reused.
        self._cancel_event.clear()
        if self._session is not None:
            try:
                self._session.close()
            except Exception:
                pass
        self._session = None
        self._initialized = False

    def close(self):
        if self._session:
            self._session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()