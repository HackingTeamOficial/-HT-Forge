#!/usr/bin/env python3
"""core/db.py - Base de datos SQLite para HT Forge"""

from __future__ import annotations

import sqlite3
import json
import os
import threading
from pathlib import Path
from typing import List, Dict, Optional, Any, TYPE_CHECKING
from datetime import datetime

if TYPE_CHECKING:
    # Evita acoplamiento circular: db tipa ScanSession sin importar engine en runtime
    from .models import ScanSession


class Database:
    """Gestor de base de datos SQLite"""
    
    def __init__(self, db_path: str = 'runtime/htforge.db'):
        # Leer de variable de entorno si no se pasa explícitamente
        self.db_path = os.environ.get('HTFORGE_DB', db_path)
        # Lock para acceso concurrente desde varios hilos (evita 'database is locked')
        self._lock = threading.RLock()
        # Asegurar que el directorio de la DB existe
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
    
    def _init_db(self):
        """Inicializa esquema"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    target TEXT NOT NULL,
                    profile TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    ended_at TEXT,
                    status TEXT NOT NULL,
                    findings_count INTEGER DEFAULT 0,
                    modules_run TEXT,
                    errors TEXT,
                    metadata TEXT
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS findings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    module TEXT,
                    phase TEXT,
                    severity TEXT,
                    title TEXT,
                    detail TEXT,
                    evidence TEXT,
                    url TEXT,
                    scored REAL,
                    timestamp TEXT,
                    type TEXT,
                    FOREIGN KEY (session_id) REFERENCES sessions(id)
                )
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_findings_session 
                ON findings(session_id)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_findings_severity 
                ON findings(severity)
            ''')
            conn.commit()
    
    def create_session(self, session: ScanSession):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    INSERT INTO sessions (id, target, profile, started_at, status, modules_run, errors, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    session.id, session.target, session.profile,
                    session.started_at.isoformat(), session.status,
                    json.dumps(session.modules_run), json.dumps(session.errors),
                    json.dumps(session.metadata)
                ))
                conn.commit()
    
    def update_session(self, session: ScanSession):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    UPDATE sessions SET 
                        ended_at = ?, status = ?, findings_count = ?,
                        modules_run = ?, errors = ?, metadata = ?
                    WHERE id = ?
                ''', (
                    session.metadata.get('ended_at'),
                    session.status,
                    len(session.findings),
                    json.dumps(session.modules_run),
                    json.dumps(session.errors),
                    json.dumps(session.metadata),
                    session.id
                ))
                conn.commit()
    
    def save_findings(self, session_id: str, findings: List[Dict]):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                for f in findings:
                    conn.execute('''
                        INSERT INTO findings (session_id, module, phase, severity, title, detail, evidence, url, scored, timestamp, type)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        session_id, f.get('module'), f.get('phase'),
                        f.get('severity', 'info'), f.get('title', ''),
                        f.get('detail', ''), json.dumps(f.get('evidence', {})),
                        f.get('url', ''), f.get('scored', 0.0),
                        f.get('timestamp', datetime.now().isoformat()),
                        f.get('type', '')
                    ))
                conn.commit()
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute('SELECT * FROM sessions WHERE id = ?', (session_id,))
            row = cur.fetchone()
            if row:
                return dict(row)
            return None
    
    def get_findings(self, session_id: str) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute('SELECT * FROM findings WHERE session_id = ? ORDER BY scored DESC', (session_id,))
            return [dict(row) for row in cur.fetchall()]
    
    def list_sessions(self, limit: int = 50) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute('SELECT * FROM sessions ORDER BY started_at DESC LIMIT ?', (limit,))
            return [dict(row) for row in cur.fetchall()]
    
    def delete_session(self, session_id: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('DELETE FROM findings WHERE session_id = ?', (session_id,))
            conn.execute('DELETE FROM sessions WHERE id = ?', (session_id,))
            conn.commit()