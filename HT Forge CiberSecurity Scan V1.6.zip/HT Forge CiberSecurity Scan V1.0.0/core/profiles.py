#!/usr/bin/env python3
"""core/profiles.py - Perfiles de escaneo de HT Forge"""

# Plugins disponibles (deben coincidir con plugins/PLUGIN_NAME)
ALL_ATTACK = [
    "sqli", "idor", "xss", "lfi", "traversal", "rce", "rfi", "xxe",
    "cors", "jwt", "graphql", "csrf", "wordpress_enum",
    "sqli_confirm", "osint_urls", "ai_analysis",
    "wpscan", "cmsmap",
    "wapiti", "nikto", "feroxbuster"
]

# Forge 1.5 usa únicamente módulos nativos del proyecto.
RECON = ["tech", "crawler", "archivos", "jsecret", "recon_cbh"]

PROFILES = {
    "recon": {
        "desc": "Solo reconocimiento (sin ataque)",
        "mode": "active",
        "recon": RECON,
        "attack": [],
        "discovery_deep": False,
    },
    "passive": {
        "desc": "Sin enviar payloads (solo observar respuestas)",
        "mode": "passive",
        "recon": ["headers", "tech", "crawler", "archivos"],
        "attack": [],
        "discovery_deep": False,
    },
    "full": {
        "desc": "Todos los módulos (recon + ataque)",
        "mode": "active",
        "recon": RECON,
        "attack": ALL_ATTACK,
        "discovery_deep": True,
        "metasploit": True,
    },
    "bugbounty": {
        "desc": "Foco bug bounty: superficie amplia con motores nativos",
        "mode": "active",
        "recon": RECON,
        "attack": ALL_ATTACK,
        "discovery_deep": True,
    },
    "api": {
        "desc": "Solo superficie de APIs",
        "mode": "active",
        "recon": ["tech", "crawler", "jsecret"],
        "attack": ["cors", "jwt", "graphql", "csrf", "idor"],
        "discovery_deep": False,
    },
    "cms": {
        "desc": "Foco CMS (WordPress/Joomla/Drupal)",
        "mode": "active",
        "recon": RECON,
        "attack": [
            "lfi", "traversal", "sqli", "xss", "idor", "csrf", "rce",
            "cors", "jwt", "graphql", "wordpress_enum", "sqli_confirm",
            "osint_urls", "ai_analysis", "wpscan", "cmsmap",
            "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
    },
    "wordpress": {
        "desc": "Orientado a WordPress",
        "mode": "active",
        "recon": ["tech", "crawler", "archivos"],
        "attack": [
            "idor", "xss", "sqli", "lfi", "traversal", "csrf", "rce",
            "wordpress_enum", "wpscan", "cmsmap", "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
    },
    "cms_pentest": {
        "desc": "Pentest CMS: WPScan + CMSmap + Wapiti/Nikto/Ferox + Metasploit",
        "mode": "active",
        "recon": ["tech", "crawler", "archivos", "jsecret"],
        "attack": [
            "sqli", "idor", "xss", "lfi", "traversal", "csrf",
            "wordpress_enum", "wpscan", "cmsmap", "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
        "metasploit": True,
    },
}


def get_profile(name: str) -> dict:
    """Devuelve el dict del perfil o 'full' por defecto."""
    return PROFILES.get(name, PROFILES["full"])


def list_profiles() -> dict:
    return {k: v["desc"] for k, v in PROFILES.items()}


def resolve_modules(name: str, available_plugins: list) -> tuple:
    """Devuelve (recon_order, attack_order, mode) para el perfil, filtrando
    los plugins que realmente existen."""
    p = get_profile(name)
    
    # Filtrar únicamente módulos nativos disponibles
    attack = [m for m in p["attack"] if m in available_plugins]
    
    # Deduplicar manteniendo orden
    seen = set()
    attack_u = []
    for m in attack:
        if m not in seen:
            seen.add(m)
            attack_u.append(m)
    
    recon = list(p["recon"])
    # recon tampoco debe incluir modulos eliminados
    recon = [r for r in recon if r in available_plugins or r in ("tech", "headers")]
    
    return recon, attack_u, p.get("mode", "active")