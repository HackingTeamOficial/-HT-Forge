# SQLi diagnostics (HT Forge 1.5)

The SQLi module is intentionally bounded per parameter. It records baseline,
HTTP status, response sizes and similarity for boolean differential checks.

Useful runtime settings:
- `sqli_max_params`: default 200
- `sqli_request_timeout`: default 10 seconds

A module timeout is isolated by rebuilding the Engine HTTP client, so a slow
parameter cannot poison subsequent modules in the same scan.

Use only against systems you are authorized to assess.
