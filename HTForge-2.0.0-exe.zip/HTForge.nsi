; HT Forge 2.0.0 UNIFIED - un solo exe, la key decide DEMO/PRO/PREMIUM. NSIS 3.x
!define PRODUCT_NAME "HT Forge"
!define PRODUCT_VERSION "2.0.0"
!define PRODUCT_PUBLISHER "Hacking Team Official"
!define PRODUCT_DIR_REGKEY "Software\Microsoft\Windows\CurrentVersion\App Paths\HTForge.exe"
!define PRODUCT_UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${PRODUCT_NAME}"
!define PRODUCT_UNINST_ROOT_KEY "HKLM"

Unicode True
SetCompressor /SOLID lzma
RequestExecutionLevel admin
BrandingText "Hacking Team Official - HT Forge 2.0.0 UNIFIED"
Name "${PRODUCT_NAME} ${PRODUCT_VERSION} UNIFIED"
OutFile "HT-Forge-2.0.0-Setup.exe"
InstallDir "$PROGRAMFILES\HT Forge"
InstallDirRegKey HKLM "${PRODUCT_DIR_REGKEY}" ""
ShowInstDetails show
ShowUnInstDetails show

!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"

!define MUI_ICON "branding\wizard.ico"
!define MUI_UNICON "branding\wizard.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "branding\wizard.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "branding\header.bmp"
!define MUI_HEADERIMAGE_RIGHT
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Ejecutar HT Forge ahora"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchHTForge

Var LicenseKey

!insertmacro MUI_PAGE_WELCOME
Page custom LicensePage LicensePageLeave
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

Function LicensePage
  !insertmacro MUI_HEADER_TEXT "Activar licencia" "Elige edicion con tu clave. Vacio = DEMO (24h trial)."
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}
  ${NSD_CreateLabel} 0 0 100% 24u "Clave de licencia (DEMO / PRO / PREMIUM):"
  Pop $0
  ${NSD_CreateText} 0 24u 100% 14u ""
  Pop $LicenseKey
  ${NSD_CreateLabel} 0 44u 100% 28u "Vacio = DEMO 24h con acceso completo.$\nCon clave PRO (30 dias) o PREMIUM (365 dias) la herramienta cambia sola de edicion."
  Pop $0
  nsDialogs::Show
FunctionEnd

Function LicensePageLeave
  ${NSD_GetText} $LicenseKey $0
  StrCpy $LicenseKey $0
FunctionEnd

Section "HT Forge Core + Python embebido" SEC_CORE
  SectionIn RO
  SetOutPath "$INSTDIR"
  File /r "HTForge_UNIFIED\*.*"
  SetOutPath "$INSTDIR\runtime"
  FileOpen $0 "$INSTDIR\runtime\.keep" w
  FileWrite $0 ""
  FileClose $0
  ${If} $LicenseKey != ""
    FileOpen $0 "$INSTDIR\runtime\license.key" w
    FileWrite $0 "$LicenseKey"
    FileClose $0
  ${EndIf}
  nsExec::ExecToLog 'icacls "$INSTDIR\runtime" /grant Users:(OI)(CI)F /T'
  CreateDirectory "$LOCALAPPDATA\HT Forge\runtime"
SectionEnd

Section "Motores de Escaneo" SEC_ENGINES
SectionEnd

Section "Modulos de Seguridad (112 plugins)" SEC_PLUGINS
  SectionIn RO
SectionEnd

Section "Interfaz Grafica + Telegram" SEC_UI
  SectionIn RO
SectionEnd

Section "Reportes (PDF/HTML/JSON)" SEC_REPORTS
SectionEnd

Section "Utilidades" SEC_TOOLS
SectionEnd

Section "Integracion Hacking Team" SEC_HT
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_CORE} "Nucleo, motor, BD y Python 3.11 embebido (sin dependencias)."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_ENGINES} "Motores nativos Forge."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_PLUGINS} "112 modulos: SQLi, XSS, SSRF, RCE, JWT, GraphQL, Cloud, etc."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_UI} "Interfaz web + avisos Telegram por hallazgo (puerto 9090)."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_REPORTS} "Exportadores PDF/HTML/JSON."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_TOOLS} "Helpers y scripts."
  !insertmacro MUI_DESCRIPTION_TEXT ${SEC_HT} "Accesos directos y marca."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Section -AdditionalIcons
  SetOutPath "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\HT Forge"
  CreateShortCut "$SMPROGRAMS\HT Forge\HT Forge.lnk" "$INSTDIR\HTForge.bat" "" "" 0
  CreateShortCut "$SMPROGRAMS\HT Forge\Activar Licencia.lnk" "$INSTDIR\activar-licencia.bat" "" "" 0
  CreateShortCut "$SMPROGRAMS\HT Forge\Uninstall.lnk" "$INSTDIR\uninst.exe"
  CreateShortCut "$DESKTOP\HT Forge.lnk" "$INSTDIR\HTForge.bat" "" "" 0
SectionEnd

Section -Post
  WriteUninstaller "$INSTDIR\uninst.exe"
  WriteRegStr HKLM "${PRODUCT_DIR_REGKEY}" "" "$INSTDIR\HTForge.bat"
  WriteRegStr ${PRODUCT_UNINST_ROOT_KEY} "${PRODUCT_UNINST_KEY}" "DisplayName" "$(^Name)"
  WriteRegStr ${PRODUCT_UNINST_ROOT_KEY} "${PRODUCT_UNINST_KEY}" "UninstallString" "$INSTDIR\uninst.exe"
  WriteRegStr ${PRODUCT_UNINST_ROOT_KEY} "${PRODUCT_UNINST_KEY}" "DisplayVersion" "${PRODUCT_VERSION}"
  WriteRegStr ${PRODUCT_UNINST_ROOT_KEY} "${PRODUCT_UNINST_KEY}" "Publisher" "${PRODUCT_PUBLISHER}"
SectionEnd

Function LaunchHTForge
  ExecShell "open" "$INSTDIR\HTForge.bat"
FunctionEnd

Section Uninstall
  RMDir /r "$SMPROGRAMS\HT Forge"
  Delete "$DESKTOP\HT Forge.lnk"
  RMDir /r "$INSTDIR"
  DeleteRegKey ${PRODUCT_UNINST_ROOT_KEY} "${PRODUCT_UNINST_KEY}"
  DeleteRegKey HKLM "${PRODUCT_DIR_REGKEY}"
  SetAutoClose true
SectionEnd
