@echo off
title HT Forge - Activar Licencia
setlocal
cd /d "%~dp0"
set HTFORGE_RUNTIME=%~dp0runtime
mkdir "%HTFORGE_RUNTIME%" 2>nul
echo test > "%HTFORGE_RUNTIME%\.write_test" 2>nul
if errorlevel 1 (
  set HTFORGE_RUNTIME=%LOCALAPPDATA%\HT Forge\runtime
  mkdir "%HTFORGE_RUNTIME%" 2>nul
) else (
  del "%HTFORGE_RUNTIME%\.write_test" 2>nul
)
set PY=%~dp0python\python.exe
if not exist "%PY%" set PY=python
echo === HT Forge - Activar Licencia (DEMO/PRO/PREMIUM) ===
echo Elige edicion en la pantalla de bienvenida o pega la clave aqui.
"%PY%" -c "from core.license import license_status; print(license_status())"
echo.
set /p LICENSE_KEY=Pega tu clave (vacio = DEMO 24h):
if "%LICENSE_KEY%"=="" (
  echo DEMO trial activo.
  pause
  exit /b 0
)
"%PY%" -c "import sys; from core.license import install_license; s=install_license(sys.argv[1]); print('Licencia activada:', s)" "%LICENSE_KEY%"
if errorlevel 1 (
  echo [ERROR] Clave no valida
  pause
  exit /b 1
)
echo [OK] Licencia activada
pause
