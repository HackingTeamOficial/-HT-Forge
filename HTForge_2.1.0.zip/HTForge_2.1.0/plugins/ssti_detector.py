#!/usr/bin/env python3
"""HT Forge 2.0 - SSTI confirmed detector.
Identify template injection only when the engine is unequivocally identified
and the evaluation is reproducible across multiple contexts.
"""
import re
from urllib.parse import quote
from core.context import Context
from core.payloads_1_8 import SSTI

# SSTI engine signatures
ENGINE_SIGNATURES = {
    'jinja2': [r'\b7\b', r'{{7\*7}}', r'config', r'ReQUEST'],
    'twig': [r'\b49\b', r'{%', r'{{', r'_self'],
    'django': [r'\b49\b', r'{{', r'__', r'{{%'],
    'mako': [r'\b49\b', r'<%', r'<%def', r'<%def'],
    'freemarker': [r'\b49\b', r'\$\{7\*7\}', r'<#', r'eval'],
    'erb': [r'\b49\b', r'<%', r'$_', r'erb'],
}

# Confirmed engines need at least 2 distinct indicators
CONFIRMATION_THRESHOLD = 2

def _detect_engine(text: str) -> list:
    """Detect which template engine is being used based on response patterns."""
    detected = []
    text_lower = text.lower() if text else ''
    
    for engine, patterns in ENGINE_SIGNATURES.items():
        matches = sum(1 for p in patterns if re.search(p, text_lower) or re.search(p, text))
        if matches >= 2:
            detected.append(engine)
    
    return detected

def _is_ssti_response(resp_text: str, payloads: list, expected: str) -> dict:
    """Check if response indicates SSTI with structured evidence."""
    if not resp_text:
        return {'ssti': False}
    
    text_lower = resp_text.lower()
    
    # Check for mathematical evaluation
    math_match = any(str(i*7) in resp_text for i in range(1, 20)) or '49' in resp_text
    
    # Check for template syntax leakage
    syntax_leak = any(x in resp_text for x in ['{{', '{%', '<%', '${', '<!'])
    
    # Check for error messages
    error_patterns = [
        'ssti', 'template', 'syntax', 'error', 'jinja', 'twig', 'django',
        'cannot', 'undefined', 'object', 'filter', 'function'
    ]
    error_found = any(p in text_lower for p in error_patterns)
    
    return {
        'ssti': math_match or syntax_leak,
        'math_eval': math_match,
        'syntax_leak': syntax_leak,
        'error_indicators': error_found if error_found else None,
        'evidence_snippets': [resp_text[i:i+100] for i in range(0, min(len(resp_text), 500), 200)]
    }

def _run_probe(ctx: Context, url: str, param: str, payload: str) -> dict:
    """Execute single SSTI probe and return structured result."""
    resp = ctx.req('GET', url, timeout=5)
    text = getattr(resp, 'text', '') or ''
    
    return {
        'status': resp.status_code if resp else 0,
        'text': text,
        'headers': dict(getattr(resp, 'headers', {}) or {}),
        'size': len(text),
    }

def run(ctx: Context) -> dict:
    """Run SSTI detection with confirmed engine identification."""
    findings = []
    params = ctx.get('discovered_params', []) or []
    
    # Filter to string-type parameters most likely to accept template expressions
    ssti_candidates = []
    for p in params:
        param = str(p.get('param', '')).lower()
        if param in ['q', 'query', 'search', 'name', 'title', 'message', 'content', 'comment']:
            ssti_candidates.append(p)
    
    if not ssti_candidates:
        return {'findings': [], 'stats': {'candidates': 0, 'scanned': 0}}
    
    ctx.log('info', f'SSTI detection: {len(ssti_candidates)} candidatos')
    
    for info in ssti_candidates:
        if ctx.stopped:
            break
            
        url = str(info.get('url', ctx.target))
        param = str(info.get('param', ''))
        
        # Run multiple payloads to confirm
        confirmed_findings = []
        probe_results = []
        
        for payload, expected in list(SSTI)[:6]:
            if ctx.stopped:
                break
                
            result = _run_probe(ctx, url, param, payload)
            probe_results.append({
                'payload': payload,
                'expected': expected,
                'result': result
            })
            
            ssti_check = _is_ssti_response(result['text'], [payload], expected)
            if ssti_check.get('ssti'):
                probe_results[-1]['ssti_detected'] = True
                probe_results[-1]['evidence'] = ssti_check
        
        # Check if we have confirmed SSTI (at least 2 independent indicators)
        confirmed_probes = [p for p in probe_results if p.get('ssti_detected')]
        
        if len(confirmed_probes) >= 2:
            # Try to identify engine
            engines = []
            for p in confirmed_probes:
                ev = p.get('evidence', {})
                detected = _detect_engine(str(ev.get('evidence_snippets', '')))
                engines.extend(detected)
            
            unique_engines = list(set(engines))
            
            # Only confirm if engine identified
            if unique_engines:
                engine = unique_engines[0] if len(unique_engines) == 1 else ', '.join(unique_engines[:2])
                
                finding = {
                    'type': 'ssti',
                    'severity': 'critical',
                    'title': 'SSTI confirmado',
                    'detail': f'Selección de plantillas inycia detectada. Motor identificado: {engine}. El parámetro {param} acepta expresiones de template.',
                    'confidence': 0.95,
                    'evidence': {
                        'engine_detected': engine,
                        'url': url,
                        'parameter': param,
                        'probes': confirmed_probes,
                        'verification_steps': [
                            'Identificar motor de plantillas',
                            'Verificar contexto de renderizado',
                            'Confirmar expresión con payload diferente'
                        ]
                    },
                    'url': url,
                    'parameter': param
                }
                findings.append(finding)
                ctx.log('ok', f'SSTI confirmado en {param} (motor: {engine})')
            else:
                # Only "possible" without engine confirmation
                finding = {
                    'type': 'ssti',
                    'severity': 'high',
                    'title': 'Posible SSTI',
                    'detail': f'Patrones de inyección de plantillas detectados en {param}, pero motor no identificado con certeza.',
                    'confidence': 0.65,
                    'evidence': {
                        'url': url,
                        'parameter': param,
                        'probes': confirmed_probes,
                        'note': 'Confirmar motor de plantillas manualmente'
                    },
                    'url': url,
                    'parameter': param
                }
                findings.append(finding)
                ctx.log('warn', f'SSTI posible en {param} (confirma motor)')
    
    stats = {
        'candidates': len(ssti_candidates),
        'scanned': len(findings),
        'confirmed': len([f for f in findings if f.get('confidence', 0) >= 0.9]),
    }
    
    return {
        'findings': findings,
        'stats': stats
    }

__version__ = '2.0.0'
__author__ = 'HT Team'
PHASE = 'attack'
REQUIRES = ['crawler']