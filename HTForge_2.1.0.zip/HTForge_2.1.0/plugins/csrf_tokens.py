"""HT Forge 2.0.0 - Anti-CSRF detector (propio)."""
import re
from plugins._new_detectors_common import req, add, targets, response_text
PLUGIN_TYPE = "csrf_tokens"; __version__ = "2.0.0"; __author__ = "HT Team"; PHASE = "recon"; REQUIRES = []
FORM_RE = re.compile(r"<form\b([^>]*)>(.*?)</form>", re.I | re.S)
TOKEN_RE = re.compile(r"name\s*=\s*[\"']([^\"']*(?:csrf|xsrf|authenticity|token|nonce|__requestverification)[^\"']*)[\"']", re.I)
METHOD_RE = re.compile(r"method\s*=\s*[\"']?(\w+)", re.I)

def run(ctx):
    for base in targets(ctx):
        r = req(ctx, base)
        if r is None:
            continue
        for m in FORM_RE.finditer(response_text(r)):
            attrs, body = m.group(1), m.group(2)
            method = (METHOD_RE.search(attrs or "").group(1) if METHOD_RE.search(attrs or "") else "get").lower()
            if method != "post":
                continue
            if not TOKEN_RE.search(body or ""):
                add(ctx, PLUGIN_TYPE, "Formulario POST sin token anti-CSRF",
                    "medium", "Formulario POST sin campo oculto anti-CSRF observable; verificar proteccion CSRF en servidor antes de calificar impacto.",
                    base, {"form": (attrs or "").strip()[:200]}, "high")
                break
    return {}
