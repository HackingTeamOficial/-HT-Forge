"""HT Forge 2.0.0 - Subresource Integrity detector (propio)."""
import re
from plugins._new_detectors_common import req, add, targets, response_text
PLUGIN_TYPE = "sri_check"; __version__ = "2.0.0"; __author__ = "HT Team"; PHASE = "recon"; REQUIRES = []
SCRIPT_RE = re.compile(r"<script\b([^>]*)>", re.I)
SRC_RE = re.compile(r"src\s*=\s*[\"'](https?://[^\"']+)[\"']", re.I)

def run(ctx):
    for base in targets(ctx):
        r = req(ctx, base)
        if r is None:
            continue
        for m in SCRIPT_RE.finditer(response_text(r)):
            tag = m.group(1) or ""
            src = SRC_RE.search(tag)
            if src and not re.search(r"integrity\s*=", tag, re.I):
                add(ctx, PLUGIN_TYPE, "Script externo sin Subresource Integrity",
                    "low", "Script de terceros sin atributo integrity; si el CDN se compromete, el codigo se ejecuta en tu origen.",
                    base, {"src": src.group(1)[:200]}, "high")
                break
    return {}
