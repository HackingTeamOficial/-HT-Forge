#!/usr/bin/env python3
"""HT Forge 2.2 - IDOR/BOLA detector con matriz de autorización multi-contexto.

Requiere dos contextos de autorización configurados (usuario A y usuario B)
para confirmación completa. Con un solo contexto, los hallazgos se degradan
a "posible IDOR" y requieren verificación manual.
"""
import base64
import hashlib
import re
import uuid as uuid_mod
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context

ID_PARAM = re.compile(
    r'(^|_)(id|uid|user|account|order|document|file|invoice|profile|customer|object|uuid|guid|slug)(_|$)',
    re.I
)
PATH_ID = re.compile(r'(?P<prefix>/)(?P<id>[^/?#]+)(?P<suffix>(?:/|$))')
NUMERIC_ID = re.compile(r'^\d+$')
UUID_PATTERN = re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I
)
BASE64_PATTERN = re.compile(r'^[A-Za-z0-9+/]{8,}={0,2}$')

OWNERSHIP_FIELDS = (
    'user_id', 'userId', 'owner_id', 'ownerId', 'account_id', 'accountId',
    'email', 'owner', 'created_by', 'createdBy', 'author', 'author_id',
    'customer_id', 'customerId', 'profile_id', 'profileId',
)


def _set_param(url, param, value):
    p = urlsplit(url)
    pairs = parse_qsl(p.query, keep_blank_values=True)
    out, replaced = [], False
    for k, v in pairs:
        if k == param and not replaced:
            out.append((k, str(value))); replaced = True
        else:
            out.append((k, v))
    if not replaced:
        out.append((param, str(value)))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out), p.fragment))


def _set_path_id(url, old, new):
    p = urlsplit(url)
    path = p.path.replace('/' + str(old) + '/', '/' + str(new) + '/', 1)
    if path == p.path:
        if p.path.endswith(str(old)):
            path = p.path[:-len(str(old))] + str(new)
        else:
            path = p.path
    return urlunsplit((p.scheme, p.netloc, path, p.query, p.fragment))


def _fp(resp):
    """Fingerprint a response: status, length, hash, content-type, JSON fields."""
    text = (getattr(resp, 'text', '') or '')
    status = int(getattr(resp, 'status_code', 0) or 0)
    headers = getattr(resp, 'headers', {}) or {}
    ct = headers.get('Content-Type', '') or ''
    body_hash = hashlib.sha256(text[:10000].encode('utf-8', 'ignore')).hexdigest()

    ownership_data = {}
    if 'json' in ct.lower() or text.strip().startswith(('{', '[')):
        try:
            import json
            data = json.loads(text)
            if isinstance(data, dict):
                for field in OWNERSHIP_FIELDS:
                    if field in data:
                        ownership_data[field] = str(data[field])[:200]
            elif isinstance(data, list) and data:
                first = data[0]
                if isinstance(first, dict):
                    for field in OWNERSHIP_FIELDS:
                        if field in first:
                            ownership_data[field] = str(first[field])[:200]
        except (json.JSONDecodeError, ValueError):
            pass

    title = ''
    title_match = re.search(r'<title[^>]*>(.*?)</title>', text, re.S | re.I)
    if title_match:
        title = title_match.group(1).strip()[:200]

    return {
        'status': status,
        'length': len(text),
        'hash': body_hash,
        'content_type': ct,
        'ownership': ownership_data,
        'title': title,
    }


def _looks_like_id(seg):
    """Un segmento de ruta solo es candidato si parece identificador."""
    if not seg or len(seg) > 64:
        return False
    if '.' in seg or ':' in seg or '@' in seg:
        return False
    if NUMERIC_ID.match(seg):
        return True
    if UUID_PATTERN.match(seg):
        return True
    if BASE64_PATTERN.match(seg):
        return True
    # slug con dígitos (order-1001, user42): letras solas como 'login' quedan fuera.
    if re.fullmatch(r'[A-Za-z0-9_-]{2,32}', seg) and any(c.isdigit() for c in seg):
        return True
    return False


def _candidate(info):
    param = str(info.get('param') or '')
    if param and ID_PARAM.search(param):
        return ('query', param)
    try:
        path = urlsplit(str(info.get('url', ''))).path or ''
    except Exception:
        path = ''
    for seg in [s for s in path.split('/') if s]:
        if _looks_like_id(seg):
            return ('path', seg)
    return (None, None)


def _generate_id_variants(original):
    """Generate ID variants based on the original value type."""
    variants = []

    if NUMERIC_ID.match(str(original)):
        n = int(original)
        variants = [str(n + 1), str(n + 2), str(n + 10), str(n + 100)]
        if n > 1:
            variants.append(str(n - 1))
    elif UUID_PATTERN.match(str(original)):
        variants = [str(uuid_mod.uuid4()), str(uuid_mod.uuid4())]
    elif BASE64_PATTERN.match(str(original)):
        try:
            decoded = base64.b64decode(str(original)).decode('utf-8', 'ignore')
            if decoded.isdigit():
                n = int(decoded)
                for new_n in [n + 1, n + 2, n + 10]:
                    variants.append(base64.b64encode(str(new_n).encode()).decode())
        except Exception:
            pass
        variants.extend(['1', '2', '100'])
    else:
        variants = ['1', '2', '100', '999999']

    return variants[:5]


def _get_auth_contexts(ctx):
    """Retrieve authorization contexts from configuration."""
    contexts = ctx.config.get('idor_auth_contexts', [])
    if not contexts:
        session = ctx.get('session_info', {}) or {}
        if session.get('authenticated'):
            return [{'name': 'authenticated_user', 'headers': {}, 'cookies': {}}]
    return contexts


def _request_with_context(ctx, method, url, auth_ctx, **kwargs):
    """Make a request with a specific authorization context."""
    headers = dict(kwargs.pop('headers', {}) or {})
    cookies = dict(kwargs.pop('cookies', {}) or {})

    if auth_ctx:
        headers.update(auth_ctx.get('headers', {}) or {})
        cookies.update(auth_ctx.get('cookies', {}) or {})

    if cookies:
        cookie_str = '; '.join(f'{k}={v}' for k, v in cookies.items())
        headers['Cookie'] = cookie_str

    return ctx.req(method, url, headers=headers, cookies=cookies, **kwargs)


def _semantic_match(fp_a, fp_b):
    """Compare two fingerprints semantically."""
    if fp_a['status'] != fp_b['status']:
        return False
    if fp_a['content_type'] != fp_b['content_type']:
        return False
    if fp_a['ownership'] and fp_b['ownership']:
        for field in OWNERSHIP_FIELDS:
            if field in fp_a['ownership'] and field in fp_b['ownership']:
                if fp_a['ownership'][field] == fp_b['ownership'][field]:
                    return True
    if fp_a['title'] and fp_a['title'] == fp_b['title']:
        return True
    if fp_a['hash'] == fp_b['hash']:
        return True
    return False


def _is_access_denied(fp):
    return fp['status'] in (401, 403)


def _is_not_found(fp):
    return fp['status'] in (404, 410)


def run(ctx: Context):
    findings = []
    params = ctx.get('discovered_params', []) or []
    candidates = []
    for p in params:
        kind, key = _candidate(p)
        if kind:
            candidates.append((p, kind, key))

    if not candidates:
        candidates = [(
            {'url': ctx.target, 'param': 'id', 'method': 'GET', 'baseline_value': '1'},
            'query', 'id'
        )]

    auth_contexts = _get_auth_contexts(ctx)
    has_two_contexts = len(auth_contexts) >= 2

    ctx.log('info', f'Analizando IDOR/BOLA en {ctx.target} ({len(candidates)} candidatos, {len(auth_contexts)} contextos de auth)')

    if not has_two_contexts:
        ctx.log('warn', 'IDOR: solo 1 contexto de autorización disponible. Los hallazgos serán "posible IDOR" hasta verificación con segundo contexto.')

    for info, kind, key in candidates[:int(ctx.config.get('idor_max_params', 30))]:
        if ctx.stopped or str(info.get('method', 'GET')).upper() != 'GET':
            continue

        url = str(info.get('url', ctx.target))
        original = str(info.get('baseline_value') or '')

        if kind == 'path':
            m = PATH_ID.search(url)
            original = m.group('id') if m else '1'
            make = lambda v: _set_path_id(url, original, v)
            param = f'path:{original}'
        else:
            if not original.isdigit():
                original = '1'
            make = lambda v: _set_param(url, key, v)
            param = key

        variants = _generate_id_variants(original)
        primary_ctx = auth_contexts[0] if auth_contexts else None
        secondary_ctx = auth_contexts[1] if len(auth_contexts) >= 2 else None

        try:
            base_url = make(original)
            base_resp = _request_with_context(ctx, 'GET', base_url, primary_ctx, timeout=10)
            base_fp = _fp(base_resp)

            if _is_access_denied(base_fp) or _is_not_found(base_fp):
                ctx.log('info', f'IDOR: baseline para {param} no accesible (status {base_fp["status"]}), saltando')
                continue

            accessible_variants = []

            for val in variants:
                if ctx.stopped:
                    break
                test_url = make(val)
                resp = _request_with_context(ctx, 'GET', test_url, primary_ctx, timeout=10)
                fp = _fp(resp)

                if fp['status'] in (200, 206) and not _semantic_match(fp, base_fp) and fp['length'] > 0:
                    accessible_variants.append({
                        'id': val,
                        'status': fp['status'],
                        'length': fp['length'],
                        'hash': fp['hash'],
                        'content_type': fp['content_type'],
                        'ownership': fp['ownership'],
                        'title': fp['title'],
                    })

            if not accessible_variants:
                continue

            cross_context_evidence = None
            escalation_type = None
            if secondary_ctx:
                cross_resp = _request_with_context(ctx, 'GET', base_url, secondary_ctx, timeout=10)
                cross_fp = _fp(cross_resp)

                if cross_fp['status'] in (200, 206) and not _semantic_match(cross_fp, base_fp):
                    cross_context_evidence = {
                        'user_a_object': {
                            'status': base_fp['status'],
                            'hash': base_fp['hash'],
                            'ownership': base_fp['ownership'],
                        },
                        'user_b_accessing_user_a': {
                            'status': cross_fp['status'],
                            'hash': cross_fp['hash'],
                            'ownership': cross_fp['ownership'],
                        },
                        'access_granted': True,
                    }
                    is_horizontal = bool(
                        cross_fp['ownership'] and
                        cross_fp['ownership'] != base_fp['ownership']
                    )
                    escalation_type = 'horizontal' if is_horizontal else 'vertical_or_data_exposure'
                elif _is_access_denied(cross_fp):
                    cross_context_evidence = {
                        'user_b_accessing_user_a': {
                            'status': cross_fp['status'],
                            'access_granted': False,
                        },
                        'access_granted': False,
                    }
                else:
                    cross_context_evidence = {
                        'user_b_accessing_user_a': {
                            'status': cross_fp['status'],
                            'access_granted': None,
                        },
                        'access_granted': None,
                    }

            if len(accessible_variants) >= 2:
                if cross_context_evidence and cross_context_evidence.get('access_granted') is True:
                    confidence = 0.95
                    severity = 'high'
                    title = 'IDOR / BOLA confirmado (cross-context)'
                    detail = (
                        f"El parámetro '{param}' permite acceso a recursos sin verificación de propiedad. "
                        f"Verificado con dos contextos de autorización: usuario B puede acceder a objetos "
                        f"del usuario A. Tipo: {escalation_type}."
                    )
                elif cross_context_evidence and cross_context_evidence.get('access_granted') is False:
                    confidence = 0.75
                    severity = 'medium'
                    title = 'Posible IDOR / BOLA (auth context diferencial)'
                    detail = (
                        f"El parámetro '{param}' permite acceso a múltiples recursos sin verificación de "
                        f"propiedad. Cross-context: usuario B correctamente denegado, pero usuario A puede "
                        f"acceder a {len(accessible_variants)} recursos adicionales."
                    )
                elif has_two_contexts:
                    confidence = 0.80
                    severity = 'high'
                    title = 'IDOR / BOLA confirmado (multi-objeto)'
                    detail = (
                        f"El parámetro '{param}' permite acceso a múltiples recursos sin verificación de "
                        f"propiedad. Confirmado con 2+ variantes accesibles."
                    )
                else:
                    confidence = 0.65
                    severity = 'medium'
                    title = 'Posible IDOR / BOLA (contexto único)'
                    detail = (
                        f"El parámetro '{param}' muestra acceso a múltiples recursos. "
                        f"Requiere verificación con segundo contexto de autorización para confirmar."
                    )

                findings.append({
                    'type': 'idor',
                    'severity': severity,
                    'title': title,
                    'detail': detail,
                    'confidence': confidence,
                    'evidence': {
                        'url': url,
                        'parameter': param,
                        'method': 'GET',
                        'request_template': make('{{id}}'),
                        'baseline': {
                            'id': original,
                            'status': base_fp['status'],
                            'length': base_fp['length'],
                            'hash': base_fp['hash'],
                            'ownership': base_fp['ownership'],
                        },
                        'variants': accessible_variants,
                        'cross_context': cross_context_evidence,
                        'auth_contexts': [c.get('name', 'unknown') for c in auth_contexts],
                        'id_type': 'numeric' if NUMERIC_ID.match(str(original)) else
                                   'uuid' if UUID_PATTERN.match(str(original)) else
                                   'base64' if BASE64_PATTERN.match(str(original)) else 'slug',
                        'verification_needed': 'none' if confidence >= 0.95 else
                                               'Confirmar con segundo contexto de autorización',
                    },
                    'url': url,
                    'parameter': param,
                })
                ctx.log('ok', f'IDOR en {param} (confidence: {confidence})')

            elif len(accessible_variants) == 1:
                findings.append({
                    'type': 'idor',
                    'severity': 'low',
                    'title': 'Posible IDOR / BOLA (único hallazgo, sin confirmar)',
                    'detail': f"El parámetro '{param}' muestra comportamiento sospechoso con una sola variante. Sin segundo contexto ni segunda variante no se confirma: requiere verificación manual.",
                    'confidence': 0.45,
                    'verification_state': 'CANDIDATE',
                    'requires_human_review': True,
                    'evidence': {
                        'url': url,
                        'parameter': param,
                        'method': 'GET',
                        'variants': accessible_variants,
                        'note': 'Hallazgo preliminar. Verificar propiedad de recurso accedido.',
                    },
                    'url': url,
                    'parameter': param,
                })
                ctx.log('warn', f'IDOR posible en {param} (confirma con segundo contexto)')

        except Exception as e:
            if not ctx.stopped:
                ctx.log('warn', f'Error probando IDOR en {param}: {e}')

    return {'findings': findings}


__version__ = '2.2.0'
__author__ = 'HT Team'
PHASE = 'attack'
REQUIRES = ['crawler']
