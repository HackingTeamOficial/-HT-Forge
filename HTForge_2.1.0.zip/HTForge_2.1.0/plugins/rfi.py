"""HT Forge 1.7 - Remote File Inclusion candidate detector.
Usa solo un marcador inofensivo inexistente; ningún archivo remoto real.
Endurecido: exige reflejo del marcador + segunda confirmación; los errores
genéricos de include() por sí solos NO generan hallazgo.
"""
from urllib.parse import urlparse
from plugins._new_detectors_common import targets, query_params, probe_param, response_text, add
PLUGIN_TYPE="rfi"; __version__="1.8"; __author__="HT Team"; PHASE="attack"; REQUIRES=[]
def run(ctx):
    marker="https://htforge.invalid/htforge-rfi-probe.txt"
    for base in targets(ctx):
        ps=query_params(base)
        if not ps: continue
        for i,(name,_) in enumerate(ps[:8]):
            u,r=probe_param(ctx,base,i,marker)
            if r is None: continue
            text=response_text(r)
            low=text.lower()
            # Segunda evidencia obligatoria: el marcador debe reflejarse.
            if "htforge-rfi-probe" not in low and "htforge.invalid" not in low:
                continue
            # Re-confirmar con segunda petición independiente.
            u2,r2=probe_param(ctx,base,i,marker)
            if r2 is None: continue
            if "htforge-rfi-probe" not in response_text(r2).lower() and "htforge.invalid" not in response_text(r2).lower():
                continue
            add(ctx,PLUGIN_TYPE,f"Posible RFI en parámetro {name} (candidato, sin confirmar)","low",
                "El marcador remoto inofensivo fue reflejado de forma reproducible. No se ejecutó código ni se incluyó archivo real: requiere validación humana.",
                u,{"parameter":name,"marker_host":"htforge.invalid","status":getattr(r,"status_code",None),"retest":True,"verification_state":"CANDIDATE"},"low")
    return {}
