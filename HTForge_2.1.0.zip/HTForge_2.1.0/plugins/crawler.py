#!/usr/bin/env python3
"""plugins/crawler.py - Crawler básico para descubrir URLs y parámetros"""

import re
from urllib.parse import urljoin, urlparse, parse_qs, parse_qsl
from typing import Dict, List, Set
from core.context import Context


def run(ctx: Context) -> Dict:
    """Crawlea el target y descubre URLs/parámetros"""
    target = ctx.target
    findings = []
    
    ctx.log('info', f"Iniciando crawler en {target}")
    
    visited: Set[str] = set()
    to_visit = [target]
    discovered_urls = []
    discovered_params = []
    base_domain = urlparse(target).netloc

    # El target inicial también puede contener parámetros. Son parte de la
    # superficie de ataque y deben llegar a los módulos de validación.
    initial_params = parse_qs(urlparse(target).query, keep_blank_values=True)
    for param_name in initial_params:
        discovered_params.append({'url': target, 'param': param_name, 'method': 'GET', 'baseline_value': initial_params.get(param_name, [''])[0]})
    
    max_pages = ctx.config.get('crawler_max_pages', 30)
    max_depth = ctx.config.get('crawler_max_depth', 2)
    
    for depth in range(max_depth):
        if ctx.stopped or len(visited) >= max_pages:
            break
        
        current_batch = list(to_visit)
        to_visit = []
        
        for url in current_batch:
            if ctx.stopped or url in visited or len(visited) >= max_pages:
                break
            
            visited.add(url)
            
            try:
                resp = ctx.req('GET', url, timeout=10)
                content = resp.text
                discovered_urls.append(url)
                # Evento de URL para el feed del LOG (cualquier código de respuesta)
                ctx.log('url', url)
                # Extraer enlaces
                links = re.findall(r'href=["\']([^"\']+)["\']', content, re.IGNORECASE)
                links += re.findall(r'src=["\']([^"\']+)["\']', content, re.IGNORECASE)
                # JS/endpoints + robots/sitemap (una vez): mas descubrimiento, menos ruido.
                try:
                    links += re.findall(r'fetch\s*\(\s*[\'\"]([^\'\"]+)[\'\"]', content)
                    links += re.findall(r'[\'\"](/[a-zA-Z0-9_\-./?=&%#]{2,120})[\'\"]', content)
                except Exception:
                    pass
                if depth == 0 and url.rstrip('/') == target.rstrip('/'):
                    for _extra in ('/robots.txt', '/sitemap.xml'):
                        try:
                            _er = ctx.req('GET', target.rstrip('/') + _extra, timeout=8)
                            _et = getattr(_er, 'text', '') or ''
                            if getattr(_er, 'status_code', 0) == 200 and _et:
                                links += re.findall(r'(?m)^(?:Allow|Disallow|Sitemap):\s*(\S+)', _et)
                                links += re.findall(r'<loc>([^<]+)</loc>', _et)
                        except Exception:
                            pass
                
                for link in links:
                    try:
                        # Filtrar activos estáticos: no aportan superficie de ataque.
                        if re.search(r'\.(png|jpg|jpeg|gif|svg|ico|css|woff2?|ttf|eot)(\?|#|$)', link, re.I):
                            continue
                        absolute = urljoin(url, link)
                        parsed = urlparse(absolute)
                        
                        # Solo mismo dominio
                        if parsed.netloc == base_domain and absolute not in visited:
                            to_visit.append(absolute)
                            
                            # Extraer parámetros
                            params = parse_qs(parsed.query, keep_blank_values=True)
                            if params:
                                for param_name, values in params.items():
                                    discovered_params.append({
                                        'url': absolute,
                                        'param': param_name,
                                        'method': 'GET',
                                        'baseline_value': values[0] if values else ''
                                    })
                    except Exception:
                        pass
                
                form_re = re.compile(r'<form\b([^>]*)>(.*?)</form>', re.I | re.S)
                for attrs, form_body in form_re.findall(content):
                    action_m = re.search(r'action=["\']([^"\']*)["\']', attrs, re.I)
                    method_m = re.search(r'method=["\']([^"\']*)["\']', attrs, re.I)
                    absolute = urljoin(url, action_m.group(1)) if action_m else url
                    method = (method_m.group(1) if method_m else 'GET').upper()
                    inputs = []
                    # input es vacio (void); textarea/select llevan cierre propio.
                    # Un unico regex los fusionaba (input+textarea en un match)
                    # y perdia campos como el textarea 'review'.
                    for tag in re.findall(r'<input\b[^>]*>', form_body, re.I):
                        name_m = re.search(r'name=["\']([^"\']+)["\']', tag, re.I)
                        if not name_m:
                            continue
                        value_m = re.search(r'value=["\']([^"\']*)["\']', tag, re.I)
                        inputs.append((name_m.group(1), value_m.group(1) if value_m else ''))
                    for block in re.findall(r'<(?:textarea|select)\b[^>]*>.*?</(?:textarea|select)>', form_body, re.I | re.S):
                        name_m = re.search(r'name=["\']([^"\']+)["\']', block, re.I)
                        if not name_m:
                            continue
                        inputs.append((name_m.group(1), ''))
                    for inp, value in inputs:
                        discovered_params.append({
                            'url': absolute, 'param': inp, 'method': method, 'baseline_value': value,
                            'form_data': {k: v for k, v in inputs}
                        })
                        
            except Exception as e:
                ctx.log('warn', f"Error crawleando {url}: {e}")
    
    # Guardar en contexto para otros módulos
    ctx.set('discovered_urls', list(set(discovered_urls)))
    # Deduplicar por URL/parámetro/método manteniendo orden.
    unique = []
    seen = set()
    for item in discovered_params:
        key = (item.get('url'), item.get('param'), item.get('method', 'GET'))
        if key not in seen:
            seen.add(key); unique.append(item)
    ctx.set('discovered_params', unique[:250])
    
    if discovered_urls:
        findings.append({
            'type': 'crawl_results',
            'severity': 'info',
            'title': 'Crawler completado',
            'detail': f"Descubiertas {len(set(discovered_urls))} URLs y {len(discovered_params)} parámetros",
            'evidence': {
                'urls_count': len(set(discovered_urls)),
                'params_count': len(discovered_params),
                'sample_urls': list(set(discovered_urls))[:10]
            },
            'url': target
        })
        ctx.log('ok', f"Crawler: {len(set(discovered_urls))} URLs, {len(discovered_params)} params")
    
    return {'findings': findings}


__version__ = "1.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []