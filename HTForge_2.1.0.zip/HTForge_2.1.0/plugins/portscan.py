#!/usr/bin/env python3
"""plugins/portscan.py - Escáner TCP de puertos comunes (código puro, stdlib).

Sin nmap ni binarios externos: connect() con timeout corto + hilos.
"""

import socket
import threading
from typing import Dict, List
from urllib.parse import urlparse
from core.context import Context

# (puerto, servicio, severidad si está abierto)
COMMON_PORTS = [
    (21, "ftp", "medium"), (22, "ssh", "info"), (23, "telnet", "high"),
    (25, "smtp", "info"), (53, "dns", "info"), (80, "http", "info"),
    (110, "pop3", "info"), (143, "imap", "info"), (443, "https", "info"),
    (445, "smb", "high"), (1433, "mssql", "medium"), (1521, "oracle", "medium"),
    (3306, "mysql", "medium"), (3389, "rdp", "high"), (5432, "postgres", "medium"),
    (5900, "vnc", "high"), (6379, "redis", "high"), (8080, "http-alt", "info"),
    (8443, "https-alt", "info"), (27017, "mongodb", "high"), (11211, "memcached", "high"),
    (9200, "elasticsearch", "medium"), (5601, "kibana", "info"),
    (5985, "winrm", "medium"), (5986, "winrm-ssl", "medium"),
    (21, "ftp", "medium"),
]

RISKY = {23, 445, 3389, 5900, 6379, 27017, 11211}


def _host_of(target: str) -> str:
    u = urlparse(target if "://" in target else "http://" + target)
    return u.hostname or target


def run(ctx: Context) -> Dict:
    host = _host_of(ctx.target)
    findings: List[Dict] = []
    ctx.log("info", f"Escaneando puertos TCP en {host}")

    try:
        base_ip = socket.gethostbyname(host)
    except Exception as e:
        ctx.log("warn", f"No se pudo resolver {host}: {e}")
        return {"findings": findings}

    open_ports: List[tuple] = []
    lock = threading.Lock()

    def probe(port: int, service: str, sev: str):
        if ctx.stopped:
            return
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.2)
        try:
            if s.connect_ex((base_ip, port)) == 0:
                banner = ""
                try:
                    s.settimeout(1.0)
                    s.sendall(b"\r\n")
                    banner = s.recv(128).decode("utf-8", "replace").strip()[:120]
                except Exception:
                    pass
                with lock:
                    open_ports.append((port, service, sev, banner))
        except Exception:
            pass
        finally:
            s.close()

    seen = set()
    threads = []
    for port, service, sev in COMMON_PORTS:
        if port in seen:
            continue
        seen.add(port)
        th = threading.Thread(target=probe, args=(port, service, sev), daemon=True)
        threads.append(th)
        th.start()
        if len(threads) >= 20:
            for th in threads:
                th.join(timeout=4)
            threads = [th for th in threads if th.is_alive()]
    for th in threads:
        th.join(timeout=4)

    for port, service, sev, banner in sorted(open_ports):
        detail = f"{host}:{port} ({service}) acepta conexiones TCP"
        if banner:
            detail += f" · banner: {banner}"
        findings.append({
            "type": "open_port",
            "severity": "high" if port in RISKY else sev,
            "title": f"Puerto abierto {port}/{service}",
            "detail": detail,
            "evidence": {"host": host, "ip": base_ip, "port": port,
                         "service": service, "banner": banner},
            "url": f"{host}:{port}",
        })
    ctx.log("ok" if open_ports else "info",
            f"Puertos abiertos en {host}: {len(open_ports)}")
    return {"findings": findings, "open_ports": [p for p, _, _, _ in sorted(open_ports)]}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
