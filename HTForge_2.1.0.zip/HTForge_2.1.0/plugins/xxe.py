#!/usr/bin/env python3
"""Detección conservadora de superficies XML potencialmente expuestas a XXE.
No intenta leer archivos ni usar servicios externos; solo identifica endpoints
XML y señales de parser XML en respuestas.
"""
import re
from urllib.parse import urljoin, urlsplit, parse_qsl, urlencode, urlunsplit
from core.context import Context
XML_HINTS=re.compile(r'xml|soap|wsdl|saml|rss|atom',re.I)
PARSER_ERRORS=re.compile(r'(SAXParseException|XMLSyntaxError|EntityRef|external entity|entity .* not defined|parser error)',re.I)

def run(ctx: Context):
    findings=[]; target=ctx.target; urls=[]
    for u in [target, urljoin(target,'/xmlrpc.php'), urljoin(target,'/soap'), urljoin(target,'/api/xml'), urljoin(target,'/sitemap.xml')]:
        if u not in urls: urls.append(u)
    for info in ctx.get('discovered_urls',[])[:80]:
        if XML_HINTS.search(info) and info not in urls: urls.append(info)
    ctx.log('info',f"Buscando superficies XML/XXE en {target}")
    for url in urls[:40]:
        if ctx.stopped: break
        try:
            r=ctx.req('GET',url,timeout=8); ct=r.headers.get('Content-Type',''); text=r.text[:8000]
            ct_xml='xml' in ct.lower()
            parser_signal=bool(PARSER_ERRORS.search(text))
            if not (ct_xml or parser_signal):
                continue
            if parser_signal:
                severity='medium'; title='Señal de parser XML — revisar XXE'; confidence=0.72
                detail='Señal del parser XML observada; requiere validación controlada para confirmar XXE.'
                finding_type='xxe_parser_signal'
            else:
                severity='info'; title='Superficie XML detectada'; confidence=0.35
                detail='Endpoint relacionado con XML detectado; no se ha demostrado procesamiento inseguro de entidades externas.'
                finding_type='xml_surface'
            findings.append({'type':finding_type,'severity':severity,'title':title,'detail':detail,
                'confidence':confidence,'evidence':{'url':url,'content_type':ct,
                'parser_signal':parser_signal,'http_status':getattr(r,'status_code',None)},'url':url})
        except Exception as e:
            ctx.log('warn',f"Error XXE {url}: {e}")
    # Sonda activa con entidad INTERNA (sin lectura de archivos ni OOB):
    # si el parser expande la entidad, la inclusión es real y reproducible.
    try:
        findings.extend(_entity_probe(ctx))
    except Exception as e:
        ctx.log('warn', f'XXE entity probe: {type(e).__name__}')
    return {'findings':findings}


def _entity_candidates(ctx):
    out, seen = [], set()
    for info in ctx.get('discovered_params', []) or []:
        if not isinstance(info, dict):
            continue
        url, param = str(info.get('url', '')), str(info.get('param', ''))
        if not url or not param:
            continue
        if 'xml' in url.lower() or param.lower() in ('xml', 'data', 'body', 'payload', 'text', 'content'):
            key = (url, param, str(info.get('method', 'GET')).upper())
            if key not in seen:
                seen.add(key)
                out.append(info)
    return out[:10]


def _entity_probe(ctx):
    import secrets as _secrets
    findings = []
    for info in _entity_candidates(ctx):
        if ctx.stopped:
            break
        marker = f'HTFORGE-XXE-{_secrets.token_hex(4)}'
        probe = f'<!DOCTYPE r [<!ENTITY htforge "{marker}">]><root>&htforge;</root>'
        method = str(info.get('method', 'GET')).upper()
        url = str(info.get('url', ctx.target))
        param = str(info.get('param', ''))
        try:
            if method == 'POST':
                r1 = ctx.req('POST', url, data=probe,
                             headers={'Content-Type': 'application/xml', 'Connection': 'close'},
                             timeout=8)
            else:
                p = urlsplit(url)
                pairs = [(k, probe if k == param else v) for k, v in parse_qsl(p.query, keep_blank_values=True)]
                r1 = ctx.req('GET', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                             headers={'Connection': 'close'}, timeout=8)
            t1 = getattr(r1, 'text', '') or ''
            if marker not in t1:
                continue
            # Confirmación con segundo marcador (reproducibilidad).
            marker2 = f'HTFORGE-XXE-{_secrets.token_hex(4)}'
            probe2 = probe.replace(marker, marker2)
            if method == 'POST':
                r2 = ctx.req('POST', url, data=probe2,
                             headers={'Content-Type': 'application/xml', 'Connection': 'close'},
                             timeout=8)
            else:
                pairs = [(k, probe2 if k == param else v) for k, v in parse_qsl(p.query, keep_blank_values=True)]
                r2 = ctx.req('GET', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                             headers={'Connection': 'close'}, timeout=8)
            t2 = getattr(r2, 'text', '') or ''
            if marker2 not in t2:
                continue
            findings.append({
                'type': 'xxe', 'severity': 'high', 'title': 'XML External Entity (XXE) — entidad expandida',
                'detail': f'El endpoint {url} expande entidades XML de forma reproducible en el parámetro "{param}" (solo entidad interna de prueba, sin lectura de archivos).',
                'confidence': 0.90, 'verification_state': 'VERIFIED', 'requires_human_review': False,
                'evidence': {'url': url, 'parameter': param, 'method': method,
                             'marker': marker2, 'technique': 'internal-entity',
                             'reproduced': True, 'snippet': t2[:800]},
                'url': url, 'parameter': param,
            })
            ctx.log('ok', f'XXE confirmado en {param}')
        except (TimeoutError, ConnectionError, RuntimeError):
            continue
        except Exception as exc:
            ctx.log('warn', f'XXE entity {param}: {exc}')
    return findings

__version__='1.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
