#!/usr/bin/env python3
"""HT Forge 2.2 - fp_verify integrado con detectores diferenciales.

Se ejecuta EL ÚLTIMO. Re-verifica cada hallazgo según su tipo:
- SQLi error: re-pide el payload y busca la firma de error
- SQLi boolean: re-ejecuta el par TRUE/FALSE y verifica diferencial
- XSS: re-inyecta el marcador y re-analiza el contexto
- IDOR: re-ejecuta la matriz de autorización
- Otros: verificación genérica (URL + evidence key)
"""

import re
from typing import Dict, List
from core.context import Context

MAX_REVERIFY = 40


def _session_findings(ctx: Context) -> List[Dict]:
    try:
        eng = getattr(ctx, "engine", None)
        sess = getattr(eng, "session", None)
        if sess is not None and getattr(sess, "findings", None):
            return sess.findings
    except Exception:
        pass
    return []


def _evidence_key(f: Dict) -> str:
    ev = f.get("evidence") or {}
    if isinstance(ev, dict):
        for k in ("matched", "payload", "snippet", "banner", "marker"):
            if ev.get(k):
                return str(ev[k])[:160]
    for k in ("param", "parameter", "payload"):
        if f.get(k):
            return str(f[k])[:160]
    return ""


def _verify_sqli_error(ctx, f, ev):
    """Re-execute SQLi error probe and check for the error signature."""
    url = f.get("url", "")
    param = f.get("parameter", "")
    payload = ev.get("payload", "")
    signature = ev.get("signature", "")

    if not all([url, payload]):
        return None

    try:
        from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
        p = urlsplit(url)
        pairs = parse_qsl(p.query, keep_blank_values=True)
        pairs = [(k, payload if k == param else v) for k, v in pairs]
        test_url = urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment))

        r = ctx.req("GET", test_url, timeout=10)
        text = getattr(r, "text", "") or ""
        status = getattr(r, "status_code", 0)

        if signature and re.search(signature, text, re.I | re.S):
            return True
        if status in (404, 410):
            return False
        return None
    except Exception:
        return None


def _verify_sqli_boolean(ctx, f, ev):
    """Re-execute the TRUE/FALSE pair and check for differential."""
    url = f.get("url", "")
    param = f.get("parameter", "")
    true_payload = ev.get("true_payload", "")
    false_payload = ev.get("false_payload", "")

    if not all([url, true_payload, false_payload]):
        return None

    try:
        from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
        from difflib import SequenceMatcher

        def _req_with(payload):
            p = urlsplit(url)
            pairs = parse_qsl(p.query, keep_blank_values=True)
            pairs = [(k, payload if k == param else v) for k, v in pairs]
            test_url = urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment))
            r = ctx.req("GET", test_url, timeout=10)
            return getattr(r, "text", "") or ""

        true_text = _req_with(true_payload)
        false_text = _req_with(false_payload)

        ratio = SequenceMatcher(None, true_text[:5000], false_text[:5000]).ratio()
        if ratio < 0.90:
            return True
        return None
    except Exception:
        return None


def _verify_xss(ctx, f, ev):
    """Re-inject the XSS marker and check for reflection context."""
    url = f.get("url", "")
    param = f.get("parameter", "")
    payload = f.get("payload", "")
    marker = ev.get("marker", "")

    if not all([url, payload]):
        return None

    try:
        from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit

        p = urlsplit(url)
        pairs = parse_qsl(p.query, keep_blank_values=True)
        pairs = [(k, payload if k == param else v) for k, v in pairs]
        test_url = urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment))

        r = ctx.req("GET", test_url, timeout=10)
        text = getattr(r, "text", "") or ""
        status = getattr(r, "status_code", 0)

        if marker and marker in text:
            return True
        if payload and payload in text:
            return True
        if status in (404, 410):
            return False
        return None
    except Exception:
        return None


def _verify_idor(ctx, f, ev):
    """Re-execute IDOR variant access and check for differential."""
    url = f.get("url", "")
    variants = ev.get("variants", [])
    baseline = ev.get("baseline", {})

    if not url or not variants:
        return None

    try:
        import hashlib

        r_base = ctx.req("GET", url, timeout=10)
        base_text = getattr(r_base, "text", "") or ""
        base_hash = hashlib.sha256(base_text[:10000].encode("utf-8", "ignore")).hexdigest()

        for v in variants[:3]:
            variant_id = v.get("id", "")
            if not variant_id:
                continue

            from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
            p = urlsplit(url)
            pairs = parse_qsl(p.query, keep_blank_values=True)
            pairs = [(k, variant_id if k == f.get("parameter") else v_val) for k, v_val in pairs]
            variant_url = urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment))

            r_var = ctx.req("GET", variant_url, timeout=10)
            var_text = getattr(r_var, "text", "") or ""
            var_hash = hashlib.sha256(var_text[:10000].encode("utf-8", "ignore")).hexdigest()

            if var_hash != base_hash and getattr(r_var, "status_code", 0) in (200, 206):
                return True

        return None
    except Exception:
        return None


def run(ctx: Context) -> Dict:
    """Re-verifica hallazgos contra el objetivo en vivo, por tipo."""
    findings = _session_findings(ctx)
    if not findings:
        ctx.log("info", "fp_verify: sin hallazgos que verificar")
        return {"findings": []}
    ctx.log("info", f"fp_verify: re-verificando {min(len(findings), MAX_REVERIFY)} hallazgos")

    ok, bad, skipped = 0, 0, 0

    for f in findings[:MAX_REVERIFY]:
        if ctx.stopped:
            break
        if not isinstance(f, dict) or f.get("type") in ("fp_stats",):
            skipped += 1
            continue

        ev = f.get("evidence") or {}
        ftype = f.get("type", "")
        result = None

        if ftype == "sqli":
            if ev.get("signature"):
                result = _verify_sqli_error(ctx, f, ev)
            elif ev.get("true_payload"):
                result = _verify_sqli_boolean(ctx, f, ev)
            else:
                result = None
        elif ftype == "xss_reflected":
            result = _verify_xss(ctx, f, ev)
        elif ftype == "idor":
            result = _verify_idor(ctx, f, ev)
        else:
            url = f.get("url")
            if not url or not str(url).startswith("http"):
                f["verified"] = None
                skipped += 1
                continue
            try:
                r = ctx.req("GET", url, timeout=10)
                body = getattr(r, "text", "") or ""
                st = getattr(r, "status_code", 0)
                key = _evidence_key(f)
                if st in (200, 301, 302, 307, 308) and (not key or key in body):
                    result = True
                elif st in (404, 410):
                    result = False
                else:
                    result = None
            except Exception:
                result = None

        f["verified"] = result
        if result is True:
            ok += 1
        elif result is False:
            bad += 1
        else:
            skipped += 1

    for f in findings[:MAX_REVERIFY]:
        if isinstance(f, dict) and f.get("verified") is False:
            f["severity"] = "info"
            f["detail"] = (f.get("detail") or "") + " [fp_verify: no reproducible, degradado a info]"

    stats = {
        "type": "fp_stats",
        "severity": "info",
        "title": f"Verificación: {ok} confirmados, {bad} refutados, {skipped} sin concluir",
        "detail": f"fp_verify re-verificó {ok + bad + skipped} hallazgos con verificación específica por tipo",
        "evidence": {"confirmed": ok, "refuted": bad, "inconclusive": skipped,
                     "verification_methods": {"sqli_error": "signature_replay",
                                              "sqli_boolean": "true_false_differential",
                                              "xss": "marker_reinjection",
                                              "idor": "variant_differential",
                                              "generic": "url_evidence_key"}},
        "url": ctx.target,
        "verified": True,
    }
    ctx.log("ok" if not bad else "info",
            f"fp_verify: {ok} confirmados · {bad} refutados · {skipped} sin concluir")
    return {"findings": [stats]}


__version__ = "2.2.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = []
