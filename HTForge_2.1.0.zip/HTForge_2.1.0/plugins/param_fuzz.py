#!/usr/bin/env python3
"""plugins/param_fuzz.py - Descubrimiento de parámetros ocultos (código puro, stdlib).

Prueba nombres de parámetro comunes y detecta reflexión o cambios de
comportamiento (código/longitud) respecto a la petición sin parámetros.
"""

from typing import Dict, List
from core.context import Context

PARAMS = [
    "id", "page", "file", "path", "dir", "url", "redirect", "next", "q",
    "query", "search", "keyword", "lang", "locale", "theme", "template",
    "view", "action", "do", "cmd", "exec", "debug", "test", "admin",
    "user", "username", "email", "token", "key", "api_key", "callback",
    "format", "type", "sort", "order", "limit", "offset", "return",
    "continue", "dest", "target", "ref", "filter", "category", "name",
]

PROBE = "htforgezqx7"


def run(ctx: Context) -> Dict:
    """Fuzzing de parámetros"""
    base = ctx.target.rstrip("/")
    findings: List[Dict] = []
    ctx.log("info", f"Fuzzing de parámetros en {base}")

    try:
        r0 = ctx.req("GET", base, timeout=10)
        base_sig = (getattr(r0, "status_code", 0), len(getattr(r0, "text", "") or ""))
    except Exception as e:
        ctx.log("warn", f"Sin respuesta base: {e}")
        return {"findings": findings}

    for param in PARAMS:
        if ctx.stopped:
            break
        url = f"{base}{'&' if '?' in base else '?'}{param}={PROBE}"
        try:
            r = ctx.req("GET", url, timeout=10)
            body = getattr(r, "text", "") or ""
            sig = (getattr(r, "status_code", 0), len(body))
            reflected = PROBE in body
            changed = sig != base_sig and abs(sig[1] - base_sig[1]) > 32
            if reflected or changed:
                findings.append({
                    "type": "param_fuzz",
                    "severity": "medium" if reflected else "low",
                    "title": f"Parámetro activo: {param}" +
                             (" (valor reflejado)" if reflected else " (cambia la respuesta)"),
                    "detail": f"{url} → {sig[0]} ({sig[1]} bytes; base: {base_sig})",
                    "evidence": {"url": url, "parameter": param,
                                 "reflected": reflected, "status": sig[0]},
                    "url": url,
                })
                ctx.log("ok", f"Parámetro {param}: " +
                        ("reflejado" if reflected else "respuesta distinta"))
        except Exception as e:
            ctx.log("warn", f"Error en param {param}: {e}")

    return {"findings": findings}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = []
