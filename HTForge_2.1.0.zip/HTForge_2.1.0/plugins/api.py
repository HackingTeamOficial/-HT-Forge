#!/usr/bin/env python3
"""Safe API surface discovery: OpenAPI/Swagger and common API documentation paths."""
from urllib.parse import urljoin
from plugins._new_detectors_common import req, add
PLUGIN_TYPE="api"; __version__="2.4"; __author__="HT Team"; PHASE="recon"; REQUIRES=[]
CAPABILITY="functional"
PATHS=['/openapi.json','/swagger.json','/swagger/','/api/','/api/docs','/docs','/openapi.yaml','/swagger.yaml']

def run(ctx):
    discovered=[]
    for path in PATHS:
        if ctx.stopped: break
        u=urljoin(ctx.target.rstrip('/')+'/', path.lstrip('/'))
        r=req(ctx,u,allow_redirects=True,timeout=8)
        if r is None: continue
        ctype=str(getattr(r,'headers',{}).get('Content-Type','')).lower()
        text=str(getattr(r,'text','') or '')[:20000]
        if getattr(r,'status_code',0) < 400 and (path.endswith(('.json','.yaml')) or 'swagger' in text.lower() or 'openapi' in text.lower()):
            discovered.append(u)
            ctx.log('url',u)
    ctx.set('api_specs',discovered)
    if discovered:
        add(ctx,PLUGIN_TYPE,'Superficie API / especificación descubierta','info',
            'Se encontró una especificación o documentación API accesible. Esto es descubrimiento, no una vulnerabilidad por sí mismo.',
            discovered[0],{'spec_urls':discovered,'count':len(discovered),'verification_state':'DISCOVERED'},'high')
    return {'findings': []}
