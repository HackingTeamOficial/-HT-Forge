#!/usr/bin/env python3
"""plugins/http_methods.py - Métodos HTTP peligrosos (código puro, stdlib).

No destructivo: solo OPTIONS (lista Allow) y TRACE (prueba XST por reflexión).
No envía PUT/DELETE con cuerpo.
"""

from typing import Dict, List
from core.context import Context


def _headers_lower(resp) -> Dict[str, str]:
    try:
        h = getattr(resp, "headers", {}) or {}
        return {str(k).lower(): str(v) for k, v in dict(h).items()}
    except Exception:
        return {}


def run(ctx: Context) -> Dict:
    """Métodos HTTP permitidos y XST"""
    target = ctx.target.rstrip("/")
    findings: List[Dict] = []
    ctx.log("info", f"Probando métodos HTTP en {target}")

    # 1. OPTIONS: qué métodos anuncia el servidor
    try:
        r = ctx.req("OPTIONS", target, timeout=10)
        allow = _headers_lower(r).get("allow", "")
        if allow:
            methods = [m.strip().upper() for m in allow.split(",") if m.strip()]
            risky = [m for m in methods if m in ("PUT", "DELETE", "TRACE", "TRACK", "CONNECT")]
            if risky:
                findings.append({
                    "type": "http_methods",
                    "severity": "medium",
                    "title": f"Métodos arriesgados permitidos: {', '.join(risky)}",
                    "detail": f"OPTIONS en {target} anuncia Allow: {allow}",
                    "evidence": {"url": target, "allow": allow, "risky": risky},
                    "url": target,
                })
                ctx.log("ok", f"Métodos arriesgados: {risky}")
            else:
                ctx.log("info", f"Allow sin métodos arriesgados: {allow}")
    except Exception as e:
        ctx.log("warn", f"OPTIONS falló: {e}")

    # 2. TRACE: ¿refleja la petición? (XST)
    probe = "HTForge-XST-Probe/1.0"
    try:
        r = ctx.req("TRACE", target, timeout=10,
                    headers={"Max-Forwards": "0", "User-Agent": probe})
        body = getattr(r, "text", "") or ""
        if probe in body or "TRACE " in body:
            findings.append({
                "type": "xst",
                "severity": "medium",
                "title": "TRACE habilitado con reflexión (XST posible)",
                "detail": f"El servidor refleja la petición TRACE en {target}; "
                          "combinado con XSS permite robo de cabeceras/cookies HttpOnly",
                "evidence": {"url": target, "method": "TRACE",
                             "snippet": body[:200]},
                "url": target,
            })
            ctx.log("ok", "TRACE refleja la petición")
    except Exception as e:
        ctx.log("warn", f"TRACE falló: {e}")

    return {"findings": findings}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = []
