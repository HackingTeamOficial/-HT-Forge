"""HT Forge 2.0.0 - Timestamp/hash disclosure detector (propio)."""
import re, time
from plugins._new_detectors_common import req, add, targets, response_text
PLUGIN_TYPE = "timestamp_disclosure"; __version__ = "2.0.0"; __author__ = "HT Team"; PHASE = "recon"; REQUIRES = []
TS_RE = re.compile(r"\b(1[0-9]{9})\b")
HASH_RE = re.compile(r"\b([0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{64})\b", re.I)

def run(ctx):
    now = int(time.time())
    for base in targets(ctx):
        r = req(ctx, base)
        if r is None:
            continue
        text = response_text(r)
        hits = [t for t in set(TS_RE.findall(text)) if now - 315360000 < int(t) < now + 86400]
        if hits:
            add(ctx, PLUGIN_TYPE, "Timestamp Unix expuesto en respuesta",
                "info", "Marcas de tiempo Unix observables que delatan generacion o actividad del sistema.",
                base, {"timestamps": hits[:5]}, "medium")
        hh = [h for h in set(HASH_RE.findall(text)) if not re.fullmatch(r"0+|f+", h, re.I)]
        if hh:
            add(ctx, PLUGIN_TYPE, "Posible hash expuesto en respuesta",
                "info", "Cadenas con formato de hash observables; verificar si corresponden a secretos o datos sensibles.",
                base, {"samples": [h[:12] + "..." for h in hh[:5]]}, "medium")
    return {}
