#!/usr/bin/env python3
"""plugins/dns_audit.py - Auditoría DNS real (código puro, stdlib).

Cliente DNS mínimo sobre UDP/TCP con `struct`: consultas A/NS/MX/TXT/SOA
al resolvedor del sistema (/etc/resolv.conf). Sin dnspython ni dig.
Comprueba SPF, DMARC, MX, diversidad de NS e intento de transferencia AXFR.
"""

import random
import socket
import struct
from typing import Dict, List, Tuple
from urllib.parse import urlparse
from core.context import Context

QTYPE = {"A": 1, "NS": 2, "SOA": 6, "MX": 15, "TXT": 16, "AAAA": 28, "ANY": 255}


def _resolvers(timeout: float = 2.0) -> List[str]:
    servers = []
    try:
        with open("/etc/resolv.conf", encoding="utf-8", errors="replace") as f:
            for line in f:
                p = line.split()
                if len(p) >= 2 and p[0] == "nameserver":
                    servers.append(p[1])
    except Exception:
        pass
    return [s for s in servers if ":" not in s] or ["8.8.8.8"]


def _encode_name(name: str) -> bytes:
    out = b""
    for part in name.rstrip(".").split("."):
        b = part.encode()[:63]
        out += bytes([len(b)]) + b
    return out + b"\x00"


def _read_name(msg: bytes, off: int) -> Tuple[str, int]:
    labels, jumped, orig = [], False, off
    for _ in range(32):
        ln = msg[off]
        if ln & 0xC0 == 0xC0:
            ptr = ((ln & 0x3F) << 8) | msg[off + 1]
            if not jumped:
                orig = off + 2
            off = ptr
            jumped = True
            continue
        if ln == 0:
            off += 1
            break
        off += 1
        labels.append(msg[off:off + ln].decode("utf-8", "replace"))
        off += ln
    return ".".join(labels), (orig if jumped else off)


def _parse(msg: bytes, qtype: int) -> List[str]:
    out: List[str] = []
    try:
        ancount = struct.unpack(">H", msg[6:8])[0]
        off = 12
        for _ in range(2):  # saltar pregunta(s)
            while msg[off] != 0:
                if msg[off] & 0xC0 == 0xC0:
                    off += 2
                    break
                off += 1 + msg[off]
            else:
                off += 1
            off += 4
        for _ in range(min(ancount, 64)):
            _, off = _read_name(msg, off)
            rtype, _, _, rdlen = struct.unpack(">HHHH", msg[off:off + 8])
            off += 8
            rdata = msg[off:off + rdlen]
            if rtype in (2, 5, 12):  # NS/CNAME/PTR
                n, _ = _read_name(msg, off)
                out.append(n)
            elif rtype == 15:  # MX
                pref = struct.unpack(">H", rdata[:2])[0]
                n, _ = _read_name(msg, off + 2)
                out.append(f"{pref} {n}")
            elif rtype == 16:  # TXT
                txt, i = [], 0
                while i < len(rdata):
                    ln = rdata[i]
                    txt.append(rdata[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                    i += 1 + ln
                out.append("".join(txt))
            elif rtype == 1 and rdlen == 4:
                out.append(socket.inet_ntoa(rdata))
            elif rtype == 6:  # SOA
                m, o2 = _read_name(msg, off)
                r, _ = _read_name(msg, o2)
                out.append(f"{m} {r}")
            off += rdlen
    except Exception:
        pass
    return out


def _query(name: str, qtype: str, server: str, timeout: float = 3.0) -> List[str]:
    qid = random.randint(0, 65535)
    pkt = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)
    pkt += _encode_name(name) + struct.pack(">HH", QTYPE[qtype], 1)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(pkt, (server, 53))
        data, _ = s.recvfrom(4096)
    finally:
        s.close()
    if struct.unpack(">H", data[:2])[0] != qid:
        return []
    return _parse(data, QTYPE[qtype])


def _axfr(server_ip: str, domain: str, timeout: float = 4.0) -> bool:
    qid = random.randint(0, 65535)
    pkt = struct.pack(">HHHHHH", qid, 0x0000, 1, 0, 0, 0)
    pkt += _encode_name(domain) + struct.pack(">HH", 252, 1)
    pkt = struct.pack(">H", len(pkt)) + pkt
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((server_ip, 53))
        s.sendall(pkt)
        data = s.recv(4096)
        return len(data) > 4
    except Exception:
        return False
    finally:
        s.close()


def _apex(host: str) -> str:
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def run(ctx: Context) -> Dict:
    """Auditoría DNS: NS/MX/TXT/SPF/DMARC/AXFR"""
    u = urlparse(ctx.target if "://" in ctx.target else "http://" + ctx.target)
    host = (u.hostname or "").lower()
    if not host:
        return {"findings": []}
    domain = _apex(host)
    findings: List[Dict] = []
    ctx.log("info", f"Auditoría DNS de {domain}")

    servers = _resolvers()
    srv = servers[0]
    data: Dict[str, List[str]] = {}
    for qt in ("NS", "MX", "TXT", "SOA"):
        if ctx.stopped:
            break
        try:
            data[qt] = _query(domain, qt, srv)
        except Exception as e:
            ctx.log("warn", f"DNS {qt} falló: {e}")
            data[qt] = []

    # NS: al menos 2 y en subredes distintas (diversidad básica por /24)
    ns = data.get("NS", [])
    if ns and len(ns) < 2:
        findings.append({"type": "dns_ns", "severity": "low",
                         "title": "Un solo servidor NS", "detail": f"{domain} tiene un único NS: {ns[0]}",
                         "evidence": {"ns": ns}, "url": domain})

    # MX ausente con web presente
    if not data.get("MX"):
        findings.append({"type": "dns_mx", "severity": "info", "title": "Sin registros MX",
                         "detail": f"{domain} no publica MX (correo no configurado o externo)",
                         "evidence": {}, "url": domain})
    else:
        ctx.log("ok", f"MX: {', '.join(data['MX'][:3])}")

    # SPF
    txts = data.get("TXT", [])
    spf = [t for t in txts if "v=spf1" in t]
    if not spf:
        findings.append({"type": "dns_spf", "severity": "medium", "title": "Sin registro SPF",
                         "detail": f"{domain} no publica SPF: cualquiera puede suplantar su correo",
                         "evidence": {"txt": txts[:5]}, "url": domain})
    elif any("v=spf1" in t and ("+all" in t or "?all" in t) for t in spf):
        findings.append({"type": "dns_spf", "severity": "medium", "title": "SPF permisivo (+all/?all)",
                         "detail": f"SPF de {domain} autoriza a todos: {spf[0][:120]}",
                         "evidence": {"spf": spf[0][:200]}, "url": domain})
    else:
        ctx.log("ok", "SPF presente")

    # DMARC
    try:
        dmarc = _query(f"_dmarc.{domain}", "TXT", srv)
    except Exception:
        dmarc = []
    if not any("v=DMARC1" in t for t in dmarc):
        findings.append({"type": "dns_dmarc", "severity": "medium", "title": "Sin registro DMARC",
                         "detail": f"_dmarc.{domain} no existe: sin política antiphishing",
                         "evidence": {}, "url": domain})
    else:
        ctx.log("ok", "DMARC presente")

    # AXFR en cada NS
    for n in ns[:4]:
        if ctx.stopped:
            break
        try:
            ip = socket.gethostbyname(n)
        except Exception:
            continue
        if _axfr(ip, domain):
            findings.append({"type": "dns_axfr", "severity": "high",
                             "title": f"Transferencia de zona abierta en {n}",
                             "detail": f"El NS {n} ({ip}) permite AXFR de {domain}: expone todo el inventario DNS",
                             "evidence": {"ns": n, "ip": ip}, "url": domain})
            ctx.log("ok", f"AXFR abierto en {n}")

    ctx.set("dns_audit", {"ns": ns, "mx": data.get("MX", []),
                          "spf": bool(spf), "dmarc": bool(dmarc)})
    return {"findings": findings}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
