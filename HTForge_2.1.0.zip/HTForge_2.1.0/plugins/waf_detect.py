#!/usr/bin/env python3
"""plugins/waf_detect.py - Detección de WAF/CDN por firmas (código puro, stdlib).

Envía una petición normal y una sonda ligeramente maliciosa y analiza
cabeceras, cookies, cuerpo y comportamiento. Sin listas externas.
"""

from typing import Dict, List
from core.context import Context

# (nombre, {cabecera: fragmento} | cookie | cuerpo)
HEADER_SIGS = {
    "Cloudflare": {"server": "cloudflare", "cf-ray": ""},
    "Akamai": {"akamai": "", "x-akamai": ""},
    "Imperva/Incapsula": {"x-iinfo": "", "incap_ses": ""},
    "F5 BIG-IP": {"x-waf-event": "", "bigip": ""},
    "Sucuri": {"x-sucuri": "", "sucuri": ""},
    "AWS WAF/CloudFront": {"x-amz-cf": "", "x-amzn-": ""},
    "Fastly": {"fastly": "", "x-fastly": ""},
    "Edgecast": {"server": "ecacc"},
    "StackPath": {"server": "stackpath"},
    "Barracuda": {"barra": ""},
    "Citrix NetScaler": {"citrix": "", "ns_af": ""},
    "FortiWeb": {"fortiwaf": "", " forti": ""},
    "Palo Alto": {"x-palo": ""},
    "Wordfence": {"wordfence": ""},
    "ModSecurity": {"mod_security": ""},
}
BODY_SIGS = {
    "Cloudflare": ["attention required! | cloudflare", "cf-error"],
    "Imperva/Incapsula": ["incapsula incident", "_incapsula_"],
    "Sucuri": ["sucuri webproxy", "access denied - sucuri"],
    "ModSecurity": ["mod_security", "not acceptable!"],
    "F5 BIG-IP": ["the requested url was rejected", "f5 networks"],
    "AWS WAF": ["aws waf", "request blocked"],
    "FortiWeb": ["fortiwafsid", "fortigate"],
}
COOKIE_SIGS = {
    "Cloudflare": ["__cf_bm", "cf_clearance"],
    "Imperva/Incapsula": ["incap_ses", "visid_incap"],
    "F5 BIG-IP": ["bigip", "f5avr", "f5_cspm"],
    "Sucuri": ["sucuri_cloudproxy"],
    "Akamai": ["ak_bmsc", "_abck"],
    "Wordfence": ["wfvt_", "wordfence_verifiedhuman"],
}


def _hdrs(resp) -> Dict[str, str]:
    try:
        return {str(k).lower(): str(v) for k, v in dict(getattr(resp, "headers", {}) or {}).items()}
    except Exception:
        return {}


def run(ctx: Context) -> Dict:
    """Detecta WAF/CDN por firmas de respuesta"""
    target = ctx.target.rstrip("/")
    findings: List[Dict] = []
    ctx.log("info", f"Detectando WAF en {target}")

    try:
        r_ok = ctx.req("GET", target, timeout=10)
    except Exception as e:
        ctx.log("warn", f"Sin respuesta base: {e}")
        return {"findings": findings}
    try:
        r_bad = ctx.req("GET", target + ("&" if "?" in target else "?") +
                        "htforge=<script>alert(1)</script>", timeout=10)
    except Exception:
        r_bad = None

    detected: Dict[str, List[str]] = {}

    def hit(name: str, why: str):
        detected.setdefault(name, []).append(why)

    for resp, tag in ((r_ok, "base"), (r_bad, "sonda")):
        if resp is None:
            continue
        h = _hdrs(resp)
        blob = " ".join([h.get("server", "")] + list(h.keys()) + list(h.values())).lower()
        cookies = h.get("set-cookie", "")
        body = (getattr(resp, "text", "") or "")[:4000].lower()
        for name, sigs in HEADER_SIGS.items():
            for hk, frag in sigs.items():
                if hk in h and (not frag or frag in h[hk].lower() or frag in blob):
                    hit(name, f"cabecera {hk} ({tag})")
                    break
        for name, frags in BODY_SIGS.items():
            if any(f in body for f in frags):
                hit(name, f"cuerpo ({tag})")
        for name, cks in COOKIE_SIGS.items():
            if any(c.lower() in cookies for c in cks):
                hit(name, f"cookie ({tag})")

    # Cambio de comportamiento ante la sonda = filtrado activo genérico
    if r_bad is not None:
        c0, c1 = getattr(r_ok, "status_code", 0), getattr(r_bad, "status_code", 0)
        if c1 in (400, 403, 406, 419, 429, 501, 509) and c1 != c0:
            hit("WAF genérico", f"sonda → {c1} (base {c0})")

    for name, whys in detected.items():
        findings.append({
            "type": "waf_detected",
            "severity": "info",
            "title": f"WAF/CDN detectado: {name}",
            "detail": f"{target} protegido por {name} ({'; '.join(sorted(set(whys)))})",
            "evidence": {"url": target, "waf": name, "signals": sorted(set(whys))},
            "url": target,
        })
        ctx.log("ok", f"WAF: {name}")
    if not detected:
        ctx.log("info", "Sin firmas de WAF conocidas")

    return {"findings": findings, "waf": sorted(detected)}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
