#!/usr/bin/env python3
"""Detect passwords submitted over cleartext HTTP without attempting login."""
import re
from urllib.parse import urljoin
from core.context import Context

PLUGIN_TYPE='password_exposure'; __version__='2.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=['crawler']
PASSWORD_INPUT = re.compile(r'<input\b[^>]*\btype=["\']?password\b[^>]*>', re.I | re.S)
FORM_RE = re.compile(r'<form\b([^>]*)>(.*?)</form>', re.I | re.S)
ACTION_RE = re.compile(r'\baction=["\']([^"\']*)', re.I)


def run(ctx: Context):
    findings=[]
    urls = list(dict.fromkeys([ctx.target] + (ctx.get('discovered_urls', []) or [])))[:25]
    for page in urls:
        if ctx.stopped: break
        try:
            r=ctx.req('GET', page, timeout=8)
            if getattr(r,'status_code',0) >= 500: continue
            text=getattr(r,'text','') or ''
            for attrs, body in FORM_RE.findall(text):
                if not PASSWORD_INPUT.search(body): continue
                action_m=ACTION_RE.search(attrs)
                action=urljoin(page, action_m.group(1)) if action_m else page
                if action.lower().startswith('http://'):
                    findings.append({
                        'type':PLUGIN_TYPE,'severity':'high','title':'Password Transmitted over HTTP',
                        'detail':'Se detectó un formulario con campo de contraseña cuyo destino es HTTP sin cifrado de transporte.',
                        'confidence':0.99,
                        'evidence':{'page_url':page,'form_action':action,'method':'FORM','password_input':True},
                        'url':action,
                    })
                    ctx.log('ok','Password transmitida por HTTP detectada')
                    break
        except Exception as exc:
            ctx.log('debug',f'password_exposure {page}: {exc}')
    return {'findings':findings}
