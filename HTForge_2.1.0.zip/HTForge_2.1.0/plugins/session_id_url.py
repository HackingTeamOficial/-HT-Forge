"""HT Forge 2.0.0 - Session ID in URL detector (propio)."""
import re
from plugins._new_detectors_common import req, add, targets, response_text
PLUGIN_TYPE = "session_id_url"; __version__ = "2.0.0"; __author__ = "HT Team"; PHASE = "recon"; REQUIRES = []
SID_RE = re.compile(r"(jsessionid|phpsessid|aspsessionid|sessionid|sid)\s*[=:]\s*[^&\"'\s<>]+", re.I)

def run(ctx):
    for base in targets(ctx):
        r = req(ctx, base)
        if r is None:
            continue
        m = SID_RE.search(response_text(r))
        if m:
            add(ctx, PLUGIN_TYPE, "Identificador de sesion en URL",
                "medium", "Identificador de sesion propagado en URLs; se filtra en logs, historial y cabecera Referer.",
                base, {"match": m.group(0)[:80]}, "high")
    return {}
