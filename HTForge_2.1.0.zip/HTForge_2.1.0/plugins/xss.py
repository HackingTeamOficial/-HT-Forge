#!/usr/bin/env python3
"""HT Forge 2.2 - Context-aware XSS detector for authorized assessments.

Detection-only. Uses unique canary markers per probe, analyses the reflection
context (HTML text, attribute, JS string, URL, CSS), and selects context-
appropriate payloads. CSP headers are used as a confidence modifier, not as
a "not vulnerable" gate.
"""
import html as html_module
import re
import secrets
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from core.context import Context
from core.payloads import PayloadCollection
from core.payloads_1_8 import XSS_CONTEXT

# --- Context-specific payloads (all inert: console.log / canary, never alert) ---

XSS_HTML_TEXT = (
    '<img src=x onerror=console.log("{m}")>',
    '<svg/onload=console.log("{m}")>',
    '<details/open/ontoggle=console.log("{m}")>',
    '<body onload=console.log("{m}")>',
    '<iframe srcdoc="<svg/onload=console.log({m})>">',
)

XSS_ATTRIBUTE_QUOTED = (
    '" autofocus onfocus=console.log("{m}") x="',
    '" onmouseover=console.log("{m}") x="',
    '"><img src=x onerror=console.log("{m}")>',
)

XSS_ATTRIBUTE_UNQUOTED = (
    ' autofocus onfocus=console.log("{m}") x=',
    ' onmouseover=console.log("{m}") ',
)

XSS_JS_STRING = (
    '";console.log("{m}");//',
    "';console.log('{m}');//",
    '</script><script>console.log("{m}")</script>',
)

XSS_URL_CONTEXT = (
    'javascript:console.log("{m}")',
    'data:text/html,<script>console.log("{m}")</script>',
)

XSS_CSS_CONTEXT = (
    ';</style><img src=x onerror=console.log("{m}")>',
    'expression(console.log("{m}"))',
)

XSS_GENERIC = PayloadCollection.XSS + XSS_CONTEXT

# Context detection patterns — order matters: most specific first
CONTEXT_PATTERNS = [
    # JS string context: inside <script> ... "value" ... </script>
    ('js_string', re.compile(
        r'<script[^>]*>.*?(["\'])[^"\']*\{M\}[^"\']*\1.*?</script>',
        re.S | re.I)),
    # CSS context: inside <style>...</style>
    ('css_context', re.compile(r'<style[^>]*>.*?\{M\}.*?</style>', re.S | re.I)),
    # Attribute value (quoted): attr="value" or attr='value'
    ('attribute_quoted', re.compile(
        r'\b(?:value|href|src|action|data|title|alt|class|id|style|onclick|onload|onerror)\s*=\s*(["\'])[^"\']*\{M\}[^"\']*\1',
        re.I)),
    # URL context: inside href="..." or src="..." or action="..."
    ('url_context', re.compile(
        r'\b(?:href|src|action|data-src)\s*=\s*(["\'])\s*(?:https?:)?//?[^\s"\'>]*\{M\}',
        re.I)),
    # Attribute value (unquoted): attr=value
    ('attribute_unquoted', re.compile(
        r'\b(?:value|href|src|action|data|title|alt|class|id)\s*=\s*[^\s"\'>]*\{M\}',
        re.I)),
    # HTML text: anywhere else in the body
    ('html_text', re.compile(r'\{M\}', re.S)),
]


def _marker() -> str:
    """Generate a unique canary marker for each probe."""
    return f"HTFORGE_XSS_{secrets.token_hex(4)}"


def _set_query_param(url, param, value):
    p = urlsplit(str(url))
    pairs = parse_qsl(p.query, keep_blank_values=True)
    out, replaced = [], False
    for k, v in pairs:
        if k == param and not replaced:
            out.append((k, value)); replaced = True
        elif k != param:
            out.append((k, v))
    if not replaced:
        out.append((param, value))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out), p.fragment))


def _post(ctx, info, param, payload):
    data = dict(info.get('form_data') or {})
    data[param] = payload
    return ctx.req('POST', str(info.get('url', ctx.target)), data=data,
                   headers={'Content-Type': 'application/x-www-form-urlencoded'},
                   timeout=float(ctx.config.get('xss_request_timeout', 8)))


def _detect_context(marker, text):
    """Detect the reflection context by searching for the marker in the response."""
    escaped_marker = re.escape(marker)
    for ctx_name, pattern in CONTEXT_PATTERNS:
        pat = re.compile(pattern.pattern.replace(r'\{M\}', escaped_marker), pattern.flags)
        if pat.search(text):
            return ctx_name
    return None


def _extract_snippet(marker, text, radius=80):
    """Extract the text around the marker for evidence."""
    idx = text.find(marker)
    if idx == -1:
        escaped = html_module.escape(marker)
        idx = text.find(escaped)
        if idx == -1:
            return ''
    start = max(0, idx - radius)
    end = min(len(text), idx + len(marker) + radius)
    return text[start:end]


def _is_escaped(marker, text):
    """Check if the marker is HTML-escaped in the response."""
    return html_module.escape(marker) in text and marker not in text


def _csp_directives(headers):
    """Extract CSP directives from response headers."""
    csp = ''
    if headers:
        csp = headers.get('Content-Security-Policy', '') or ''
    directives = {}
    for part in csp.split(';'):
        tokens = part.strip().split()
        if tokens:
            directives[tokens[0]] = tokens[1:]
    return directives


def _csp_blocks_inline(directives):
    """Check if CSP blocks inline scripts (no 'unsafe-inline')."""
    if not directives:
        return False
    for src in ('script-src', 'default-src'):
        if src in directives:
            values = directives[src]
            if "'unsafe-inline'" in values:
                return False
            if any(v.startswith("'nonce-") or v.startswith("'sha256-") for v in values):
                return 'partial'
            return True
    return False


def _payloads_for_context(context, marker):
    """Select appropriate payloads for the detected context."""
    m = marker
    if context == 'html_text':
        return [p.format(m=m) for p in XSS_HTML_TEXT]
    elif context == 'attribute_quoted':
        return [p.format(m=m) for p in XSS_ATTRIBUTE_QUOTED]
    elif context == 'attribute_unquoted':
        return [p.format(m=m) for p in XSS_ATTRIBUTE_UNQUOTED]
    elif context == 'js_string':
        return [p.format(m=m) for p in XSS_JS_STRING]
    elif context == 'url_context':
        return [p.format(m=m) for p in XSS_URL_CONTEXT]
    elif context == 'css_context':
        return [p.format(m=m) for p in XSS_CSS_CONTEXT]
    return [p.replace('HTFORGE_XSS', m) if 'HTFORGE_XSS' in p else p for p in XSS_GENERIC[:5]]


def _classify_reflection(marker, text, content_type, status, headers=None):
    """Classify reflection: is it escaped? In what context? Is it executable?"""
    raw = marker in text
    escaped = _is_escaped(marker, text)
    ct = (content_type or '').lower()
    is_html = 'text/html' in ct or 'application/xhtml+xml' in ct

    legacy = headers is None
    if headers is None:
        headers = {}
    if not raw and not escaped:
        return (False, False, None) if legacy else (False, False, None, None, None)

    context = _detect_context(marker, text) if (raw or escaped) else None
    snippet = _extract_snippet(marker, text)

    executable = False
    if raw and is_html and context:
        executable = context in (
            'html_text', 'attribute_quoted', 'attribute_unquoted',
            'js_string', 'url_context', 'css_context'
        )

    if status is not None and int(status) >= 500:
        executable = False

    csp = _csp_directives(headers)
    csp_blocks = _csp_blocks_inline(csp)

    if executable and csp_blocks is True:
        executable = False

    if executable:
        return (raw, True, 'high') if legacy else (raw, True, 'high', context, snippet)
    if raw and is_html:
        return (raw, False, 'medium') if legacy else (raw, False, 'medium', context, snippet)
    if raw:
        return (raw, False, 'low') if legacy else (raw, False, 'low', context, snippet)
    return (False, False, 'low') if legacy else (False, False, 'low', context, snippet)


DOM_SINKS = (
    'location.hash', 'location.search', 'document.write', 'document.writeln',
    '.innerHTML', '.outerHTML', 'eval(', 'setTimeout(', 'setInterval(',
    'Function(', '.html(', 'document.domain',
)


def _dom_sink_scan(ctx, findings):
    seen = set()
    urls = [ctx.target] + [u for u in (ctx.get('discovered_urls', []) or []) if isinstance(u, str) and u.startswith(('http://', 'https://'))][:5]
    for url in urls:
        if url in seen:
            continue
        seen.add(url)
        try:
            r = ctx.req('GET', url, timeout=float(ctx.config.get('xss_request_timeout', 8)))
        except Exception:
            continue
        text = getattr(r, 'text', '') or ''
        hits = sorted({s for s in DOM_SINKS if s in text})
        if hits:
            findings.append({
                'type': 'xss_dom_sink', 'severity': 'info', 'title': 'Posible sumidero DOM',
                'detail': 'Patrones de sumidero DOM observables en JavaScript: %s. Revisar flujo fuente-sumidero.' % ', '.join(hits[:6]),
                'confidence': 0.60,
                'evidence': {'url': url, 'sinks': hits[:6]},
                'url': url,
            })


def run(ctx: Context):
    target = ctx.target
    findings = []
    params = (ctx.get('discovered_params', []) or [
        {'url': target, 'param': 'q', 'method': 'GET'},
        {'url': target, 'param': 'search', 'method': 'GET'},
    ])[:int(ctx.config.get('xss_max_params', 50))]

    ctx.log('info', f'Iniciando detección XSS context-aware en {target}')

    for info in params:
        if ctx.stopped:
            break
        param = str(info.get('param') or '')
        method = str(info.get('method', 'GET')).upper()
        if not param:
            continue

        # Phase 1: Canary probe to detect reflection context
        marker = _marker()
        try:
            if method == 'POST':
                resp = _post(ctx, info, param, marker)
                test_url = str(info.get('url', target))
            else:
                test_url = _set_query_param(info.get('url', target), param, marker)
                resp = ctx.req('GET', test_url, timeout=float(ctx.config.get('xss_request_timeout', 8)))

            text = getattr(resp, 'text', '') or ''
            status = getattr(resp, 'status_code', None)
            ct = getattr(resp, 'headers', {}).get('Content-Type', '') if getattr(resp, 'headers', None) else ''
            headers = getattr(resp, 'headers', {}) or {}

            reflected = marker in text or _is_escaped(marker, text)

            if not reflected:
                continue

            # Escape-test: un segundo marcador con <>" distingue página que
            # escapa (sin reflejo crudo -> FP evitado) de reflejo crudo real.
            esc_marker = _marker() + '<>"'
            try:
                if method == 'POST':
                    _eresp = _post(ctx, info, param, esc_marker)
                else:
                    _eresp = ctx.req('GET', _set_query_param(info.get('url', target), param, esc_marker),
                                     timeout=float(ctx.config.get('xss_request_timeout', 8)))
                _etext = getattr(_eresp, 'text', '') or ''
            except Exception:
                _etext = ''
            if esc_marker not in _etext:
                ctx.log('info', f'XSS: {param} escapa o filtra HTML (sin reflejo crudo, omitido)')
                continue

            context = _detect_context(marker, text)
            snippet = _extract_snippet(marker, text)
            escaped = _is_escaped(marker, text)

            ctx.log('info', f'XSS: {param} refleja marcador (contexto: {context}, escapado: {escaped})')

            # Phase 2: Context-specific payloads with unique markers
            context_marker = _marker()
            context_payloads = _payloads_for_context(context, context_marker)

            for payload in context_payloads:
                if ctx.stopped:
                    break
                payload_marker = _marker()
                payload = payload.replace(context_marker, payload_marker)

                try:
                    if method == 'POST':
                        resp2 = _post(ctx, info, param, payload)
                        payload_url = str(info.get('url', target))
                    else:
                        payload_url = _set_query_param(info.get('url', target), param, payload)
                        resp2 = ctx.req('GET', payload_url, timeout=float(ctx.config.get('xss_request_timeout', 8)))

                    text2 = getattr(resp2, 'text', '') or ''
                    status2 = getattr(resp2, 'status_code', None)
                    ct2 = getattr(resp2, 'headers', {}).get('Content-Type', '') if getattr(resp2, 'headers', None) else ''
                    headers2 = getattr(resp2, 'headers', {}) or {}

                    raw2, executable, severity, ctx2, snippet2 = _classify_reflection(
                        payload_marker, text2, ct2, status2, headers2)

                    if raw2 and severity:
                        csp = _csp_directives(headers2)
                        csp_blocks = _csp_blocks_inline(csp)

                        if executable:
                            title = 'XSS Reflejado (context-aware)'
                            confidence = 0.95
                            if csp_blocks is True:
                                confidence = 0.75
                                title = 'XSS Reflejado (CSP mitiga parcialmente)'
                            elif csp_blocks == 'partial':
                                confidence = 0.85
                        else:
                            title = 'Reflejo no ejecutable (requiere revisión)'
                            confidence = 0.35 if 'text/html' in str(ct2).lower() else 0.25
                            # Segunda evidencia obligatoria: reinyectar con otro marcador.
                            try:
                                _m2 = _marker()
                                _p2 = _payloads_for_context(ctx2, _m2)
                                _ok2 = False
                                for _pp in (_p2[:1] if _p2 else []):
                                    _mm = _marker()
                                    _ppx = _pp.replace(_m2, _mm)
                                    if method == 'POST':
                                        _r3 = _post(ctx, info, param, _ppx)
                                    else:
                                        _r3 = ctx.req('GET', _set_query_param(info.get('url', target), param, _ppx), timeout=float(ctx.config.get('xss_request_timeout', 8)))
                                    _t3 = getattr(_r3, 'text', '') or ''
                                    if _mm in _t3:
                                        _ok2 = True
                                        break
                                if not _ok2:
                                    continue
                            except Exception:
                                continue

                        findings.append({
                            'type': 'xss_reflected',
                            'severity': severity if executable else ('low' if 'text/html' in str(ct2).lower() else 'info'),
                            'title': title,
                            'verification_state': 'VERIFIED' if executable else 'CANDIDATE',
                            'requires_human_review': (not executable),
                            'detail': (
                                f'Payload reflejado sin escapar en parámetro {param}. '
                                f'Contexto de reflexión: {ctx2}. '
                                f'CSP: {"bloquea inline" if csp_blocks is True else "no bloquea" if csp_blocks is False else "parcial (nonce/hash)"}'
                            ),
                            'confidence': confidence,
                            'evidence': {
                                'url': payload_url,
                                'parameter': param,
                                'payload': payload,
                                'marker': payload_marker,
                                'method': method,
                                'response_status': status2,
                                'content_type': ct2,
                                'raw_reflection': True,
                                'reflection_context': ctx2,
                                'escaped': _is_escaped(payload_marker, text2),
                                'snippet': snippet2,
                                'csp_header': csp.get('script-src', csp.get('default-src', [])),
                                'csp_blocks_inline': csp_blocks,
                            },
                            'url': payload_url,
                            'parameter': param,
                            'payload': payload,
                        })
                        ctx.log('ok' if executable else 'info', f'{title} en {param} (contexto: {ctx2})')
                        try:
                            clean = ctx.req('GET', str(info.get('url', target)), timeout=float(ctx.config.get('xss_request_timeout', 8)))
                            clean_text = getattr(clean, 'text', '') or ''
                            if payload_marker in clean_text:
                                findings.append({
                                    'type': 'xss_stored',
                                    'severity': 'high',
                                    'title': 'XSS Almacenado',
                                    'detail': ('Marcador persistente en %s: el payload queda guardado y se refleja en visitas limpias.' % param),
                                    'confidence': 0.90,
                                    'evidence': {'url': str(info.get('url', target)), 'parameter': param, 'marker': payload_marker, 'method': method},
                                    'url': str(info.get('url', target)),
                                    'parameter': param,
                                })
                                ctx.log('ok', 'XSS almacenado en %s' % param)
                        except Exception:
                            pass
                        break
                except (TimeoutError, ConnectionError, RuntimeError) as exc:
                    ctx.log('warn', f'XSS {param}: {exc}')
                except Exception as exc:
                    ctx.log('warn', f'XSS {param}: {exc}')

        except (TimeoutError, ConnectionError, RuntimeError) as exc:
            ctx.log('warn', f'XSS canary {param}: {exc}')
        except Exception as exc:
            ctx.log('warn', f'XSS canary {param}: {exc}')

    try:
        _dom_sink_scan(ctx, findings)
    except Exception:
        pass
    return {'findings': findings}


__version__ = '2.2'
__author__ = 'HT Team'
PHASE = 'attack'
REQUIRES = ['crawler']
