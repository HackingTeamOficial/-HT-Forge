#!/usr/bin/env python3
"""Session cookie security detector with per-cookie parsing."""
from http.cookies import SimpleCookie
from core.context import Context

PLUGIN_TYPE='session_cookies'; __version__='2.0.0'; __author__='HT Team'; PHASE='attack'; REQUIRES=[]


def _set_cookie_values(resp):
    raw_headers=getattr(getattr(resp,'raw',None),'headers',None)
    if raw_headers is not None and hasattr(raw_headers,'get_all'):
        vals=raw_headers.get_all('Set-Cookie') or []
        if vals: return vals
    raw=(getattr(resp,'headers',{}) or {}).get('Set-Cookie','')
    return [raw] if raw else []


def run(ctx):
    findings=[]
    try:
        r=ctx.req('GET',ctx.target,allow_redirects=False,timeout=8)
    except Exception as exc:
        ctx.log('debug',f'session_cookies: {exc}'); return {'findings':[]}
    for raw in _set_cookie_values(r):
        c=SimpleCookie()
        try: c.load(raw)
        except Exception: continue
        for name,morsel in c.items():
            low=raw.lower()
            missing=[]
            if not morsel['secure']: missing.append('Secure')
            if not morsel['httponly']: missing.append('HttpOnly')
            if not morsel['samesite']: missing.append('SameSite')
            if not missing: continue
            # Treat cookies with session-like names as higher-value evidence.
            sessionish=any(x in name.lower() for x in ('session','sess','sid','auth','token','jwt'))
            severity='medium' if sessionish else 'low'
            findings.append({'type':PLUGIN_TYPE,'severity':severity,
                'title':f'Cookie sin atributos de seguridad: {name}',
                'detail':f'La cookie {name} no incluye: {", ".join(missing)}.',
                'confidence':0.98,
                'evidence':{'cookie':name,'missing_attributes':missing,'set_cookie':raw[:1200]},
                'url':ctx.target})
            ctx.log('ok',f'Cookie {name}: faltan {", ".join(missing)}')
    return {'findings':findings}
