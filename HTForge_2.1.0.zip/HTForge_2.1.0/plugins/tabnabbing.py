"""HT Forge 2.0.0 - Reverse tabnabbing detector (propio)."""
import re
from plugins._new_detectors_common import req, add, targets, response_text
PLUGIN_TYPE = "tabnabbing"; __version__ = "2.0.0"; __author__ = "HT Team"; PHASE = "recon"; REQUIRES = []
A_RE = re.compile(r"<a\b([^>]*)>", re.I)

def run(ctx):
    for base in targets(ctx):
        r = req(ctx, base)
        if r is None:
            continue
        for m in A_RE.finditer(response_text(r)):
            a = m.group(1) or ""
            if re.search(r"target\s*=\s*[\"']?_blank", a, re.I) and not re.search(r"noopener", a, re.I):
                add(ctx, PLUGIN_TYPE, "Reverse tabnabbing posible (target=_blank sin noopener)",
                    "low", "Enlace con target=_blank sin rel=noopener; la pagina destino puede controlar window.opener.",
                    base, {"anchor": a.strip()[:200]}, "high")
                break
    return {}
