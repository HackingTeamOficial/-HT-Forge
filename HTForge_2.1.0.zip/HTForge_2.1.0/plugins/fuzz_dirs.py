#!/usr/bin/env python3
"""plugins/fuzz_dirs.py - Fuzzing de directorios y ficheros (código puro, stdlib).

Wordlist integrada. Compara contra la respuesta 404 base para evitar falsos positivos.
"""

from typing import Dict, List
from urllib.parse import urlparse
from core.context import Context

WORDLIST = [
    "admin", "administrator", "login", "wp-admin", "wp-login.php",
    "backup", "backups", "bak", "old", "test", "tests", "dev", "staging",
    ".git/HEAD", ".git/config", ".svn/entries", ".env", ".env.bak",
    "config.php", "config.php.bak", "web.config", "phpinfo.php", "info.php",
    "robots.txt", "sitemap.xml", ".DS_Store", "server-status", "server-info",
    "api", "api/v1", "api/docs", "swagger", "swagger-ui.html", "graphql",
    "console", "manager", "phpmyadmin", "pma", "dbadmin", "tmp", "uploads",
    "files", "private", "secret", "internal", "debug", "trace.axd",
    "elmah.axd", "actuator", "actuator/health", ".well-known/security.txt",
]


def _base(target: str) -> str:
    return target.rstrip("/")


def run(ctx: Context) -> Dict:
    """Fuzzing de rutas comunes"""
    base = _base(ctx.target)
    findings: List[Dict] = []
    ctx.log("info", f"Fuzzing de directorios en {base}")

    # Respuesta base 404 para comparar
    try:
        r404 = ctx.req("GET", base + "/htforge-probe-{:x}".format(abs(hash(base)) % 0xFFFFFF), timeout=10)
        base_status, base_len = r404.status_code, len(r404.text or "")
    except Exception as e:
        ctx.log("warn", f"Sin respuesta base: {e}")
        return {"findings": findings}
    if base_status != 404:
        ctx.log("warn", f"El objetivo no devuelve 404 ({base_status}); fuzzing poco fiable, sigo igual")

    for word in WORDLIST:
        if ctx.stopped:
            break
        url = f"{base}/{word}"
        try:
            r = ctx.req("GET", url, timeout=10)
            st, ln = r.status_code, len(r.text or "")
            if st == 404 and abs(ln - base_len) < 64:
                continue
            if st in (200, 301, 302, 307, 308, 401, 403):
                # 403/401 también es hallazgo (existe pero protegido)
                sev = "medium" if st in (200, 301, 302, 307, 308) else "low"
                findings.append({
                    "type": "fuzz_dir",
                    "severity": sev,
                    "title": f"Ruta interesante: /{word} [{st}]",
                    "detail": f"{url} responde {st} ({ln} bytes; base 404: {base_len} bytes)",
                    "evidence": {"url": url, "status": st, "length": ln,
                                 "baseline_404_length": base_len},
                    "url": url,
                })
                ctx.log("ok", f"Ruta {st}: /{word}")
        except Exception as e:
            ctx.log("warn", f"Error en fuzz /{word}: {e}")

    return {"findings": findings}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "attack"
REQUIRES = []
