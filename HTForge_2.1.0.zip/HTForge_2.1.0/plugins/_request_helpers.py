"""Shared, safe request mutation helpers for HT Forge detectors."""
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def set_query_param(url: str, param: str, value: str) -> str:
    p = urlsplit(str(url))
    pairs = parse_qsl(p.query, keep_blank_values=True)
    out, replaced = [], False
    for key, old in pairs:
        if key == param and not replaced:
            out.append((key, value))
            replaced = True
        elif key != param:
            out.append((key, old))
    if not replaced:
        out.append((param, value))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out, doseq=True), p.fragment))


def request_param(ctx, info: dict, value: str, timeout: float = 8.0):
    """Replay a discovered parameter preserving GET/POST semantics and form data."""
    method = str(info.get("method", "GET")).upper()
    url = str(info.get("url", ctx.target))
    param = str(info.get("param", ""))
    if method == "POST":
        data = dict(info.get("form_data") or {})
        data[param] = value
        return ctx.req(
            "POST", url, data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded", "Connection": "close"},
            timeout=timeout,
        )
    return ctx.req("GET", set_query_param(url, param, value),
                   headers={"Connection": "close"}, timeout=timeout)
