#!/usr/bin/env python3
"""plugins/subdomains.py - Enumeración de subdominios (código puro, stdlib).

Fuerza bruta DNS con el resolvedor del sistema (socket): sin APIs externas,
sin crt.sh, sin binarios. Lista integrada + variaciones con guiones.
"""

import socket
from typing import Dict, List
from urllib.parse import urlparse
from core.context import Context

SUBS = [
    "www", "mail", "ftp", "admin", "blog", "shop", "api", "dev", "test",
    "staging", "stage", "prod", "beta", "demo", "portal", "vpn", "remote",
    "secure", "login", "sso", "auth", "cdn", "static", "assets", "img",
    "media", "docs", "support", "help", "status", "monitor", "grafana",
    "jenkins", "git", "gitlab", "jira", "confluence", "owa", "exchange",
    "webmail", "smtp", "imap", "pop", "ns1", "ns2", "dns", "mx", "web",
    "site", "app", "mobile", "m", "cms", "crm", "erp", "intranet",
    "extranet", "partner", "client", "dashboard", "panel", "cpanel",
    "whm", "webmin", "phpmyadmin", "db", "sql", "backup", "old", "new",
    "v1", "v2", "api1", "api2", "rest", "graphql", "ws", "socket",
]


def _apex(host: str) -> str:
    parts = host.split(".")
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    return host


def run(ctx: Context) -> Dict:
    """Fuerza bruta de subdominios por DNS"""
    u = urlparse(ctx.target if "://" in ctx.target else "http://" + ctx.target)
    host = (u.hostname or "").lower()
    if not host:
        return {"findings": []}
    domain = _apex(host)
    findings: List[Dict] = []
    found: List[Dict] = []
    ctx.log("info", f"Enumerando subdominios de {domain} ({len(SUBS)} candidatos)")

    # Comodín DNS: si *.domain resuelve, los resultados no son fiables
    wildcard_ips: set = set()
    try:
        _, _, ips = socket.gethostbyname_ex(f"htforge-noexiste-{abs(hash(domain)) % 999999}.{domain}")
        wildcard_ips = set(ips)
        ctx.log("warn", f"{domain} tiene wildcard DNS; se filtrará por IP {sorted(wildcard_ips)}")
    except Exception:
        pass

    candidates = list(dict.fromkeys(SUBS + [f"{s}-{d}" for s in ("dev", "test", "api") for d in ("1", "2")]))
    for sub in candidates:
        if ctx.stopped:
            break
        name = f"{sub}.{domain}"
        try:
            _, _, ips = socket.gethostbyname_ex(name)
        except Exception:
            continue
        ips = sorted(set(ips) - wildcard_ips)
        if not ips:
            continue
        found.append({"subdomain": name, "ips": ips})
        findings.append({
            "type": "subdomain",
            "severity": "info",
            "title": f"Subdominio: {name}",
            "detail": f"{name} → {', '.join(ips)}",
            "evidence": {"subdomain": name, "ips": ips, "apex": domain},
            "url": f"http://{name}",
        })
        ctx.log("ok", f"Subdominio {name} → {', '.join(ips)}")

    ctx.set("discovered_subdomains", found)
    return {"findings": findings, "subdomains": found}


__version__ = "2.0.0"
__author__ = "HT Team"
PHASE = "recon"
REQUIRES = []
