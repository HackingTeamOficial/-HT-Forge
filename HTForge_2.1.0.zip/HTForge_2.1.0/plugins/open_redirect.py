#!/usr/bin/env python3
"""Detección de redirecciones abiertas mediante comprobación controlada.

Usa un destino inofensivo reservado (https://example.com/) y nunca sigue la
redirección: solo observa la cabecera Location. Doble confirmación.
"""
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
from core.context import Context
PARAMS = {'next', 'url', 'uri', 'redirect', 'redirect_url', 'return', 'return_url',
          'continue', 'dest', 'destination', 'link', 'target', 'to', 'r', 'u'}
CANARY = 'https://example.com/htforge-probe'
AUTH_NOTE = 'Destinos externos no probados: solo example.com (dominio reservado).'


def _is_evil_redirect(resp):
    try:
        st = int(getattr(resp, 'status_code', 0) or 0)
    except Exception:
        return None
    if st not in (301, 302, 303, 307, 308):
        return None
    loc = str((getattr(resp, 'headers', {}) or {}).get('Location', '') or '')
    if loc.startswith(CANARY):
        return loc
    return None


def _candidates(ctx):
    out, seen = [], set()
    for info in ctx.get('discovered_params', []) or []:
        if not isinstance(info, dict):
            continue
        param = str(info.get('param', ''))
        method = str(info.get('method', 'GET')).upper()
        url = str(info.get('url', ''))
        if param.lower() in PARAMS:
            key = (url, param, method)
            if key not in seen:
                seen.add(key)
                out.append(info)
        # Formulario POST cuya ACTION lleva el destino en query (?next=):
        # el campo no está en el body pero sí en la URL (caso /register?next=).
        if method == 'POST' and '?' in url:
            try:
                qnames = [k for k, _ in parse_qsl(urlsplit(url).query, keep_blank_values=True)]
            except Exception:
                qnames = []
            for qn in qnames:
                if qn.lower() in PARAMS:
                    key = (url, qn, 'POSTQ')
                    if key not in seen:
                        seen.add(key)
                        extra = dict(info)
                        extra['param'] = qn
                        extra['_in_query'] = True
                        out.append(extra)
    # Pareado GET+POST: formulario POST sin query cuya MISMA ruta aparece en
    # una entrada GET con ?next= (el destino viaja en la action, no en el body).
    try:
        _getq = {}
        for info in ctx.get('discovered_params', []) or []:
            if not isinstance(info, dict):
                continue
            if str(info.get('method', 'GET')).upper() != 'GET':
                continue
            try:
                _p = urlsplit(str(info.get('url', '')))
            except Exception:
                continue
            for k, _ in parse_qsl(_p.query, keep_blank_values=True):
                if k.lower() in PARAMS:
                    _getq.setdefault((_p.scheme.lower(), _p.netloc.lower(), _p.path), set()).add(k)
        for info in ctx.get('discovered_params', []) or []:
            if not isinstance(info, dict):
                continue
            if str(info.get('method', 'GET')).upper() != 'POST' or '?' in str(info.get('url', '')):
                continue
            try:
                _p = urlsplit(str(info.get('url', '')))
            except Exception:
                continue
            for qn in _getq.get((_p.scheme.lower(), _p.netloc.lower(), _p.path), ()):
                key = (str(info.get('url', '')), qn, 'POSTQ-PAIR')
                if key not in seen:
                    seen.add(key)
                    extra = dict(info)
                    extra['param'] = qn
                    extra['_in_query'] = True
                    # La URL POST no trae query: injertar el parámetro para que
                    # run() lo sustituya por el canario al construir la petición.
                    _base = str(info.get('url', ''))
                    extra['url'] = _base + ('&' if '?' in _base else '?') + qn + '=htforge'
                    out.append(extra)
    except Exception:
        pass
    return out[:20]


def run(ctx):
    findings = []
    cands = _candidates(ctx)
    if cands:
        ctx.log('info', f'Analizando open redirect en {len(cands)} parámetros')
    for info in cands:
        if ctx.stopped:
            break
        url, param = str(info.get('url', ctx.target)), str(info.get('param', ''))
        method = str(info.get('method', 'GET')).upper()
        in_query = bool(info.get('_in_query'))
        try:
            if method == 'POST' and not in_query:
                data = dict(info.get('form_data') or {})
                data[param] = CANARY
                r1 = ctx.req('POST', url, data=data,
                             headers={'Content-Type': 'application/x-www-form-urlencoded',
                                      'Connection': 'close'},
                             timeout=8, allow_redirects=False)
            else:
                p = urlsplit(url)
                pairs = [(k, CANARY if k == param else v)
                         for k, v in parse_qsl(p.query, keep_blank_values=True)]
                if method == 'POST':
                    data = dict(info.get('form_data') or {})
                    r1 = ctx.req('POST', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                                 data=data,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded',
                                          'Connection': 'close'},
                                 timeout=8, allow_redirects=False)
                else:
                    r1 = ctx.req('GET', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                                 headers={'Connection': 'close'}, timeout=8, allow_redirects=False)
            loc1 = _is_evil_redirect(r1)
            if not loc1:
                continue
            if method == 'POST' and not in_query:
                data = dict(info.get('form_data') or {})
                data[param] = CANARY
                r2 = ctx.req('POST', url, data=data,
                             headers={'Content-Type': 'application/x-www-form-urlencoded',
                                      'Connection': 'close'},
                             timeout=8, allow_redirects=False)
            else:
                p = urlsplit(url)
                pairs = [(k, CANARY if k == param else v)
                         for k, v in parse_qsl(p.query, keep_blank_values=True)]
                if method == 'POST':
                    data = dict(info.get('form_data') or {})
                    r2 = ctx.req('POST', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                                 data=data,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded',
                                          'Connection': 'close'},
                                 timeout=8, allow_redirects=False)
                else:
                    r2 = ctx.req('GET', urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment)),
                                 headers={'Connection': 'close'}, timeout=8, allow_redirects=False)
            loc2 = _is_evil_redirect(r2)
            if not loc2:
                continue
            findings.append({
                'type': 'open_redirect', 'severity': 'medium',
                'title': 'Open Redirect confirmado',
                'detail': f'El parámetro "{param}" redirige de forma reproducible a un destino externo controlado ({CANARY}). {AUTH_NOTE}',
                'confidence': 0.85, 'verification_state': 'VERIFIED',
                'requires_human_review': False,
                'evidence': {'url': url, 'parameter': param, 'method': method,
                             'location': loc2, 'reproduced': True},
                'url': url, 'parameter': param,
            })
            ctx.log('ok', f'Open redirect confirmado en {param}')
        except (TimeoutError, ConnectionError, RuntimeError):
            continue
        except Exception as exc:
            ctx.log('warn', f'Open redirect {param}: {exc}')
    return {'findings': findings}


__version__ = '2.0.0'
__author__ = 'HT Team'
PHASE = 'attack'
REQUIRES = ['crawler']
