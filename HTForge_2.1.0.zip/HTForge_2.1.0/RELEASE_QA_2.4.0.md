# HT Forge 2.4.0 Unified — QA

## Automated validation
- Python compilation: PASS
- Pytest: **17/17 PASS**
- Plugin import audit: PASS
- AI core robustness tests: PASS
- Evidence-state tests: PASS
- Module-health import audit: PASS
- Context report regression test: PASS

## Improvements in this build
- Central evidence lifecycle and evidence-quality metadata.
- Forge Core remains authoritative over AI verdicts.
- Functional OpenAPI/Swagger/API documentation discovery.
- Runtime module-health inventory.
- Fixed Context.get_report() regression.
- UI/API version updated to 2.4.0.

## Manual verification still recommended
1. Run a controlled lab target.
2. Verify HTML/PDF/JSON/CSV/MD/XML/TXT download buttons from the UI.
3. Check Ollama self-test and finding/session analysis with a local model.
4. Review module-health output and exercise modules against a purpose-built test lab.
5. Validate DEMO/PRO/PREMIUM limits and existing license/key behavior.

Existing key/license and Telegram behavior are intentionally preserved.
