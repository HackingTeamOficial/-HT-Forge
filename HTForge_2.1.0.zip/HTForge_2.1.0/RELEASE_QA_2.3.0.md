# HT Forge 2.4.0 Unified — QA

- Limpieza: sin sesiones, DB, reportes ni activación de licencia preexistentes.
- Se conserva el sistema de licencia y Telegram; no se elimina su código.
- Se eliminaron backups de versiones anteriores y cachés Python.
- 100% de los plugins `.py` públicos deben cargar y exponer `run`.
- IA local: Ollama se comprueba con inferencia real JSON, no solo `/api/tags`.
- IA: fallback `/api/generate` → `/api/chat` y reintento estructurado.
- IA: solo lectura; no se permiten acciones externas.
- Descargas: HTML/PDF/JSON/CSV/MD/XML/TXT usan `Content-Disposition: attachment` y descarga por Blob desde la interfaz.
- XSS: clasificación conserva compatibilidad con llamadas antiguas de tres valores y el motor usa el análisis contextual ampliado.

## Nota de verificación
La validación automatizada cubre importación, contratos, lógica de detección y Workbench. La ejecución real contra un objetivo externo no se considera una prueba humana universal: requiere un laboratorio autorizado con respuestas controladas.
