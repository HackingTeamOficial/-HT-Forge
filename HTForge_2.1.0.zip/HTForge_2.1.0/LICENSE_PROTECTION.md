# HT Forge DEMO 2.1.0 — protección de licencia

- Edición: DEMO
- Activación: primer uso válido
- Duración: 7 días desde la primera activación
- Firma de licencia: Ed25519
- Integridad del código: manifiesto firmado Ed25519 + SHA-256

Las claves privadas de emisión y firma de código no forman parte del paquete.
