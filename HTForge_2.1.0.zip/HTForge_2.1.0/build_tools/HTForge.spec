# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

hiddenimports = collect_submodules('core') + collect_submodules('plugins') + collect_submodules('ui') + collect_submodules('ai_core')
datas = []
for pkg in ('ui',):
    datas += collect_data_files(pkg, include_py_files=False)

datas += [
    ('config', 'config'),
    ('security', 'security'),
    ('docs', 'docs'),
    ('reports', 'reports'),
    ('EDITION.json', '.'),
    ('VERSION', '.'),
    ('README.md', '.'),
    ('LICENSE_CLIENT_README.md', '.'),
    ('ai_core', 'ai_core'),
]

block_cipher = None

a = Analysis(
    ['ui/server.py'],
    pathex=['.'],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name='HTForge',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
)
