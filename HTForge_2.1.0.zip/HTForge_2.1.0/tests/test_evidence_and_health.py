from core.context import Context
from core.evidence import correlate
from core.module_health import audit

def test_context_report_and_evidence_state():
    c=Context('http://127.0.0.1:8080')
    c.finding({'type':'xss','title':'candidate','severity':'medium','evidence':{'marker':'abc'}})
    r=c.get_report()
    assert r['findings'][0]['verification_state']=='CANDIDATE'
    assert r['findings'][0]['evidence_quality']=='weak'

def test_ai_cannot_override_core():
    x=correlate({'verification_state':'VERIFIED','evidence':{'baseline':{},'retest':{}}}, {'verdict':'REFUTED','confidence':.99})
    assert x['final_verdict']=='VERIFIED'

def test_module_health_has_no_broken_imports():
    rows=audit()
    assert rows
    assert not [x for x in rows if x.status=='BROKEN']
