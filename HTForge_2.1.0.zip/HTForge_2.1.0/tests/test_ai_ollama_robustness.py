import json, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, '.')
from ai_core import AICore, AIConfig

class BrokenGenerateOllama(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/tags':
            body=json.dumps({'models':[
                {'name':'tiny:1b','size':1000,'details':{'parameter_size':'1B'}},
                {'name':'large:8b','size':8000,'details':{'parameter_size':'8B'}}]}).encode()
            self.send_response(200); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        self.send_error(404)
    def do_POST(self):
        if self.path == '/api/generate': self.send_error(500,'simulated'); return
        if self.path == '/api/chat':
            body=json.dumps({'message':{'content':json.dumps({'classification':'RFI','verdict':'LIKELY','confidence':0.8,'severity':'critical','cwe':'CWE-98','owasp':'A05','cves':[],'cve_status':'none','rationale':'ok','evidence_used':['type'],'remediation':'validate paths','references':[]})}}).encode()
            self.send_response(200); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        self.send_error(404)
    def log_message(self,*args): pass

def test_smallest_model_and_500_fallback():
    srv=ThreadingHTTPServer(('127.0.0.1',0),BrokenGenerateOllama)
    threading.Thread(target=srv.serve_forever,daemon=True).start()
    try:
        ai=AICore(AIConfig(base_url=f'http://127.0.0.1:{srv.server_port}'))
        assert ai.status()['model']=='tiny:1b'
        result=ai.analyze_finding({'type':'rfi','severity':'critical'})
        assert result['classification']=='RFI'
        assert result['cwe']=='CWE-98'
    finally: srv.shutdown()
