import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from ai_core import AICore, AIConfig, AIError


class FakeOllama(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/tags":
            body = json.dumps({"models": [{"name": "hermes3:8b"}, {"name": "tiny:test"}]}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0")); self.rfile.read(n)
        if self.path == "/api/generate":
            body = json.dumps({"response": json.dumps({
                "classification": "sqli",
                "verdict": "CONFIRMED",
                "confidence": 0.94,
                "severity": "high",
                "false_positive_risk": "low",
                "rationale": "Differential evidence is consistent.",
                "evidence_used": ["type", "detail"],
                "remediation": "Use parameterized queries.",
                "references": ["CWE-89"]
            })}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        else:
            self.send_response(404); self.end_headers()

    def log_message(self, *_):
        pass


def test_ai_status_and_finding_analysis(tmp_path):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeOllama)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        cfg = AIConfig(base_url=f"http://127.0.0.1:{srv.server_port}")
        ai = AICore(cfg, tmp_path / "knowledge")
        st = ai.status()
        assert st["ollama"]["ok"] and st["model_available"] and st["read_only"]
        result = ai.analyze_finding({"type": "sqli", "severity": "high", "detail": "boolean differential"})
        assert result["verdict"] == "CONFIRMED" and result["confidence"] == 0.94
        assert result["engine_authority"] == "HT Forge Forge Core"
    finally:
        srv.shutdown()


def test_ai_rejects_action_policy():
    try:
        AIConfig(allow_actions=True).validate()
    except AIError as exc:
        assert "read-only" in str(exc)
    else:
        raise AssertionError("AI actions must remain blocked")
