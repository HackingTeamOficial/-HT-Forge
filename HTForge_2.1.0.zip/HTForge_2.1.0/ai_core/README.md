# HT Forge AI Core

Capa de inteligencia local y **read-only** para HT Forge.

## Proveedor

La primera integración usa **Ollama** en `http://127.0.0.1:11434`.
El preset recomendado es `hermes3:8b`, aunque se puede seleccionar otro modelo instalado.

## Principios

- Forge Core sigue siendo la autoridad para detección y verificación.
- El modelo no ejecuta shell, comandos ni herramientas arbitrarias.
- La IA analiza evidencia ya recogida por HT Forge.
- La configuración por defecto no envía datos a Internet.
- El RAG inicial es local y ligero, sin dependencias externas.
- Las respuestas estructuradas se validan antes de incorporarse a findings.

## Capacidades iniciales

- estado de Ollama y modelos instalados;
- análisis de un finding;
- resumen de sesión;
- correlación/explicación asistida;
- análisis de riesgo de falso positivo;
- recomendaciones de remediación;
- base de conocimiento local preparada para crecer.

## Modelos

`hermes3:8b` es el preset de referencia. Modelos mayores pueden seleccionarse en equipos con recursos suficientes.
