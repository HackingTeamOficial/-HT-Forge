# HT Forge AI Detector - Generate Detection Templates

## Instalación

```bash
pip install -r requirements.txt
```

## Configuración

Edita `config/settings.json` para configurar:

```json
{
  "ollama": {
    "base_url": "http://127.0.0.1:11434",
    "model": "hermes3:8b",
    "timeout": 30
  },
  "detection": {
    "max_templates_per_type": 5,
    "min_confidence": 0.7
  }
}
```

## Uso

```python
from ai_core import AIAnalyzer

analyzer = AIAnalyzer(config_path="config/settings.json")
templates = analyzer.generate_detection_templates("sqli", target_url="https://example.com")
```

## Modelos de IA soportados

### Ollama (Local)
- `hermes3:8b` - Predeterminado
- `llama3.1:8b`
- `llama3.1:70b`
- `mistral`
- `mixtral`

### Modelos de Hermes IA
```python
# Auto-detección de modelos disponibles
models = analyzer.list_available_models()
# Selección explícita de modelo
analyzer.set_model("hermes_code:latest")
```

## Tipos de detección soportados

| Tipo | Descripción |
|------|-------------|
| `sqli` | Inyección SQL (error-based, boolean, time-based) |
| `idor` | Insecure Direct Object Reference / Broken Object Level Authorization |
| `rce` | Remote Code Execution / Command Injection |
| `xss` | Cross-Site Scripting (reflejado, almacenado, DOM) |
| `path_traversal` | Path Traversal / Local File Inclusion |
| `ssrf` | Server-Side Request Forgery |
| `open_redirect` | Open Redirect |
| `ssti` | Server-Side Template Injection |
| `sqli_v2` | SQLi avanzado con detección de columnas y tipo de BD |
| `idor_v2` | IDOR con análisis de relaciones de usuarios |
| `rce_v2` | RCE con detección de PATH y variables de entorno |

## Ejemplo de uso

```python
# Generar templates para SQLi
templates = analyzer.generate_detection_templates("sqli", {
    "endpoint": "/api/users",
    "method": "GET",
    "params": ["id", "user_id", "category"]
})

# Generar templates para XSS
templates = analyzer.generate_detection_templates("xss", {
    "endpoint": "/search",
    "method": "POST",
    "params": ["q", "query", "search"]
})

# Generar templates para IDOR
templates = analyzer.generate_detection_templates("idor", {
    "endpoint": "/api/users",
    "method": "GET",
    "params": ["user_id", "profile_id", "order_id"]
})
```