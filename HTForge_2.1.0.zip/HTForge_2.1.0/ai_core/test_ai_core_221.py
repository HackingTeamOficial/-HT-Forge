import unittest
from ai_core import _extract_json_object, AICore, AIError

class TestAIJson(unittest.TestCase):
    def test_plain_json(self):
        self.assertEqual(_extract_json_object('{"a":1}')['a'], 1)

    def test_markdown_json(self):
        self.assertEqual(_extract_json_object('```json\n{"a":1}\n```')['a'], 1)

    def test_json_embedded_in_prose(self):
        self.assertEqual(_extract_json_object('resultado: {"a":1} fin')['a'], 1)

    def test_invalid_json_is_rejected(self):
        with self.assertRaises(AIError):
            _extract_json_object('esto no es json')

    def test_forge_severity_remains_authoritative(self):
        result = AICore._normalize({'verdict':'LIKELY','confidence':.9,'severity':'critical'},
                                   {'type':'open_port','severity':'info'})
        self.assertEqual(result['severity'], 'info')
        self.assertEqual(result['ai_severity'], 'critical')
        self.assertTrue(result['read_only'])

if __name__ == '__main__':
    unittest.main()
