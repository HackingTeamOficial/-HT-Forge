#!/usr/bin/env python3
"""HT Forge AI Configuration"""

from typing import Any, Dict
from urllib.parse import urlparse


class AIError(RuntimeError):
    """AI-related errors"""
    pass


class AIConfig:
    """Configuration for AI detector"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self._config = config or {}
        
        # Ollama settings
        ollama = self._config.get("ollama", {})
        self.ollama_base_url = ollama.get("base_url", "http://127.0.0.1:11434")
        self.ollama_timeout = ollama.get("timeout", 90)
        self.ollama_model = ollama.get("model", "hermes3:8b")
        self.ollama_enabled = ollama.get("enabled", True)
        
        # vLLM settings
        vllm = self._config.get("vllm", {})
        self.vllm_base_url = vllm.get("base_url", "http://127.0.0.1:8000")
        self.vllm_timeout = vllm.get("timeout", 90)
        self.vllm_enabled = vllm.get("enabled", False)
        
        # Hermes IA settings
        hermes = self._config.get("hermes_ia", {})
        self.hermes_base_url = hermes.get("base_url", "http://127.0.0.1:9000")
        self.hermes_timeout = hermes.get("timeout", 90)
        self.hermes_enabled = hermes.get("enabled", True)
        
        # Claude settings
        claude = self._config.get("claude", {})
        self.claude_enabled = claude.get("enabled", False)
        
        # OpenAI settings
        openai = self._config.get("openai", {})
        self.openai_base_url = openai.get("base_url", "https://api.openai.com/v1")
        self.openai_timeout = openai.get("timeout", 90)
        self.openai_enabled = openai.get("enabled", False)
        
        # Detection settings
        detection = self._config.get("detection", {})
        self.max_templates_per_type = detection.get("max_templates_per_type", 5)
        self.min_confidence = detection.get("min_confidence", 0.7)
        
        # General settings
        self.timeout = self._config.get("timeout", self.ollama_timeout)
        self.default_model = self._config.get("model", self.ollama_model)
    
    def validate(self) -> None:
        """Validate configuration"""
        from urllib.parse import urlparse
        
        # Validate URLs
        for url in [self.ollama_base_url, self.vllm_base_url, self.hermes_base_url, self.openai_base_url]:
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                raise AIError(f"Invalid URL: {url}")
        
        if self.timeout < 5 or self.timeout > 600:
            raise AIError(f"Timeout must be between 5 and 600 seconds, got: {self.timeout}")
    
    def __getitem__(self, key: str) -> Any:
        """Get config value with fallback to environment variables"""
        # Check environment variables first
        env_mapping = {
            "OLLAMA_BASE_URL": "ollama_base_url",
            "OLLAMA_TIMEOUT": "ollama_timeout",
            "OLLAMA_MODEL": "ollama_model",
            "VLLM_BASE_URL": "vllm_base_url",
            "HERMES_BASE_URL": "hermes_base_url",
            "OPENAI_BASE_URL": "openai_base_url",
        }
        
        env_key = env_mapping.get(key.upper())
        if env_key:
            import os
            env_val = os.environ.get(env_key.upper())
            if env_val:
                try:
                    if "TIMEOUT" in env_key or "PORT" in env_key:
                        return int(env_val)
                    return env_val
                except ValueError:
                    pass
        
        # Check internal config
        return self._config.get(key)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return self._config