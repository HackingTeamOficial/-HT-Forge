#!/usr/bin/env python3
"""
HT Forge Ollama Service Manager

Manages Ollama service during scans:
- Stops Ollama when a scan starts to prevent conflicts
- Restarts Ollama when the scan completes
- Automatically manages the service lifecycle

Usage:
    from ai_core.htforge.ollama_manager import OllamaManager
    
    manager = OllamaManager()
    manager.on_scan_start()  # Stops Ollama
    # ... scan runs ...
    manager.on_scan_end()    # Restarts Ollama
"""

import subprocess
import time
import urllib.request
import urllib.error
from typing import Optional, List, Callable


class OllamaManager:
    """Manages Ollama service lifecycle during scans"""
    
    def __init__(self, base_url: str = "http://127.0.0.1:11434", 
                 check_interval: int = 2):
        self.base_url = base_url
        self.check_interval = check_interval
        self._ollama_was_running = False
        self._ollama_pid: Optional[int] = None
    
    def _check_ollama_running(self) -> bool:
        """Check if Ollama is currently running"""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/api/tags",
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                return resp.status == 200
        except:
            return False
    
    def _get_ollama_pid(self) -> Optional[int]:
        """Get Ollama process ID"""
        try:
            result = subprocess.run(
                ["pgrep", "-f", "ollama"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split('\n')
                return int(pids[0])
        except:
            pass
        return None
    
    def _stop_ollama_service(self) -> bool:
        """Stop Ollama service"""
        try:
            # Try graceful stop first
            result = subprocess.run(
                ["ollama", "stop"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            # Wait for service to stop
            for _ in range(10):
                if not self._check_ollama_running():
                    return True
                time.sleep(0.5)
            
            # Force kill if still running
            pid = self._get_ollama_pid()
            if pid:
                subprocess.run(["kill", "-9", str(pid)], timeout=5)
                time.sleep(1)
                return not self._check_ollama_running()
            
            return True
        except Exception as e:
            print(f"[WARN] Failed to stop Ollama: {e}")
            return False
    
    def _start_ollama_service(self) -> bool:
        """Start Ollama service"""
        try:
            # Check if ollama CLI is available
            result = subprocess.run(
                ["which", "ollama"],
                capture_output=True,
                timeout=5
            )
            
            if result.returncode != 0:
                print("[WARN] Ollama CLI not found in PATH")
                return False
            
            # Start Ollama in background
            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            
            # Wait for service to be ready
            for _ in range(20):
                if self._check_ollama_running():
                    return True
                time.sleep(0.5)
            
            return False
        except Exception as e:
            print(f"[WARN] Failed to start Ollama: {e}")
            return False
    
    def on_scan_start(self) -> bool:
        """
        Called when a scan starts.
        Stops Ollama if it was running to prevent conflicts.
        Returns True if Ollama was stopped or wasn't running.
        """
        was_running = self._check_ollama_running()
        self._ollama_was_running = was_running
        
        if was_running:
            print("[INFO] Stopping Ollama service to avoid scan conflicts...")
            return self._stop_ollama_service()
        
        return True
    
    def on_scan_end(self) -> bool:
        """
        Called when a scan ends.
        Restarts Ollama if it was running before the scan.
        Returns True if Ollama was restarted or wasn't running before.
        """
        if not self._ollama_was_running:
            return True
        
        print("[INFO] Restarting Ollama service after scan...")
        return self._start_ollama_service()
    
    def is_ollama_available(self) -> bool:
        """Check if Ollama is available for AI operations"""
        return self._check_ollama_running()


# Global instance for convenience
_manager: Optional[OllamaManager] = None


def get_ollama_manager() -> OllamaManager:
    """Get or create the global Ollama manager instance"""
    global _manager
    if _manager is None:
        _manager = OllamaManager()
    return _manager


def with_ollama_management(scan_func: Callable):
    """
    Decorator/context manager for automatic Ollama management during scans
    
    Usage:
        @with_ollama_management
        def run_scan(target: str):
            engine = get_engine()
            return engine.scan(target)
        
        # Or as context manager:
        with OllamaManager.managed_scan():
            engine.scan(target)
    """
    class OllamaContext:
        def __enter__(self):
            self.manager = get_ollama_manager()
            self.manager.on_scan_start()
            return self
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            self.manager.on_scan_end()
            return False
    
    return OllamaContext


# Convenience class for context manager usage
class ManagedScan:
    """Context manager for automatic Ollama management"""
    
    def __init__(self, base_url: str = "http://127.0.0.1:11434"):
        self.manager = OllamaManager(base_url)
    
    def __enter__(self):
        self.manager.on_scan_start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.manager.on_scan_end()
        return False


if __name__ == "__main__":
    # Test the manager
    manager = OllamaManager()
    
    print("Testing Ollama Service Manager...")
    print(f"Ollama currently running: {manager.is_ollama_available()}")
    
    print("\nSimulating scan start...")
    manager.on_scan_start()
    print(f"Ollama after scan start: {manager.is_ollama_available()}")
    
    print("\nSimulating scan end...")
    manager.on_scan_end()
    print(f"Ollama after scan end: {manager.is_ollama_available()}")