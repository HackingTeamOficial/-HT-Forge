#!/usr/bin/env python3
"""
Ollama Service Integration for HT Forge Engine

This module patches the HT Forge Engine to automatically manage Ollama service
during scans. When a scan starts, Ollama is stopped if running to prevent conflicts.
When the scan ends, Ollama is restarted.

Integration instructions:
1. Import this module before running a scan
2. The Engine class will automatically manage Ollama

Usage:
    import ollama_integration
    
    from core.engine import Engine
    
    engine = Engine()
    # Ollama will be managed automatically during scan()
    engine.scan("https://target.com")
"""

import functools
import time
from typing import Optional, Dict

# Singleton manager instance
_ollama_manager = None

def _get_ollama_manager():
    """Get or create Ollama manager singleton"""
    global _ollama_manager
    if _ollama_manager is None:
        # Import here to avoid circular imports
        from htforge.ollama_manager import OllamaManager
        _ollama_manager = OllamaManager()
    return _ollama_manager


def _should_manage_ollama() -> bool:
    """Check if Ollama management is enabled"""
    import os
    return os.environ.get("HTFORGE_MANAGE_OLLAMA", "false").lower() in ("true", "1", "yes")


def integrate_ollama_management():
    """
    Integrate Ollama management into the HT Forge Engine.
    
    This patches the Engine.scan() method to automatically:
    1. Stop Ollama when a scan starts (if it was running)
    2. Restart Ollama when the scan completes
    """
    from core.engine import Engine
    
    original_scan = Engine.scan
    
    @functools.wraps(original_scan)
    def patched_scan(self, target: str, profile: str = 'full', options: Optional[Dict] = None):
        if not _should_manage_ollama():
            return original_scan(self, target, profile, options)
        
        manager = _get_ollama_manager()
        was_running = manager.is_ollama_available()
        manager._ollama_was_running = was_running
        
        if was_running:
            print("[INFO] Stopping Ollama service to avoid scan conflicts...")
            manager.on_scan_start()
        
        try:
            return original_scan(self, target, profile, options)
        finally:
            if was_running:
                print("[INFO] Restarting Ollama service after scan...")
                manager.on_scan_end()
    
    Engine.scan = patched_scan
    print("[INFO] Ollama service management integrated into Engine.scan()")
    return True


# Auto-integration when module is imported
# Set HTFORGE_AUTO_INTEGRATE_OLLAMA=0 to disable auto-integration
if _should_manage_ollama():
    try:
        integrate_ollama_management()
    except Exception as e:
        print(f"[WARN] Could not auto-integrate Ollama management: {e}")


# Manual integration function for explicit use
def setup_ollama_lifecycle():
    """Set up Ollama lifecycle management. Call this before creating Engine."""
    return integrate_ollama_management()


if __name__ == "__main__":
    # Test the integration
    print("Testing Ollama Integration...")
    manager = _get_ollama_manager()
    print(f"Ollama currently: {'running' if manager.is_ollama_available() else 'stopped'}")
    
    if _should_manage_ollama():
        print("Ollama management is enabled")
        integrate_ollama_management()
    else:
        print("Ollama management is disabled (set HTFORGE_MANAGE_OLLAMA=1 to enable)")