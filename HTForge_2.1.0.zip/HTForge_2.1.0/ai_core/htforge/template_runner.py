#!/usr/bin/env python3
"""HT Forge 2.2 - Template Runner: bridge between AI templates and scanning pipeline.

Validates AI-generated templates against safety rules before execution.
Never executes payloads that are not on the approved allowlist.

Usage:
    from ai_core.htforge.template_runner import TemplateRunner
    runner = TemplateRunner(ctx)
    templates = runner.generate_and_validate("sqli", {
        "endpoint": "/api/users",
        "method": "GET",
        "params": ["id"]
    })
    for t in templates:
        resp = runner.execute(t)
"""

import re
from typing import List, Dict, Tuple
from .detector_ai import DetectionTemplate, AIAnalyzer


# Allowlist of approved payload patterns (regex). AI-generated payloads must
# match at least one to be considered for execution.
ALLOWED_PAYLOAD_PATTERNS = [
    # SQLi: error probes (inert syntax breakers)
    re.compile(r"^['\";)\s]+$"),
    re.compile(r"^.*--\s*-$"),
    re.compile(r"^.*AND\s+\d+=\d+$", re.I),
    re.compile(r"^.*AND\s+\d+=\d+\s*$", re.I),
    # XSS: canary markers only (no alert, no external resources)
    re.compile(r"^.*console\.log\(.*\).*$"),
    re.compile(r"^<img\s+src=x\s+onerror=console\.log\(.*\)>$"),
    re.compile(r"^<svg/onload=console\.log\(.*\)>$"),
    # IDOR: numeric variants only
    re.compile(r"^\d+$"),
    # SSTI: math expressions only
    re.compile(r"^\{\{\d+[\*+]\d+\}\}$"),
    re.compile(r"^\$\{\d+[\*+]\d+\}$"),
]

# Blocked payload patterns (never execute, even if AI suggests them)
BLOCKED_PATTERNS = [
    re.compile(r"alert\s*\(", re.I),
    re.compile(r"document\.cookie", re.I),
    re.compile(r"window\.location", re.I),
    re.compile(r"fetch\s*\(", re.I),
    re.compile(r"XMLHttpRequest", re.I),
    re.compile(r"eval\s*\(", re.I),
    re.compile(r"DROP\s+TABLE", re.I),
    re.compile(r"INSERT\s+INTO", re.I),
    re.compile(r"DELETE\s+FROM", re.I),
    re.compile(r"UPDATE\s+.*SET", re.I),
    re.compile(r"UNION\s+SELECT", re.I),
    re.compile(r"SLEEP\s*\(", re.I),
    re.compile(r"BENCHMARK\s*\(", re.I),
]

# Allowed categories
ALLOWED_CATEGORIES = {
    'error_based', 'boolean', 'reflection', 'path', 'detection',
    'canary', 'syntax_probe', 'differential',
}


class TemplateValidator:
    """Validate AI-generated templates against safety rules."""

    @staticmethod
    def validate(template: DetectionTemplate) -> Tuple[bool, str]:
        """Returns (valid, reason)."""
        payload = template.payload.strip()

        if not payload:
            return False, "Empty payload"

        for pattern in BLOCKED_PATTERNS:
            if pattern.search(payload):
                return False, f"Blocked pattern matched: {pattern.pattern}"

        allowed = any(pattern.search(payload) for pattern in ALLOWED_PAYLOAD_PATTERNS)
        if not allowed:
            return False, "Payload does not match any allowed pattern"

        if template.category not in ALLOWED_CATEGORIES:
            return False, f"Category '{template.category}' not in allowlist"

        if template.confidence < 0.5:
            return False, "Confidence below threshold"

        return True, "OK"


class TemplateRunner:
    """Bridge between AI templates and the scanning pipeline."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.analyzer = AIAnalyzer()
        self.validator = TemplateValidator()

    def generate_and_validate(self, vuln_type: str, target_info: Dict = None) -> List[DetectionTemplate]:
        """Generate templates via AI and filter through validation."""
        try:
            raw_templates = self.analyzer.generate_detection_templates(vuln_type, target_info)
        except Exception as e:
            self.ctx.log('warn', f'AI template generation failed: {e}')
            return []

        validated = []
        for t in raw_templates:
            ok, reason = self.validator.validate(t)
            if ok:
                validated.append(t)
            else:
                self.ctx.log('debug', f'AI template rejected: {reason} (payload: {t.payload[:50]})')

        self.ctx.log('info', f'AI templates: {len(validated)}/{len(raw_templates)} validated for {vuln_type}')
        return validated

    def execute(self, template: DetectionTemplate):
        """Execute a validated template against the target."""
        ok, reason = self.validator.validate(template)
        if not ok:
            self.ctx.log('warn', f'Refusing to execute unvalidated template: {reason}')
            return None

        url = template.endpoint_pattern
        if not url.startswith('http'):
            url = self.ctx.target.rstrip('/') + '/' + url.lstrip('/')

        method = template.http_method or 'GET'

        try:
            if method == 'GET':
                from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
                p = urlsplit(url)
                pairs = parse_qsl(p.query, keep_blank_values=True)
                if pairs and template.params:
                    pairs[0] = (template.params[0], template.payload)
                elif template.params:
                    pairs = [(template.params[0], template.payload)]
                test_url = urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), p.fragment))
                return self.ctx.req('GET', test_url, timeout=10)
            elif method == 'POST':
                data = {p: template.payload for p in template.params} if template.params else {'q': template.payload}
                return self.ctx.req('POST', url, data=data, timeout=10)
        except Exception as e:
            self.ctx.log('warn', f'Template execution failed: {e}')
            return None


__all__ = ['TemplateRunner', 'TemplateValidator']
