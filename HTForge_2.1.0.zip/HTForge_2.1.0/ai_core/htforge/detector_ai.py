#!/usr/bin/env python3
"""
HT Forge AI Detector - Generate Detection Templates for Security Testing

Multi-provider support: Ollama, Hermes IA, Claude, OpenClaw, vLLM, Opencode

This module provides AI-powered template generation for detecting:
- IDOR/BOLA
- RCE/Command Injection  
- SQLi (Error, Boolean, Time-based)
- XSS (Reflected, Stored, DOM)
- Path Traversal
- SSRF
- Open Redirect
- SSTI
- And more...

Usage:
    from ai_core.htforge import AIAnalyzer
    
    analyzer = AIAnalyzer()
    templates = analyzer.generate_detection_templates("sqli", {
        "endpoint": "/api/users",
        "method": "GET", 
        "params": ["id", "user_id"]
    })
    
    # Or use convenience functions
    from ai_core.htforge import generate_sqli_templates
    templates = generate_sqli_templates({
        "endpoint": "/search",
        "params": ["q", "query"]
    }, model="hermes3:8b")
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import os
import time
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from abc import ABC, abstractmethod


# Import from local config
from .config import AIConfig, AIError as ConfigAIError


@dataclass
class ModelInfo:
    """Information about an available model"""
    name: str
    provider: str
    size: str = ""
    modified_at: str = ""
    digest: str = ""


@dataclass 
class DetectionTemplate:
    """A detection template for security testing"""
    vulnerability_type: str
    payload: str
    confidence: float
    category: str  # error_based, boolean, time_based, reflection, etc.
    endpoint_pattern: str
    http_method: str = "GET"
    params: List[str] = field(default_factory=list)
    headers: Dict[str, str] = field(default_factory=dict)
    data: Dict[str, str] = field(default_factory=dict)
    description: str = ""
    references: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            "vulnerability_type": self.vulnerability_type,
            "payload": self.payload,
            "confidence": self.confidence,
            "category": self.category,
            "endpoint_pattern": self.endpoint_pattern,
            "http_method": self.http_method,
            "params": self.params,
            "headers": self.headers,
            "data": self.data,
            "description": self.description,
            "references": self.references
        }


# Use AIError from config
AIError = ConfigAIError


# ============== Provider Interfaces ==============

class BaseProvider(ABC):
    """Abstract base for AI providers"""
    
    @abstractmethod
    def list_models(self) -> List[str]:
        """List available models"""
        pass
    
    @abstractmethod
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate text with a model"""
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if provider is available"""
        pass


# ============== Ollama Provider ==============

class OllamaProvider(BaseProvider):
    """Client for Ollama API - Local AI models"""
    
    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: int = 90):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._model_cache = []
        self._cache_time = 0
        
    def _request(self, path: str, payload: Optional[dict] = None) -> dict:
        """Make request to Ollama API"""
        url = self.base_url + path
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        
        headers = {"Content-Type": "application/json"}
        req = urllib.request.Request(url, data=data, headers=headers,
                                     method="POST" if payload else "GET")
        
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                detail=e.read().decode("utf-8", "replace")[:500]
            except Exception:
                detail=str(e)
            raise AIError(f"Ollama HTTP {e.code}: {detail}") from e
        except urllib.error.URLError as e:
            raise AIError(f"Ollama no disponible en {self.base_url}: {e.reason}") from e
        except json.JSONDecodeError as e:
            raise AIError(f"Ollama devolvió JSON no válido: {e}") from e
    
    def is_available(self) -> bool:
        """Check if Ollama is available"""
        try:
            resp = self._request("/api/tags")
            return True
        except:
            return False
    
    def list_models(self) -> List[str]:
        """List available models"""
        if time.time() - self._cache_time < 30 and self._model_cache:
            return self._model_cache
            
        try:
            resp = self._request("/api/tags")
            models = resp.get("models", [])
            self._model_cache = [m["name"] for m in models if isinstance(m, dict)]
            self._cache_time = time.time()
            return self._model_cache
        except Exception:
            return []
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate text with a model, preferring Ollama's JSON mode when requested."""
        return self._generate(prompt, model, system, json_mode=False)

    def generate_structured(self, prompt: str, model: str, system: str = "") -> str:
        """Generate a syntactically valid JSON document using Ollama's native JSON mode."""
        return self._generate(prompt, model, system, json_mode=True)

    def _generate(self, prompt: str, model: str, system: str = "", json_mode: bool = False) -> str:
        payload = {
            "model": model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {"temperature": 0.0 if json_mode else 0.1, "num_predict": 4096},
        }
        if json_mode:
            payload["format"] = "json"
        try:
            resp = self._request("/api/generate", payload)
            return str(resp.get("response", "")).strip()
        except AIError as first:
            chat = {
                "model": model,
                "messages": ([{"role": "system", "content": system}] if system else [])
                           + [{"role": "user", "content": prompt}],
                "stream": False,
                "options": {"temperature": 0.0 if json_mode else 0.1, "num_predict": 4096},
            }
            if json_mode:
                chat["format"] = "json"
            try:
                resp = self._request("/api/chat", chat)
                msg = resp.get("message") or {}
                text = msg.get("content", "") if isinstance(msg, dict) else ""
                if text:
                    return text.strip()
            except AIError:
                pass
            raise first



# ============== vLLM Provider ==============

class VLLMProvider(BaseProvider):
    """Client for vLLM API"""
    
    def __init__(self, base_url: str = "http://127.0.0.1:8000", timeout: int = 90):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
    def is_available(self) -> bool:
        """Check if vLLM is available"""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/health",
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except:
            return False
    
    def list_models(self) -> List[str]:
        """List available models via vLLM API"""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/v1/models",
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
                return [m["id"] for m in data.get("data", [])]
        except Exception:
            return []
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate text via vLLM API"""
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system} if system else {},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.1,
            "max_tokens": 2048,
            "stop": ["\n\n", "###"]
        }
        payload = {k: v for k, v in payload.items() if v}
        
        req = urllib.request.Request(
            f"{self.base_url}/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read().decode())
            return data["choices"][0]["message"]["content"].strip()


# ============== Opencode Provider ==============

class OpencodeProvider(BaseProvider):
    """Client for Opencode CLI tool"""
    
    def __init__(self, timeout: int = 120):
        self.timeout = timeout
        
    def is_available(self) -> bool:
        """Check if opencode CLI is available"""
        try:
            result = subprocess.run(
                ["which", "opencode"],
                capture_output=True, timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def list_models(self) -> List[str]:
        """Opencode doesn't have centralized model listing"""
        return ["opencode:default"]
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate using opencode CLI"""
        cmd = ["opencode", "--model", model]
        if system:
            cmd.extend(["--system", system])
        cmd.append(prompt)
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            return result.stdout.strip()
        except subprocess.TimeoutExpired:
            raise AIError(f"Opencode timeout after {self.timeout}s")
        except Exception as e:
            raise AIError(f"Opencode error: {e}")


# ============== Hermes IA Provider ==============

class HermesIAProvider(BaseProvider):
    """Client for Hermes IA models running locally"""
    
    def __init__(self, base_url: str = "http://127.0.0.1:9000", timeout: int = 90):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
    def is_available(self) -> bool:
        """Check if Hermes IA is available"""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/health",
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except:
            return False
    
    def list_models(self) -> List[str]:
        """List Hermes IA models"""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/models",
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
                return data.get("models", [])
        except:
            return []
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate using Hermes IA API"""
        payload = {
            "model": model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "temperature": 0.1,
            "max_tokens": 2048
        }
        
        req = urllib.request.Request(
            f"{self.base_url}/generate",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read().decode())
            return data.get("response", data.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()


# ============== Claude Provider ==============

class ClaudeProvider(BaseProvider):
    """Client for Claude via Anthropic API"""
    
    def __init__(self, api_key: Optional[str] = None, timeout: int = 90):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.timeout = timeout
        self.base_url = "https://api.anthropic.com/v1"
        
    def is_available(self) -> bool:
        """Check if Claude API key is configured"""
        return bool(self.api_key)
    
    def list_models(self) -> List[str]:
        """Claude models"""
        return ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"]
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        """Generate using Claude API"""
        if not self.api_key:
            raise AIError("Claude API key not configured. Set ANTHROPIC_API_KEY environment variable.")
        
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        
        payload = {
            "model": model,
            "max_tokens": 2048,
            "temperature": 0.1,
            "messages": []
        }
        
        if system:
            payload["system"] = system
        
        if "sonnet" in model or "haiku" in model:
            payload["messages"].append({"role": "user", "content": prompt})
        else:
            payload["messages"].append({"role": "user", "content": prompt})
        
        req = urllib.request.Request(
            f"{self.base_url}/messages",
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST"
        )
        
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
                return data["content"][0]["text"].strip()
        except urllib.error.HTTPError as e:
            raise AIError(f"Claude API error: {e.code} {e.reason}")


# ============== OpenAI Provider ==============

class OpenAIProvider(BaseProvider):
    """Client for OpenAI-compatible APIs (including o1, o3, etc.)"""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, timeout: int = 90):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.base_url = base_url or "https://api.openai.com/v1"
        self.timeout = timeout
        
    def is_available(self) -> bool:
        return bool(self.api_key)
    
    def list_models(self) -> List[str]:
        try:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            req = urllib.request.Request(
                f"{self.base_url}/models",
                headers=headers
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode())
                return [m["id"] for m in data.get("data", [])]
        except:
            return []
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        if not self.api_key:
            raise AIError("OpenAI API key not configured")
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model,
            "messages": [],
            "temperature": 0.1,
            "max_tokens": 2048
        }
        
        if system:
            payload["messages"].append({"role": "system", "content": system})
        payload["messages"].append({"role": "user", "content": prompt})
        
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read().decode())
            return data["choices"][0]["message"]["content"].strip()


# ============== Claude Code Provider ==============

class ClaudeCodeProvider(BaseProvider):
    """Client for Claude Code CLI"""
    
    def __init__(self, timeout: int = 120):
        self.timeout = timeout
        
    def is_available(self) -> bool:
        try:
            result = subprocess.run(
                ["which", "claude"],
                capture_output=True, timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def list_models(self) -> List[str]:
        return ["claude-code:default"]
    
    def generate(self, prompt: str, model: str, system: str = "") -> str:
        cmd = ["claude", "-p", prompt]
        if system:
            cmd = ["claude", "--system", system, "-p", prompt]
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            return result.stdout.strip()
        except subprocess.TimeoutExpired:
            raise AIError(f"Claude Code timeout")
        except Exception as e:
            raise AIError(f"Claude Code error: {e}")


# ============== Provider Manager ==============

class ProviderManager:
    """Manages multiple AI providers with auto-selection"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.providers: Dict[str, BaseProvider] = {}
        self._initialize_providers()
    
    def _initialize_providers(self):
        """Initialize all available providers"""
        ollama_config = self.config.get("ollama", {})
        
        # Initialize providers based on config
        if ollama_config.get("enabled", True):
            self.providers["ollama"] = OllamaProvider(
                base_url=ollama_config.get("base_url", "http://127.0.0.1:11434"),
                timeout=ollama_config.get("timeout", 90)
            )
        
        if self.config.get("vllm", {}).get("enabled", False):
            self.providers["vllm"] = VLLMProvider(
                base_url=self.config.get("vllm", {}).get("base_url", "http://127.0.0.1:8000"),
                timeout=self.config.get("vllm", {}).get("timeout", 90)
            )
        
        if self.config.get("hermes_ia", {}).get("enabled", False):
            self.providers["hermes_ia"] = HermesIAProvider(
                base_url=self.config.get("hermes_ia", {}).get("base_url", "http://127.0.0.1:9000"),
                timeout=self.config.get("hermes_ia", {}).get("timeout", 90)
            )
        
        # CLI providers (always try to detect)
        cli_providers = [
            ("opencode", OpencodeProvider),
            ("claude", ClaudeCodeProvider),
        ]
        
        for name, cls in cli_providers:
            try:
                self.providers[name] = cls(timeout=self.config.get("cli_timeout", 120))
            except:
                pass
        
        # API providers (need keys)
        if self.config.get("claude", {}).get("enabled", False):
            self.providers["claude"] = ClaudeProvider(
                api_key=os.environ.get("ANTHROPIC_API_KEY"),
                timeout=self.config.get("claude", {}).get("timeout", 90)
            )
        
        if self.config.get("openai", {}).get("enabled", False):
            self.providers["openai"] = OpenAIProvider(
                api_key=os.environ.get("OPENAI_API_KEY"),
                base_url=self.config.get("openai", {}).get("base_url", "https://api.openai.com/v1"),
                timeout=self.config.get("openai", {}).get("timeout", 90)
            )
    
    def get_available_providers(self) -> List[str]:
        """Get list of available providers"""
        return [name for name, provider in self.providers.items() 
                if provider.is_available()]
    
    def get_provider(self, name: str) -> Optional[BaseProvider]:
        """Get a specific provider by name"""
        return self.providers.get(name)
    
    def auto_select_provider(self) -> Tuple[str, BaseProvider]:
        """Auto-select the best available provider with priority"""
        # Priority order for providers
        priority = ["hermes_ia", "ollama", "vllm", "opencode", "claude", "claude", "openai"]
        
        available = self.get_available_providers()
        
        for p in priority:
            if p in available:
                return p, self.providers[p]
        
        # Keep the local Ollama provider visible even when the service is
        # temporarily offline. The GUI can then show its real status and
        # recover as soon as Ollama starts, instead of disabling AI entirely.
        if available:
            provider = available[0]
            return provider, self.providers[provider]
        if "ollama" in self.providers:
            return "ollama", self.providers["ollama"]
        raise AIError("No hay un proveedor de IA configurado.")


# ============== AI Analyzer ==============

class AIAnalyzer:
    """Main AI analyzer for generating detection templates"""
    
    VULNERABILITY_TYPES = [
        "sqli", "idor", "rce", "xss", "path_traversal", 
        "ssrf", "open_redirect", "ssti", "xss_dombased",
        "sqli_time", "idor_bola", "rce_command", "ssrf_metadata",
        "csrf", "headers", "auth_bypass", "mass_assignment"
    ]
    
    # Default configuration
    DEFAULT_CONFIG = {
        "ollama": {
            "base_url": "http://127.0.0.1:11434",
            "timeout": 90,
            "enabled": True,
            "model": "hermes3:8b"
        },
        "detection": {
            "max_templates_per_type": 5,
            "min_confidence": 0.7
        },
        "cli_timeout": 120
    }
    
    def __init__(self, config_path: str = None, config: Dict = None):
        """Initialize AI analyzer"""
        if config:
            self.config = {**self.DEFAULT_CONFIG, **config}
        elif config_path and Path(config_path).exists():
            with open(config_path) as f:
                self.config = {**self.DEFAULT_CONFIG, **json.load(f)}
        else:
            self.config = self.DEFAULT_CONFIG
        
        self.prov_manager = ProviderManager(self.config)
        self._current_provider = None
        self._current_model = None
        self.max_templates = self.config["detection"]["max_templates_per_type"]
        
        # Auto-select provider
        self._auto_select_provider()
    
    def _auto_select_provider(self):
        """Auto-select the best available provider"""
        self._current_provider, provider = self.prov_manager.auto_select_provider()
        
        models = provider.list_models()
        if models:
            self._current_model = models[0]
        else:
            # Default models per provider
            defaults = {
                "ollama": "hermes3:8b",
                "vllm": "meta-llama/Meta-Llama-3.1-8B-Instruct",
                "hermes_ia": "hermes-code",
                "opencode": "opencode:default",
                "claude": "claude-3-sonnet-20240229",
                "openai": "gpt-4o-mini"
            }
            self._current_model = defaults.get(self._current_provider, "default")
    
    def list_available_providers(self) -> List[str]:
        """List available AI providers"""
        return self.prov_manager.get_available_providers()
    
    def list_available_models(self) -> Dict[str, List[str]]:
        """List available models for each provider"""
        result = {}
        for name, provider in self.providers.items():
            if provider.is_available():
                result[name] = provider.list_models()
        return result
    
    @property
    def providers(self) -> Dict:
        return self.prov_manager.providers
    
    @property
    def current_provider(self) -> str:
        return self._current_provider or "ollama"
    
    @property
    def current_model(self) -> str:
        return self._current_model
    
    def set_provider(self, name: str) -> bool:
        """Set the provider to use"""
        if name not in self.providers:
            raise AIError(f"Unknown provider: {name}")
        
        provider = self.providers[name]
        if not provider.is_available():
            raise AIError(f"Provider {name} is not available")
        
        self._current_provider = name
        models = provider.list_models()
        self._current_model = models[0] if models else "default"
        return True
    
    def set_model(self, model: str, provider: str = None) -> bool:
        """Set the model to use"""
        target_provider = provider or self._current_provider
        
        if target_provider not in self.providers:
            raise AIError(f"Unknown provider: {target_provider}")
        
        p = self.providers[target_provider]
        if not p.is_available():
            raise AIError(f"Provider {target_provider} is not available")
        
        models = p.list_models()
        if model not in models and models:
            raise AIError(f"Model {model} not available in {target_provider}. Available: {models}")
        
        self._current_model = model
        if not provider:
            self._current_provider = target_provider
        return True
    
    def _generate_with_provider(self, provider: BaseProvider, model: str, 
                                 prompt: str, system: str) -> str:
        """Generate text with a specific provider"""
        return provider.generate(prompt, model, system)
    
    def generate_detection_templates(self, vuln_type: str, 
                                     target_info: Optional[Dict] = None,
                                     model: Optional[str] = None,
                                     provider: Optional[str] = None) -> List[DetectionTemplate]:
        """Generate detection templates for a vulnerability type"""
        
        if vuln_type not in self.VULNERABILITY_TYPES:
            raise AIError(f"Unknown vulnerability type: {vuln_type}")
        
        if target_info is None:
            target_info = {
                "endpoint": "/api",
                "method": "GET",
                "params": ["id", "user_id", "q"]
            }
        
        # Determine provider and model
        use_provider = provider or self._current_provider
        use_model = model or self._current_model
        
        if use_provider not in self.providers:
            self._auto_select_provider()
            use_provider = self._current_provider
        
        provider_instance = self.providers[use_provider]
        if not provider_instance.is_available():
            raise AIError(f"Provider {use_provider} is not available")
        
        if use_model not in provider_instance.list_models():
            use_model = self._current_model
        
        return self._generate_templates(vuln_type, target_info, provider_instance, use_model)
    
    def _generate_templates(self, vuln_type: str, target_info: Dict,
                            provider: BaseProvider, model: str) -> List[DetectionTemplate]:
        """Internal method to generate templates"""
        
        prompt = f"""Generate detection templates for {vuln_type.upper()} vulnerability testing.

Target information:
{json.dumps(target_info, indent=2)}

Generate {self.max_templates} distinct detection templates.

Known types/categories:
- sqli: sql_injection (error_based, boolean_based, time_based)
- idor: broken_object_level_authorization (path_based, query_based)
- rce: remote_code_execution (path_injection, command_injection)
- xss: cross_site_scripting (reflected, dom, stored)
- path_traversal: local_file_inclusion (unix, windows, double_evade)
- ssrf: server_side_request_forgery (internal_ip, cloud_metadata)
- open_redirect: open_redirect (param_pollution, protocol_relative)
- ssti: server_side_template_injection (jinja, twig, velocity, mako)
- csrf: cross_site_request_forgery (state_changes, logout)
- headers: security_headers (missing, weak)
- auth_bypass: authentication_bypass (jwt_none, basic_auth)
- mass_assignment: mass_assignment (overposting)

Return exactly {self.max_templates} templates in JSON format.
Never include payloads that could be destructive or access real data.
Use only benign detection payloads (echo canary, math expressions, null bytes).

Format:
{{
  "templates": [
    {{
      "vulnerability_type": "type",
      "payload": "payload_string",
      "confidence": 0.95,
      "category": "error_based|boolean|reflection|path",
      "endpoint_pattern": "pattern_or_regex",
      "http_method": "GET|POST",
      "params": ["param1"],
      "headers": {{"Header": "Value"}},
      "description": "what this detects",
      "references": ["CWE-89", "OWASP"]
    }}
  ]
}}
"""
        
        system = """You are HT Forge AI Detector, an expert penetration testing tool generator.

Create detection templates for web security testing. You are read-only and will NOT:
- Execute actual attacks
- Perform data extraction
- Use destructive payloads
- Contact external systems

Only provide detection/probing templates for authorized security assessments.

Format requirements: JSON with specific structure. Do not include explanations or markdown."""
        
        try:
            response = provider.generate(prompt, model, system)
            
            # Parse JSON response
            content = response.strip()
            if content.startswith("```"):
                content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
            
            data = json.loads(content)
            templates = []
            
            for t in data.get("templates", []):
                templates.append(DetectionTemplate(
                    vulnerability_type=t.get("vulnerability_type", vuln_type),
                    payload=t.get("payload", ""),
                    confidence=float(t.get("confidence", 0.5)),
                    category=t.get("category", "detection"),
                    endpoint_pattern=t.get("endpoint_pattern", ".*"),
                    http_method=t.get("http_method", "GET"),
                    params=t.get("params", []),
                    headers=t.get("headers", {}),
                    data=t.get("data", {}),
                    description=t.get("description", ""),
                    references=t.get("references", [])
                ))
            
            return templates
            
        except json.JSONDecodeError as e:
            raise AIError(f"Failed to parse AI response: {e}")
        except Exception as e:
            raise AIError(f"Template generation failed: {e}")
    
    def generate_all_templates(self, target_info: Optional[Dict] = None,
                               types: List[str] = None) -> Dict[str, List[DetectionTemplate]]:
        """Generate detection templates for all or specified vulnerability types"""
        
        if types is None:
            types = self.VULNERABILITY_TYPES
        
        results = {}
        for vtype in types:
            try:
                results[vtype] = self.generate_detection_templates(vtype, target_info)
            except Exception as e:
                results[vtype] = []
        
        return results
    
    def generate_sqli_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate SQLi detection templates specifically"""
        return self.generate_detection_templates("sqli", target_info)
    
    def generate_idor_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate IDOR detection templates specifically"""
        return self.generate_detection_templates("idor", target_info)
    
    def generate_rce_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate RCE detection templates specifically"""
        return self.generate_detection_templates("rce", target_info)
    
    def generate_xss_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate XSS detection templates specifically"""
        return self.generate_detection_templates("xss", target_info)
    
    def generate_path_traversal_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate Path Traversal detection templates"""
        return self.generate_detection_templates("path_traversal", target_info)
    
    def generate_ssrf_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate SSRF detection templates"""
        return self.generate_detection_templates("ssrf", target_info)
    
    def generate_open_redirect_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate Open Redirect detection templates"""
        return self.generate_detection_templates("open_redirect", target_info)
    
    def generate_ssti_templates(self, target_info: Dict) -> List[DetectionTemplate]:
        """Generate SSTI detection templates"""
        return self.generate_detection_templates("ssti", target_info)


# ============== Convenience Functions ==============

def generate_sqli_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate SQLi detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("sqli", target_info)


def generate_idor_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate IDOR detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("idor", target_info)


def generate_rce_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate RCE detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("rce", target_info)


def generate_xss_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate XSS detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("xss", target_info)


def generate_path_traversal_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate Path Traversal detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("path_traversal", target_info)


def generate_ssrf_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate SSRF detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("ssrf", target_info)


def generate_open_redirect_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate Open Redirect detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("open_redirect", target_info)


def generate_ssti_templates(target_info: Dict, model: str = None) -> List[DetectionTemplate]:
    """Generate SSTI detection templates"""
    analyzer = AIAnalyzer()
    if model:
        analyzer.set_model(model)
    return analyzer.generate_detection_templates("ssti", target_info)


__all__ = [
    "AIAnalyzer", "AIConfig", "DetectionTemplate", "AIError",
    "OllamaProvider", "VLLMProvider", "HermesIAProvider", 
    "ClaudeProvider", "OpenAIProvider", "OpencodeProvider",
    "generate_sqli_templates", "generate_idor_templates",
    "generate_rce_templates", "generate_xss_templates",
    "generate_path_traversal_templates", "generate_ssrf_templates",
    "generate_open_redirect_templates", "generate_ssti_templates",
    "ProviderManager"
]

__version__ = "2.1.0"
__author__ = "HT Team"