#!/usr/bin/env python3
"""
Test script for HT Forge AI Detector v2.1
Run this to verify the module is working correctly
"""

import sys
import json
from pathlib import Path

# Add the ai_core to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ai_core import (
    AIAnalyzer, AIError, DetectionTemplate,
    OllamaManager, get_ollama_manager, ManagedScan,
    generate_sqli_templates, generate_idor_templates,
    generate_xss_templates, generate_path_traversal_templates,
    generate_ssrf_templates, generate_rce_templates,
    generate_open_redirect_templates, generate_ssti_templates
)


def test_basic_import():
    """Test basic imports work"""
    print("[✓] All imports successful")
    return True


def test_analyzer_creation():
    """Test AIAnalyzer can be created"""
    try:
        analyzer = AIAnalyzer()
        print(f"[✓] AIAnalyzer created successfully")
        print(f"    Current provider: {analyzer.current_provider}")
        print(f"    Current model: {analyzer.current_model}")
        return True
    except Exception as e:
        print(f"[✗] Failed to create AIAnalyzer: {e}")
        return False


def test_list_providers():
    """Test listing available providers"""
    try:
        analyzer = AIAnalyzer()
        providers = analyzer.list_available_providers()
        print(f"[✓] Available providers: {providers}")
        return True
    except Exception as e:
        print(f"[✗] Failed to list providers: {e}")
        return False


def test_model_selection():
    """Test model selection works"""
    try:
        analyzer = AIAnalyzer()
        models_by_provider = analyzer.list_available_models()
        print(f"[✓] Models by provider: {json.dumps(models_by_provider, indent=2)}")
        
        # Test setting a model
        if models_by_provider.get("ollama"):
            first_model = models_by_provider["ollama"][0]
            analyzer.set_model(first_model)
            print(f"[✓] Successfully set model: {first_model}")
        
        return True
    except Exception as e:
        print(f"[✗] Failed to list/select models: {e}")
        return False


def test_template_structure():
    """Test DetectionTemplate structure"""
    try:
        template = DetectionTemplate(
            vulnerability_type="sqli",
            payload="' OR 1=1--",
            confidence=0.95,
            category="boolean",
            endpoint_pattern="/api/users",
            http_method="GET",
            params=["id"],
            description="Boolean-based SQLi detection",
            references=["CWE-89", "OWASP"]
        )
        
        result = template.to_dict()
        assert result["vulnerability_type"] == "sqli"
        assert result["confidence"] == 0.95
        print(f"[✓] DetectionTemplate structure works correctly")
        return True
    except Exception as e:
        print(f"[✗] Failed template structure test: {e}")
        return False


def test_ollama_manager():
    """Test Ollama manager"""
    try:
        manager = OllamaManager()
        running = manager.is_ollama_available()
        print(f"[✓] OllamaManager initialized")
        print(f"    Ollama currently: {'running' if running else 'stopped'}")
        
        # Test scan lifecycle (without actually stopping/restarting)
        print("[✓] OllamaManager methods available: on_scan_start, on_scan_end, is_ollama_available")
        return True
    except Exception as e:
        print(f"[✗] Failed OllamaManager test: {e}")
        return False


def test_convenience_functions():
    """Test convenience functions exist and are importable"""
    try:
        functions = [
            "generate_sqli_templates",
            "generate_idor_templates", 
            "generate_xss_templates",
            "generate_path_traversal_templates",
            "generate_ssrf_templates",
            "generate_rce_templates",
            "generate_open_redirect_templates",
            "generate_ssti_templates"
        ]
        
        print("[✓] Convenience functions available:")
        for func_name in functions:
            print(f"    - {func_name}")
        return True
    except Exception as e:
        print(f"[✗] Failed convenience functions test: {e}")
        return False


def test_provider_classes():
    """Test provider classes are available"""
    try:
        providers = [
            "OllamaProvider",
            "VLLMProvider", 
            "HermesIAProvider",
            "ClaudeProvider",
            "OpenAIProvider",
            "OpencodeProvider"
        ]
        
        print("[✓] Provider classes available:")
        for p in providers:
            print(f"    - {p}")
        return True
    except Exception as e:
        print(f"[✗] Failed provider classes test: {e}")
        return False


def test_vulnerability_types():
    """Test all vulnerability types are supported"""
    try:
        analyzer = AIAnalyzer()
        types = analyzer.VULNERABILITY_TYPES
        
        print(f"[✓] Supported vulnerability types ({len(types)}):")
        for t in types:
            print(f"    - {t}")
        return True
    except Exception as e:
        print(f"[✗] Failed vulnerability types test: {e}")
        return False


def main():
    """Run all tests"""
    print("=" * 60)
    print("HT Forge AI Detector v2.1 - Test Suite")
    print("=" * 60)
    print()
    
    tests = [
        ("Basic Imports", test_basic_import),
        ("Analyzer Creation", test_analyzer_creation),
        ("List Providers", test_list_providers),
        ("Model Selection", test_model_selection),
        ("Template Structure", test_template_structure),
        ("Ollama Manager", test_ollama_manager),
        ("Convenience Functions", test_convenience_functions),
        ("Provider Classes", test_provider_classes),
        ("Vulnerability Types", test_vulnerability_types),
    ]
    
    results = []
    for name, test_func in tests:
        print(f"\nTesting: {name}")
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"[✗] Unexpected error: {e}")
            results.append((name, False))
    
    print("\n" + "=" * 60)
    print("Test Results Summary")
    print("=" * 60)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "[✓]" if result else "[✗]"
        print(f"{status} {name}")
    
    print()
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("\nAll tests passed! Module is working correctly.")
        print("\nAvailable functionality:")
        print("  - AI-powered detection template generation")
        print("  - Multi-provider support (Ollama, Hermes IA, Claude, OpenAI, vLLM, Opencode)")
        print("  - Ollama service lifecycle management")
        print("  - SQLi, IDOR, RCE, XSS, Path Traversal, SSRF, SSTI, Open Redirect detection")
        return 0
    else:
        print(f"\n{total - passed} test(s) failed. Check output above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())