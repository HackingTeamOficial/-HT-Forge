#!/usr/bin/env python3
"""HT Forge GUI server."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import sys
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.engine import get_engine
from core.profiles import PROFILES
from core.exporters import export_report, generate_infographic
from core.db import Database
from core.session_store import save as save_auth_session, get as get_auth_session, masked as masked_auth_session
from core.workbench import get_workbench
from core.license import install_license, license_status, LicenseError
from core import telegram as tg
from ai_core import AICore, AIConfig, AIError

def _default_runtime() -> Path:
    if os.name == "nt":
        base = Path(os.getenv("LOCALAPPDATA") or Path.home())
        return base / "HT Forge" / "runtime"
    return Path.home() / ".htforge"

RUNTIME = Path(os.getenv("HTFORGE_RUNTIME", str(_default_runtime())))
RUNTIME.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("HTFORGE_RUNTIME", str(RUNTIME))
os.environ.setdefault("HTFORGE_DB", str(RUNTIME / "htforge.db"))
CONFIG_FILE = RUNTIME / "config.json"
INDEX = ROOT / "ui" / "index.html"


def _reports_base() -> Path:
    try:
        from core.exporters import default_reports_dir
        p = Path(default_reports_dir())
    except Exception:
        p = ROOT / "reports"
    p.mkdir(parents=True, exist_ok=True)
    return p


REPORTS_DIR = _reports_base()
STATIC = ROOT / "ui" / "static"
AI_MODEL = os.getenv("HTFORGE_AI_MODEL", "").strip()
AI_BASE_URL = os.getenv("HTFORGE_OLLAMA_URL", "http://127.0.0.1:11434")

# Local-first AI: when no model is explicitly forced, AICore selects the
# smallest installed Ollama model automatically.
try:
    AI_CORE = AICore(base_url=AI_BASE_URL, model=(AI_MODEL or None), timeout=120,
                     max_templates_per_type=5, min_confidence=0.7)
except Exception:
    AI_CORE = None


def json_safe(v):
    if v is None or isinstance(v, (str, int, float, bool)): return v
    if isinstance(v, dict): return {str(k): json_safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple, set)): return [json_safe(x) for x in v]
    if hasattr(v, "isoformat"): return v.isoformat()
    return str(v)


def session_dict(s):
    if isinstance(s, dict): return json_safe(s)
    return json_safe({"id": s.id, "target": s.target, "profile": s.profile, "started_at": s.started_at, "status": s.status, "findings": s.findings, "modules_run": s.modules_run, "errors": s.errors, "metadata": s.metadata})


class GUIHandler(BaseHTTPRequestHandler):
    server_version = "HTForge/2.1.0"

    def log_message(self, fmt, *args):
        return

    def _send(self, status, data, content_type="application/json"):
        body = data if isinstance(data, bytes) else (json.dumps(json_safe(data), ensure_ascii=False).encode("utf-8") if content_type == "application/json" else str(data).encode("utf-8"))
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS"); self.send_header("Access-Control-Allow-Headers", "Content-Type"); self.end_headers(); self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0")); raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8")) if raw else {}


    def _active_edition(self):
        try:
            lic = license_status() or {}
            ed = str(lic.get("edition") or "").upper()
            if ed in ("DEMO", "PRO", "PREMIUM"):
                return ed
        except Exception:
            pass
        return os.getenv("HTFORGE_EDITION", "DEMO")

    # --- Estado de sincronización (sigiloso: jamás expone destino ni secreto) ---
    def _sync_state(self):
        try:
            rt = Path(os.getenv("HTFORGE_RUNTIME", str(ROOT / "runtime")))
            cache = {}
            for name in ("state_sync.json",):
                try:
                    obj = json.loads((rt / name).read_text())
                    if isinstance(obj, dict) and obj:
                        cache = obj
                        break
                except Exception:
                    continue
            last = {}
            lids = list(cache.keys())
            if lids:
                last = {"checked_at": cache[lids[0]].get("checked_at"),
                        "verdict": cache[lids[0]].get("verdict")}
        except Exception:
            last = {}
        try:
            from core.sync_link import find_blob
            linked = find_blob() is not None
        except Exception:
            linked = False
        return {"linked": linked, "last_check": last}

    def do_OPTIONS(self):
        self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization"); self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS"); self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"): return self._file(INDEX, "text/html; charset=utf-8")
        if p.startswith("/static/"): return self._file(STATIC / Path(p[len("/static/"):]).name)
        if p == "/api/status": return self._send(200, {"ok": True, "version": "2.1.0", "edition": self._active_edition(), "workbench": True, "license": license_status()})
        if p == "/api/workbench/history": return self._send(200, get_workbench().list_history())
        if p.startswith("/api/workbench/history/"): return self._history_item(p.rsplit("/",1)[-1])
        if p == "/api/workbench/extensions": return self._send(200, get_workbench().list_extensions())
        if p == "/api/workbench/workspace": return self._send(200, get_workbench().get_workspace())
        if p.startswith("/api/workbench/fuzz/"): return self._fuzz_status(p.rsplit("/",1)[-1])
        if p == "/api/sessions": return self._send(200, self._sessions())
        if p == "/api/telegram/config": return self._send(200, tg.status())
        if p == "/api/module-health":
            from core.module_health import summary as module_health_summary
            return self._send(200, module_health_summary())
        if p == "/api/ai/status": return self._ai_status()
        if p == "/api/ai/check": return self._ai_check()
        if p == "/api/ai/models": return self._ai_models()
        if p == "/api/sync/state": return self._send(200, self._sync_state())
        if p.startswith("/api/sessions/") and p.endswith("/infographic.svg"):
            sid=p.split("/")[3]
            return self._infographic(sid)
        if p.startswith("/api/sessions/") and "/reports/" in p:
            parts=p.strip("/").split("/")
            # /api/sessions/<sid>/reports/<fmt> -> parts[4] es el formato
            if len(parts) >= 5:
                return self._report_file(parts[2], parts[4])
            if len(parts) >= 4:
                return self._report_file(parts[2], parts[3])
        if p.startswith("/api/sessions/"):
            return self._session(p.rsplit("/",1)[-1])
        self._send(404, {"error":"Ruta no encontrada"})

    def do_DELETE(self):
        p = urlparse(self.path).path
        try:
            if p == "/api/sessions":
                count = self.server.session_db.delete_all_sessions()
                self.server.sessions.clear()
                self.server.engines.clear()
                return self._send(200, {"ok": True, "deleted": count})
            if p.startswith("/api/sessions/"):
                sid = p.rsplit("/", 1)[-1]
                if sid in self.server.engines:
                    self.server.engines[sid].stop()
                    self.server.engines.pop(sid, None)
                self.server.sessions.pop(sid, None)
                deleted = self.server.session_db.delete_session(sid)
                return self._send(200, {"ok": True, "deleted": bool(deleted)})
            return self._send(404, {"error": "Ruta no encontrada"})
        except Exception as e:
            return self._send(400, {"error": str(e)})

    def do_POST(self):
        p = urlparse(self.path).path; data = self._body()
        try:

            if p == "/api/license":
                if data.get("key"):
                    return self._send(200, install_license(data["key"]))
                return self._send(200, license_status())
            if p == "/api/telegram/config":
                return self._send(200, tg.save_config(data or {}))
            if p == "/api/telegram/test":
                try:
                    return self._send(200, tg.test_message())
                except Exception as e:
                    return self._send(400, {"ok": False, "error": str(e)})
            if p == "/api/scan": return self._start_scan(data)
            if p == "/api/scan/stop": return self._stop_scan(data)
            if p == "/api/export": return self._export(data)
            if p == "/api/workbench/repeater": return self._repeater(data)
            if p == "/api/workbench/retest": return self._repeater({**data, "source": "retest"})
            if p == "/api/workbench/intruder": return self._intruder(data)
            if p == "/api/workbench/diff": return self._send(200, get_workbench().diff(data.get("left") or {}, data.get("right") or {}))
            if p == "/api/workbench/workspace": return self._send(200, get_workbench().update_workspace(data))
            if p == "/api/workbench/workspace/target": return self._send(200, get_workbench().add_target(data.get("target", "")))
            if p == "/api/workbench/openapi": return self._send(200, get_workbench().import_openapi(data.get("document", "")))
            if p == "/api/workbench/websocket": return self._send(200, get_workbench().websocket_send(data.get("url", ""), data.get("message", ""), data.get("timeout", 10), data.get("verify_ssl", False)))
            if p == "/api/workbench/history/clear": get_workbench().clear_history(); return self._send(200,{"ok":True})
            if p == "/api/ai/analyze": return self._ai_analyze(data)
            if p == "/api/ai/model": return self._ai_model(data)
            if p == "/api/ai/session": return self._ai_session(data)
            if p == "/api/auth/session":
                save_auth_session(data.get("target",""),data.get("session_id",""),data.get("token",""),data.get("session_cookie_name","sessionid")); return self._send(200,{"ok":True,"session":masked_auth_session(data.get("target",""))})
            self._send(404,{"error":"Ruta no encontrada"})
        except Exception as e:
            self._send(400,{"error":str(e)})

    def _ai_status(self):
        if AI_CORE is None:
            return self._send(200, {"enabled": False, "error": "AI Core no pudo inicializarse", "read_only": True, "actions_enabled": False})
        return self._send(200, AI_CORE.status())

    def _ai_check(self):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible", "read_only": True})
        try:
            return self._send(200, {"ok": True, **AI_CORE.self_test()})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc), "read_only": True})

    def _ai_models(self):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        return self._send(200, {"ok": True, "models": AI_CORE.model_details(), "selected": AI_CORE.selected_model, "auto_smallest": AI_CORE.auto_smallest, "providers": AI_CORE.PROVIDER_INFO})

    def _ai_model(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        try:
            if data.get("auto_smallest"):
                return self._send(200, {"ok": True, **AI_CORE.auto_select_smallest()})
            model = str(data.get("model") or "")
            if not model:
                return self._send(400, {"ok": False, "error": "Modelo requerido"})
            return self._send(200, {"ok": True, **AI_CORE.set_model(model)})
        except AIError as exc:
            return self._send(400, {"ok": False, "error": str(exc)})

    def _ai_analyze(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        finding = data.get("finding") or {}
        if not isinstance(finding, dict) or not finding:
            return self._send(400, {"ok": False, "error": "finding requerido"})
        try:
            return self._send(200, {"ok": True, "analysis": AI_CORE.analyze_finding(finding)})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc)})

    def _ai_session(self, data):
        if AI_CORE is None:
            return self._send(503, {"ok": False, "error": "AI Core no disponible"})
        sid = str(data.get("session_id") or "")
        if not sid:
            return self._send(400, {"ok": False, "error": "session_id requerido"})
        try:
            session = self.server.sessions.get(sid)
            if session:
                obj = session_dict(session)
            else:
                row = self.server.session_db.get_session(sid)
                if not row:
                    return self._send(404, {"ok": False, "error": "Sesión no encontrada"})
                obj = dict(row)
                obj["findings"] = self.server.session_db.get_findings(sid)
                obj["metadata"] = json.loads(obj.get("metadata") or "{}")
            return self._send(200, {"ok": True, "summary": AI_CORE.summarize_session(obj)})
        except AIError as exc:
            return self._send(503, {"ok": False, "error": str(exc)})

    def _repeater(self,data):
        try:return self._send(200,get_workbench().send(data,"repeater"))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _intruder(self,data):
        try:return self._send(202,get_workbench().start_fuzz(data.get("request") or {},data.get("position","url"),data.get("payloads") or [],data.get("workers",4)))
        except Exception as e:return self._send(400,{"error":str(e)})

    def _history_item(self,eid):
        x=get_workbench().get_history(eid); return self._send(200,x) if x else self._send(404,{"error":"Intercambio no encontrado"})

    def _fuzz_status(self,jid):
        x=get_workbench().get_fuzz(jid); return self._send(200,x) if x else self._send(404,{"error":"Trabajo no encontrado"})

    def _file(self, path, content_type=None, download=False):
        try:
            body=path.read_bytes(); ct=content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            if download:
                self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body))); self.send_header("Content-Disposition", f"attachment; filename=\"{path.name}\""); self.send_header("Cache-Control", "no-store"); self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers(); self.wfile.write(body); return
            return self._send(200,body,ct)
        except FileNotFoundError: return self._send(404,{"error":"Archivo no encontrado"})

    def _sessions(self):
        out=[]
        for r in self.server.session_db.list_sessions(100):
            s=dict(r); s["findings"]=s.get("findings_count",0); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); out.append(s)
        for sid,s in self.server.sessions.items(): out.append(session_dict(s))
        seen={}; [seen.__setitem__(x["id"],x) for x in out]; return list(seen.values())

    def _session(self,sid):
        if sid in self.server.sessions: return self._send(200,session_dict(self.server.sessions[sid]))
        r=self.server.session_db.get_session(sid)
        if not r:return self._send(404,{"error":"Sesión no encontrada"})
        s=dict(r); s["findings"]=self.server.session_db.get_findings(sid); s["metadata"]=json.loads(s.get("metadata") or "{}"); s["modules_run"]=json.loads(s.get("modules_run") or "[]"); s["errors"]=json.loads(s.get("errors") or "[]"); return self._send(200,s)

    def _infographic(self, sid):
        s=self.server.sessions.get(sid)
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            # Stored sessions are reconstructed in the same shape used by _session.
            from core.models import ScanSession
            started=r.get("started_at") if isinstance(r,dict) else None
            try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
            except Exception: started=datetime.now()
            s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
        try:
            svg=generate_infographic(s, str(REPORTS_DIR))
            return self._file(Path(svg), "image/svg+xml; charset=utf-8")
        except Exception as exc:
            return self._send(500,{"error":str(exc)})

    def _start_scan(self,data):
        try: from core.license import require_license; require_license()
        except LicenseError as e: return self._send(403,{"error":str(e),"license_required":True,"license":license_status()})
        target=data.get("target","").strip(); profile=data.get("profile","full")
        if not target:return self._send(400,{"error":"Target requerido"})
        sid=str(uuid.uuid4())[:8]; config=data.get("config") or {}; config["session_id"]=sid; config.setdefault("reports_dir", str(REPORTS_DIR)); config["modules"]=data.get("modules") or []
        engine=get_engine(config=config); self.server.engines[sid]=engine
        try:
            from core import telegram as _tg
            engine.on_finding = lambda f, _t=target: _tg.notify_finding(f if isinstance(f, dict) else {}, _t)
        except Exception:
            pass
        def worker():
            s=engine.scan(target,profile,options=config); self.server.sessions[sid]=s
            try:
                from core import telegram as _tg2
                _tg2.notify_summary(s)
            except Exception:
                pass
        t=threading.Thread(target=worker,daemon=True); self.server.threads[sid]=t; t.start()
        # session object is created immediately by Engine; expose it once available
        for _ in range(50):
            if engine.session: self.server.sessions[sid]=engine.session; break
            time.sleep(.01)
        return self._send(202,{"session_id":sid})

    def _stop_scan(self,data):
        sid=data.get("session_id"); e=self.server.engines.get(sid)
        if not e:return self._send(404,{"error":"Escaneo no encontrado"})
        e.stop(); return self._send(200,{"ok":True})


    def _report_file(self, sid, fmt):
        if fmt not in {"svg", "html", "pdf", "json", "csv", "md", "xml", "txt"}:
            return self._send(400, {"error": "Formato no soportado"})
        s=self.server.sessions.get(sid)
        report_path=None
        if s and isinstance(s.metadata, dict):
            report_path=(s.metadata.get("reports") or {}).get(fmt)
        if not report_path or not Path(str(report_path)).is_file():
            r=self.server.session_db.get_session(sid)
            if r:
                try:
                    meta=json.loads(r.get("metadata") or "{}")
                    report_path=(meta.get("reports") or {}).get(fmt)
                except Exception:
                    report_path=None
        # El SVG se puede regenerar bajo demanda. Esto evita vistas vacías
        # si el escaneo terminó antes de persistir el mapa de reportes.
        if fmt == "svg" and (not report_path or not Path(str(report_path)).is_file()):
            try:
                if s is None:
                    r=self.server.session_db.get_session(sid)
                    if r:
                        from core.models import ScanSession
                        started=r.get("started_at")
                        try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
                        except Exception: started=datetime.now()
                        s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
                if s is not None:
                    report_path=generate_infographic(s, str(REPORTS_DIR))
                    if isinstance(s.metadata, dict):
                        s.metadata.setdefault("reports", {})["svg"]=report_path
                        try: self.server.session_db.update_session(s)
                        except Exception: pass
            except Exception as exc:
                return self._send(500, {"error": f"No se pudo generar el SVG: {exc}"})
        if not report_path or not Path(str(report_path)).is_file():
            return self._send(404, {"error": f"Reporte {fmt.upper()} no generado todavía"})
        path=Path(str(report_path)).resolve()
        try:
            path.relative_to(REPORTS_DIR.resolve())
        except ValueError:
            return self._send(403, {"error": "Ruta de reporte no permitida"})
        cts={"svg":"image/svg+xml; charset=utf-8","html":"text/html; charset=utf-8","pdf":"application/pdf","json":"application/json; charset=utf-8","csv":"text/csv; charset=utf-8","md":"text/markdown; charset=utf-8","xml":"application/xml; charset=utf-8","txt":"text/plain; charset=utf-8"}
        return self._file(path, cts[fmt], download=(fmt != "svg"))

    def _export(self,data):
        sid=data.get("session_id"); fmt=data.get("format","json"); e=self.server.engines.get(sid); s=e.session if e and e.session else self.server.sessions.get(sid)
        if not s:
            r=self.server.session_db.get_session(sid)
            if not r:return self._send(404,{"error":"Sesión no encontrada"})
            # Regenerar el reporte desde la sesión persistida (no exige sesión en memoria).
            try:
                from core.models import ScanSession
                started=r.get("started_at")
                try: started=datetime.fromisoformat(str(started).replace("Z","+00:00"))
                except Exception: started=datetime.now(timezone.utc)
                s=ScanSession(id=sid,target=r.get("target",""),profile=r.get("profile","full"),started_at=started,status=r.get("status","completed"),findings=self.server.session_db.get_findings(sid),modules_run=json.loads(r.get("modules_run") or "[]"),errors=json.loads(r.get("errors") or "[]"),metadata=json.loads(r.get("metadata") or "{}"))
            except Exception as exc:
                return self._send(500,{"error":f"No se pudo reconstruir la sesión: {exc}"})
        try:
            out=export_report(s,fmt,str(REPORTS_DIR))
        except Exception as exc:
            return self._send(500,{"error":f"No se pudo generar el reporte {fmt}: {exc}"})
        # Descarga real: devolver URL + forzar persistencia en metadata.
        try:
            if isinstance(getattr(s,"metadata",None),dict):
                s.metadata.setdefault("reports",{})[fmt]=out
        except Exception:
            pass
        return self._send(200,{"output":out,"download":f"/api/sessions/{sid}/reports/{fmt}"})

def run_server(host="127.0.0.1",port=9090,open_browser=True):
    
    try:
        server=ThreadingHTTPServer((host,port),GUIHandler)
    except OSError as exc:
        if getattr(exc,"errno",None)==98:
            raise RuntimeError(f"El puerto {port} ya está en uso. Cierra la instancia anterior de HT Forge o usa --port <puerto>." ) from exc
        raise
    
    def _db_path():
        import os as _os, pathlib as _pl
        primary = _os.getenv("HTFORGE_DB", str(ROOT/"runtime"/"htforge.db"))
        try:
            _pl.Path(primary).parent.mkdir(parents=True, exist_ok=True)
            probe = _pl.Path(primary).parent / ".write_test"
            probe.write_text("ok")
            probe.unlink(missing_ok=True)
            return primary
        except Exception:
            fb_base = _os.getenv("LOCALAPPDATA") or _os.getenv("APPDATA") or str(_pl.Path.home())
            fb = _pl.Path(fb_base) / "HT Forge" / "runtime" / "htforge.db"
            fb.parent.mkdir(parents=True, exist_ok=True)
            return str(fb)
    import pathlib as _pl
    server.sessions={}; server.engines={}; server.threads={}; server._lock=threading.RLock(); server.session_db=Database(_db_path())
    url=f"http://{host}:{port}"; print(f"🌐 HT Forge GUI corriendo en {url}")
    if open_browser: threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: server.shutdown()


if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--host",default="127.0.0.1"); ap.add_argument("--port",type=int,default=9090); ap.add_argument("--no-browser",action="store_true"); a=ap.parse_args(); run_server(a.host,a.port,not a.no_browser)
