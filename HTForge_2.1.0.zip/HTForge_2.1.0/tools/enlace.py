#!/usr/bin/env python3
"""Genera el enlace cifrado de esta copia (uso del proveedor).

Crea config/sync_link.dat con el destino ya cifrado: la app sale
conectada de fábrica, sin mostrar nada en pantalla ni en disco.

Uso:
  python3 tools/enlace.py --url http(s)://TU-DESTINO:PUERTO [--secret ...] [--interval 6]
  python3 tools/enlace.py --quitar        # vuelve a modo offline
  python3 tools/enlace.py --ver           # comprueba el enlace actual

Después re-firma el manifest y reconstruye el instalador para repartir.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from core.sync_link import create_blob, load_blob  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="Genera el enlace cifrado de esta copia")
    ap.add_argument("--url", default="", help="Ej. https://tu-host:8080")
    ap.add_argument("--secret", default="", help="Secreto (si se usa)")
    ap.add_argument("--interval", type=float, default=6.0, help="Horas entre avisos")
    ap.add_argument("--quitar", action="store_true", help="Elimina el enlace")
    ap.add_argument("--ver", action="store_true", help="Verifica el enlace actual")
    a = ap.parse_args()
    dest = ROOT / "config" / "sync_link.dat"
    if a.quitar:
        try:
            dest.unlink()
        except FileNotFoundError:
            pass
        print("Enlace eliminado: la app funcionará offline.")
        return 0
    if a.ver:
        if not dest.is_file():
            print("Sin enlace (offline).")
            return 0
        try:
            d = load_blob(dest.read_text())
            print(f"Enlace OK: descifra bien, intervalo {d['interval']} h.")
            print("(El destino no se muestra: está cifrado.)")
            return 0
        except Exception as e:
            print(f"Enlace ROTO: {e}")
            return 1
    if not a.url or not (a.url.startswith("http://") or a.url.startswith("https://")):
        print("Indica --url http(s)://TU-DESTINO:PUERTO")
        return 2
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(create_blob(a.url, a.secret, a.interval))
    try:
        import os
        os.chmod(dest, 0o600)
    except Exception:
        pass
    check = load_blob(dest.read_text())
    print(f"Enlace cifrado guardado en config/sync_link.dat "
          f"(intervalo {check['interval']} h, "
          f"{'con secreto' if a.secret else 'sin secreto'}).")
    print("Re-firma el manifest y reconstruye el instalador antes de repartir.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
