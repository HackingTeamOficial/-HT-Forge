#!/usr/bin/env python3
"""core/profiles.py - Perfiles de escaneo de HT Forge"""

# Plugins disponibles (deben coincidir con plugins/PLUGIN_NAME)
ALL_ATTACK = [
    "sqli", "idor", "xss", "lfi", "traversal", "rce",
    "ssrf", "xxe", "open_redirect", "crlf", "command_injection",
    "api", "graphql", "wordpress", "joomla", "drupal", "plugins"
]

# HT Forge 1.7 EXTENDED: módulos nuevos añadidos sin alterar los módulos existentes.
EXTENDED_1_7 = ['os_command_injection', 'ldap_injection', 'xpath_injection', 'nosql_injection', 'ssti', 'rfi', 'http_smuggling', 'ssi', 'broken_access_control', 'privilege_escalation', 'auth_bypass', 'weak_password_policy', 'credential_stuffing', 'session_fixation', 'session_hijacking', 'jwt_weaknesses', 'oauth_oidc', 'missing_mfa', 'password_reset', 'session_cookies', 'api_auth', 'rate_limit', 'mass_assignment', 'api_data_exposure', 'api_bfla', 'api_versioning', 'graphql_auth', 'graphql_introspection', 'file_upload', 'backup_exposure', 'config_exposure', 'git_exposure', 'env_exposure', 'source_disclosure', 'cloud_aws_s3', 'cloud_azure_blob', 'cloud_gcp_storage', 'cloud_credentials', 'cloud_metadata', 'cloud_iam', 'cloud_public', 'containers', 'kubernetes', 'security_headers', 'cors', 'tls_weaknesses', 'certificates', 'exposed_services', 'default_credentials', 'debug_mode', 'version_disclosure', 'directory_listing', 'api_keys', 'token_exposure', 'password_exposure', 'secret_exposure', 'internal_ips', 'stack_traces', 'db_disclosure', 'js_secrets', 'race_conditions', 'business_logic', 'price_manipulation', 'workflow_bypass', 'coupon_abuse', 'account_takeover_logic', 'operation_reuse', 'quantity_limits', 'dns_misconfig', 'subdomain_takeover', 'management_interfaces', 'smb_nfs_ftp', 'ssh_config', 'cve_known', 'dependencies', 'js_libraries', 'frameworks_eol', 'cms_vulnerable', 'wordpress_plugins', 'components_eol', 'websocket_smuggling', 'websocket_hijack', 'cache_key_injection', 'http_smuggling_h2c', 'jwt_key_confusion', 'jwt_alg_none',
    'portscan', 'subdomains', 'waf_detect', 'dns_audit', 'fuzz_dirs', 'param_fuzz', 'http_methods', 'fp_verify']
ALL_ATTACK = list(dict.fromkeys(ALL_ATTACK + EXTENDED_1_7))

# Forge 1.5 usa únicamente módulos nativos del proyecto.
RECON = ["tech", "crawler", "archivos", "jsecret", "recon_cbh", "payload_inventory",
    "portscan", "subdomains", "waf_detect", "dns_audit",
    "csrf_tokens", "tabnabbing", "timestamp_disclosure", "sri_check", "session_id_url"]

PROFILES = {
    "recon": {
        "desc": "Solo reconocimiento (sin ataque)",
        "mode": "active",
        "recon": RECON,
        "attack": [],
        "discovery_deep": False,
    },
    "passive": {
        "desc": "Sin enviar payloads (solo observar respuestas)",
        "mode": "passive",
        "recon": ["headers", "tech", "crawler", "archivos",
                  "csrf_tokens", "tabnabbing", "timestamp_disclosure", "sri_check", "session_id_url"],
        "attack": [],
        "discovery_deep": False,
    },
    "full": {
        "desc": "Todos los módulos (recon + ataque)",
        "mode": "active",
        "recon": RECON,
        "attack": ALL_ATTACK,
        "discovery_deep": True,
        "metasploit": True,
    },
    "bugbounty": {
        "desc": "Foco bug bounty: superficie amplia con motores nativos",
        "mode": "active",
        "recon": RECON,
        "attack": ALL_ATTACK,
        "discovery_deep": True,
    },
    "api": {
        "desc": "Solo superficie de APIs",
        "mode": "active",
        "recon": ["tech", "crawler", "jsecret"],
        "attack": ["cors", "jwt", "graphql", "csrf", "idor", "api", "xxe", "crlf"],
        "discovery_deep": False,
    },
    "cms": {
        "desc": "Foco CMS (WordPress/Joomla/Drupal)",
        "mode": "active",
        "recon": RECON,
        "attack": [
            "lfi", "traversal", "sqli", "xss", "idor", "csrf", "rce", "ssrf", "xxe", "open_redirect", "crlf", "command_injection", "api", "graphql", "wordpress", "joomla", "drupal", "plugins",
            "cors", "jwt", "graphql", "wordpress_enum", "sqli_confirm",
            "osint_urls", "ai_analysis", "wpscan", "cmsmap",
            "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
    },
    "wordpress": {
        "desc": "Orientado a WordPress",
        "mode": "active",
        "recon": ["tech", "crawler", "archivos"],
        "attack": [
            "idor", "xss", "sqli", "lfi", "traversal", "csrf", "rce", "ssrf", "xxe", "open_redirect", "crlf", "command_injection", "api", "graphql", "wordpress", "joomla", "drupal", "plugins",
            "wordpress_enum", "wpscan", "cmsmap", "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
    },
    "cms_pentest": {
        "desc": "Pentest CMS: WPScan + CMSmap + Wapiti/Nikto/Ferox + Metasploit",
        "mode": "active",
        "recon": ["tech", "crawler", "archivos", "jsecret"],
        "attack": [
            "sqli", "idor", "xss", "lfi", "traversal", "csrf",
            "wordpress_enum", "wpscan", "cmsmap", "wapiti", "nikto", "feroxbuster"
        ],
        "discovery_deep": True,
        "metasploit": True,
    },
}


def get_profile(name: str) -> dict:
    """Devuelve el dict del perfil o 'full' por defecto."""
    return PROFILES.get(name, PROFILES["full"])


def list_profiles() -> dict:
    return {k: v["desc"] for k, v in PROFILES.items()}


def resolve_modules(name: str, available_plugins: list) -> tuple:
    """Devuelve (recon_order, attack_order, mode) para el perfil, filtrando
    los plugins que realmente existen."""
    p = get_profile(name)
    
    # Filtrar únicamente módulos nativos disponibles
    attack = [m for m in p["attack"] if m in available_plugins]
    
    # Deduplicar manteniendo orden
    seen = set()
    attack_u = []
    for m in attack:
        if m not in seen:
            seen.add(m)
            attack_u.append(m)
    
    recon = list(p["recon"])
    # recon tampoco debe incluir modulos eliminados
    recon = [r for r in recon if r in available_plugins or r in ("tech", "headers")]
    
    return recon, attack_u, p.get("mode", "active")