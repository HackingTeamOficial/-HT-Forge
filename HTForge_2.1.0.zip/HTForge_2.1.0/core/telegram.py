"""core/telegram.py - Avisos de hallazgos y resúmenes por Telegram (Bot API, solo stdlib).

Config (orden de prioridad): variables de entorno HTFORGE_TG_TOKEN / HTFORGE_TG_CHAT,
después config/telegram.json en el runtime. Todo el envío es fire-and-forget en
hilos daemon y nunca eleva excepciones al escaneo.
"""
from __future__ import annotations
import json
import os
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

API_BASE = "https://api.telegram.org"
TIMEOUT = 12


def _runtime_dir() -> Path:
    env = os.getenv("HTFORGE_RUNTIME")
    if env:
        return Path(env)
    for var in ("LOCALAPPDATA", "APPDATA"):
        val = os.getenv(var)
        if val:
            return Path(val) / "HT Forge" / "runtime"
    return Path.home() / ".htforge"


def config_path() -> Path:
    return _runtime_dir() / "config" / "telegram.json"


def get_config() -> Dict[str, Any]:
    """Config efectiva. Nunca incluye el token completo en claro fuera de este módulo."""
    cfg: Dict[str, Any] = {
        "enabled": False,
        "token": "",
        "chat_id": "",
        "notify_findings": True,
        "notify_summary": True,
        "min_severity": "medium",
    }
    try:
        fp = config_path()
        if fp.is_file():
            cfg.update(json.loads(fp.read_text()) or {})
    except Exception:
        pass
    if os.getenv("HTFORGE_TG_TOKEN"):
        cfg["token"] = os.getenv("HTFORGE_TG_TOKEN", "")
    if os.getenv("HTFORGE_TG_CHAT"):
        cfg["chat_id"] = os.getenv("HTFORGE_TG_CHAT", "")
    return cfg


def save_config(data: Dict[str, Any]) -> Dict[str, Any]:
    cfg = get_config()
    for k in ("enabled", "token", "chat_id", "notify_findings", "notify_summary", "min_severity"):
        if k in data:
            cfg[k] = data[k]
    cfg["enabled"] = bool(cfg.get("enabled"))
    cfg["notify_findings"] = bool(cfg.get("notify_findings", True))
    cfg["notify_summary"] = bool(cfg.get("notify_summary", True))
    sev = str(cfg.get("min_severity", "medium")).lower()
    cfg["min_severity"] = sev if sev in ("critical", "high", "medium", "low", "info") else "medium"
    fp = config_path()
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(json.dumps({k: cfg[k] for k in (
        "enabled", "token", "chat_id", "notify_findings", "notify_summary", "min_severity")}))
    try:
        os.chmod(fp, 0o600)
    except Exception:
        pass
    return status()


def status() -> Dict[str, Any]:
    cfg = get_config()
    tok = str(cfg.get("token") or "")
    return {
        "enabled": bool(cfg.get("enabled")) and bool(tok) and bool(str(cfg.get("chat_id") or "")),
        "configured": bool(tok) and bool(str(cfg.get("chat_id") or "")),
        "token_set": bool(tok),
        "token_hint": ("…" + tok[-4:]) if len(tok) > 4 else "",
        "chat_id": str(cfg.get("chat_id") or ""),
        "notify_findings": bool(cfg.get("notify_findings", True)),
        "notify_summary": bool(cfg.get("notify_summary", True)),
        "min_severity": str(cfg.get("min_severity", "medium")),
    }


_SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
_SEV_EMOJI = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"}


def _passes_severity(severity: str, minimum: str) -> bool:
    return _SEV_ORDER.get(str(severity or "info").lower(), 0) >= _SEV_ORDER.get(str(minimum or "medium").lower(), 2)


def _send(token: str, chat_id: str, text: str) -> Dict[str, Any]:
    url = f"{API_BASE}/bot{token}/sendMessage"
    body = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": text, "disable_web_page_preview": "true"}).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode() or "{}")


def _async_send(text: str) -> None:
    def _run():
        try:
            cfg = get_config()
            if not cfg.get("enabled") or not cfg.get("token") or not cfg.get("chat_id"):
                return
            _send(str(cfg["token"]), str(cfg["chat_id"]), text[:3900])
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


def format_finding(f: Dict[str, Any], target: str = "") -> str:
    sev = str(f.get("severity") or "info").lower()
    lines = [
        f"{_SEV_EMOJI.get(sev, '⚪')} [{sev.upper()}] {f.get('title') or f.get('type') or 'Hallazgo'}",
        f"🎯 {target or f.get('url') or '—'}",
    ]
    if f.get("url") and target and str(f.get("url")) != str(target):
        lines.append(f"🔗 {f.get('url')}")
    if f.get("param"):
        lines.append(f"📌 Parámetro: {f.get('param')}")
    if f.get("module"):
        lines.append(f"🧩 Módulo: {f.get('module')}")
    detail = str(f.get("detail") or f.get("description") or "")
    if detail:
        lines.append(f"📝 {detail[:400]}")
    if f.get("evidence"):
        lines.append(f"🔎 Evidencia: {str(f.get('evidence'))[:300]}")
    return "\n".join(lines)


def notify_finding(finding: Dict[str, Any], target: str = "") -> None:
    try:
        cfg = get_config()
        if not cfg.get("enabled") or not cfg.get("notify_findings"):
            return
        if not _passes_severity(str(finding.get("severity") or "info"), str(cfg.get("min_severity", "medium"))):
            return
        _async_send("🛡 HT Forge — nuevo hallazgo\n\n" + format_finding(finding, target))
    except Exception:
        pass


def format_summary(session: Any) -> str:
    try:
        findings: List[Dict[str, Any]] = list(getattr(session, "findings", []) or [])
    except Exception:
        findings = []
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings:
        s = str((f.get("severity") if isinstance(f, dict) else "") or "info").lower()
        if s in counts:
            counts[s] += 1
    target = getattr(session, "target", "—")
    lines = [
        "🛡 HT Forge — escaneo finalizado",
        f"🎯 {target}",
        (f"📊 {len(findings)} hallazgos · "
         f"🔴{counts['critical']} 🟠{counts['high']} 🟡{counts['medium']} "
         f"🔵{counts['low']} ⚪{counts['info']}"),
    ]
    top = [f for f in findings if isinstance(f, dict)
           and str(f.get("severity") or "").lower() in ("critical", "high")][:5]
    for f in top:
        lines.append(f"• [{str(f.get('severity','')).upper()}] {f.get('title') or f.get('type') or '?'}")
    return "\n".join(lines)


def notify_summary(session: Any) -> None:
    try:
        cfg = get_config()
        if not cfg.get("enabled") or not cfg.get("notify_summary"):
            return
        _async_send(format_summary(session))
    except Exception:
        pass


def test_message() -> Dict[str, Any]:
    """Envía un mensaje de prueba de forma síncrona. Devuelve el resultado (lanza si falla)."""
    cfg = get_config()
    if not cfg.get("token") or not cfg.get("chat_id"):
        raise ValueError("Configura token y chat_id primero")
    started = time.monotonic()
    res = _send(str(cfg["token"]), str(cfg["chat_id"]),
                "🛡 HT Forge — conexión Telegram verificada ✅")
    return {"ok": bool(res.get("ok")), "took_s": round(time.monotonic() - started, 2), "response": res}
