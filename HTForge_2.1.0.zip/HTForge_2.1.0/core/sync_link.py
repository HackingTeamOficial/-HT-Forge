"""Enlace de sincronización cifrado (fábrica).

El destino viaja CIFRADO dentro de la app (config/sync_link.dat):
ningún texto plano en disco, ninguna opción visible en la interfaz,
ningún endpoint que lo revele.

Solo stdlib: XOR con keystream SHA-256 + HMAC-SHA256 de integridad.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path

# Clave simétrica de fábrica (ofuscada por fragmentos; el .dat solo lo
# puede generar quien tenga este fichero o la herramienta del proveedor).
_P1 = "7c2a91f4e83b45d6"
_P2 = "a05d3c8891e6b27f4"
_P3 = "5b8e02d3f6a94c1e7"
_DOMAIN = b"HTForge-sync-v1::"


def _key() -> bytes:
    return hashlib.sha256(_DOMAIN + (_P1 + _P2 + _P3).encode()).digest()


def _keystream(key: bytes, nonce: bytes, n: int) -> bytes:
    out = b""
    ctr = 0
    while len(out) < n:
        out += hashlib.sha256(key + nonce + ctr.to_bytes(4, "big")).digest()
        ctr += 1
    return out[:n]


def create_blob(url: str, secret: str = "", interval: float = 6.0) -> str:
    """Cifra {url, secret, interval} y devuelve el .dat en base64."""
    key = _key()
    raw = json.dumps({"u": url.strip().rstrip("/"), "s": secret or "",
                      "i": float(interval or 6.0)},
                     separators=(",", ":")).encode()
    nonce = os.urandom(16)
    ks = _keystream(key, nonce, len(raw))
    ct = bytes(a ^ b for a, b in zip(raw, ks))
    mac = hmac.new(key, nonce + ct, hashlib.sha256).digest()
    return base64.b64encode(nonce + ct + mac).decode()


def load_blob(blob: str) -> dict:
    """Descifra y verifica; lanza ValueError si está manipulado."""
    key = _key()
    try:
        data = base64.b64decode(blob.strip())
    except Exception as e:
        raise ValueError("enlace ilegible") from e
    if len(data) < 16 + 32 + 1:
        raise ValueError("enlace incompleto")
    nonce, ct, mac = data[:16], data[16:-32], data[-32:]
    if not hmac.compare_digest(hmac.new(key, nonce + ct,
                                        hashlib.sha256).digest(), mac):
        raise ValueError("enlace manipulado")
    ks = _keystream(key, nonce, len(ct))
    raw = bytes(a ^ b for a, b in zip(ct, ks))
    try:
        obj = json.loads(raw.decode())
    except Exception as e:
        raise ValueError("enlace corrupto") from e
    url = str(obj.get("u") or "").strip()
    if not url:
        raise ValueError("enlace vacío")
    return {"url": url, "secret": str(obj.get("s") or ""),
            "interval": float(obj.get("i") or 6.0)}


def find_blob() -> Path | None:
    """Busca config/sync_link.dat junto a la app (y override de tests)."""
    override = (os.getenv("HTFORGE_SYNC_LINK", "") or "").strip()
    if override:
        p = Path(override)
        if p.is_file():
            return p
    here = Path(__file__).resolve().parent.parent
    for cand in (here / "config" / "sync_link.dat",
                 Path.home() / ".htforge" / "sync_link.dat"):
        try:
            if cand.is_file() and cand.stat().st_size > 0:
                return cand
        except Exception:
            continue
    return None


def load_link() -> dict:
    p = find_blob()
    if not p:
        return {}
    try:
        return load_blob(p.read_text())
    except Exception:
        return {}


# --- Hilos de protocolo (ofuscados para que no aparezcan en claro) ---
def _d(s: str) -> str:
    return base64.b64decode(s).decode()


def endpoint() -> str:
    return _d("L2FwaS9oZWFydGJlYXQ=")


def hdr_secret() -> str:
    return _d("WC1QYW5lbC1TZWNyZXQ=")


def hdr_sig() -> str:
    return _d("WC1QYW5lbC1TaWc=")
