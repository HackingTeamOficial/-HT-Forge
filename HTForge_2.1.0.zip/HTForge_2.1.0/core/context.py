#!/usr/bin/env python3
"""core/context.py - Contexto de ejecución para módulos"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from .evidence import normalize_finding


class MockEngine:
    """Mock engine para testing"""
    def __init__(self):
        self.http = None
        self._stop_requested = False
    
    def emit(self, event: Dict):
        pass
    
    def stop(self):
        self._stop_requested = True


@dataclass
class Context:
    """Contexto que se pasa a cada módulo durante la ejecución"""
    target: str
    engine: Any = None  # Opcional para testing
    
    # Estado de la sesión
    session_id: str = ""
    profile: str = "full"
    phase: str = "recon"
    
    # Configuración
    config: Dict = field(default_factory=dict)
    
    # Almacenamiento temporal para módulos
    _storage: Dict = field(default_factory=dict)
    _report: Dict = field(default_factory=lambda: {'findings': []})
    
    # Control de ejecución
    _stop_requested: bool = False
    _skip_module: bool = False
    
    def __post_init__(self):
        if self.engine is None:
            self.engine = MockEngine()
    
    def emit(self, event: Dict):
        """Emite evento al motor"""
        self.engine.emit(event)
    
    def log(self, level: str, msg: str):
        """Log simple"""
        self.emit({'type': 'log', 'level': level, 'msg': msg})
    
    def finding(self, finding: Dict):
        """Reporta un hallazgo con estado y calidad de evidencia normalizados."""
        finding = normalize_finding(finding)
        finding.setdefault('timestamp', datetime.now().isoformat())
        finding.setdefault('target', self.target)
        self._report.setdefault('findings', []).append(finding)
        self.emit({'type': 'finding', **finding})
    
    def progress(self, current: int, total: int, msg: str = ""):
        """Progreso del módulo actual"""
        self.emit({'type': 'progress', 'current': current, 'total': total, 'msg': msg})
    
    def ctrl(self, action: str):
        """Control de ejecución: 'stop', 'skip'"""
        if action == 'stop':
            self._stop_requested = True
            self.engine.stop()
        elif action == 'skip':
            self._skip_module = True
    
    @property
    def stopped(self) -> bool:
        return self._stop_requested or getattr(self.engine, '_stop_requested', False)
    
    @property
    def skipped(self) -> bool:
        return self._skip_module
    
    def get(self, key: str, default=None):
        return self._storage.get(key, default)
    
    def set(self, key: str, value: Any):
        self._storage[key] = value
    
    def req(self, method: str, url: str, **kwargs):
        """HTTP request a través del cliente del motor"""
        if self.engine and self.engine.http:
            return self.engine.http.request(method, url, **kwargs)
        # Fallback para testing
        import requests
        return requests.request(method, url, **kwargs)
    
    def run_cmd(self, cmd: List[str], timeout: int = 60) -> str:
        """Ejecuta comando externo"""
        import subprocess
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            return result.stdout
        except subprocess.TimeoutExpired:
            return f"TIMEOUT after {timeout}s"
        except Exception as e:
            return f"ERROR: {e}"
    
    def get_report(self) -> Dict:
        """Obtiene reporte acumulado"""
        return self._report