"""Evidence and verification primitives shared by HT Forge modules.

The verifier is deliberately conservative: it never upgrades a finding merely
because a payload was reflected.  It records what was actually observed so the
Core and optional AI analyst can correlate evidence without inventing it.
"""
from typing import Any, Dict

VERDICTS = {"DISCOVERED", "CANDIDATE", "PROBED", "CORRELATED", "VERIFIED", "CONFIRMED", "INCONCLUSIVE", "REFUTED"}

def normalize_finding(finding: Dict[str, Any]) -> Dict[str, Any]:
    f = dict(finding or {})
    evidence = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    state = str(f.get("verification_state") or evidence.get("verification_state") or "CANDIDATE").upper()
    if state not in VERDICTS:
        state = "CANDIDATE"
    f["verification_state"] = state
    f.setdefault("requires_human_review", state not in {"VERIFIED", "CONFIRMED", "REFUTED"})
    f["evidence"] = evidence
    f["evidence_quality"] = evidence_quality(evidence)
    return f

def evidence_quality(evidence: Dict[str, Any]) -> str:
    if not evidence:
        return "none"
    keys = set(evidence)
    strong = {"baseline", "comparison", "retest", "authorization_matrix", "matched_signature", "response_pair"}
    if len(keys & strong) >= 2:
        return "strong"
    if keys & strong or len(keys) >= 2:
        return "moderate"
    return "weak"

def correlate(core_finding: Dict[str, Any], ai_result: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return a read-only correlation record; Core remains authoritative."""
    f = normalize_finding(core_finding)
    ai = ai_result or {}
    core_state = f["verification_state"]
    ai_state = str(ai.get("verdict", "INCONCLUSIVE")).upper()
    if ai_state not in {"CONFIRMED", "LIKELY", "INCONCLUSIVE", "REFUTED"}:
        ai_state = "INCONCLUSIVE"
    final = core_state
    if core_state in {"CONFIRMED", "REFUTED"}:
        final = core_state
    elif core_state == "VERIFIED" and ai_state == "REFUTED":
        final = "VERIFIED"  # AI cannot override Core verification.
    return {"core_verdict": core_state, "ai_verdict": ai_state, "final_verdict": final,
            "ai_confidence": max(0.0, min(1.0, float(ai.get("confidence", 0) or 0))),
            "authority": "HT Forge Core", "read_only": True}


def human_verification(finding: Dict[str, Any]) -> Dict[str, Any]:
    """Human Verification Mode: auditable card derived only from stored evidence."""
    f = normalize_finding(finding)
    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
    state = f["verification_state"]
    try:
        conf = float(f.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        conf = 0.0
    return {
        "state": state,
        "evidences": len([k for k in ev.keys() if k]),
        "reproducible": bool(ev.get("reproduced") or ev.get("retest") or f.get("verified") is True),
        "differential": bool(ev.get("comparison") or ev.get("baseline") or ev.get("response_pair")),
        "secondary_check": bool(ev.get("retest") or ev.get("confirmation") or f.get("verified") is True),
        "confidence": round(conf if conf <= 1.0 else conf / 100.0, 2),
        "engine": "HT Forge Core",
        "requires_human_review": bool(f.get("requires_human_review", state not in ("VERIFIED", "CONFIRMED", "REFUTED"))),
    }
