"""HT Forge Core - Motor principal y componentes base"""

from .models import ScanSession
from .engine import Engine, get_engine
from .context import Context
from .plugin import PluginManager, Plugin
from .profiles import get_profile, list_profiles, resolve_modules, PROFILES, ALL_ATTACK
from .http_client import HTTPClient
from .db import Database
from .scoring import RiskScorer
from .vulndb import VulnDB
from .exporters import export_report
from .control import EngineControl, ControlState, ControlConfig

__all__ = [
    'Engine',
    'ScanSession', 
    'get_engine',
    'Context',
    'PluginManager',
    'Plugin',
    'get_profile',
    'list_profiles',
    'resolve_modules',
    'PROFILES',
    'ALL_ATTACK',
    'HTTPClient',
    'Database',
    'RiskScorer',
    'VulnDB',
    'export_report',
    'EngineControl',
    'ControlState',
    'ControlConfig',
]

__version__ = '2.1.0'