"""Runtime module health inventory.
Classifies modules without pretending that import success means detection success.
"""
import importlib
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List

@dataclass
class ModuleHealth:
    name: str
    import_ok: bool
    runnable: bool
    status: str
    detail: str = ""

def audit(plugin_dir: str | None = None) -> List[ModuleHealth]:
    root = Path(plugin_dir or Path(__file__).resolve().parent.parent / "plugins")
    out=[]
    for path in sorted(root.glob("*.py")):
        if path.name.startswith("_") or path.name == "__init__.py": continue
        name=path.stem
        try:
            mod=importlib.import_module(f"plugins.{name}")
            run=getattr(mod,"run",None)
            if not callable(run):
                out.append(ModuleHealth(name,True,False,"DISCOVERY_ONLY","No callable run(ctx)."))
                continue
            # A function can be importable without being a real detector; inspect explicit marker.
            marker=str(getattr(mod,"CAPABILITY", "functional"))
            status="FUNCTIONAL" if marker != "discovery_only" else "DISCOVERY_ONLY"
            out.append(ModuleHealth(name,True,True,status, str(getattr(mod,"DESCRIPTION",""))))
        except Exception as exc:
            out.append(ModuleHealth(name,False,False,"BROKEN",str(exc)))
    return out

def summary() -> dict:
    rows=audit()
    return {"total":len(rows),"functional":sum(x.status=="FUNCTIONAL" for x in rows),
            "discovery_only":sum(x.status=="DISCOVERY_ONLY" for x in rows),
            "broken":sum(x.status=="BROKEN" for x in rows),
            "modules":[asdict(x) for x in rows]}
